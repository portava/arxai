---
name: Deriv synthetic feed — liveness signal & boot behavior
description: How to authoritatively confirm the Deriv synthetic WS is live, and why the DB mirror is not the signal.
---

The Deriv WebSocket **self-establishes on server boot** — `artifacts/api-server/src/index.ts`
has a non-blocking eager `getDerivWsClient().ensureConnection()` (gated on `DERIV_APP_ID`),
with lazy `ensureConnection()` as fallback. So after a restart it connects on its own,
**no kick needed** (observed: `connectedAt` ~6s after process start, eager warmup complete
~14s after start, `reconnectCount:0`). Warmup subscribes a core set only
(R_25, R_75, 1HZ25V, 1HZ75V, BOOM1000, CRASH1000); other indices subscribe on first request.

**Do NOT use the `market_candles source='deriv'` mirror as a liveness signal.** Direct reads
of `GET /api/market-data/deriv/candles` do NOT write that mirror (the mirror is written only on
the marketDataRouter path used by scanner/chart routes). A live, healthy feed can show ZERO
fresh `source='deriv'` rows. Trusting the mirror produced a false "feed may be down" alarm.

**Authoritative liveness = `GET /api/market-data/deriv/status`** (USER-gated, no admin needed).
Healthy looks like: `connected:true`, `feedReadinessState:"LIVE_FEED"`, `healthSummary:"healthy"`,
`hasRecentTick:true` with `lastTickAgeMs` in the tens-to-hundreds of ms, fresh `lastTickAt`/`lastCandleAt`.
`otpLastResult:"The token is invalid."` can appear even when healthy/live — it's a benign legacy
OTP-probe field, not a feed failure (the WS authorizes and streams regardless).
Per-index proof: `GET /api/market-data/deriv/candles?symbol=V10|V25|V50|V75|V100&granularity=M5`
returns `ok:true` + real OHLC. Admin-only equivalents: `GET /api/admin/deriv-status` (+ `/check`, `/probe`).

EURUSD/EA broker feed is independent: it's gated by forex market hours. On weekends the EA
re-POSTs Friday's already-present bars (`acceptedBars>0` but `broker_candles.received_at` does
NOT advance because the upsert is a no-op) — that's expected, not a stale feed.
