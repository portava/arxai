---
name: Text-scan import-boundary guard escape ladder
description: How to make a CI text-scan "module X must NEVER import forbidden module Y" guard actually robust, and what is provably out of scope.
---

# Text-scan import-boundary guard — the escape ladder

When a CI guard enforces "fenced execution/safety modules must NEVER acquire
forbidden module Y (e.g. a display-only contract)", a naive "no `import … from
"Y"`" regex is trivially bypassable. A determined caller can reach a bundled
global `require` through unbounded callee/argument syntaxes. Do NOT chase callee
shapes one by one — anchor on the only ALLOWED context and ban the two
capabilities.

**Robust invariant set (all four needed):**
1. **Ban the forbidden specifier LITERAL in every position except a genuine
   static `from` source.** Match a string literal whose WHOLE content is the
   forbidden specifier, then flag it unless it is the source of `import … from` /
   `export … from`. This single rule kills call-arg, array-element,
   object-literal-property (`{0:"Y"}` array-like for `apply`), variable-stash
   (`const S="Y"`), and side-effect `import "Y"` forms at once.
2. **A genuine static `from` source is ALWAYS quote-delimited (`'`/`"`), NEVER
   backtick.** `` from`Y` `` is a TAGGED-TEMPLATE call on an identifier merely
   named `from` (`const from=(s)=>import(s[0]); await from`Y``), not an import.
   So require BOTH quoted AND preceded-by-`from`; flag backtick literals
   unconditionally. (`from "Y"` quoted with no operator between is grammatically
   valid ONLY as import syntax — identifiers can't juxtapose a quoted string.)
3. **Ban the `require`/`createRequire` IDENTIFIER** (run on comment+string-
   stripped code) — catches `require(x)`, `globalThis.require`, `module.require`,
   `.require.cache`, even with a VARIABLE specifier.
4. **Ban bracket-string `["require"]` access** — the bundler-injected global
   require (and its `.cache`) hides the token inside a string that the identifier
   scan in (3) strips. (3)+(4) together cover every way to NAME `require`.

**Accepted OUT-OF-SCOPE for a text scan (do NOT try to detect — brittle false
positives):** pure runtime reflection that names NEITHER the specifier literal
NOR the require capability — `Reflect.get(globalThis, computedKey)`, walking a
require cache populated by other non-fenced code, member reached by computed
access — and split-string / char-code construction (`"@scope/" + "pkg"`). These
construct nothing statically resolvable and belong to the architectural
fenced-dir boundary + code review, not a regex.

**Why:** chasing callee/argument syntax is unbounded; recognising the one
allowed context (quoted `from` source) plus the two capabilities (specifier
literal anywhere else, `require` named as identifier or bracket-string) is
finite and complete within static text scope. Keep the named-import/whole-
namespace/dynamic-import detectors too — they vet WHAT is imported in genuine
`from` positions (the literal-position rule defers to them there).

**How to apply:** any "never import X" CI guard for a safety boundary. Keep a
big regression suite of escape cases wired into the guards lane; each architect
escape becomes a permanent flag-case. Anchor closure on an explicit scope
boundary and get the reviewer to confirm it, or the review loop never converges.

**Env note:** typecheck the `scripts` package with a heap cap
(`NODE_OPTIONS=--max-old-space-size=2560 pnpm --filter @workspace/scripts run
typecheck`); the full workspace `typecheck:ci` OOMs in this sandbox.
