---
name: Scalp flame endpoint-test determinism
description: How to write deterministic service-level scalp/market tests when this env has live forex providers.
---

# Deterministic candle windows in endpoint tests

When an in-process endpoint test needs a *controlled* candle window for a real
market symbol, push it through the **mt5_broker seam** (`updateCandlesFromMT5` /
`updateQuoteFromMT5` in `mt5Provider.ts`). That slot is FIRST in every
`marketDataRouter` chain, so a non-empty push wins outright and the real fetch
returns exactly your candles.

**Why:** this Replit env has live TwelveData/Polygon forex feeds, so the
composite `assistant_real` provider serves major pairs (EURUSD, GBPUSD, …) real
candles *non-deterministically*. A "no-push, expect blind/awaiting" assertion on
a major flakes because the provider fills it. A made-up symbol can't be used
either — `normalizeSymbol` rejects unknowns → route 400s.

**How to apply (scalp flame test):**
- Non-blind/live case: push ≥ `MIN_FLAME_CANDLES` (5) candles for the symbol →
  the only path that can legitimately be non-blind is Focus
  (`evaluateScalpForSymbol`), which fetches a per-symbol window. Broad
  (`rankScalpsForUniverse`) and Builder (`buildScalp`) go through
  `buildRankInputs` which sets `candles:null` → ALWAYS blind by design.
- Honest blind/awaiting case: push a **sub-threshold** window (< 5 candles) for a
  symbol OUTSIDE the Broad/Builder forex universe (e.g. AUDUSD; universe is
  EURUSD/GBPUSD/USDJPY) so it doesn't disturb the rank/build scans. The real
  fetch returns the short window → `flameRead` blind = `candles.length < 5`.
- A non-blind read need NOT be actionable: a clean long monotonic uptrend reads
  as `EXHAUSTED` / `NO_SCALP` (overextended). Assert `blind===false` and
  `flameAgeCandles >= 1` (proves the window was consumed), NOT a BUY/SELL
  direction.
- Actionable read: push a **flat base + short (2-candle) momentum burst** window
  for an OUT-OF-UNIVERSE forex pair (NZDUSD) → Focus drives the engine's
  fresh-ignition branch: `flameStage` IGNITING/ACTIVE, real `readDirection` BUY,
  `scalpScore > 0`. Out-of-universe keeps it off the rank/build scans.

## News veto makes major-pair (EURUSD) focus/rank cases time-of-day flaky

The Focus(live) EURUSD case and the Broad `rank` (forex) case are **not
deterministic** even with candles pushed via the mt5 seam, because the engine
applies a NEWS gate that the test does not control:
`evaluateScalp` rejects with `NEWS_DANGER` (→ blind flame) when
`scanner.newsRisk === "HIGH"`. That risk comes from a **mock economic calendar**
(`news/calendar/economicEvents.ts` `getMockEvents` + `newsRiskScorer.ts`
`scoreNewsRisk`), which flags HIGH only inside a narrow `m >= -15 && m <= 30`
minute window around fixed-hour events (USD events at hours 3,11,12,14,18,21 UTC).

**Why it bites the whole forex universe at once:** EURUSD/GBPUSD/USDJPY are ALL
in the `affectedMarkets` of the USD events, so during a USD-event window every
forex-universe major is vetoed simultaneously → Focus EURUSD reads blind AND
`rank` returns 0 opportunities (vetoed symbols are excluded). ~6 windows/day ≈
several hours/day of red. NZDUSD is in **no** event's `affectedMarkets` →
`scoreNewsRisk` returns `none` → never vetoed → fully deterministic.

**How to apply:** the actionable/blind cases must use out-of-universe,
out-of-calendar symbols (NZDUSD/AUDUSD) — never a major. The pre-existing
EURUSD focus(live) + rank assertions are inherently time-of-day flaky; verify
green by neutralizing news (env-gated `scoreNewsRisk` → `none`, reverted) rather
than re-running until a quiet minute. No-fabrication invariant with both live
Focus reads (overextended EURUSD + actionable NZDUSD) = exactly TWO non-blind
flames; rank/build flames all blind.

# Synthetic (Deriv) sibling

The synthetic asset class routes `[mt5_broker, deriv]` (forex is
`[mt5_broker, assistant_real]`). Deriv IS configured in this env, but the same
mt5_broker push trick stays deterministic because mt5_broker is FIRST in the
chain, so a non-empty push wins outright and Deriv is never consulted for the
pushed symbol — both the ≥5 live window and the sub-threshold awaiting window are
exact. Use ARX labels (`V75`, `V25`); `normalizeSymbol` strips non-alphanumerics
(so `R_75`→`R75` does NOT resolve, but `V75` and `VOLATILITY75INDEX` do).
ALL Deriv synthetics live in the one `synthetic` universe (no "outside the
universe" symbol exists like forex's AUDUSD), but that's fine: Broad/Builder set
`candles:null` so every rank/build flame is blind regardless, and the awaiting
symbol's push only feeds its own blind rank row. Same numeric uptrend generator
as the forex test reaches a non-blind Focus flame (scale is irrelevant to the
%-based analyzer and count-based blindness). The synthetic test pushes only ONE
live ≥5 window (V75 Focus), so its no-fabrication invariant is exactly ONE
non-blind flame (vs the forex test's TWO); rank/build all blind. Sibling file +
`test:scalp-flame-synthetic-endpoint`, also in the CI chain.
