// Economic-calendar provider seam (Task #197).
//
// HONESTY (inviolable): this is the single source of truth for the Market Impact
// Radar's *scheduled economic events*. It returns the real provider connection
// state AND the real event list together, so the radar can never drift into
// showing events while reporting "disconnected" (or vice-versa).
//
// No real economic-calendar provider (Trading Economics / FRED) is wired in this
// environment, so this returns `connected:false` with an EMPTY event list — we
// NEVER fabricate a scheduled macro event, a forecast, or an `actual` result.
// This mirrors the reserved `mt5_broker` market-data slot: the moment a real
// provider is integrated, populate `events` (mapped to `RawCalendarEvent`) and
// set `connected:true` here — the radar lights up with zero changes elsewhere,
// and the `buildRadarEvents` domain honesty gate keeps suppressing everything
// until `connected` is genuinely true.

import type { RawCalendarEvent } from "@workspace/domain/smart-chart";

export interface EconomicCalendarSnapshot {
  /** True ONLY when a real economic-calendar provider feed is connected. */
  connected: boolean;
  /** Provider identifier ("none" until a real feed is wired). */
  provider: string;
  /** Real scheduled events from the connected provider. Empty when disconnected. */
  events: RawCalendarEvent[];
}

/**
 * Read the scheduled economic calendar for a symbol from the connected provider.
 * Honest real-or-absent: no live provider is configured, so this reports
 * `connected:false` and an empty event list (never fabricated). `symbol` and
 * `nowMs` are accepted so a future real provider can scope/time its query
 * without changing any caller.
 */
export async function getEconomicCalendar(
  _symbol: string,
  _nowMs: number = Date.now(),
): Promise<EconomicCalendarSnapshot> {
  return { connected: false, provider: "none", events: [] };
}
