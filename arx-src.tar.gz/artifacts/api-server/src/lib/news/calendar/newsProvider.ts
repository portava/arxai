// (N) Pluggable news provider interface. The mock provider mirrors the
// existing in-memory generator (kept for /news/calendar back-compat) but
// produces records in the spec shape (CRITICAL impact level supported,
// stable externalId, eventTime as ISO). Replace this file's `pickProvider`
// with a real API client when one is configured.

import { getMockEvents } from "./economicEvents.js";

export interface ProviderEvent {
  externalId: string;
  eventName: string;
  country: string;
  currency: string;
  impactLevel: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  forecast: string | null;
  previous: string | null;
  actual: string | null;
  eventTime: Date;
  source: string;
  affectedSymbols: string[] | null;
}

export interface NewsProvider {
  name: string;
  fetchEvents(daysAhead: number): Promise<ProviderEvent[]>;
}

const IMPACT_UPPER: Record<string, "LOW" | "MEDIUM" | "HIGH" | "CRITICAL"> = {
  low: "LOW", medium: "MEDIUM", high: "HIGH", critical: "CRITICAL",
};

// Heuristic: certain titles are de-facto CRITICAL (rate decisions of major
// central banks). Mock data only flags them as HIGH; promote here so the
// downstream rules can exercise the CRITICAL path.
const CRITICAL_TITLES = [/FOMC Rate Decision/i, /ECB Rate Decision/i, /BoE Rate Decision/i, /BoJ Policy/i];

export const mockNewsProvider: NewsProvider = {
  name: "mock",
  async fetchEvents(daysAhead: number): Promise<ProviderEvent[]> {
    const raw = getMockEvents(daysAhead);
    return raw.map((e) => {
      const baseImpact = IMPACT_UPPER[e.impact] ?? "LOW";
      const promoted = CRITICAL_TITLES.some((rx) => rx.test(e.title));
      return {
        externalId: e.id,
        eventName: e.title,
        country: e.country,
        currency: e.currency,
        impactLevel: promoted ? "CRITICAL" : baseImpact,
        forecast: e.forecast,
        previous: e.previous,
        actual: e.actual,
        eventTime: new Date(e.eventTime),
        source: "mock",
        affectedSymbols: e.affectedMarkets ?? null,
      };
    });
  },
};

// Selector — env-driven. When NEWS_PROVIDER=real (and a real client is
// configured), swap here. For now we always return mock and never fail closed,
// because news-risk is advisory-by-default and the spec requires graceful
// degradation when a live API is unavailable.
export function pickNewsProvider(): NewsProvider {
  return mockNewsProvider;
}
