// ARX Native Chart — Level 1: timeframe contract.
//
// The chart endpoints accept ONLY the canonical ARX timeframe codes below.
// Anything else is rejected cleanly at the zod boundary (generated from the
// OpenAPI enum). This module is the single source of truth for the allowed
// list and each timeframe's bar interval in seconds, used by the candle
// sequence validator (gap / staleness detection).

export const CHART_TIMEFRAMES = [
  "M1", "M2", "M3", "M4", "M5", "M6", "M10", "M12", "M15", "M20", "M30",
  "H1", "H2", "H3", "H4", "H6", "H8", "H12", "D1", "W1", "MN1",
] as const;

export type ChartTimeframe = (typeof CHART_TIMEFRAMES)[number];

const TIMEFRAME_SECONDS: Record<ChartTimeframe, number> = {
  M1: 60,
  M2: 2 * 60,
  M3: 3 * 60,
  M4: 4 * 60,
  M5: 5 * 60,
  M6: 6 * 60,
  M10: 10 * 60,
  M12: 12 * 60,
  M15: 15 * 60,
  M20: 20 * 60,
  M30: 30 * 60,
  H1: 60 * 60,
  H2: 2 * 60 * 60,
  H3: 3 * 60 * 60,
  H4: 4 * 60 * 60,
  H6: 6 * 60 * 60,
  H8: 8 * 60 * 60,
  H12: 12 * 60 * 60,
  D1: 24 * 60 * 60,
  W1: 7 * 24 * 60 * 60,
  // Month length varies 28-31d; the UPPER bound is the SAFE direction for
  // gap/staleness detection (avoids false gaps + false-stale on a fresh
  // monthly bar). Mirrors brokerCandleStore TIMEFRAME_MS (MN1 = 31d).
  MN1: 31 * 24 * 60 * 60,
};

export function isChartTimeframe(tf: string): tf is ChartTimeframe {
  return (CHART_TIMEFRAMES as readonly string[]).includes(tf);
}

/** Bar interval in seconds for a canonical timeframe. */
export function timeframeSeconds(tf: ChartTimeframe): number {
  return TIMEFRAME_SECONDS[tf];
}

/** Bar interval in milliseconds for a canonical timeframe. */
export function timeframeMs(tf: ChartTimeframe): number {
  return TIMEFRAME_SECONDS[tf] * 1000;
}
