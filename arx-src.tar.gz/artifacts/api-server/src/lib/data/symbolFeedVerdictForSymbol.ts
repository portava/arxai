import type { SymbolFeedVerdict } from "@workspace/domain/safety-contracts/syntheticLiveFloor";
import { resolveSymbolFeedVerdict } from "./symbolFeedVerdict.js";
import { rawTrailingIntervalGap } from "./chart/candleNormalization.js";
import { isChartTimeframe } from "./chart/timeframes.js";
import { routeCandles } from "./marketDataRouter.js";
import { hasRecentDerivTickFor } from "./providers/derivProvider.js";

type CandlesResult = Awaited<ReturnType<typeof routeCandles>>;

const FEED_VERDICT_TIMEOUT_MS = 2500;

function withTimeout<T>(p: Promise<T>, fallback: T): Promise<T> {
  return new Promise<T>((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        resolve(fallback);
      }
    }, FEED_VERDICT_TIMEOUT_MS);
    p.then((value) => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve(value);
      }
    }).catch(() => {
      if (!settled) {
        settled = true;
        clearTimeout(timer);
        resolve(fallback);
      }
    });
  });
}

export async function resolveSymbolFeedVerdictForSymbol(
  symbol: string,
  timeframe = "M1",
): Promise<SymbolFeedVerdict> {
  const hasRecentTick = hasRecentDerivTickFor(symbol);
  if (!hasRecentTick) return "AWAITING";
  if (!isChartTimeframe(timeframe)) return "AWAITING";
  const cr = await withTimeout<CandlesResult | null>(
    routeCandles(symbol, timeframe, 30),
    null,
  );
  if (cr == null || !cr.ok || cr.candles.length === 0) return "AWAITING";
  const trailingIntervals = rawTrailingIntervalGap(
    cr.candles,
    cr.primaryProvider ?? null,
    timeframe,
  );
  return resolveSymbolFeedVerdict({ hasRecentTick, trailingIntervals });
}
