// Normalize broker-suffixed symbols to a canonical base used by the scanner.
//
// Examples:
//   EURUSDm     -> EURUSD
//   XAUUSD.r    -> XAUUSD
//   US30.cash   -> US30
//   BTCUSD-pro  -> BTCUSD
//   "  eurusd " -> EURUSD
//
// We only strip well-known broker suffixes/decorations. Anything unrecognised
// is returned upper-cased and trimmed so a user typing "FOO" still sees a
// clean "FOO not available" envelope rather than a 500.

const SUFFIX_PATTERNS: RegExp[] = [
  /\.(cash|pro|raw|ecn|c|m|r|i|spot|sb)$/i,
  /[._-](cash|pro|raw|ecn|m|i|spot|sb)$/i,
  /(?<=[A-Z]{6})[mciM]$/, // e.g. EURUSDm, EURUSDc
];

const CANONICAL_ALIASES: Record<string, string> = {
  NAS100: "NAS100",
  NASDAQ100: "NAS100",
  US100: "NAS100",
  US30: "US30",
  DJ30: "US30",
  WS30: "US30",
  GOLD: "XAUUSD",
  XAUUSD: "XAUUSD",
  BTC: "BTCUSD",
  BTCUSD: "BTCUSD",
  BTCUSDT: "BTCUSDT",
  ETHUSD: "ETHUSD",
  ETHUSDT: "ETHUSDT",
};

export function normalizeSymbol(raw: string): string {
  let s = String(raw ?? "").trim().toUpperCase();
  if (!s) return "";
  for (const rx of SUFFIX_PATTERNS) {
    s = s.replace(rx, "");
  }
  s = s.replace(/[^A-Z0-9]/g, "");
  return CANONICAL_ALIASES[s] ?? s;
}

// Whitelist of canonical symbols the scanner can analyze today. New symbols
// should be added to the simulator + this list together.
export const SUPPORTED_SYMBOLS: readonly string[] = [
  "EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "NZDUSD", "USDCHF",
  "XAUUSD", "XAGUSD",
  "BTCUSDT", "ETHUSDT", "BTCUSD", "ETHUSD",
  "AAPL", "TSLA", "MSFT", "NVDA",
  "US30", "NAS100", "SPX500",
];

export function isSupported(canonical: string): boolean {
  return SUPPORTED_SYMBOLS.includes(canonical);
}
