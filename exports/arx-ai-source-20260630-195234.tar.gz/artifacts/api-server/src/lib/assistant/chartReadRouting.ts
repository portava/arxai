// Deterministic chart-read routing (Task #602 follow-up).
//
// The chat assistant lets the model pick tools (tool_choice:"auto"). For a
// single-symbol "read/analyze <symbol>" request the model was drifting to the
// OLD getSymbolMarketContext / getTradeMarketContext path, whose 8-section UX6
// output collapses to "Data insufficient / no primary timeframe / key levels
// not available" — even though readChartStructure (the SAME shared service the
// Scanner "Ruby Chart Read" panel uses) would produce a real structural read.
//
// These helpers are PURE (no DB / no network / no LLM) so chart-read routing is
// unit-testable offline. They live in their own module — separate from the
// db-importing tools.ts — so the routing test stays in the offline `ci` lane
// instead of the DB-backed integration lane. tools.ts re-exports them.

// detectChartReadIntent is a high-precision classifier: when it returns true
// the handler FORCES tool_choice to readChartStructure on the first turn so
// chat and the Scanner panel never disagree. A miss simply falls back to "auto"
// + the (non-contradictory) system prompt, so false negatives are safe.
// We deliberately DO NOT force for account/journal analysis ("analyze my
// performance") or trade-management ("should I hold these V75 buys") — those
// keep their existing performance / trade-decision / action-draft flows.
export function detectChartReadIntent(text: string): boolean {
  const s = (text ?? "").toLowerCase();
  if (!s.trim()) return false;

  // Exclude analysis aimed at the user's OWN account / journal / performance —
  // not a market chart. These must keep getMyPerformanceSummary / journal flows.
  if (/\banaly[sz]\w*\s+(my\s+)?(performance|trades?|trading|journal|account|portfolio|p&l|pnl|results?|stats?|statistics|history|risk|exposure)\b/.test(s)) {
    return false;
  }
  // Also exclude own-trade management framed as "analyze (my) (open/current/live)
  // positions / orders / holdings" — that is trade management, not a market
  // chart read, and must keep its existing trade-decision flow.
  if (/\banaly[sz]\w*\s+(?:my\s+)?(?:open\s+|current\s+|live\s+)?(positions?|orders?|holdings?)\b/.test(s)) {
    return false;
  }

  // Symbol-looking token: Deriv synthetics (v75, boom1000, crash500, step
  // index, jump 25, volatility 75), real currency PAIRS (eurusd / eur/usd /
  // xauusd), metals / crypto / indices by name. Lowercased input. The pair
  // matcher is restricted to known currency codes so plain 6-letter words
  // (e.g. "another") never look like a symbol.
  const SYMBOL = /\b(v\d{2,4}|boom\s?\d+|crash\s?\d+|step\s?index|jump\s?\d+|volatility\s?\d+|(?:usd|eur|gbp|jpy|aud|nzd|cad|chf|xau|xag)\/?(?:usd|eur|gbp|jpy|aud|nzd|cad|chf|xau|xag)|gold|silver|btc|eth|us30|us500|nas100|ger40|uk100|spx|ndx)\b/;

  // 1. "analyze / analyse / analyzing <anything>" (verb forms) OR
  //    "analysis on/of/for <…>" — in a trading chat this is a chart read
  //    (account-analysis already excluded above). The bare NOUN "analysis"
  //    alone is intentionally NOT a trigger (e.g. "where are the analysis tools").
  if (/\banaly[sz](?:e|es|ed|ing)\b/.test(s)) return true;
  if (/\banalysis\s+(on|of|for)\b/.test(s)) return true;

  // 2. "read / redo / re-read" + chart|structure|setup, OR + this|it|that
  //    (defaults to the on-screen chart symbol), OR + a symbol token.
  if (/\b(re-?read|read|redo)\s+(?:the\s+|my\s+|this\s+|on\s+)?(chart|structure|setup)\b/.test(s)) return true;
  if (/\b(re-?read|read|redo)\s+(?:the\s+|on\s+)?(this|it|that)\b/.test(s)) return true;
  if (/\b(re-?read|read|redo)\b/.test(s) && SYMBOL.test(s)) return true;

  // 3. "chart read" / "chart structure" / "chart setup".
  if (/\bchart\s+(read|structure|setup)\b/.test(s)) return true;

  // 4. "what do / can you see" — open chart-read phrasing.
  if (/\bwhat\s+(do|can)\s+you\s+see\b/.test(s)) return true;

  // 5. "what's / whats / what is the structure/setup/read/chart" /
  //    "your read" / "a read".
  if (/\bwhat(?:'s|s|\s+is)?\s+(?:the\s+)?(structure|setup|read|chart)\b/.test(s)) return true;
  if (/\b(your|a)\s+read\b/.test(s)) return true;

  // 6. "structure/setup/bias on|for|of <symbol>".
  if (/\b(structure|setup|bias)\s+(on|for|of)\b/.test(s) && SYMBOL.test(s)) return true;

  return false;
}

// OpenAI chat-completions tool_choice union (the subset we use).
export type AssistantToolChoice =
  | "auto"
  | { type: "function"; function: { name: string } };

// Pure resolver for the chat handler's per-turn tool_choice. We force the
// structural read ONLY on the first turn of a detected chart-read request;
// every later turn (and every non-chart-read request) stays "auto" so the
// model finalizes the natural-language answer and can call follow-up tools
// (e.g. getTradeMarketContext for P&L context). Forcing first-turn-only also
// prevents an infinite re-force loop.
export function resolveAssistantToolChoice(
  turn: number,
  chartReadIntent: boolean,
): AssistantToolChoice {
  if (turn === 0 && chartReadIntent) {
    return { type: "function", function: { name: "readChartStructure" } };
  }
  return "auto";
}
