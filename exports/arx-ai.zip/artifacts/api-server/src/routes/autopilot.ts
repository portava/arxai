// AI Autopilot Orchestrator HTTP surface.
//
// SAFETY: All mutating endpoints (start/pause/resume/stop/force-scan/
// human-override/mark-decision) require ADMIN. Live broker execution is
// never invoked. FUTURE_MT5_LIVE_AUTO is rejected.
import { Router, type Request, type Response, type NextFunction } from "express";
import { readRoleFromRequest } from "../lib/security/middleware.js";

import { z } from "zod/v4";
import {
  status, startSession, pauseSession, resumeSession, stopSession,
  runDecisionPipeline, listDecisions, listSessions, getSession,
  humanOverride, markDecision, getStateMachine, getSafetyLocks, generateReport,
} from "../lib/autopilot.js";

const router = Router();

function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  const role = readRoleFromRequest(req);
  if (role !== "ADMIN" && role !== "OWNER") {
    res.status(403).json({ error: "Forbidden", requiredRole: "ADMIN" });
    return;
  }
  next();
}

const Mode = z.enum(["OFF", "OBSERVE_ONLY", "AI_ASSIST", "DEMO_AUTO_SIMULATOR", "LIVE_INTENT_AUTO_TESTER", "FUTURE_MT5_LIVE_AUTO_LOCKED"]);

router.get("/autopilot/status", (_req, res) => res.json(status()));
router.get("/autopilot/decisions", (req, res) => res.json({ decisions: listDecisions(Math.min(Number(req.query.limit) || 100, 500)), dataSource: "SIMULATOR" }));
router.get("/autopilot/state-machine", (_req, res) => res.json(getStateMachine()));
router.get("/autopilot/safety-locks", (_req, res) => res.json({ locks: getSafetyLocks() }));
router.get("/autopilot/sessions", (_req, res) => res.json({ sessions: listSessions() }));
router.get("/autopilot/session/:id", (req, res) => {
  const s = getSession(String(req.params.id)); if (!s) return res.status(404).json({ error: "not found" });
  return res.json(s);
});
router.get("/autopilot/reports", (req, res) => {
  const r = generateReport(req.query.sessionId ? String(req.query.sessionId) : undefined);
  return res.json(r);
});

router.post("/autopilot/start", requireAdmin, (req, res) => {
  const Body = z.object({
    name: z.string().min(1),
    mode: Mode,
    strategy: z.string().optional(),
    requireApproval: z.boolean().optional(),
    simulatorBalance: z.number().optional(),
    notes: z.string().optional(),
    rules: z.object({
      symbols: z.array(z.string()).optional(),
      timeframes: z.array(z.string()).optional(),
      maxTrades: z.number().int().min(1).optional(),
      maxOpenPositions: z.number().int().min(1).optional(),
      maxRiskPerTradePct: z.number().optional(),
      maxDailyLossUsd: z.number().optional(),
      maxWeeklyLossUsd: z.number().optional(),
      minConfidence: z.number().optional(),
      minOpportunity: z.number().optional(),
      minEntrySniper: z.number().optional(),
      minTradeGrade: z.number().optional(),
      minRiskReward: z.number().optional(),
    }).partial().optional(),
  });
  const p = Body.safeParse(req.body ?? {});
  if (!p.success) return res.status(400).json({ error: "invalid", issues: p.error.issues });
  const r = startSession(p.data);
  if ("error" in r) return res.status(400).json(r);
  return res.status(201).json(r);
});

router.post("/autopilot/pause", requireAdmin, (_req, res) => { const r = pauseSession(); return res.json(r); });
router.post("/autopilot/resume", requireAdmin, (_req, res) => { const r = resumeSession(); return res.json(r); });
router.post("/autopilot/stop", requireAdmin, (_req, res) => { const r = stopSession(); return res.json(r); });
router.post("/autopilot/force-scan", requireAdmin, (req, res) => {
  const symbol = req.query.symbol ? String(req.query.symbol) : undefined;
  const r = runDecisionPipeline({ force: true, symbol });
  return res.json(r);
});

router.post("/autopilot/human-override", requireAdmin, (req, res) => {
  const Body = z.object({
    kind: z.enum(["APPROVE", "REJECT", "PAUSE", "RESUME", "STOP", "EMERGENCY_STOP", "FORCE_SCAN"]),
    decisionId: z.string().optional(),
    note: z.string().optional(),
  });
  const p = Body.safeParse(req.body ?? {});
  if (!p.success) return res.status(400).json({ error: "invalid", issues: p.error.issues });
  const r = humanOverride(p.data);
  return res.json(r);
});

router.post("/autopilot/mark-decision", requireAdmin, (req, res) => {
  const Body = z.object({ decisionId: z.string(), mark: z.enum(["GOOD", "BAD"]), note: z.string().optional() });
  const p = Body.safeParse(req.body ?? {});
  if (!p.success) return res.status(400).json({ error: "invalid", issues: p.error.issues });
  const r = markDecision(p.data.decisionId, p.data.mark, p.data.note);
  if (!r) return res.status(404).json({ error: "not found" });
  return res.json(r);
});

export default router;
