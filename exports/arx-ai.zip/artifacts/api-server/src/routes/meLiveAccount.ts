// Per-user live slot summary. Read-only.
//
// SAFETY:
// - Strictly per-user. Every query is scoped by req.authUser.id. A user
//   can never see another user's slot, positions, or allocation. The
//   shared MASTER MT5 balance/equity/margin is NEVER returned here.
// - No fake ownership: positions are read straight from arx_live_positions
//   where userId matches the caller. Closed rows contribute to realised
//   P/L; open rows contribute to floating P/L and estimated used margin.
// - No order placement, no kill switch, no admin approval, no auto-close.
// - When no allocation exists, we return zeros + an explicit honest note
//   instead of fabricating a balance.

import { Router, type Request, type Response } from "express";
import { and, eq, isNull, isNotNull, sql } from "drizzle-orm";
import { requireUser } from "../lib/auth/middleware.js";
import {
  db,
  arxLivePositionsTable,
  mt5ConnectionTable,
  userSlotAllocationTable,
} from "@workspace/db";

const router = Router();

function uid(req: Request): number | null {
  const u = (req as Request & { authUser?: { id?: number } }).authUser;
  return u?.id ?? null;
}

const HEARTBEAT_LIVE_MS = 20_000;

// Conservative notional-based margin estimate used ONLY when EA does not
// push per-position margin. Forex standard lot = 100,000 base units.
// Marked internally as estimated so the UI / admin views can show source.
function estimateMarginUsd(volume: number, price: number, leverage: number): number {
  if (!Number.isFinite(volume) || !Number.isFinite(price) || !Number.isFinite(leverage) || leverage <= 0) {
    return 0;
  }
  return (volume * 100_000 * price) / leverage;
}

router.get("/me/live/slot-summary", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) {
    res.status(401).json({ error: "AUTH_REQUIRED" });
    return;
  }

  // 1. Allocation row (zero/empty if absent — no fake balance).
  const allocRows = await db.select().from(userSlotAllocationTable)
    .where(eq(userSlotAllocationTable.userId, userId)).limit(1);
  const alloc = allocRows[0];
  const allocatedFunds = alloc ? Number(alloc.allocatedFunds) : 0;
  const accountCurrency = alloc?.accountCurrency ?? "USD";
  const isAllocated = Boolean(alloc?.isActive);

  // 2. Open positions for this user only.
  const openPositions = await db.select().from(arxLivePositionsTable)
    .where(and(
      eq(arxLivePositionsTable.userId, userId),
      isNull(arxLivePositionsTable.closedAt),
    ));

  // 3. Realised P/L = sum of floatingPl on closed positions assigned to user.
  const closedRows = await db.select({
    realised: sql<number>`coalesce(sum(${arxLivePositionsTable.floatingPl}), 0)`,
  }).from(arxLivePositionsTable)
    .where(and(
      eq(arxLivePositionsTable.userId, userId),
      isNotNull(arxLivePositionsTable.closedAt),
    ));
  const realisedPnl = Number(closedRows[0]?.realised ?? 0);

  // 4. The user's own bridge connection (used for leverage + heartbeat
  //    freshness). We do NOT read accountBalance/accountEquity from the
  //    master connection here — that is admin-only.
  const connRows = await db.select().from(mt5ConnectionTable)
    .where(eq(mt5ConnectionTable.userId, userId))
    .orderBy(mt5ConnectionTable.id)
    .limit(1);
  const conn = connRows[0];
  const leverage = conn?.leverage ?? 100;
  const lastHeartbeat = conn?.lastHeartbeat ?? null;
  const heartbeatAgeMs = lastHeartbeat ? Date.now() - new Date(lastHeartbeat).getTime() : null;
  const isLive = heartbeatAgeMs !== null && heartbeatAgeMs <= HEARTBEAT_LIVE_MS;
  const isStale = heartbeatAgeMs !== null && heartbeatAgeMs > HEARTBEAT_LIVE_MS;

  // 5. Derive floating P/L, used margin estimate, per-position payload.
  let openPnL = 0;
  let usedMargin = 0;
  const slotBalanceForPct = allocatedFunds + realisedPnl;
  const positions = openPositions.map((p) => {
    const floating = p.floatingPl != null ? Number(p.floatingPl) : 0;
    const vol = Number(p.volume);
    const price = p.currentPrice != null ? Number(p.currentPrice) : Number(p.entryPrice);
    const marginEst = estimateMarginUsd(vol, price, leverage);
    openPnL += floating;
    usedMargin += marginEst;
    const profitPercentOfSlot = slotBalanceForPct > 0 ? (floating / slotBalanceForPct) * 100 : null;
    return {
      brokerTicket: p.brokerTicket,
      symbol: p.symbol,
      direction: p.side,
      volume: vol,
      entryPrice: Number(p.entryPrice),
      currentPrice: p.currentPrice != null ? Number(p.currentPrice) : null,
      stopLoss: p.stopLoss != null ? Number(p.stopLoss) : null,
      takeProfit: p.takeProfit != null ? Number(p.takeProfit) : null,
      grossProfit: floating,
      // EA does not currently push swap/commission per-position; we surface
      // null honestly rather than zero so the UI can omit the row.
      swap: null as number | null,
      commission: null as number | null,
      netProfit: floating,
      profitPercentOfSlot,
      openedAt: p.openedAt,
      lastUpdated: p.lastSyncedAt,
    };
  });

  const slotBalance = allocatedFunds + realisedPnl;
  const slotEquity = slotBalance + openPnL;
  const freeMargin = slotEquity - usedMargin;
  const marginLevelPercent = usedMargin > 0 ? (slotEquity / usedMargin) * 100 : null;

  res.json({
    accountCurrency,
    balance: slotBalance,
    equity: slotEquity,
    margin: usedMargin,
    freeMargin,
    marginLevelPercent,
    openPnL,
    positions,
    isLive,
    isStale,
    isAllocated,
    allocationNote: isAllocated
      ? null
      : "No fund allocation assigned yet. An operator must allocate funds before live slot metrics will populate.",
    lastUpdated: new Date().toISOString(),
    readOnly: true,
    safetyMode: "phase_b_live_runtime_gated" as const,
  });
});

export default router;
