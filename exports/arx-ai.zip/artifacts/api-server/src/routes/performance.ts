import { Router } from "express";
import { db } from "@workspace/db";
import { tradesTable, performanceDailyTable } from "@workspace/db";
import { and, desc, eq } from "drizzle-orm";
import {
  GetPerformanceSummaryResponse,
  GetDailyPerformanceQueryParams,
  GetDailyPerformanceResponse,
  GetStrategyBreakdownResponse,
} from "@workspace/api-zod";
import { requireUser } from "../lib/auth/middleware.js";

const router = Router();

// GET /performance/summary
router.get("/performance/summary", requireUser, async (req, res) => {
  try {
    const trades = await db.select().from(tradesTable)
      .where(eq(tradesTable.userId, req.authUser!.id));
    const openTrades = trades.filter((t) => t.status === "OPEN");
    const closedTrades = trades.filter((t) => t.status !== "OPEN" && t.status !== "CANCELLED");
    const wins = closedTrades.filter((t) => t.status === "CLOSED_WIN");
    const losses = closedTrades.filter((t) => t.status === "CLOSED_LOSS");
    const totalPnl = closedTrades.reduce((acc, t) => acc + (t.pnl ?? 0), 0);
    const winRate = closedTrades.length > 0 ? (wins.length / closedTrades.length) * 100 : 0;
    const pnlValues = closedTrades.map((t) => t.pnl ?? 0);
    const bestTradePnl = pnlValues.length > 0 ? Math.max(...pnlValues) : 0;
    const worstTradePnl = pnlValues.length > 0 ? Math.min(...pnlValues) : 0;
    const grossProfit = wins.reduce((a, t) => a + (t.pnl ?? 0), 0);
    const grossLoss = Math.abs(losses.reduce((a, t) => a + (t.pnl ?? 0), 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? 9.99 : 0;
    const avgConfidence = trades.length > 0 ? trades.reduce((a, t) => a + t.confidence, 0) / trades.length : 0;

    // Today's P&L
    const today = new Date().toISOString().slice(0, 10);
    const todayTrades = closedTrades.filter((t) => t.closedAt && t.closedAt.toISOString().slice(0, 10) === today);
    const todayPnl = todayTrades.reduce((a, t) => a + (t.pnl ?? 0), 0);

    // Max drawdown (simplified)
    let peak = 10000;
    let maxDD = 0;
    let balance = 10000;
    for (const t of closedTrades) {
      balance += t.pnl ?? 0;
      if (balance > peak) peak = balance;
      const dd = ((peak - balance) / peak) * 100;
      if (dd > maxDD) maxDD = dd;
    }

    const accountBalance = 10000 + totalPnl;

    const data = GetPerformanceSummaryResponse.parse({
      accountBalance,
      todayPnl,
      todayPnlPct: accountBalance > 0 ? (todayPnl / accountBalance) * 100 : 0,
      totalPnl,
      winRate,
      maxDrawdown: maxDD,
      totalTrades: closedTrades.length,
      winningTrades: wins.length,
      losingTrades: losses.length,
      openTrades: openTrades.length,
      bestTradePnl,
      worstTradePnl,
      profitFactor,
      avgConfidence,
    });
    res.json(data);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get performance summary" });
  }
});

// GET /performance/daily
router.get("/performance/daily", requireUser, async (req, res) => {
  try {
    const params = GetDailyPerformanceQueryParams.parse({
      days: req.query["days"] ? Number(req.query["days"]) : 30,
    });
    const rows = await db.select().from(performanceDailyTable)
      .where(eq(performanceDailyTable.userId, req.authUser!.id))
      .orderBy(desc(performanceDailyTable.date)).limit(params.days ?? 30);
    const data = GetDailyPerformanceResponse.parse(rows.map((r) => ({
      ...r,
      date: r.date,
    })));
    res.json(data);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get daily performance" });
  }
});

// GET /performance/strategy-breakdown
router.get("/performance/strategy-breakdown", requireUser, async (req, res) => {
  try {
    const userId = req.authUser!.id;
    const trades = await db.select().from(tradesTable)
      .where(and(eq(tradesTable.status, "CLOSED_WIN"), eq(tradesTable.userId, userId)))
      .then(async (wins) => {
        const losses = await db.select().from(tradesTable)
          .where(and(eq(tradesTable.status, "CLOSED_LOSS"), eq(tradesTable.userId, userId)));
        return [...wins, ...losses];
      });

    const grouped: Record<string, { wins: number; losses: number; pnl: number }> = {};
    for (const t of trades) {
      if (!grouped[t.strategy]) grouped[t.strategy] = { wins: 0, losses: 0, pnl: 0 };
      if (t.status === "CLOSED_WIN") grouped[t.strategy].wins++;
      if (t.status === "CLOSED_LOSS") grouped[t.strategy].losses++;
      grouped[t.strategy].pnl += t.pnl ?? 0;
    }

    const breakdown = Object.entries(grouped).map(([strategy, stats]) => {
      const total = stats.wins + stats.losses;
      return {
        strategy,
        totalTrades: total,
        wins: stats.wins,
        losses: stats.losses,
        winRate: total > 0 ? (stats.wins / total) * 100 : 0,
        totalPnl: stats.pnl,
      };
    });

    const data = GetStrategyBreakdownResponse.parse(breakdown);
    res.json(data);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Failed to get strategy breakdown" });
  }
});

export default router;
