import { Router, type IRouter } from "express";
import healthRouter from "./health";
import appDoctorRouter from "./appDoctor";
import botRouter from "./bot";
import signalsRouter from "./signals";
import tradesRouter from "./trades";
import riskRouter from "./risk";
import strategiesRouter from "./strategies";
import performanceRouter from "./performance";
import backtestsRouter from "./backtests";
import mt5Router from "./mt5";
import learningRouter from "./learning";
import dataRouter from "./data";
import tradeManagementRouter from "./tradeManagement";
import newsRouter from "./news";
import alertsRouter from "./alerts";
import watchlistsRouter from "./watchlists";
import portfolioRouter from "./portfolio";
import journalRouter from "./journal";
import intelligenceRouter from "./intelligence";
import brainRouter from "./brain";
import systemRouter from "./system";
import auditRouter from "./audit";
import agentsRouter from "./agents";
import executionRouter from "./execution";
import executionIntelRouter from "./executionIntelligence";
import traderDNARouter from "./traderDNA";
import cognitiveRouter from "./cognitive";
import personalEdgeRouter from "./personalEdge";
import temporalIntelligenceRouter from "./temporalIntelligence";
import replayLabRouter from "./replayLab";
import replayLabSimRouter from "./replayLabSim";
import validationPipelineRouter from "./validationPipeline";
import validationCommandCenterRouter from "./validationCommandCenter";
import adversarialValidationRouter from "./adversarialValidation";
import continuousValidationRouter from "./continuousValidation";
import decisionIntelligenceRouter from "./decisionIntelligence";
import economyRouter from "./economy";
import ecosystemRouter from "./ecosystem";
import permissionRouter from "./permission";
import executionConfirmationsRouter from "./executionConfirmations";
import brokerHealthRouter from "./brokerHealth";
import livePositionsRouter from "./livePositions";
import journalEntriesRouter from "./journalEntries";
import weeklyReviewsRouter from "./weeklyReviews";
import tradePlansRouter from "./tradePlans";
import multiTimeframeRouter from "./multiTimeframe";
import newsCalendarRouter from "./newsCalendar";
import portfolioRiskRouter from "./portfolioRisk";
import backtestRunsRouter from "./backtestRuns";
import paperTradingRouter from "./paperTrading";
import paperIntelligenceRouter from "./paperIntelligence";
import demoExecutionRouter from "./demoExecution";
import meDemoExecutionReadinessRouter from "./meDemoExecutionReadiness";
import meDemoExecutionRouter from "./meDemoExecution";
import meDemoCommandsRouter from "./meDemoCommands";
import meDemoBridgeDebugRouter from "./meDemoBridgeDebug";
import meDemoPositionsRouter from "./meDemoPositions";
import meLiveRouter from "./meLive";
import meLiveAccountRouter from "./meLiveAccount";
import adminLiveAccountRouter from "./adminLiveAccount";
import tradesLiveSharedRouter from "./tradesLiveShared";
import mePositionsUnifiedRouter from "./mePositionsUnified";
import mt5DemoBridgeRouter from "./mt5DemoBridge";
import mt5LiveRouter from "./mt5Live";
import propChallengesRouter from "./propChallenges";
import ruleContractsRouter from "./ruleContracts";
import tradingReadinessRouter from "./tradingReadiness";
import postTradeDebriefsRouter from "./postTradeDebriefs";
import tradingPlaybooksRouter from "./tradingPlaybooks";
import edgeDiscoveryRouter from "./edgeDiscovery";
import traderSkillRouter from "./traderSkill";
import aiMentorRouter from "./aiMentor";
import analyticsCommandRouter from "./analytics";
import tradeDecisionRouter from "./tradeDecision";
import autoDebriefRouter from "./autoDebrief";
import marketDataRouter from "./marketData";
import paperExecutionRouter from "./paperExecution";
import paperAutopilotRouter from "./paperAutopilot";
import performanceCommandCenterRouter from "./performanceCommandCenter";
import riskGovernorRouter from "./riskGovernor";
import traderCoachRouter from "./traderCoach";
import replayRouter from "./replay";
import strategyLabRouter from "./strategyLab";
import dataImportRouter from "./dataImport";
import brokerReadOnlyRouter from "./brokerReadOnly";
import notificationsRouter from "./notifications";
import systemHealthRouter from "./systemHealth";
import securityRouter from "./security";
import readinessRouter from "./readiness";
import integrationTestsRouter from "./integrationTests";
import paperSessionsRouter from "./paperSessions";
import tradingCockpitRouter from "./tradingCockpit";
import onboardingRouter from "./onboarding";
import helpRouter from "./help";
import featureAnnouncementsRouter from "./featureAnnouncements";
import brokerRouter from "./broker";
import liveTradingRouter from "./liveTrading";
import tradingSessionsRouter from "./tradingSessions";
import meMt5ConnectionsRouter from "./meMt5Connections";
import meMt5CommandsRouter from "./meMt5Commands";
import mePaperTradesRouter from "./mePaperTrades";
import meFirstRunReadinessRouter from "./meFirstRunReadiness";
import mePaperBetaReadinessRouter from "./mePaperBetaReadiness";
import meTradeJournalRouter from "./meTradeJournal";
import mePerformanceCalendarRouter from "./mePerformanceCalendar";
import meAiReviewsRouter from "./meAiReviews";
import mePlaybooksRouter from "./mePlaybooks";
import setupsAndCoachRouter from "./setupsAndCoach";
import meRiskGovernorRouter from "./meRiskGovernor";
import meDashboardRouter from "./meDashboard";
import meAlertsRouter from "./meAlerts";
import meNotificationsRouter from "./meNotifications";
import meViewModeRouter from "./meViewMode";
import meActivityRouter from "./meActivity";
import meReportsRouter from "./meReports";
import { meAssistantRouter } from "./meAssistant";
import adminTradingRouter from "./adminTrading";
import adminAuditCenterRouter from "./adminAuditCenter";
import adminLaunchReadinessRouter from "./adminLaunchReadiness";
import adminReconciliationCenterRouter from "./adminReconciliationCenter.js";
import adminLiveTestReadinessRouter from "./adminLiveTestReadiness.js";
import adminOperatorCommandCenterRouter from "./adminOperatorCommandCenter.js";
import meTradingModeRouter from "./meTradingMode";
import tradePlacementRouter from "./tradePlacement";
import meTradesRouter from "./meTrades";
import meTradeIntelligenceRouter from "./meTradeIntelligence";
import meMarketContextRouter from "./meMarketContext";
import meTradeDecisionsRouter from "./meTradeDecisions";
import meTradeActionsRouter from "./meTradeActions";
import pendingOrderDraftRouter from "./pendingOrderDraft";
import meTradeCoachRouter from "./meTradeCoach";
import meProtectiveAutoCloseRouter from "./meProtectiveAutoClose";
import meMarketDataRouter from "./meMarketData";
import historicalAnalysisRouter from "./historicalAnalysis";
import newsIntelligenceRouter from "./newsIntelligence";
import { attachSecurityContext } from "../lib/security/middleware";
import { requireAuthOrPublic } from "../lib/auth/globalGate";

const router: IRouter = Router();

// PHASE-1 SAFETY NET: deny-by-default per-user auth gate. 401s any /api/*
// request from a logged-out caller unless the path is on the public
// allowlist (health, /auth/*, MT5 bridge endpoints, version/release).
// See lib/auth/globalGate.ts for the full allowlist + rationale.
router.use(requireAuthOrPublic);

router.use(healthRouter);
router.use(appDoctorRouter);
router.use(botRouter);
router.use(signalsRouter);
router.use(tradesRouter);
router.use(riskRouter);
router.use(strategiesRouter);
router.use(performanceRouter);
router.use(backtestsRouter);
router.use(mt5Router);
router.use(mt5DemoBridgeRouter);
router.use(mt5LiveRouter);
router.use(tradingSessionsRouter);
router.use(meMt5ConnectionsRouter);
router.use(meMt5CommandsRouter);
router.use(mePaperTradesRouter);
router.use(meFirstRunReadinessRouter);
router.use(mePaperBetaReadinessRouter);
router.use(meTradeJournalRouter);
router.use(mePerformanceCalendarRouter);
router.use(meAiReviewsRouter);
router.use(mePlaybooksRouter);
router.use(setupsAndCoachRouter);
router.use(meRiskGovernorRouter);
router.use(meMarketDataRouter);
router.use(historicalAnalysisRouter);
router.use(newsIntelligenceRouter);
router.use(meDashboardRouter);
router.use(meAlertsRouter);
router.use(meNotificationsRouter);
router.use(meViewModeRouter);
router.use(meActivityRouter);
router.use(meReportsRouter);
router.use(meAssistantRouter);
router.use(adminTradingRouter);
router.use(adminAuditCenterRouter);
router.use(adminLaunchReadinessRouter);
router.use(adminReconciliationCenterRouter);
router.use(adminLiveTestReadinessRouter);
router.use(adminOperatorCommandCenterRouter);
router.use(meTradingModeRouter);
router.use(tradePlacementRouter);
router.use(meTradesRouter);
router.use(meTradeIntelligenceRouter);
router.use(meMarketContextRouter);
router.use(meTradeDecisionsRouter);
router.use(meTradeActionsRouter);
router.use(pendingOrderDraftRouter);
router.use(meTradeCoachRouter);
router.use(meProtectiveAutoCloseRouter);
router.use(brokerHealthRouter);
router.use(brokerRouter);
router.use(livePositionsRouter);
router.use(journalEntriesRouter);
router.use(weeklyReviewsRouter);
router.use(tradePlansRouter);
router.use(learningRouter);
router.use(dataRouter);
router.use(tradeManagementRouter);
router.use(newsRouter);
router.use(alertsRouter);
router.use(watchlistsRouter);
router.use(portfolioRouter);
router.use(journalRouter);
router.use(intelligenceRouter);
router.use(brainRouter);
router.use(systemRouter);
router.use(auditRouter);
router.use(agentsRouter);
router.use(executionRouter);
router.use(executionIntelRouter);
router.use(traderDNARouter);
router.use(cognitiveRouter);
router.use(personalEdgeRouter);
router.use(temporalIntelligenceRouter);
router.use(replayLabRouter);
router.use(replayLabSimRouter);
router.use(validationPipelineRouter);
router.use(validationCommandCenterRouter);
router.use(adversarialValidationRouter);
router.use(continuousValidationRouter);
router.use(decisionIntelligenceRouter);
router.use(economyRouter);
router.use(ecosystemRouter);
router.use(permissionRouter);
router.use(executionConfirmationsRouter);
router.use(multiTimeframeRouter);
router.use(newsCalendarRouter);
router.use(portfolioRiskRouter);
router.use(backtestRunsRouter);
router.use(paperTradingRouter);
router.use("/paper", paperIntelligenceRouter);
router.use("/paper/demo-execution", demoExecutionRouter);
router.use(meDemoExecutionReadinessRouter);
router.use(meDemoExecutionRouter);
router.use(meDemoCommandsRouter);
router.use(meDemoBridgeDebugRouter);
router.use(meDemoPositionsRouter);
router.use(meLiveRouter);
router.use(meLiveAccountRouter);
router.use(adminLiveAccountRouter);
router.use(tradesLiveSharedRouter);
router.use(mePositionsUnifiedRouter);
router.use(propChallengesRouter);
router.use(ruleContractsRouter);
router.use(tradingReadinessRouter);
router.use(postTradeDebriefsRouter);
router.use(tradingPlaybooksRouter);
router.use(edgeDiscoveryRouter);
router.use(traderSkillRouter);
router.use(aiMentorRouter);
router.use(analyticsCommandRouter);
router.use(tradeDecisionRouter);
router.use(autoDebriefRouter);
router.use(marketDataRouter);
router.use(paperExecutionRouter);
router.use(paperAutopilotRouter);
router.use(performanceCommandCenterRouter);
router.use(riskGovernorRouter);
router.use(traderCoachRouter);
router.use(replayRouter);
router.use(strategyLabRouter);
router.use(dataImportRouter);
router.use(brokerReadOnlyRouter);
router.use(notificationsRouter);
router.use(systemHealthRouter);
router.use(attachSecurityContext);
router.use(securityRouter);
router.use(readinessRouter);
router.use(integrationTestsRouter);
router.use(paperSessionsRouter);
router.use(tradingCockpitRouter);
router.use(onboardingRouter);
router.use(helpRouter);
router.use(featureAnnouncementsRouter);
router.use(liveTradingRouter);

// Build TT — Live Intent Queue (FULL TESTER ACCESS, MT5-deferred).
import liveIntentRouter from "./liveIntent.js";
router.use(liveIntentRouter);

// Build TT — Simulated Market Engine + tester demo-data.
import marketRouter from "./market.js";
import testerDataRouter from "./testerData.js";
router.use(marketRouter);
router.use(testerDataRouter);

// AI Strategy Brain — analysis, trade cards, sniper score, grader, replay,
// scorecard, coach summary. Simulator only.
import aiBrainRouter from "./aiBrain.js";
router.use(aiBrainRouter);

// Market Scanner + Opportunity Scoring + Session Plan + Decision Stream + Alerts.
import scannerRouter from "./scanner.js";
router.use(scannerRouter);

// Real-time Market Data Layer: quotes/candles envelopes, session clock,
// news risk, spread/vol monitors, market health, data quality, risk governor.
import marketDataLayerRouter from "./marketDataLayer.js";
router.use(marketDataLayerRouter);

// Order Management System + Position Manager + Simulated Execution + P/L engine.
import omsRouter from "./oms.js";
router.use(omsRouter);

// AI Autopilot Orchestrator + Human Control Layer.
import autopilotRouter from "./autopilot.js";
router.use(autopilotRouter);

// Risk Governor 2.0 + Account Protection.
import riskGov2Router from "./riskGovernor2.js";
router.use(riskGov2Router);

// Shadow Mode + Forward Testing + Strategy Tournament + Promotion Gates.
import shadowModeRouter from "./shadowMode.js";
router.use(shadowModeRouter);

// Full System Stabilization aggregator.
import systemFullHealthRouter from "./systemFullHealth.js";
router.use(systemFullHealthRouter);

// Owner / Tester auth + session.
import authRouter from "./auth.js";
router.use(authRouter);

// Backup / export endpoints.
import exportsRouter from "./exports.js";
router.use(exportsRouter);

// Build UU — Beta release: version, readiness gates, feedback, diagnostics.
import releaseRouter from "./release.js";
router.use(releaseRouter);

// Build WW — Daily Owner Testing Mode: sessions, steps, ratings, weekly
// summary, readiness trend, exports. Simulator + tester intents only.
import dailyTestingRouter from "./dailyTesting.js";
router.use(dailyTestingRouter);

// Per-user Trading Readiness (14-status engine).
import userReadinessRouter from "./userReadiness.js";
router.use("/api", userReadinessRouter);

// Opportunity Radar / AI Scanner Brain (read-only ranking + watchlist prefs).
import opportunityRadarRouter from "./opportunityRadar.js";
router.use("/api", opportunityRadarRouter);

// P0-1 — Per-user Shared Account read API (/api/me/shared-account/*).
import meSharedAccountRouter from "./meSharedAccount.js";
router.use(meSharedAccountRouter);

import meAccountShellRouter from "./meAccountShell.js";
router.use(meAccountShellRouter);

// P0-1 + P0-3 — Admin Shared Master API namespace (/api/admin/shared-master/*).
// Additive to existing /api/admin/trading/* in adminTrading.ts.
import adminSharedMasterRouter from "./adminSharedMaster.js";
router.use(adminSharedMasterRouter);
import adminMasterBridgeRouter from "./adminMasterBridge.js";
router.use(adminMasterBridgeRouter);
import meMasterBridgeRouter from "./meMasterBridge.js";
router.use(meMasterBridgeRouter);
import adminMasterLiveAccessRouter from "./adminMasterLiveAccess.js";
router.use(adminMasterLiveAccessRouter);
import adminUserControlRouter from "./adminUserControl.js";
router.use(adminUserControlRouter);
import adminRiskTemplatesRouter from "./adminRiskTemplates.js";
router.use(adminRiskTemplatesRouter);
import meMasterLiveAccessRouter from "./meMasterLiveAccess.js";
router.use(meMasterLiveAccessRouter);
import meReadinessSummaryRouter from "./meReadinessSummary.js";
router.use(meReadinessSummaryRouter);
import adminLiveGatesDiagnosticRouter from "./adminLiveGatesDiagnostic.js";
router.use(adminLiveGatesDiagnosticRouter);
import adminLiveSharedReadinessRouter from "./adminLiveSharedReadiness.js";
router.use(adminLiveSharedReadinessRouter);
import adminLiveSharedActivationRouter from "./adminLiveSharedActivation.js";
router.use(adminLiveSharedActivationRouter);
import meOneClickRouter from "./meOneClick.js";
router.use(meOneClickRouter);
import instantTradeRouter from "./instantTrade.js";
router.use(instantTradeRouter);
import adminPerformanceRouter from "./adminPerformance.js";
router.use(adminPerformanceRouter);

// Centralized Master MT5 Bridge (Slice 1+2) — per-user routing status.
import meRoutingStatusRouter from "./meRoutingStatus.js";
router.use(meRoutingStatusRouter);

// ── Private Beta 10 cohort ───────────────────────────────────────────────
import adminBetaControlRouter from "./adminBetaControl.js";
import meBetaStatusRouter from "./meBetaStatus.js";
router.use(adminBetaControlRouter);
router.use(meBetaStatusRouter);

import adminDerivStatusRouter from "./adminDerivStatus.js";
router.use(adminDerivStatusRouter);

import marketDataDerivRouter from "./marketDataDeriv.js";
router.use(marketDataDerivRouter);

export default router;
