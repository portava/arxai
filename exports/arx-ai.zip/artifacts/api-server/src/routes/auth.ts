// Auth + session endpoints.
//
// LAYER 1 — role cookie (`hr_session`) + dev `x-security-role` header. Drives
// OWNER/ADMIN/TESTER permission checks. Endpoints: /auth/session,
// /auth/permissions, /auth/roles, /auth/dev-owner-login, /auth/logout.
//
// LAYER 2 — per-user identity (`arx_user_session` cookie). Drives the new
// userId-scoped data isolation. Endpoints: /auth/register, /auth/login,
// /auth/user-logout, /me. Independent from LAYER 1 — they coexist.

import { Router } from "express";
import { eq } from "drizzle-orm";
import { z } from "zod/v4";
import { db, usersTable, toPublicUser, betaInvitesRepo } from "@workspace/db";
import { auditEvent } from "../lib/systemHealth/audit.js";
import {
  AUTH_ROLES, ALLOW_DEV_AUTH, IS_PROD, type AuthRole, buildMatrix, clearSessionCookie,
  getSessionFromReq, setSessionCookie,
} from "../lib/security/session.js";
import { hashPassword, verifyPassword } from "../lib/auth/password.js";
import {
  createUserSession, destroyUserSession, USER_SESSION_COOKIE,
} from "../lib/auth/userSessions.js";
import { requireUser } from "../lib/auth/middleware.js";
import { recordUserActivity } from "../lib/auth/activity.js";

const router = Router();

// ── LAYER 1 (existing role cookie) ────────────────────────────────────────

router.get("/auth/session", (req, res) => {
  const s = getSessionFromReq(req);
  res.json({
    role: s.role, sessionId: s.sid, ts: s.ts,
    fullTesterAccess: s.role === "OWNER" || s.role === "ADMIN" || s.role === "TESTER",
    mt5Connected: false, mt5Deferred: true, realBrokerExecutionAvailable: false,
  });
});

router.get("/auth/permissions", (req, res) => {
  const s = getSessionFromReq(req);
  res.json(buildMatrix(s.role));
});

router.get("/auth/roles", (_req, res) => {
  res.json({
    roles: AUTH_ROLES.map((role) => ({ role, matrix: buildMatrix(role) })),
    note: "OWNER and ADMIN can activate full tester access. LOCKED denies all access. TESTER maps to DB-role TRADER for permission lookups.",
  });
});

router.post("/auth/dev-owner-login", async (req, res) => {
  if (IS_PROD && !ALLOW_DEV_AUTH) {
    await auditEvent({
      eventType: "AUTH_LOGIN_BLOCKED", severity: "HIGH", actor: "USER",
      action: "dev-owner-login blocked in production", sourceService: "auth",
      metadata: { reason: "ALLOW_DEV_AUTH not set" }, ipAddress: req.ip ?? null,
    }).catch(() => {});
    res.status(403).json({ allowed: false, reason: "dev-owner-login is disabled in production. Set ALLOW_DEV_AUTH=true to enable." });
    return;
  }
  const requested = String((req.body as { role?: string } | undefined)?.role ?? "OWNER").toUpperCase() as AuthRole;
  const role: AuthRole = (AUTH_ROLES as readonly string[]).includes(requested) ? requested : "OWNER";
  const s = setSessionCookie(res, role);
  await auditEvent({
    eventType: "AUTH_LOGIN", severity: "INFO", actor: "USER",
    action: `dev-owner-login as ${role}`, sourceService: "auth",
    metadata: { role, sessionId: s.sid }, ipAddress: req.ip ?? null,
  }).catch(() => {});
  res.json({ ok: true, role, sessionId: s.sid });
});

router.post("/auth/logout", async (req, res) => {
  const s = getSessionFromReq(req);
  clearSessionCookie(res);
  await auditEvent({
    eventType: "AUTH_LOGOUT", severity: "INFO", actor: "USER",
    action: "logout", sourceService: "auth", metadata: { previousRole: s.role },
    ipAddress: req.ip ?? null,
  }).catch(() => {});
  res.json({ ok: true });
});

// ── LAYER 2 (per-user identity, Phase 1 isolation refactor) ───────────────

const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

const registerSchema = z.object({
  email: z.string().email().max(254),
  password: z.string().min(8).max(200),
  name: z.string().min(1).max(120).optional(),
  inviteCode: z.string().min(8).max(64).optional(),
});

async function recordBetaGateAudit(eventType: string, payload: Record<string, unknown>): Promise<void> {
  try {
    const { randomBytes, createHash } = await import("node:crypto");
    const eventId = randomBytes(12).toString("hex");
    const ts = new Date().toISOString();
    const body = JSON.stringify({ source: "beta-invite-gate", eventType, payload, ts });
    const checksum = createHash("sha256").update(body).digest("hex");
    const { sql } = await import("drizzle-orm");
    await db.execute(sql`
      INSERT INTO audit_events (event_id, timestamp, event_type, source, severity, payload, checksum, schema_version)
      VALUES (${eventId}, ${ts}, ${eventType}, 'beta-invite-gate', 'INFO', ${JSON.stringify(payload)}::jsonb, ${checksum}, 1)
    `);
  } catch { /* never block registration on audit failure */ }
}

const loginSchema = z.object({
  email: z.string().email().max(254),
  password: z.string().min(1).max(200),
});

function setUserSessionCookie(res: import("express").Response, rawToken: string): void {
  res.cookie(USER_SESSION_COOKIE, rawToken, {
    httpOnly: true,
    sameSite: "lax",
    secure: IS_PROD,
    path: "/",
    maxAge: SESSION_TTL_MS,
  });
}

function clearUserSessionCookie(res: import("express").Response): void {
  res.clearCookie(USER_SESSION_COOKIE, { path: "/" });
}

router.post("/auth/register", async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "INVALID_INPUT", message: "Email and password (min 8 chars) are required." });
    return;
  }
  const email = parsed.data.email.trim().toLowerCase();
  const existing = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  if (existing.length > 0) {
    res.status(409).json({ error: "EMAIL_TAKEN", message: "An account with that email already exists." });
    return;
  }
  // Hard invite-gate (ARX_BETA_INVITE_REQUIRED=true). When off, behaviour is unchanged.
  if (betaInvitesRepo.isBetaInviteGateEnabled()) {
    const code = parsed.data.inviteCode ?? "";
    const v = await betaInvitesRepo.validateInviteForRegistration({ inviteCode: code, email });
    if (!v.ok) {
      await recordBetaGateAudit("beta_invite_validation_failed", { email, error: v.error });
      res.status(betaInvitesRepo.inviteErrorStatus(v.error))
         .json({ error: v.error, message: betaInvitesRepo.inviteErrorMessage(v.error) });
      return;
    }
  }
  let passwordHash: string;
  try {
    passwordHash = hashPassword(parsed.data.password);
  } catch (err) {
    res.status(400).json({ error: "WEAK_PASSWORD", message: (err as Error).message });
    return;
  }
  // Atomic registration boundary. When the invite gate is on, the user
  // insert AND the invite acceptance share a single db.transaction. If
  // acceptInvite returns !ok we throw an internal sentinel that rolls
  // the whole tx back — no user row, no invite mutation, no seat burned.
  // Session creation/cookie issuance happen strictly AFTER the tx commits.
  type RegisterFailure = { kind: "INVITE_GATE"; error: betaInvitesRepo.InviteValidationError };
  let user: typeof usersTable.$inferSelect;
  try {
    user = await db.transaction(async (tx) => {
      const inserted = await tx.insert(usersTable).values({
        email,
        name: parsed.data.name ?? null,
        passwordHash,
        role: "USER",
        lastLoginAt: new Date(),
      }).returning();
      const u = inserted[0]!;
      if (betaInvitesRepo.isBetaInviteGateEnabled() && parsed.data.inviteCode) {
        const accepted = await betaInvitesRepo.acceptInviteTx(tx, {
          inviteCode: parsed.data.inviteCode, email, userId: u.id,
        });
        if (!accepted.ok) {
          // Throw the sentinel — drizzle will ROLLBACK the entire tx,
          // discarding the just-inserted user row and any other writes.
          const failure: RegisterFailure = { kind: "INVITE_GATE", error: accepted.error };
          throw failure;
        }
      }
      return u;
    });
  } catch (err) {
    if (err && typeof err === "object" && (err as RegisterFailure).kind === "INVITE_GATE") {
      const f = err as RegisterFailure;
      // Audit is written OUTSIDE the rolled-back tx so it survives.
      await recordBetaGateAudit(
        f.error === "CAP_REACHED"
          ? "beta_invite_cap_blocked_at_accept"
          : "beta_invite_accept_failed_post_validation",
        { email, error: f.error },
      );
      res.status(betaInvitesRepo.inviteErrorStatus(f.error))
         .json({ error: f.error, message: betaInvitesRepo.inviteErrorMessage(f.error) });
      return;
    }
    throw err;
  }
  const session = await createUserSession({
    userId: user.id,
    ipAddress: req.ip ?? null,
    userAgent: req.header("user-agent") ?? null,
  });
  setUserSessionCookie(res, session.rawToken);
  await recordUserActivity(user.id, "USER_REGISTERED", { email });
  res.status(201).json({ user: toPublicUser(user) });
});

// Pre-computed dummy hash so login does the same scrypt work whether or not
// the email exists, blocking timing-based email enumeration. Generated once
// at module load.
const DUMMY_HASH = hashPassword("not-a-real-password-timing-decoy");

router.post("/auth/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "INVALID_INPUT", message: "Email and password are required." });
    return;
  }
  const email = parsed.data.email.trim().toLowerCase();
  const rows = await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1);
  const user = rows[0];
  // Always run scrypt to keep the response time constant regardless of
  // whether the email exists — prevents user-enumeration via timing.
  const hashToCheck = user?.passwordHash ?? DUMMY_HASH;
  const passwordOk = verifyPassword(parsed.data.password, hashToCheck);
  if (!user || !user.passwordHash || !passwordOk) {
    res.status(401).json({ error: "INVALID_CREDENTIALS", message: "Invalid email or password." });
    return;
  }
  await db.update(usersTable).set({ lastLoginAt: new Date() }).where(eq(usersTable.id, user.id));
  const session = await createUserSession({
    userId: user.id,
    ipAddress: req.ip ?? null,
    userAgent: req.header("user-agent") ?? null,
  });
  setUserSessionCookie(res, session.rawToken);
  // Bridge LAYER-1 ↔ LAYER-2: mirror the user's DB role onto the
  // `hr_session` cookie that requireRole() reads. Without this, an
  // admin who logs in via /auth/login (LAYER 2) would still be
  // treated as anonymous by every requireRole()-guarded admin route.
  // Regular USER → VIEWER (read-only safe default), never OWNER/ADMIN.
  const dbRole = String(user.role ?? "USER").toUpperCase();
  const mirroredRole: AuthRole =
    dbRole === "OWNER" ? "OWNER" :
    dbRole === "ADMIN" ? "ADMIN" :
    dbRole === "TESTER" ? "TESTER" :
    "VIEWER";
  setSessionCookie(res, mirroredRole);
  await recordUserActivity(user.id, "USER_LOGGED_IN");
  res.json({ user: toPublicUser({ ...user, lastLoginAt: new Date() }) });
});

router.post("/auth/user-logout", async (req, res) => {
  const cookies = (req as import("express").Request & { cookies?: Record<string, string> }).cookies;
  const raw = cookies?.[USER_SESSION_COOKIE];
  const userId = req.authUser?.id;
  if (raw) await destroyUserSession(raw);
  clearUserSessionCookie(res);
  // Also clear the mirrored role cookie so a subsequent anon session
  // has no leftover ADMIN/OWNER role from the previous user.
  clearSessionCookie(res);
  if (userId) void recordUserActivity(userId, "USER_LOGGED_OUT");
  res.json({ ok: true });
});

router.get("/me", requireUser, (req, res) => {
  // Identity endpoint MUST always reflect the REAL role, never the
  // view-mode-downgraded role. Otherwise an admin in user-view would
  // get role=USER back from /api/me, and the frontend would conclude
  // they have no admin capability — stranding them in user mode with
  // no toggle. The view-mode middleware stashes the real role on
  // `authUser.realRole` before mutating; recover it here.
  const u = req.authUser!;
  const stashed = (u as { realRole?: string }).realRole;
  const realUser = stashed ? { ...u, role: stashed } : u;
  res.json({ user: toPublicUser(realUser) });
});

export default router;
