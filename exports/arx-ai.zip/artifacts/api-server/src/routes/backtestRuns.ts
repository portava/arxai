// (P) Build P — Backtesting & Strategy Validation Engine routes.
//
// Composes:
//   - strategyEngine (runStrategyScan, generateSyntheticCandles, getMarketTypeForSymbol)
//   - @workspace/domain/backtest (pure simulator + metrics)
//   - vault BEHAVIOR audit on every run + AI review
//
// Routes:
//   POST /backtest-runs                 — create + execute a run
//   GET  /backtest-runs                 — list recent runs
//   GET  /backtest-runs/:id             — run by id
//   GET  /backtest-runs/:id/trades      — per-trade detail
//   POST /backtest-runs/:id/ai-review   — generate / refresh AI summary
//
// SAFETY: never mutates trades / live_positions / safetyCore. Pure
// historical simulation. AI review always closes with the spec disclaimer
// "Past performance does not guarantee future results."

import { Router } from "express";
import {
  db, backtestRunsTable, backtestTradesTable, vaultEventsTable,
} from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { z } from "zod/v4";
import {
  simulateBacktest, computeMetrics, summarizeBacktest, isVerificationEligible,
  type BacktestCandle, type BacktestSignal,
} from "@workspace/domain/backtest";
import {
  generateDeterministicCandles, runSingleStrategy, isKnownStrategyId,
  timeframeMs, type StrategyId,
} from "../lib/backtestStrategyRegistry.js";
import type { Candle } from "../lib/strategyEngine.js";

const router = Router();

async function vaultBehavior(kind: string, payload: Record<string, unknown>) {
  await db.insert(vaultEventsTable).values({
    kind, severity: "INFO", source: "SYSTEM", truthDomain: "BEHAVIOR",
    summary: kind, payload, reasons: [], blockers: [],
    generatedAtIso: new Date().toISOString(),
  }).catch(() => { /* non-fatal */ });
}

// ── POST /backtest-runs ───────────────────────────────────────────────────
const ALLOWED_TIMEFRAMES = ["M1","M5","M15","H1","H4","D1"] as const;

const CreateBacktestBody = z.object({
  strategyId: z.string().min(1).max(64),
  symbol: z.string().min(1).max(64),
  timeframe: z.enum(ALLOWED_TIMEFRAMES).default("M1"),
  candleCount: z.number().int().min(50).max(5000).default(500),
  initialBalance: z.number().positive().default(10_000),
  minConfidence: z.number().int().min(0).max(100).default(60),
  // Deterministic seed. If omitted, defaults to the strategy+symbol+timeframe
  // tuple so identical configs reproduce identical results.
  seed: z.string().min(1).max(128).optional(),
});

router.post("/backtest-runs", async (req, res): Promise<void> => {
  try {
    const body = CreateBacktestBody.parse(req.body ?? {});
    if (!isKnownStrategyId(body.strategyId)) {
      res.status(400).json({
        error: "Unknown strategyId",
        allowed: ["trendContinuation","breakOfStructure","liquiditySweep","volatilityExpansion","pullbackContinuation","meanReversion","sessionBreakout"],
      });
      return;
    }
    const strategyId = body.strategyId as StrategyId;
    const seed = body.seed ?? `${strategyId}|${body.symbol}|${body.timeframe}`;
    // Anchor candle stream so endTime is deterministic & spec-compliant
    // (endTime = baseTime + (count-1) * timeframeMs).
    const baseTimeMs = Date.UTC(2024, 0, 1, 0, 0, 0);
    const candles: Candle[] = generateDeterministicCandles({
      symbol: body.symbol, count: body.candleCount,
      timeframe: body.timeframe, seed, baseTimeMs,
    });

    // Pure-domain simulation: route binds the *single* requested strategy
    // (not the multi-strategy scanner) so verification/AI summary attribution
    // is correct.
    const simInput: BacktestCandle[] = candles;
    const signalFn = (window: BacktestCandle[]): BacktestSignal => {
      const sig = runSingleStrategy(strategyId, body.symbol, window as Candle[], body.minConfidence);
      return {
        direction: sig.direction,
        entryPrice: sig.entryPrice,
        stopLoss: sig.stopLoss,
        takeProfit: sig.takeProfit,
        confidence: sig.confidence,
        strategy: sig.strategy,
      };
    };

    const sim = simulateBacktest(body.symbol, simInput, signalFn, body.initialBalance);
    const fallbackEndIso = new Date(baseTimeMs + body.candleCount * timeframeMs(body.timeframe)).toISOString();
    const startCandleTime = candles[0]?.time ?? new Date(baseTimeMs).toISOString();
    const endCandleTime   = candles[candles.length - 1]?.time ?? fallbackEndIso;

    const status = sim.metrics.totalTrades === 0
      ? "INSUFFICIENT_DATA"
      : "COMPLETED";
    const isVerified = sim.metrics.totalTrades > 0 && isVerificationEligible(sim.metrics)
      ? "VERIFIED" : "UNVERIFIED";
    const aiSummary = summarizeBacktest({
      strategyId, symbol: body.symbol,
      timeframe: body.timeframe, metrics: sim.metrics,
    });

    const inserted = await db.insert(backtestRunsTable).values({
      strategyId,
      symbol: body.symbol,
      timeframe: body.timeframe,
      startTime: new Date(startCandleTime),
      endTime: new Date(endCandleTime),
      initialBalance: body.initialBalance,
      totalTrades: sim.metrics.totalTrades,
      winningTrades: sim.metrics.winningTrades,
      losingTrades: sim.metrics.losingTrades,
      netProfitLoss: sim.metrics.netProfitLoss,
      maxDrawdown: sim.metrics.maxDrawdown,
      winRate: sim.metrics.winRate,
      averageRr: sim.metrics.averageRr,
      expectancy: sim.metrics.expectancy,
      profitFactor: sim.metrics.profitFactor,
      status, aiSummary, isVerified,
    }).returning();
    const run = inserted[0]!;

    if (sim.trades.length > 0) {
      await db.insert(backtestTradesTable).values(sim.trades.map((t) => ({
        backtestRunId: run.id,
        symbol: t.symbol, direction: t.direction,
        entryTime: new Date(t.entryTime), exitTime: new Date(t.exitTime),
        entryPrice: t.entryPrice, exitPrice: t.exitPrice,
        stopLoss: t.stopLoss, takeProfit: t.takeProfit,
        profitLoss: t.profitLoss, rewardToRisk: t.rewardToRisk,
        result: t.result,
      })));
    }

    await vaultBehavior("BACKTEST_RUN_COMPLETED", {
      runId: run.id, strategyId, symbol: body.symbol,
      timeframe: body.timeframe, status, isVerified, seed,
      totalTrades: sim.metrics.totalTrades, profitFactor: sim.metrics.profitFactor,
      netPnl: sim.metrics.netProfitLoss,
    });

    res.json({
      ...run,
      startTime: run.startTime.toISOString(),
      endTime: run.endTime.toISOString(),
      createdAt: run.createdAt.toISOString(),
      equityCurve: sim.metrics.equityCurve,
    });
  } catch (err) {
    if (err instanceof z.ZodError) { res.status(400).json({ error: "Invalid backtest request", issues: err.issues }); return; }
    req.log.error({ err: String(err) }, "POST /backtest-runs failed");
    res.status(500).json({ error: "Failed to run backtest" });
  }
});

// ── GET /backtest-runs ────────────────────────────────────────────────────
router.get("/backtest-runs", async (req, res): Promise<void> => {
  try {
    const limit = Math.min(200, Math.max(1, Number(req.query["limit"]) || 50));
    const rows = await db.select().from(backtestRunsTable)
      .orderBy(desc(backtestRunsTable.createdAt)).limit(limit);
    res.json({ runs: rows.map((r) => ({
      ...r,
      startTime: r.startTime.toISOString(),
      endTime: r.endTime.toISOString(),
      createdAt: r.createdAt.toISOString(),
    })) });
  } catch (err) {
    req.log.error({ err: String(err) }, "GET /backtest-runs failed");
    res.status(500).json({ error: "Failed to load runs" });
  }
});

// ── GET /backtest-runs/:id ────────────────────────────────────────────────
router.get("/backtest-runs/:id", async (req, res): Promise<void> => {
  try {
    const id = Number(req.params["id"]);
    if (!Number.isFinite(id)) { res.status(400).json({ error: "Invalid id" }); return; }
    const rows = await db.select().from(backtestRunsTable).where(eq(backtestRunsTable.id, id)).limit(1);
    if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
    const r = rows[0];
    res.json({
      ...r,
      startTime: r.startTime.toISOString(),
      endTime: r.endTime.toISOString(),
      createdAt: r.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error({ err: String(err) }, "GET /backtest-runs/:id failed");
    res.status(500).json({ error: "Failed to load run" });
  }
});

// ── GET /backtest-runs/:id/trades ─────────────────────────────────────────
router.get("/backtest-runs/:id/trades", async (req, res): Promise<void> => {
  try {
    const id = Number(req.params["id"]);
    if (!Number.isFinite(id)) { res.status(400).json({ error: "Invalid id" }); return; }
    const rows = await db.select().from(backtestTradesTable)
      .where(eq(backtestTradesTable.backtestRunId, id))
      .orderBy(backtestTradesTable.entryTime);
    res.json({ trades: rows.map((t) => ({
      ...t,
      entryTime: t.entryTime.toISOString(),
      exitTime: t.exitTime.toISOString(),
      createdAt: t.createdAt.toISOString(),
    })) });
  } catch (err) {
    req.log.error({ err: String(err) }, "GET /backtest-runs/:id/trades failed");
    res.status(500).json({ error: "Failed to load trades" });
  }
});

// ── POST /backtest-runs/:id/ai-review ─────────────────────────────────────
router.post("/backtest-runs/:id/ai-review", async (req, res): Promise<void> => {
  try {
    const id = Number(req.params["id"]);
    if (!Number.isFinite(id)) { res.status(400).json({ error: "Invalid id" }); return; }
    const runs = await db.select().from(backtestRunsTable).where(eq(backtestRunsTable.id, id)).limit(1);
    const run = runs[0];
    if (!run) { res.status(404).json({ error: "Not found" }); return; }
    const trades = await db.select().from(backtestTradesTable)
      .where(eq(backtestTradesTable.backtestRunId, id))
      .orderBy(backtestTradesTable.entryTime);

    // Recompute equity curve so we can re-summarize without storing it.
    const equity = [run.initialBalance];
    let eq2 = run.initialBalance;
    for (const t of trades) { eq2 += t.profitLoss; equity.push(eq2); }
    const metrics = computeMetrics(
      trades.map((t) => ({
        symbol: t.symbol, direction: t.direction as "BUY" | "SELL",
        entryTime: t.entryTime.toISOString(), exitTime: t.exitTime.toISOString(),
        entryPrice: t.entryPrice, exitPrice: t.exitPrice,
        stopLoss: t.stopLoss, takeProfit: t.takeProfit,
        profitLoss: t.profitLoss, rewardToRisk: t.rewardToRisk,
        result: t.result as "WIN" | "LOSS" | "BREAKEVEN" | "TIMEOUT",
      })),
      run.initialBalance, equity,
    );
    const aiSummary = summarizeBacktest({
      strategyId: run.strategyId, symbol: run.symbol,
      timeframe: run.timeframe, metrics,
    });

    await db.update(backtestRunsTable).set({ aiSummary }).where(eq(backtestRunsTable.id, id));
    await vaultBehavior("BACKTEST_AI_REVIEW_GENERATED", { runId: id });
    res.json({ id, aiSummary, metrics });
  } catch (err) {
    req.log.error({ err: String(err) }, "POST /backtest-runs/:id/ai-review failed");
    res.status(500).json({ error: "Failed to generate AI review" });
  }
});

// Export latest VERIFIED run summary per strategy for the strategy-fit
// scoring engine to consume (read-only). Future build can pull from this.
export async function getLatestVerifiedRunForStrategy(strategyId: string): Promise<typeof backtestRunsTable.$inferSelect | null> {
  const rows = await db.select().from(backtestRunsTable)
    .where(eq(backtestRunsTable.strategyId, strategyId))
    .orderBy(desc(backtestRunsTable.createdAt)).limit(20);
  return rows.find((r) => r.isVerified === "VERIFIED") ?? null;
}

export default router;
