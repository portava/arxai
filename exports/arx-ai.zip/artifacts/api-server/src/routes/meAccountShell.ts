// Phase Account-Shell — Unified per-user "My Account" view.
//
// Single aggregator endpoint that joins existing per-user data into a
// uniform shape across all 3 routing modes (Demo / Personal MT5 /
// Shared Master MT5). NO schema changes — every field is computed
// from tables that already exist.
//
// SAFETY:
//   * Every query scopes by req.authUser.id. Cross-user reads are
//     structurally impossible.
//   * Never returns master broker credentials, bridge tokens, IPs,
//     account numbers, or any other user's data.
//   * NOT shown to normal users: full shared-master global balance.
//     They see ONLY their own assigned allocation slice + personal P/L.
//   * Pure read. No execution. No queue inserts. No live broker call.

import { Router } from "express";
import { db } from "@workspace/db";
import {
  virtualTradingAccountsTable,
  sharedTradeAttributionTable,
  userRiskSettingsTable,
  userMasterLiveAccessTable,
  performanceDailyTable,
  paperTradesTable,
  globalTradingSettingsTable,
  userTradingPermissionsTable,
  mt5ConnectionTable,
} from "@workspace/db/schema";
import { and, asc, eq, isNull } from "drizzle-orm";
import { requireUser } from "../lib/auth/middleware.js";

const router = Router();

export type AccountShellResponse = {
  ok: true;
  userId: number;
  // Mode + status
  accountMode: "DEMO" | "PERSONAL_MT5" | "SHARED_MASTER_MT5";
  // Per-user trading mode literally as set by the operator. Spec mapping:
  //   PAPER ≡ SIMULATED. Defaults to DISABLED for new users.
  tradingMode: "DISABLED" | "SIMULATED" | "DEMO" | "LIVE";
  tradingModeLabel: string;
  tradingModeUpdatedAt: string | null;
  previousTradingMode: string | null;
  approvalStatus:
    | "NOT_REQUIRED"
    | "NOT_APPROVED"
    | "APPROVED"
    | "SUSPENDED"
    | "RISK_LOCKED"
    | "DISABLED";
  tradingStatus: "ACTIVE" | "WAITING_APPROVAL" | "PAUSED" | "RESTRICTED" | "NEEDS_REVIEW";
  // Money view — user's own slice only.
  allocation: {
    assignedStartingBalance: number | null;
    currentBalance: number;
    equity: number;
    marginUsed: number;
  };
  pnl: {
    openPnl: number;
    closedPnlToday: number;
    closedPnlWeek: number;
    closedPnlTotal: number;
    tradesToday: number;
    winsToday: number;
    lossesToday: number;
  };
  risk: {
    availableRiskAmount: number | null;
    dailyLossRemaining: number | null;
    openExposureLots: number;
    maxLotSize: number | null;
    maxOpenTrades: number | null;
    maxDailyLossAmount: number | null;
    maxExposurePerSymbolLots: number | null;
    allowedSymbols: string[] | null; // null = all symbols allowed
    requireStopLoss: boolean;
  };
  // For UI banners. Never leaks other users' data.
  notes: {
    needsReviewItems: number;
    sharedMasterAccountAssigned: boolean;
  };
};

// Exported so Ruby (the assistant) can call it directly without an HTTP
// round-trip. Same per-user scoping; same shape; never returns other
// users' data or master credentials.
export async function computeAccountShell(userId: number): Promise<AccountShellResponse> {
    // 1) Routing + trading mode — STRICTLY READ-ONLY. We intentionally do
    //    NOT call getEnvelope() here because its getGlobalSettings() helper
    //    seeds a fail-closed row on first read (a write-on-read side effect).
    //    A user-facing GET must never mutate state, so we SELECT both
    //    singletons directly. Missing rows fall back to safe defaults.
    const [globalRows, permRows, mt5Rows] = await Promise.all([
      db.select({
        platformMode: globalTradingSettingsTable.platformMode,
        accountRoutingMode: globalTradingSettingsTable.accountRoutingMode,
      })
        .from(globalTradingSettingsTable)
        .orderBy(asc(globalTradingSettingsTable.id))
        .limit(1),
      db.select({
        accountRoutingOverride: userTradingPermissionsTable.accountRoutingOverride,
        tradingMode: userTradingPermissionsTable.tradingMode,
        previousTradingMode: userTradingPermissionsTable.previousTradingMode,
        tradingModeUpdatedAt: userTradingPermissionsTable.tradingModeUpdatedAt,
      })
        .from(userTradingPermissionsTable)
        .where(eq(userTradingPermissionsTable.userId, userId))
        .limit(1),
      db.select({ accountType: mt5ConnectionTable.accountType })
        .from(mt5ConnectionTable)
        .where(eq(mt5ConnectionTable.userId, userId))
        .limit(1),
    ]);
    const globalRow = globalRows[0];
    const globalRoutingMode: "USER_OWNED_MT5" | "SHARED_MASTER_MT5" =
      globalRow?.accountRoutingMode === "SHARED_MASTER_MT5" ? "SHARED_MASTER_MT5" : "USER_OWNED_MT5";
    const override = String(permRows[0]?.accountRoutingOverride ?? "inherit").toLowerCase();
    const routingMode: "USER_OWNED_MT5" | "SHARED_MASTER_MT5" =
      override === "user_owned_mt5" ? "USER_OWNED_MT5"
        : override === "shared_master_mt5" ? "SHARED_MASTER_MT5"
        : globalRoutingMode;
    const platformMode = String(globalRow?.platformMode ?? "OFF").toUpperCase();
    const mt5AccountType = String(mt5Rows[0]?.accountType ?? "").toLowerCase();
    const tradingMode: "DISABLED" | "SIMULATED" | "DEMO" | "LIVE" =
      platformMode === "LIVE" ? "LIVE"
        : platformMode === "DEMO" ? "DEMO"
        : platformMode === "SIMULATED" ? "SIMULATED"
        : "DISABLED";
    const accountMode: AccountShellResponse["accountMode"] =
      routingMode === "SHARED_MASTER_MT5"
        ? "SHARED_MASTER_MT5"
        : (mt5AccountType === "live" || mt5AccountType === "real") && tradingMode === "LIVE"
          ? "PERSONAL_MT5"
          : "DEMO";

    // 2) Virtual account slice (SHARED_MASTER_MT5 only).
    const vAccounts = await db
      .select({
        virtualBalance: virtualTradingAccountsTable.virtualBalance,
        virtualEquity: virtualTradingAccountsTable.virtualEquity,
        virtualMarginUsed: virtualTradingAccountsTable.virtualMarginUsed,
        virtualPnl: virtualTradingAccountsTable.virtualPnl,
        status: virtualTradingAccountsTable.status,
        sharedMasterAccountId: virtualTradingAccountsTable.sharedMasterAccountId,
      })
      .from(virtualTradingAccountsTable)
      .where(eq(virtualTradingAccountsTable.userId, userId));

    const allocatedBalance = vAccounts.reduce((s, a) => s + Number(a.virtualBalance || 0), 0);
    const allocatedEquity = vAccounts.reduce((s, a) => s + Number(a.virtualEquity || 0), 0);
    const allocatedMargin = vAccounts.reduce((s, a) => s + Number(a.virtualMarginUsed || 0), 0);
    const allocatedOpenPnl = vAccounts.reduce((s, a) => s + Number(a.virtualPnl || 0), 0);
    const sharedMasterAssigned = vAccounts.some(
      (a) => a.sharedMasterAccountId != null && a.status === "active"
    );

    // 3) Master live access (hard limits + approval).
    const [mla] = await db
      .select()
      .from(userMasterLiveAccessTable)
      .where(eq(userMasterLiveAccessTable.userId, userId))
      .limit(1);

    // 4) Advisory risk settings.
    const [rs] = await db
      .select()
      .from(userRiskSettingsTable)
      .where(eq(userRiskSettingsTable.userId, userId))
      .limit(1);

    // 5) Performance — closed P/L today / week / total + counts.
    const today = new Date().toISOString().slice(0, 10);
    const weekAgo = new Date(Date.now() - 7 * 86400_000).toISOString().slice(0, 10);
    const perfRows = await db
      .select({
        date: performanceDailyTable.date,
        pnl: performanceDailyTable.pnl,
        trades: performanceDailyTable.trades,
        wins: performanceDailyTable.wins,
        losses: performanceDailyTable.losses,
      })
      .from(performanceDailyTable)
      .where(eq(performanceDailyTable.userId, userId));

    const todayRow = perfRows.find((r) => r.date === today);
    const closedPnlToday = todayRow ? Number(todayRow.pnl || 0) : 0;
    const tradesToday = todayRow ? Number(todayRow.trades || 0) : 0;
    const winsToday = todayRow ? Number(todayRow.wins || 0) : 0;
    const lossesToday = todayRow ? Number(todayRow.losses || 0) : 0;
    const closedPnlWeek = perfRows
      .filter((r) => r.date >= weekAgo)
      .reduce((s, r) => s + Number(r.pnl || 0), 0);
    const closedPnlTotal = perfRows.reduce((s, r) => s + Number(r.pnl || 0), 0);

    // 6) Open exposure & open P/L (per-user). For SHARED_MASTER_MT5 use
    //    open attributions; otherwise use open paper trades. Both already
    //    scoped by userId.
    let openExposureLots = 0;
    let openPnl = allocatedOpenPnl;
    if (routingMode === "SHARED_MASTER_MT5") {
      const openAtts = await db
        .select({
          lotSize: sharedTradeAttributionTable.lotSize,
        })
        .from(sharedTradeAttributionTable)
        .where(
          and(
            eq(sharedTradeAttributionTable.userId, userId),
            isNull(sharedTradeAttributionTable.closedAt)
          )
        );
      openExposureLots = openAtts.reduce((s, r) => s + Number(r.lotSize || 0), 0);
    } else {
      const openPapers = await db
        .select({
          lotSize: paperTradesTable.lotSize,
          pnl: paperTradesTable.pnl,
        })
        .from(paperTradesTable)
        .where(
          and(
            eq(paperTradesTable.userId, userId),
            eq(paperTradesTable.status, "open")
          )
        );
      openExposureLots = openPapers.reduce((s, r) => s + Number(r.lotSize || 0), 0);
      openPnl = openPapers.reduce((s, r) => s + Number(r.pnl || 0), 0);
    }

    // 7) Approval + trading status.
    const approvalStatus: AccountShellResponse["approvalStatus"] =
      accountMode === "SHARED_MASTER_MT5"
        ? ((mla?.masterLiveStatus as AccountShellResponse["approvalStatus"]) ?? "NOT_APPROVED")
        : accountMode === "PERSONAL_MT5"
          ? "APPROVED"
          : "NOT_REQUIRED";

    const tradingStatus: AccountShellResponse["tradingStatus"] =
      tradingMode === "DISABLED"
        ? "RESTRICTED"
        : approvalStatus === "NOT_APPROVED" && accountMode === "SHARED_MASTER_MT5"
          ? "WAITING_APPROVAL"
          : approvalStatus === "SUSPENDED" || approvalStatus === "DISABLED"
            ? "PAUSED"
            : approvalStatus === "RISK_LOCKED"
              ? "RESTRICTED"
              : "ACTIVE";

    // 8) Risk view — merge hard limits (master live access) with advisory.
    const maxLotSize = mla?.maxLot != null
      ? Number(mla.maxLot)
      : rs?.maxPositionSize != null
        ? Number(rs.maxPositionSize)
        : null;
    const maxOpenTrades = mla?.maxOpenPositions != null
      ? Number(mla.maxOpenPositions)
      : rs?.maxOpenTrades != null
        ? Number(rs.maxOpenTrades)
        : null;
    const maxDailyLossAmount = mla?.dailyLossLimitUsd != null
      ? Number(mla.dailyLossLimitUsd)
      : rs?.maxDailyLossAmount != null
        ? Number(rs.maxDailyLossAmount)
        : null;
    const maxExposurePerSymbolLots = mla?.maxExposurePerSymbolLots != null
      ? Number(mla.maxExposurePerSymbolLots)
      : null;
    // allowed_symbols: jsonb default '[]'. Empty array means "no
    // restriction" today by convention; non-empty means whitelist.
    const allowedSymbolsRaw = (mla?.allowedSymbols ?? []) as unknown;
    const allowedSymbols = Array.isArray(allowedSymbolsRaw) && allowedSymbolsRaw.length > 0
      ? (allowedSymbolsRaw as string[])
      : null;

    const dailyLossRemaining = maxDailyLossAmount != null
      ? Math.max(0, maxDailyLossAmount - Math.max(0, -closedPnlToday))
      : null;
    // Best-effort available risk: per-trade % of current balance, if known.
    const baseBalance = allocatedBalance > 0
      ? allocatedBalance
      : (todayRow?.pnl != null ? 10000 + Number(todayRow.pnl) : 10000);
    const availableRiskAmount = rs?.maxRiskPerTradePercent != null
      ? (Number(rs.maxRiskPerTradePercent) / 100) * baseBalance
      : null;

    const perUserTradingMode = (() => {
      const raw = String(permRows[0]?.tradingMode ?? "DISABLED").toUpperCase();
      return (raw === "SIMULATED" || raw === "DEMO" || raw === "LIVE") ? raw : "DISABLED";
    })() as "DISABLED" | "SIMULATED" | "DEMO" | "LIVE";
    const tradingModeLabel = (() => {
      switch (perUserTradingMode) {
        case "SIMULATED": return "Paper Mode — simulated only.";
        case "DEMO": return "Demo Mode — no real-money order.";
        case "LIVE": return "Live Mode — real account risk. Review before confirming.";
        default: return "Your operator has not enabled trading.";
      }
    })();

    const response: AccountShellResponse = {
      ok: true,
      userId,
      accountMode,
      tradingMode: perUserTradingMode,
      tradingModeLabel,
      tradingModeUpdatedAt: permRows[0]?.tradingModeUpdatedAt
        ? new Date(permRows[0].tradingModeUpdatedAt).toISOString() : null,
      previousTradingMode: permRows[0]?.previousTradingMode ?? null,
      approvalStatus,
      tradingStatus,
      allocation: {
        assignedStartingBalance: vAccounts.length > 0 ? allocatedBalance : null,
        currentBalance: allocatedBalance,
        equity: allocatedEquity || allocatedBalance,
        marginUsed: allocatedMargin,
      },
      pnl: {
        openPnl,
        closedPnlToday,
        closedPnlWeek,
        closedPnlTotal,
        tradesToday,
        winsToday,
        lossesToday,
      },
      risk: {
        availableRiskAmount,
        dailyLossRemaining,
        openExposureLots,
        maxLotSize,
        maxOpenTrades,
        maxDailyLossAmount,
        maxExposurePerSymbolLots,
        allowedSymbols,
        requireStopLoss: mla?.requireStopLoss ?? rs?.requireStopLoss ?? true,
      },
      notes: {
        needsReviewItems: 0, // surfaced to admins only; users see 0
        sharedMasterAccountAssigned: sharedMasterAssigned,
      },
    };

    return response;
}

// ── GET /api/me/account-shell ──────────────────────────────────────────────
router.get("/me/account-shell", requireUser, async (req, res) => {
  const userId = req.authUser!.id;
  try {
    const response = await computeAccountShell(userId);
    res.json(response);
  } catch (e) {
    req.log.warn({ err: (e as Error).message }, "me_account_shell_failed");
    res.status(500).json({ ok: false, error: "ACCOUNT_SHELL_UNAVAILABLE" });
  }
});

export default router;
