// P0-1 — Per-user Shared Account API surface.
//
// In SHARED_MASTER_MT5 mode, each user has a virtual ledger row on the
// shared master account. These routes give the user a read-only window
// into their own virtual balance, attribution history, and open
// attributed positions. They DO NOT expose:
//   - Master broker credentials (apiKeyHash, accountLogin, server, etc).
//   - Any other user's data.
//   - Any execution capability — these are read-only.
//
// SAFETY:
//   * Every query scopes by req.authUser.id. Cross-user reads are
//     structurally impossible.
//   * No secret-named fields returned. We project explicit columns; we do
//     NOT return entire rows from mt5_connection.
//   * No execution. No order placement. No live-trade flags toggled.

import { Router } from "express";
import { db } from "@workspace/db";
import {
  virtualTradingAccountsTable,
  sharedTradeAttributionTable,
  sharedMasterAccountsTable,
} from "@workspace/db/schema";
import { and, desc, eq, sql } from "drizzle-orm";
import { requireUser } from "../lib/auth/middleware.js";

const router = Router();

// ── GET /api/me/shared-account/summary ─────────────────────────────────────
// Aggregate read for the current user across every virtual account row
// they hold (one per shared master account + accountType). Returns:
//   - per-account virtualBalance / virtualEquity / virtualPnl / marginUsed
//   - the masked master account info (NO credentials)
//   - openAttributions count + last 7-day realized PnL sum
router.get("/me/shared-account/summary", requireUser, async (req, res) => {
  const userId = req.authUser!.id;
  try {
    const accounts = await db.select({
      id: virtualTradingAccountsTable.id,
      routingMode: virtualTradingAccountsTable.routingMode,
      sharedMasterAccountId: virtualTradingAccountsTable.sharedMasterAccountId,
      accountType: virtualTradingAccountsTable.accountType,
      virtualBalance: virtualTradingAccountsTable.virtualBalance,
      virtualEquity: virtualTradingAccountsTable.virtualEquity,
      virtualMarginUsed: virtualTradingAccountsTable.virtualMarginUsed,
      virtualPnl: virtualTradingAccountsTable.virtualPnl,
      status: virtualTradingAccountsTable.status,
      updatedAt: virtualTradingAccountsTable.updatedAt,
      masterBrokerName: sharedMasterAccountsTable.brokerName,
      masterAccountNumberMasked: sharedMasterAccountsTable.accountNumberMasked,
      masterStatus: sharedMasterAccountsTable.status,
    })
      .from(virtualTradingAccountsTable)
      .leftJoin(
        sharedMasterAccountsTable,
        eq(sharedMasterAccountsTable.id, virtualTradingAccountsTable.sharedMasterAccountId),
      )
      .where(eq(virtualTradingAccountsTable.userId, userId));

    // Open attribution count per virtual account.
    const openByAccount = await db.select({
      virtualAccountId: sharedTradeAttributionTable.virtualAccountId,
      count: sql<number>`count(*)::int`,
    })
      .from(sharedTradeAttributionTable)
      .where(and(
        eq(sharedTradeAttributionTable.userId, userId),
        eq(sharedTradeAttributionTable.status, "open"),
      ))
      .groupBy(sharedTradeAttributionTable.virtualAccountId);
    const openMap = new Map<number, number>(
      openByAccount.map(r => [r.virtualAccountId, Number(r.count)]),
    );

    // 7-day realized P&L per virtual account (applied closes only).
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const realized7d = await db.select({
      virtualAccountId: sharedTradeAttributionTable.virtualAccountId,
      sum: sql<number>`coalesce(sum(${sharedTradeAttributionTable.pnl}),0)::float8`,
    })
      .from(sharedTradeAttributionTable)
      .where(and(
        eq(sharedTradeAttributionTable.userId, userId),
        eq(sharedTradeAttributionTable.status, "closed"),
        sql`${sharedTradeAttributionTable.realizedAppliedAt} is not null and ${sharedTradeAttributionTable.realizedAppliedAt} >= ${sevenDaysAgo}`,
      ))
      .groupBy(sharedTradeAttributionTable.virtualAccountId);
    const realizedMap = new Map<number, number>(
      realized7d.map(r => [r.virtualAccountId, Number(r.sum)]),
    );

    res.json({
      ok: true,
      userId,
      accounts: accounts.map(a => ({
        ...a,
        openAttributions: openMap.get(a.id) ?? 0,
        realizedPnl7d: realizedMap.get(a.id) ?? 0,
      })),
    });
  } catch (e) {
    req.log?.error({ err: e }, "me_shared_account_summary_failed");
    res.status(500).json({ ok: false, error: "summary_failed" });
  }
});

// ── GET /api/me/shared-account/attributions ────────────────────────────────
// Paged history of THIS user's shared_trade_attribution rows. Query params:
//   ?status=open|closed|pending|rejected|failed   (optional)
//   ?limit=50 (max 200)   ?offset=0
router.get("/me/shared-account/attributions", requireUser, async (req, res) => {
  const userId = req.authUser!.id;
  const limit = Math.min(Math.max(parseInt(String(req.query.limit ?? "50"), 10) || 50, 1), 200);
  const offset = Math.max(parseInt(String(req.query.offset ?? "0"), 10) || 0, 0);
  const status = typeof req.query.status === "string" ? req.query.status : null;
  try {
    const where = status
      ? and(
          eq(sharedTradeAttributionTable.userId, userId),
          eq(sharedTradeAttributionTable.status, status),
        )
      : eq(sharedTradeAttributionTable.userId, userId);
    const rows = await db.select({
      id: sharedTradeAttributionTable.id,
      virtualAccountId: sharedTradeAttributionTable.virtualAccountId,
      sharedMasterAccountId: sharedTradeAttributionTable.sharedMasterAccountId,
      symbol: sharedTradeAttributionTable.symbol,
      side: sharedTradeAttributionTable.side,
      lotSize: sharedTradeAttributionTable.lotSize,
      entryPrice: sharedTradeAttributionTable.entryPrice,
      closePrice: sharedTradeAttributionTable.closePrice,
      stopLoss: sharedTradeAttributionTable.stopLoss,
      takeProfit: sharedTradeAttributionTable.takeProfit,
      pnl: sharedTradeAttributionTable.pnl,
      fees: sharedTradeAttributionTable.fees,
      slippage: sharedTradeAttributionTable.slippage,
      status: sharedTradeAttributionTable.status,
      rejectionReason: sharedTradeAttributionTable.rejectionReason,
      openedAt: sharedTradeAttributionTable.openedAt,
      closedAt: sharedTradeAttributionTable.closedAt,
      realizedAppliedAt: sharedTradeAttributionTable.realizedAppliedAt,
      createdAt: sharedTradeAttributionTable.createdAt,
    })
      .from(sharedTradeAttributionTable)
      .where(where)
      .orderBy(desc(sharedTradeAttributionTable.createdAt))
      .limit(limit)
      .offset(offset);
    res.json({ ok: true, userId, count: rows.length, limit, offset, rows });
  } catch (e) {
    req.log?.error({ err: e }, "me_shared_account_attributions_failed");
    res.status(500).json({ ok: false, error: "attributions_failed" });
  }
});

// ── GET /api/me/shared-account/positions ───────────────────────────────────
// Open attribution rows only — the "live exposure" view of this user's
// shared-master positions.
router.get("/me/shared-account/positions", requireUser, async (req, res) => {
  const userId = req.authUser!.id;
  try {
    const rows = await db.select({
      id: sharedTradeAttributionTable.id,
      virtualAccountId: sharedTradeAttributionTable.virtualAccountId,
      sharedMasterAccountId: sharedTradeAttributionTable.sharedMasterAccountId,
      symbol: sharedTradeAttributionTable.symbol,
      side: sharedTradeAttributionTable.side,
      lotSize: sharedTradeAttributionTable.lotSize,
      entryPrice: sharedTradeAttributionTable.entryPrice,
      stopLoss: sharedTradeAttributionTable.stopLoss,
      takeProfit: sharedTradeAttributionTable.takeProfit,
      slippage: sharedTradeAttributionTable.slippage,
      openedAt: sharedTradeAttributionTable.openedAt,
      mt5PositionTicket: sharedTradeAttributionTable.mt5PositionTicket,
    })
      .from(sharedTradeAttributionTable)
      .where(and(
        eq(sharedTradeAttributionTable.userId, userId),
        eq(sharedTradeAttributionTable.status, "open"),
      ))
      .orderBy(desc(sharedTradeAttributionTable.openedAt));
    res.json({ ok: true, userId, count: rows.length, rows });
  } catch (e) {
    req.log?.error({ err: e }, "me_shared_account_positions_failed");
    res.status(500).json({ ok: false, error: "positions_failed" });
  }
});

export default router;
