// Phase B — EA-facing LIVE execution endpoints.
//
// SAFETY (inviolable):
// - All routes are guarded by `bridgeAuthPerUserOnly`. Server-wide
//   server-wide bridge token env value is REJECTED.
// - Every route asserts `mt5Connection.accountType` is "live" or "real".
//   Demo bridges hitting these endpoints are refused with 403
//   BRIDGE_NOT_LIVE_ACCOUNT.
// - Live commands are NEVER read or written by the demo poll endpoints, and
//   vice versa — the demo path (`/api/mt5/demo-commands-poll`) reads only
//   from `mt5_demo_commands`; this file reads only from `arx_live_commands`.
// - Per-user isolation: every query is scoped by `req.mt5Connection.userId`.

import { Router, type Request, type Response } from "express";
import { and, eq } from "drizzle-orm";
import { db, arxLiveCommandsTable, arxLivePositionsTable, mt5ConnectionTable } from "@workspace/db";
import { bridgeAuthPerUserOnly } from "./mt5.js";
import {
  pickupNextLiveCommand,
  recordLiveCommandResult,
} from "../lib/live/liveCommandPipeline.js";

const router = Router();

interface AugReq extends Request {
  mt5Connection?: typeof mt5ConnectionTable.$inferSelect;
}

function requireLiveBridge(req: AugReq, res: Response): typeof mt5ConnectionTable.$inferSelect | null {
  const conn = req.mt5Connection;
  if (!conn) {
    res.status(401).json({ error: "BRIDGE_AUTH_REQUIRED" });
    return null;
  }
  const acct = (conn.accountType ?? "").toLowerCase();
  if (acct !== "live" && acct !== "real") {
    res.status(403).json({
      error: "BRIDGE_NOT_LIVE_ACCOUNT",
      detail: `Live endpoints require accountType=live/real. Bridge reports "${conn.accountType ?? "?"}".`,
    });
    return null;
  }
  // Phase B MOCK refusal at the EA-facing edge. A MOCK placeholder cannot
  // poll live commands or write live results even if its accountType
  // column reads 'live'. The heartbeat ingest path is what lifts a real
  // EA out of MOCK (mode -> LIVE on first heartbeat with accountType).
  if (conn.mode === "MOCK") {
    res.status(403).json({
      error: "BRIDGE_IS_MOCK_NOT_LIVE_CAPABLE",
      detail: `Bridge ${conn.id} is a MOCK placeholder. A real MT5 EA must POST /api/mt5/heartbeat with accountType=live/real before live endpoints accept it.`,
    });
    return null;
  }
  if (conn.userId == null) {
    res.status(401).json({ error: "BRIDGE_NO_USER_ATTRIBUTION" });
    return null;
  }
  return conn;
}

const LIVE_SAFETY_ENVELOPE = {
  safetyMode: "phase_b_live" as const,
  liveDispatchPath: "phase_b" as const,
  perUserIsolation: true as const,
};

// ── POST /api/mt5/live-commands-poll ───────────────────────────────────────
// EA pulls the next SENT_TO_MT5_LIVE command for its bridge.
router.post("/mt5/live-commands-poll", bridgeAuthPerUserOnly, async (req: AugReq, res) => {
  const conn = requireLiveBridge(req, res);
  if (!conn) return;
  const result = await pickupNextLiveCommand({
    userId: conn.userId!,
    bridgeConnectionId: conn.id,
    bridgeAccountType: conn.accountType,
  });
  if (result.refusalReason) {
    res.status(403).json({ error: result.refusalReason, ...LIVE_SAFETY_ENVELOPE });
    return;
  }
  if (!result.command) {
    res.json({ command: null, ...LIVE_SAFETY_ENVELOPE });
    return;
  }
  const c = result.command;
  res.json({
    command: {
      commandId: c.commandId,
      commandType: c.commandType,
      symbol: c.symbol,
      side: c.side,
      orderType: c.orderType,
      requestedVolume: c.requestedVolume,
      stopLoss: c.stopLoss,
      takeProfit: c.takeProfit,
      payload: c.payload,
      accountLogin: c.accountLogin,
      brokerServer: c.brokerServer,
    },
    ...LIVE_SAFETY_ENVELOPE,
  });
});

// ── POST /api/mt5/live-command-result ──────────────────────────────────────
// EA reports a LIVE_FILLED / LIVE_REJECTED / LIVE_FAILED outcome.
router.post("/mt5/live-command-result", bridgeAuthPerUserOnly, async (req: AugReq, res) => {
  const conn = requireLiveBridge(req, res);
  if (!conn) return;
  const b = (req.body ?? {}) as Record<string, unknown>;
  const commandId = typeof b["commandId"] === "string" ? b["commandId"] : null;
  // EA v1.27 posts the result under the field name `status`. Earlier
  // server drafts used `outcome`. Accept BOTH for forward/backward
  // compatibility — otherwise live commands would be trapped in
  // SENT_TO_MT5_LIVE and the EA loop could re-execute them.
  const outcomeRaw =
    typeof b["status"] === "string" ? b["status"]
    : typeof b["outcome"] === "string" ? b["outcome"]
    : null;
  const allowedOutcomes = ["LIVE_FILLED", "LIVE_REJECTED", "LIVE_FAILED"] as const;
  if (!commandId || !outcomeRaw || !(allowedOutcomes as readonly string[]).includes(outcomeRaw)) {
    res.status(400).json({ error: "INVALID_BODY", detail: "commandId and status required" });
    return;
  }
  const outcome = outcomeRaw as (typeof allowedOutcomes)[number];

  // Ownership re-check: the command must belong to this bridge's user.
  const owned = await db.select().from(arxLiveCommandsTable)
    .where(and(eq(arxLiveCommandsTable.commandId, commandId), eq(arxLiveCommandsTable.userId, conn.userId!)))
    .limit(1);
  if (!owned[0]) {
    res.status(404).json({ error: "COMMAND_NOT_FOUND_FOR_USER" });
    return;
  }

  const result = await recordLiveCommandResult({
    userId: conn.userId!,
    commandId,
    outcome,
    reportingBridgeConnectionId: conn.id,
    brokerTicket: typeof b["brokerTicket"] === "string" || typeof b["brokerTicket"] === "number" ? String(b["brokerTicket"]) : null,
    fillPrice: typeof b["fillPrice"] === "number" ? Number(b["fillPrice"]) : null,
    executedVolume: typeof b["executedVolume"] === "number" ? Number(b["executedVolume"]) : null,
    mt5Retcode: typeof b["mt5Retcode"] === "number" ? Number(b["mt5Retcode"]) : null,
    brokerMessage: typeof b["brokerMessage"] === "string" ? String(b["brokerMessage"]) : null,
  });
  res.status(result.ok ? 200 : 409).json({ ...result, ...LIVE_SAFETY_ENVELOPE });
});

// ── POST /api/mt5/sync-live-positions ──────────────────────────────────────
// EA pushes the full snapshot of currently-open live positions for this
// bridge. Server upserts on (userId, brokerTicket). Positions absent from
// the snapshot are NOT auto-closed here — auto-close is ALERT_ONLY.
router.post("/mt5/sync-live-positions", bridgeAuthPerUserOnly, async (req: AugReq, res) => {
  const conn = requireLiveBridge(req, res);
  if (!conn) return;
  const b = (req.body ?? {}) as Record<string, unknown>;
  const positions = Array.isArray(b["positions"]) ? (b["positions"] as Array<Record<string, unknown>>) : [];

  let upserts = 0;
  for (const p of positions) {
    // EA v1.27 sends the field as `brokerTicket`; older drafts used `ticket`.
    const ticketRaw = p["brokerTicket"] ?? p["ticket"];
    const ticket = typeof ticketRaw === "string" || typeof ticketRaw === "number" ? String(ticketRaw) : null;
    const symbol = typeof p["symbol"] === "string" ? p["symbol"] : null;
    const side = typeof p["side"] === "string" ? p["side"] : null;
    const volume = typeof p["volume"] === "number" ? Number(p["volume"]) : null;
    const entryPrice = typeof p["entryPrice"] === "number" ? Number(p["entryPrice"]) : null;
    const openedAtRaw = typeof p["openedAt"] === "string" ? p["openedAt"] : null;
    if (!ticket || !symbol || !side || volume == null || entryPrice == null || !openedAtRaw) continue;
    const openedAt = new Date(openedAtRaw);
    if (Number.isNaN(openedAt.getTime())) continue;

    const existing = await db.select().from(arxLivePositionsTable)
      .where(and(
        eq(arxLivePositionsTable.userId, conn.userId!),
        eq(arxLivePositionsTable.brokerTicket, ticket),
      )).limit(1);

    const common = {
      symbol,
      side,
      volume,
      entryPrice,
      currentPrice: typeof p["currentPrice"] === "number" ? Number(p["currentPrice"]) : null,
      floatingPl: typeof p["floatingPl"] === "number" ? Number(p["floatingPl"]) : null,
      stopLoss: typeof p["stopLoss"] === "number" ? Number(p["stopLoss"]) : null,
      takeProfit: typeof p["takeProfit"] === "number" ? Number(p["takeProfit"]) : null,
      bridgeConnectionId: conn.id,
      accountLogin: conn.accountNumber,
      brokerServer: conn.brokerName,
      lastSyncedAt: new Date(),
    };
    if (existing[0]) {
      await db.update(arxLivePositionsTable).set(common)
        .where(eq(arxLivePositionsTable.id, existing[0].id));
    } else {
      await db.insert(arxLivePositionsTable).values({
        userId: conn.userId!,
        brokerTicket: ticket,
        openedAt,
        sourceCommandId: typeof p["sourceCommandId"] === "string" ? p["sourceCommandId"] : null,
        ...common,
      });
    }
    upserts += 1;
  }
  res.json({ ok: true, upserts, received: positions.length, ...LIVE_SAFETY_ENVELOPE });
});

export default router;
