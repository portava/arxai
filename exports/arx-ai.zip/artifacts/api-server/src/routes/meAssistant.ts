// Phase 13 — ARX AI Live Assistant routes.
// SAFETY: requireUser; every conversation/message/tool call scoped by
// req.authUser.id. The assistant cannot place trades, modify connections,
// reveal secrets, or read another user's data. Streaming uses SSE.
//
// Endpoints:
//   GET  /api/me/assistant/conversations            list user's conversations
//   POST /api/me/assistant/conversations            create
//   GET  /api/me/assistant/conversations/:id        get with messages
//   GET  /api/me/assistant/conversations/:id/messages   list messages
//   POST /api/me/assistant/conversations/:id/messages   SSE stream chat reply
//   POST /api/me/assistant/conversations/:id/voice     SSE stream voice reply
//   GET  /api/me/assistant/tools                    list tool definitions
//   GET  /api/me/assistant/market-status            market provider status

import express, { Router } from "express";
import multer from "multer";

// Phase 22D — voice uploads use multipart/form-data via multer with a
// route-scoped 20 MB ceiling. Keeps global express.json() at default size,
// so the rest of the API stays protected from oversized JSON payloads.
const voiceUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024, files: 1 },
});
import type { Request } from "express";
import {
  db, arxAssistantConversationsTable, arxAssistantMessagesTable, arxAssistantToolCallsTable,
  oneClickAuditTable, userOneClickSettingsTable, arxLivePositionsTable,
} from "@workspace/db";
import { and, asc, desc, eq, isNull } from "drizzle-orm";
import { parseTradeCommand } from "../lib/assistant/parseTradeCommand.js";
import { executeInstant, type InstantTradeIntent } from "../lib/live/instantTrade.js";
import { z } from "zod/v4";
import { requireUser } from "../lib/auth/middleware.js";
import { openai } from "@workspace/integrations-openai-ai-server";
import {
  TOOL_DEFINITIONS, dispatchTool, classifyIntent, ASSISTANT_SAFETY_ENVELOPE,
  setRequestPageContext,
} from "../lib/assistant/tools.js";
import { buildSessionSystemMessages, type PageContext } from "../lib/assistant/systemPrompt.js";
import { getMarketStatus } from "../lib/assistant/marketProvider.js";
import { mintRealtimeSession, getVoiceModeStatus } from "../lib/assistant/realtimeSession.js";
import {
  getMemory, getConversationPendingAction, setConversationPendingAction,
  getRecentToolResults, formatMemoryForSystemPrompt, summarizeIfNeeded,
  extractPromiseFromAssistantText, pushUnresolvedAction, resolveUnresolvedAction,
  wipeAllUserMemory, setMemoryEnabled, type PendingAction,
} from "../lib/assistant/memoryStore.js";

const router = Router();
const SAFETY_ENVELOPE = ASSISTANT_SAFETY_ENVELOPE;

// Phase 23 — per-user dynamic envelope. Layered ON TOP of the compile-time
// constant so the fail-closed defaults (liveLocked, allowOrderExecution:false)
// are preserved even when the per-user envelope read throws.
import { getEnvelope as getUserTradingEnvelope } from "../lib/adminTrading/safetyEnvelope.js";
async function buildPerUserEnvelope(userId: number | null | undefined) {
  try {
    const dyn = await getUserTradingEnvelope(userId ?? 0);
    return {
      ...SAFETY_ENVELOPE,
      tradingMode: dyn.tradingMode,
      globalLiveEnabled: dyn.globalLiveEnabled,
      userLiveApproved: dyn.userLiveApproved,
      emergencyKillSwitch: dyn.emergencyKillSwitch,
      accountType: dyn.accountType,
      // Phase 3 — broker placement layer is ENABLED in code. The dynamic
      // envelope is now trusted for liveLocked/allowOrderExecution; runtime
      // safety is still governed by the singleton + per-user permissions +
      // EA-side gates.
      liveLocked: dyn.liveLocked,
      allowOrderExecution: dyn.allowOrderExecution,
      safetyMode: dyn.safetyMode,
      bannerLabel: dyn.bannerLabel,
    };
  } catch {
    return SAFETY_ENVELOPE;
  }
}
const MAX_TURNS_PER_REQUEST = 4;
const MAX_HISTORY_MESSAGES = 20;
const MAX_USER_MESSAGE_CHARS = 4000;
const MODEL = "gpt-5.4";

function err(res: import("express").Response, status: number, message: string) {
  res.status(status).json({ error: message, ...SAFETY_ENVELOPE });
}
function safe(h: (req: import("express").Request, res: import("express").Response) => Promise<void>) {
  return async (req: import("express").Request, res: import("express").Response) => {
    try { await h(req, res); }
    catch (e) {
      try { (req as { log?: { error: (...a: unknown[]) => void } }).log?.error({ err: (e as Error)?.message }, "assistant_route_failure"); } catch { /* noop */ }
      if (!res.headersSent) err(res, 500, "assistant_failed");
      else { try { res.end(); } catch { /* noop */ } }
    }
  };
}

const CreateConvBody = z.object({ title: z.string().min(1).max(200).optional() });
const PageContextBody = z.object({
  pathname: z.string().min(1).max(200),
  label: z.string().max(200).optional().nullable(),
});
const SendMessageBody = z.object({
  content: z.string().min(1).max(MAX_USER_MESSAGE_CHARS),
  voiceMode: z.enum(["off", "listening", "speaking"]).optional(),
  pageContext: PageContextBody.optional().nullable(),
});

// ── tools list (for UI) ──────────────────────────────────────────────────
router.get("/me/assistant/tools", requireUser, (_req, res) => {
  res.json({ tools: TOOL_DEFINITIONS, count: TOOL_DEFINITIONS.length, ...SAFETY_ENVELOPE });
});

// ── market provider status ───────────────────────────────────────────────
router.get("/me/assistant/market-status", requireUser, (_req, res) => {
  res.json({ ...getMarketStatus(), ...SAFETY_ENVELOPE });
});

// ── voice mode status (for UI badge) ─────────────────────────────────────
router.get("/me/assistant/voice-status", requireUser, (_req, res) => {
  res.json({ ...getVoiceModeStatus(), ...SAFETY_ENVELOPE });
});

// ── Phase 22H: AI provider status (no secrets) ───────────────────────────
// Reports whether the AI provider is wired server-side. The actual key
// (AI_INTEGRATIONS_OPENAI_API_KEY) is NEVER returned and never logged here.
// `connected` mirrors `configured`: we do not probe the upstream API on every
// request (avoids unnecessary token spend), so we only claim connectivity
// when the key is present and the in-process openai client was constructed.
router.get("/me/assistant/provider-status", requireUser, (_req, res) => {
  const proxyKey = process.env["AI_INTEGRATIONS_OPENAI_API_KEY"];
  const directKey = process.env["OPENAI_API_KEY"];
  const configured = Boolean(proxyKey && proxyKey.trim().length > 0);
  res.json({
    provider: configured ? "openai" : "none",
    configured,
    connected: configured,
    model: configured ? MODEL : null,
    streamingEnabled: configured,
    toolCallingEnabled: configured,
    realtimeWebRtcConfigured: Boolean(directKey && directKey.trim().length > 0),
    keysExposed: false as const,
    lastCheckedAt: new Date().toISOString(),
    notes: configured
      ? "AI provider is wired via Replit AI Integrations (server-only). Streaming + tool calling enabled."
      : "AI provider is not configured. Set AI_INTEGRATIONS_OPENAI_API_KEY as a server secret. The assistant will report unavailable until then.",
    ...SAFETY_ENVELOPE,
  });
});

// ── true Realtime WebRTC session minter ──────────────────────────────────
// Returns { configured:false } when OPENAI_API_KEY is not set server-side.
// Never returns the direct OPENAI_API_KEY — only the short-lived ephemeral
// client_secret minted by OpenAI's /v1/realtime/sessions.
router.post("/me/assistant/realtime/session", requireUser, safe(async (req, res) => {
  const userId = req.authUser!.id;
  const result = await mintRealtimeSession(userId);
  res.json(result);
}));

// ── conversations ────────────────────────────────────────────────────────
router.get("/me/assistant/conversations", requireUser, safe(async (req, res) => {
  const userId = req.authUser!.id;
  const rows = await db.select().from(arxAssistantConversationsTable)
    .where(eq(arxAssistantConversationsTable.userId, userId))
    .orderBy(desc(arxAssistantConversationsTable.updatedAt))
    .limit(50);
  res.json({ conversations: rows, isEmpty: rows.length === 0, ...SAFETY_ENVELOPE });
}));

router.post("/me/assistant/conversations", requireUser, safe(async (req, res) => {
  const userId = req.authUser!.id;
  const parsed = CreateConvBody.safeParse(req.body);
  if (!parsed.success) { err(res, 400, "invalid_body"); return; }
  const title = parsed.data.title ?? "New chat";
  const inserted = await db.insert(arxAssistantConversationsTable)
    .values({ userId, title }).returning();
  res.status(201).json({ conversation: inserted[0], ...SAFETY_ENVELOPE });
}));

router.get("/me/assistant/conversations/:id", requireUser, safe(async (req, res) => {
  const userId = req.authUser!.id;
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) { err(res, 400, "invalid_id"); return; }
  const conv = await db.select().from(arxAssistantConversationsTable)
    .where(and(eq(arxAssistantConversationsTable.id, id), eq(arxAssistantConversationsTable.userId, userId)))
    .limit(1);
  if (conv.length === 0) { err(res, 404, "conversation_not_found"); return; }
  const messages = await db.select().from(arxAssistantMessagesTable)
    .where(and(eq(arxAssistantMessagesTable.conversationId, id), eq(arxAssistantMessagesTable.userId, userId)))
    .orderBy(asc(arxAssistantMessagesTable.createdAt))
    .limit(MAX_HISTORY_MESSAGES * 4);
  res.json({ conversation: conv[0], messages, ...SAFETY_ENVELOPE });
}));

router.get("/me/assistant/conversations/:id/messages", requireUser, safe(async (req, res) => {
  const userId = req.authUser!.id;
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) { err(res, 400, "invalid_id"); return; }
  // Per-user isolation: confirm the conversation belongs to this user
  // before listing its messages. Returns 404 (not 200 + empty) for
  // any other user's id, matching the POST handler's behavior.
  const convOwned = await db.select({ id: arxAssistantConversationsTable.id })
    .from(arxAssistantConversationsTable)
    .where(and(eq(arxAssistantConversationsTable.id, id), eq(arxAssistantConversationsTable.userId, userId)))
    .limit(1);
  if (convOwned.length === 0) { err(res, 404, "conversation_not_found"); return; }
  const messages = await db.select().from(arxAssistantMessagesTable)
    .where(and(eq(arxAssistantMessagesTable.conversationId, id), eq(arxAssistantMessagesTable.userId, userId)))
    .orderBy(asc(arxAssistantMessagesTable.createdAt))
    .limit(MAX_HISTORY_MESSAGES * 4);
  res.json({ messages, isEmpty: messages.length === 0, ...SAFETY_ENVELOPE });
}));

// ── Ruby Setup Reason — scanner signal explanation ───────────────────────
// Small deterministic structured explanation used by the Market Scanner
// cards (and trade modal) under the heading "Ruby's Setup Reason".
//
// Design notes:
//  - No LLM call. The scanner has already produced reasonForTrade /
//    reasonToAvoid / bias / confidence; Ruby just rephrases them into a
//    hedged, user-friendly micro-summary. Predictable latency, free, and
//    no chance of the model hallucinating a "guaranteed trade".
//  - Language is hedged ("looks like a possible buy setup", "may favor
//    sellers") — never guaranteed/profit-certain. See acceptance criteria
//    item 4 in the scanner trade spec.
//  - Returns the user-scoped safety envelope so callers can confirm
//    liveLocked/allowOrderExecution remain enforced.
const explainSignalSchema = z.object({
  symbol: z.string().min(1).max(20),
  timeframe: z.string().min(1).max(10).optional(),
  recommendedAction: z.string().min(1).max(20),
  bias: z.string().min(1).max(40),
  confidenceScore: z.number().min(0).max(100).optional(),
  riskScore: z.number().min(0).max(100).optional(),
  entrySniperScore: z.number().min(0).max(100).optional(),
  reasonForTrade: z.string().max(500).optional(),
  reasonToAvoid: z.string().max(500).optional(),
  setupType: z.string().max(80).optional(),
  entry: z.number().optional(),
  stopLoss: z.number().optional(),
  takeProfit: z.number().optional(),
  statusBadge: z.string().max(60).optional(),
});
router.post("/me/assistant/explain-signal", requireUser, safe(async (req, res) => {
  const parsed = explainSignalSchema.safeParse(req.body ?? {});
  if (!parsed.success) { err(res, 400, "invalid_body"); return; }
  const s = parsed.data;
  const side: "BUY" | "SELL" | "NEUTRAL" =
    s.recommendedAction.toUpperCase() === "BUY" ? "BUY" :
    s.recommendedAction.toUpperCase() === "SELL" ? "SELL" : "NEUTRAL";
  const conf = s.confidenceScore ?? 0;
  const confidenceLabel = conf >= 75 ? "High" : conf >= 50 ? "Medium" : conf >= 25 ? "Low" : "Very Low";
  const hedge = side === "BUY"
    ? "This looks like a possible buy setup."
    : side === "SELL"
    ? "This setup may favor sellers."
    : "No clear directional edge right now — consider waiting for confirmation.";
  // Build a short "why" — keep it small and clear. Source data comes from
  // the scanner; Ruby just reshapes it.
  const whyParts: string[] = [];
  if (s.setupType) whyParts.push(s.setupType);
  if (s.reasonForTrade) whyParts.push(s.reasonForTrade);
  const why = whyParts.join(" — ").slice(0, 220) || "Scanner detected a tradable structure on the current timeframe.";
  const risk = s.reasonToAvoid
    ? s.reasonToAvoid.slice(0, 180)
    : s.stopLoss != null
    ? `Setup weakens if price closes ${side === "SELL" ? "above" : "below"} ${s.stopLoss}.`
    : "Setup weakens if momentum stalls or structure breaks against the bias.";
  const possibleTpArea = s.takeProfit != null
    ? `Around ${s.takeProfit}`
    : "Wait for the scanner to publish a target before sizing.";
  const suggestedStopArea = s.stopLoss != null
    ? `Near ${s.stopLoss}`
    : "Place beyond the most recent swing against your bias.";
  const invalidation = s.stopLoss != null
    ? `Idea invalidates ${side === "SELL" ? "above" : "below"} ${s.stopLoss}.`
    : "Idea invalidates if price closes through the opposing structure.";
  const cautions: string[] = [];
  if ((s.riskScore ?? 0) >= 70) cautions.push("Volatility risk elevated — size smaller.");
  if (conf < 50) cautions.push("Confidence is not high — wait for confirmation if momentum is weak.");
  if (s.statusBadge && /SPREAD|CHOPPY|REJECT/i.test(s.statusBadge)) {
    cautions.push(`Scanner flagged ${s.statusBadge.replace(/_/g, " ").toLowerCase()}.`);
  }
  const envelope = await buildPerUserEnvelope(req.authUser?.id ?? null);
  res.json({
    setupReason: {
      bias: side,
      hedge,
      why,
      risk,
      invalidation,
      possibleTpArea,
      suggestedStopArea,
      confidenceLabel,
      confidenceScore: conf,
      cautions,
      disclaimer: "Educational only — not financial advice. Test in demo first.",
    },
    ...envelope,
    readOnlyMode: true,
  });
}));

// ── Phase 22K: memory inspection + user controls ─────────────────────────
// GET memory snapshot (read-only). Returns long-term summary, trading style,
// preferences, unresolved actions — all scoped to req.authUser.id.
router.get("/me/assistant/memory", requireUser, safe(async (req, res) => {
  const userId = req.authUser!.id;
  const snap = await getMemory(userId);
  res.json({ memory: snap, ...SAFETY_ENVELOPE });
}));

// DELETE all ARX memory for this user. Removes conversations, messages,
// tool calls, and the long-term memory row. Cannot affect other users.
router.delete("/me/assistant/memory", requireUser, safe(async (req, res) => {
  const userId = req.authUser!.id;
  const counts = await wipeAllUserMemory(userId);
  res.json({ ok: true, ...counts, ...SAFETY_ENVELOPE });
}));

// Ruby memory settings — flip the per-user long-term memory toggle.
// When disabled, the rolling summarizer is a no-op AND the system prompt
// stops injecting saved memory. Past chats remain queryable / exportable.
const MemorySettingsBody = z.object({ memoryEnabled: z.boolean() });
router.patch("/me/assistant/memory/settings", requireUser, safe(async (req, res) => {
  const userId = req.authUser!.id;
  const parsed = MemorySettingsBody.safeParse(req.body);
  if (!parsed.success) { err(res, 400, "invalid_body"); return; }
  await setMemoryEnabled(userId, parsed.data.memoryEnabled);
  const snap = await getMemory(userId);
  res.json({ ok: true, memoryEnabled: snap.memoryEnabled, ...SAFETY_ENVELOPE });
}));

// Export all Ruby chat history + memory snapshot for this user as JSON.
// Per-user scoped. No secrets, no other users' rows. Returns one bundle
// for the user to download / archive locally.
router.get("/me/assistant/export", requireUser, safe(async (req, res) => {
  const userId = req.authUser!.id;
  const convs = await db.select().from(arxAssistantConversationsTable)
    .where(eq(arxAssistantConversationsTable.userId, userId))
    .orderBy(asc(arxAssistantConversationsTable.createdAt));
  const msgs = await db.select().from(arxAssistantMessagesTable)
    .where(eq(arxAssistantMessagesTable.userId, userId))
    .orderBy(asc(arxAssistantMessagesTable.createdAt));
  const memory = await getMemory(userId);
  const exportedAt = new Date().toISOString();
  res.setHeader("Content-Disposition", `attachment; filename="ruby-export-${userId}-${exportedAt.slice(0,10)}.json"`);
  res.setHeader("Content-Type", "application/json");
  res.json({
    schema: "arx.ruby.export.v1",
    assistantName: "Ruby",
    userId,
    exportedAt,
    memory,
    conversations: convs.map((c) => ({
      id: c.id,
      title: c.title,
      createdAt: c.createdAt,
      updatedAt: c.updatedAt,
      archivedAt: c.archivedAt,
      messages: msgs
        .filter((m) => m.conversationId === c.id)
        .map((m) => ({
          id: m.id,
          role: m.role,
          content: m.content,
          intent: m.intent,
          createdAt: m.createdAt,
        })),
    })),
    ...SAFETY_ENVELOPE,
  });
}));

// DELETE a single conversation (and cascade its messages/tool calls).
// Long-term memory + other conversations are preserved.
router.delete("/me/assistant/conversations/:id", requireUser, safe(async (req, res) => {
  const userId = req.authUser!.id;
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) { err(res, 400, "invalid_id"); return; }
  const owned = await db.select({ id: arxAssistantConversationsTable.id })
    .from(arxAssistantConversationsTable)
    .where(and(eq(arxAssistantConversationsTable.id, id), eq(arxAssistantConversationsTable.userId, userId)))
    .limit(1);
  if (owned.length === 0) { err(res, 404, "conversation_not_found"); return; }
  await db.delete(arxAssistantConversationsTable)
    .where(and(eq(arxAssistantConversationsTable.id, id), eq(arxAssistantConversationsTable.userId, userId)));
  res.json({ ok: true, deletedId: id, ...SAFETY_ENVELOPE });
}));

// ── streaming text chat with tool calling ────────────────────────────────
router.post("/me/assistant/conversations/:id/messages", requireUser, safe(async (req, res) => {
  const userId = req.authUser!.id;
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) { err(res, 400, "invalid_id"); return; }
  const parsed = SendMessageBody.safeParse(req.body);
  if (!parsed.success) { err(res, 400, "invalid_body"); return; }

  const conv = await db.select().from(arxAssistantConversationsTable)
    .where(and(eq(arxAssistantConversationsTable.id, id), eq(arxAssistantConversationsTable.userId, userId)))
    .limit(1);
  if (conv.length === 0) { err(res, 404, "conversation_not_found"); return; }

  const userText = parsed.data.content.trim();
  const intent = classifyIntent(userText);
  const pageContext: PageContext | null = parsed.data.pageContext
    ? { pathname: parsed.data.pageContext.pathname, label: parsed.data.pageContext.label ?? null }
    : null;
  setRequestPageContext(req, pageContext);

  // Persist user message immediately.
  const userInsert = await db.insert(arxAssistantMessagesTable)
    .values({ userId, conversationId: id, role: "user", content: userText, intent })
    .returning();
  const userMessageId = userInsert[0]?.id;
  try {
    (req as { log?: { info: (...a: unknown[]) => void } }).log?.info(
      { userId, conversationId: id, intent, pathname: pageContext?.pathname ?? null, len: userText.length },
      "ruby_chat_request",
    );
  } catch { /* noop */ }

  // Load recent history (user-scoped).
  const history = await db.select().from(arxAssistantMessagesTable)
    .where(and(eq(arxAssistantMessagesTable.conversationId, id), eq(arxAssistantMessagesTable.userId, userId)))
    .orderBy(desc(arxAssistantMessagesTable.createdAt))
    .limit(MAX_HISTORY_MESSAGES);
  const ordered = history.slice().reverse();

  // Phase 22K — load long-term memory + pendingAction + recent tool results
  // (all scoped to this user / this conversation) and inject as a system
  // message so the model can answer "what did I ask earlier?", continue
  // promises, and avoid re-asking facts it already knows.
  const [memSnapshot, pending, toolHistory] = await Promise.all([
    getMemory(userId),
    getConversationPendingAction(userId, id),
    getRecentToolResults(userId, id, 5),
  ]);
  const memoryBlock = formatMemoryForSystemPrompt(memSnapshot, pending, toolHistory);

  // Build OpenAI chat messages.
  type ChatMessage =
    | { role: "system"; content: string }
    | { role: "user"; content: string }
    | { role: "assistant"; content: string | null; tool_calls?: Array<{ id: string; type: "function"; function: { name: string; arguments: string } }> }
    | { role: "tool"; content: string; tool_call_id: string };
  const messages: ChatMessage[] = [
    ...buildSessionSystemMessages(userId, pageContext, memoryBlock),
    ...ordered.map((m) => ({ role: (m.role === "assistant" ? "assistant" : "user") as "user" | "assistant", content: m.content })),
  ];

  // SSE setup
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  (res as unknown as { flushHeaders?: () => void }).flushHeaders?.();

  // Phase 22F — strict canonical ARX stream contract.
  // ONLY these event types may reach the frontend:
  //   safety | intent | content | tool_call | tool_result | error | done | ping
  // Any other shape (raw provider event, unknown payload, exception
  // string) MUST be filtered here. The frontend whitelist is the
  // second line of defense; this is the first.
  const CANONICAL = new Set(["safety", "intent", "content", "tool_call", "tool_result", "error", "done", "ping"]);
  const send = (event: Record<string, unknown>) => {
    const t = typeof event?.type === "string" ? event.type : "";
    if (!CANONICAL.has(t)) {
      try { (req as { log?: { warn: (...a: unknown[]) => void } }).log?.warn({ type: t }, "assistant_dropped_noncanonical_event"); } catch { /* noop */ }
      return;
    }
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  };

  send({ type: "safety", ...(await buildPerUserEnvelope(userId)) });
  send({ type: "intent", intent });

  let assistantText = "";
  let aborted = false;
  // Periodic heartbeat keeps proxies/load balancers from closing the
  // SSE connection during long tool turns. Canonical {type:"ping"} only.
  const heartbeat = setInterval(() => { if (!aborted) send({ type: "ping", ts: Date.now() }); }, 15_000);
  const cleanupStream = () => { clearInterval(heartbeat); };
  req.on("close", () => { aborted = true; cleanupStream(); });

  const tools = TOOL_DEFINITIONS.map((t) => ({
    type: "function" as const,
    function: { name: t.name, description: t.description, parameters: t.parameters as unknown as Record<string, unknown> },
  }));

  for (let turn = 0; turn < MAX_TURNS_PER_REQUEST; turn++) {
    if (aborted) break;
    let stream: AsyncIterable<{ choices: Array<{ delta: { content?: string | null; tool_calls?: Array<{ index: number; id?: string; function?: { name?: string; arguments?: string } }> }; finish_reason?: string | null }> }>;
    try {
      stream = await openai.chat.completions.create({
        model: MODEL,
        max_completion_tokens: 8192,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        messages: messages as any,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        tools: tools as any,
        tool_choice: "auto",
        stream: true,
      }) as unknown as AsyncIterable<{ choices: Array<{ delta: { content?: string | null; tool_calls?: Array<{ index: number; id?: string; function?: { name?: string; arguments?: string } }> }; finish_reason?: string | null }> }>;
    } catch (e) {
      try { (req as { log?: { error: (...a: unknown[]) => void } }).log?.error({ err: (e as Error)?.message }, "assistant_openai_failed"); } catch { /* noop */ }
      send({ type: "error", message: "AI provider unavailable. Please try again in a moment." });
      send({ type: "done" });
      cleanupStream();
      res.end();
      return;
    }

    let turnContent = "";
    const toolCallsAcc: Record<number, { id: string; name: string; args: string }> = {};
    let finishReason: string | null = null;
    // Phase 22S2 — preamble suppression. Buffer content for this turn and
    // ONLY flush it as SSE `content` events after we know whether tool_calls
    // followed. If tool_calls are present, the content is preamble (e.g.
    // "I'll check the scanner...") and we drop it entirely. This guarantees
    // the user/UI/TTS only ever see the final post-tools answer, regardless
    // of what the model decides to narrate. Tradeoff: replies that don't
    // call tools are flushed at end-of-turn instead of streamed token-by-
    // token. Acceptable: most non-tool replies generate in <1s.

    // Phase 22F — wrap the consumer loop so a mid-stream provider
    // exception (network blip, malformed chunk, abort) becomes a clean
    // canonical ARX error instead of crashing the request and letting
    // Express send an HTML error page through the SSE socket.
    try {
      for await (const chunk of stream) {
        if (aborted) break;
        const choice = chunk.choices?.[0];
        if (!choice) continue;
        const delta = choice.delta ?? {};
        if (delta.content) {
          // Phase 22S2 — buffer only. Decision to flush vs. drop is made
          // after the turn ends, once we know whether tool_calls followed.
          turnContent += delta.content;
        }
        if (delta.tool_calls && Array.isArray(delta.tool_calls)) {
          for (const tc of delta.tool_calls) {
            const idx = tc.index ?? 0;
            if (!toolCallsAcc[idx]) toolCallsAcc[idx] = { id: tc.id ?? `call_${idx}`, name: "", args: "" };
            if (tc.id) toolCallsAcc[idx].id = tc.id;
            if (tc.function?.name) toolCallsAcc[idx].name += tc.function.name;
            if (tc.function?.arguments) toolCallsAcc[idx].args += tc.function.arguments;
          }
        }
        if (choice.finish_reason) finishReason = choice.finish_reason;
      }
    } catch (e) {
      try { (req as { log?: { error: (...a: unknown[]) => void } }).log?.error({ err: (e as Error)?.message }, "assistant_stream_consume_failed"); } catch { /* noop */ }
      send({ type: "error", message: "AI stream interrupted. Please try again." });
      send({ type: "done" });
      cleanupStream();
      res.end();
      return;
    }

    if (aborted) break;

    const calls = Object.values(toolCallsAcc).filter((c) => c.name);
    if (calls.length === 0) {
      // Phase 22S2 — final turn. Flush buffered content as a single
      // SSE frame; this is the actual answer the user wanted.
      if (turnContent) {
        assistantText += turnContent;
        send({ type: "content", content: turnContent });
      }
      // Plain text reply done.
      break;
    }

    // Phase 22S2 — this turn produced tool_calls. Any text it also produced
    // is preamble ("Let's get a full market picture, I'll check the
    // scanner..."). DROP it: never surface to UI, never speak via TTS,
    // never persist. The model still sees its own narration in
    // `turnContent` below (passed back as the assistant message in
    // history) so its reasoning is preserved across turns; the user just
    // never has to look at it.
    messages.push({
      role: "assistant",
      content: turnContent || null,
      tool_calls: calls.map((c) => ({ id: c.id, type: "function", function: { name: c.name, arguments: c.args || "{}" } })),
    });

    // Execute each tool; report progress; append tool results.
    for (const c of calls) {
      let parsedArgs: Record<string, unknown> = {};
      try { parsedArgs = c.args ? (JSON.parse(c.args) as Record<string, unknown>) : {}; } catch { parsedArgs = {}; }
      send({ type: "tool_call", name: c.name });
      const t0 = Date.now();
      let result: unknown;
      let status = "ok";
      try {
        result = await dispatchTool(c.name, parsedArgs, userId, req);
      } catch (e) {
        status = "error";
        result = { error: "tool_failed", name: c.name, message: (e as Error)?.message ?? "unknown" };
      }
      const ms = Date.now() - t0;
      send({ type: "tool_result", name: c.name, status, durationMs: ms });
      try {
        (req as { log?: { info: (...a: unknown[]) => void } }).log?.info(
          { userId, conversationId: id, tool: c.name, status, durationMs: ms },
          "ruby_tool_call",
        );
      } catch { /* noop */ }
      try {
        await db.insert(arxAssistantToolCallsTable).values({
          userId, conversationId: id, messageId: userMessageId ?? null,
          toolName: c.name, args: parsedArgs as Record<string, unknown>,
          result: result as Record<string, unknown>, status, durationMs: ms,
        });
      } catch { /* tool log non-fatal */ }
      messages.push({ role: "tool", tool_call_id: c.id, content: JSON.stringify(result).slice(0, 8000) });
    }

    if (finishReason && finishReason !== "tool_calls") break;
  }

  // Persist final assistant message
  if (assistantText.trim().length > 0) {
    try {
      await db.insert(arxAssistantMessagesTable).values({
        userId, conversationId: id, role: "assistant", content: assistantText, intent,
      });
      await db.update(arxAssistantConversationsTable)
        .set({ updatedAt: new Date(), lastIntent: intent })
        .where(and(eq(arxAssistantConversationsTable.id, id), eq(arxAssistantConversationsTable.userId, userId)));
    } catch { /* persist non-fatal */ }

    // Phase 22K — pendingAction lifecycle.
    // 1. If a tool ran THIS turn, mark its matching unresolved action resolved.
    // 2. If the assistant promised something new ("let me check the scanner"),
    //    create / refresh the pendingAction on the conversation row AND
    //    long-term unresolved list.
    try {
      const toolNamesThisTurn = new Set<string>();
      for (const m of messages) {
        if (m.role === "assistant" && Array.isArray((m as { tool_calls?: unknown[] }).tool_calls)) {
          for (const tc of (m as { tool_calls: Array<{ function: { name: string } }> }).tool_calls) {
            if (tc?.function?.name) toolNamesThisTurn.add(tc.function.name);
          }
        }
      }
      const TOOL_TO_PENDING: Record<string, PendingAction["type"]> = {
        getMarketScannerOpportunities: "scanner_check",
        getMT5BridgeStatus: "mt5_status",
        getMT5Heartbeat: "mt5_status",
        getTradeJournalSummary: "trade_analysis",
        getOpenPositions: "trade_analysis",
        getRiskLimits: "risk_explanation",
        getAccountSnapshot: "account_lookup",
      };
      for (const tn of toolNamesThisTurn) {
        const pt = TOOL_TO_PENDING[tn];
        if (pt) await resolveUnresolvedAction(userId, pt, id);
      }
      if (pending && toolNamesThisTurn.size > 0) {
        const matched = Array.from(toolNamesThisTurn).some((tn) => TOOL_TO_PENDING[tn] === pending.type);
        if (matched) await setConversationPendingAction(userId, id, null);
      }
      // 3. New promise extraction.
      const promise = extractPromiseFromAssistantText(assistantText);
      if (promise) {
        const action: PendingAction = {
          type: promise.type,
          status: toolNamesThisTurn.size > 0 ? "in_progress" : "open",
          userIntent: userText.slice(0, 240),
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          lastAssistantPromise: promise.promiseSentence,
          conversationId: id,
        };
        await setConversationPendingAction(userId, id, action);
        await pushUnresolvedAction(userId, action);
      }
    } catch { /* memory side-effects are best-effort */ }

    // Phase 22K — fire-and-forget rolling summary update. Throttled inside.
    void summarizeIfNeeded(userId, id).catch(() => { /* best-effort */ });
  }

  send({ type: "done" });
  cleanupStream();
  res.end();
}));

// ── streaming voice (gpt-audio speech-to-speech) ─────────────────────────
router.post("/me/assistant/conversations/:id/voice", requireUser, voiceUpload.single("audio"), safe(async (req, res) => {
  const userId = req.authUser!.id;
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) { err(res, 400, "invalid_id"); return; }
  const file = (req as unknown as { file?: { buffer: Buffer; size: number; mimetype: string } }).file;
  if (!file || !file.buffer || file.size === 0) { err(res, 400, "missing_audio"); return; }
  const conv = await db.select().from(arxAssistantConversationsTable)
    .where(and(eq(arxAssistantConversationsTable.id, id), eq(arxAssistantConversationsTable.userId, userId)))
    .limit(1);
  if (conv.length === 0) { err(res, 404, "conversation_not_found"); return; }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  (res as unknown as { flushHeaders?: () => void }).flushHeaders?.();

  // Phase 22F — same strict canonical contract as the text stream.
  // The voice provider emits its own event names ("transcript",
  // "user_transcript", "audio_chunk", and any future additions). We
  // translate the ones we care about into ARX canonical events and DROP
  // every other shape. Raw provider events MUST NOT reach the browser.
  const VOICE_CANONICAL = new Set(["safety", "content", "transcript", "user_transcript", "audio_chunk", "error", "done", "ping"]);
  const sendVoice = (event: Record<string, unknown>) => {
    const t = typeof event?.type === "string" ? event.type : "";
    if (!VOICE_CANONICAL.has(t)) {
      try { (req as { log?: { warn: (...a: unknown[]) => void } }).log?.warn({ type: t }, "assistant_voice_dropped_noncanonical_event"); } catch { /* noop */ }
      return;
    }
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  };
  sendVoice({ type: "safety", ...(await buildPerUserEnvelope(userId)) });

  let voiceAborted = false;
  const voiceHeartbeat = setInterval(() => { if (!voiceAborted) sendVoice({ type: "ping", ts: Date.now() }); }, 15_000);
  const cleanupVoice = () => { clearInterval(voiceHeartbeat); };
  req.on("close", () => { voiceAborted = true; cleanupVoice(); });

  const audioBuffer = file.buffer;

  // Phase 22H — voice now shares the same conversation memory + system
  // prompt as text chat. Load the recent history (user-scoped, same
  // limit as the text route) and prepend the system messages so the
  // gpt-audio model sees the full thread + ARX safety + follow-up rules.
  // Phase 22K — also inject long-term memory + pendingAction + recent tool
  // results so voice has identical recall to text.
  const [voiceHistory, voiceMem, voicePending, voiceToolHistory] = await Promise.all([
    db.select().from(arxAssistantMessagesTable)
      .where(and(eq(arxAssistantMessagesTable.conversationId, id), eq(arxAssistantMessagesTable.userId, userId)))
      .orderBy(desc(arxAssistantMessagesTable.createdAt))
      .limit(MAX_HISTORY_MESSAGES),
    getMemory(userId),
    getConversationPendingAction(userId, id),
    getRecentToolResults(userId, id, 5),
  ]);
  const voiceOrdered = voiceHistory.slice().reverse();
  const voiceMemoryBlock = formatMemoryForSystemPrompt(voiceMem, voicePending, voiceToolHistory);
  const voicePriorMessages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
    ...buildSessionSystemMessages(userId, null, voiceMemoryBlock),
    ...voiceOrdered.map((m) => ({
      role: (m.role === "assistant" ? "assistant" : "user") as "user" | "assistant",
      content: m.content,
    })),
  ];

  let userTranscript = "";
  let assistantTranscript = "";
  try {
    const audio = await import("@workspace/integrations-openai-ai-server/audio");
    const { buffer, format } = await audio.ensureCompatibleFormat(audioBuffer);
    const stream = await audio.voiceChatStream(buffer, "alloy", format, voicePriorMessages);
    for await (const event of stream) {
      if (voiceAborted) break;
      const ev = event as { type?: string; data?: string };
      const evType = typeof ev?.type === "string" ? ev.type : "";
      if (evType === "transcript" && typeof ev.data === "string") {
        assistantTranscript += ev.data;
        sendVoice({ type: "transcript", data: ev.data });
      } else if (evType === "user_transcript" && typeof ev.data === "string") {
        userTranscript += ev.data;
        sendVoice({ type: "user_transcript", data: ev.data });
      } else if (evType === "audio_chunk" && typeof ev.data === "string") {
        // Pass through base64 audio chunk, no transformation. Frontend
        // already understands this canonical shape.
        sendVoice({ type: "audio_chunk", data: ev.data });
      } else {
        // Unknown / future provider event — log server-side, drop client-side.
        try { (req as { log?: { warn: (...a: unknown[]) => void } }).log?.warn({ type: evType }, "assistant_voice_provider_event_unmapped"); } catch { /* noop */ }
      }
    }
  } catch (e) {
    try { (req as { log?: { error: (...a: unknown[]) => void } }).log?.error({ err: (e as Error)?.message }, "assistant_voice_failed"); } catch { /* noop */ }
    sendVoice({ type: "error", message: "voice_unavailable" });
  }

  // Persist transcripts
  try {
    if (userTranscript.trim()) {
      await db.insert(arxAssistantMessagesTable).values({
        userId, conversationId: id, role: "user", content: userTranscript, audioTranscript: userTranscript,
      });
    }
    if (assistantTranscript.trim()) {
      await db.insert(arxAssistantMessagesTable).values({
        userId, conversationId: id, role: "assistant", content: assistantTranscript, audioTranscript: assistantTranscript,
      });
      await db.update(arxAssistantConversationsTable)
        .set({ updatedAt: new Date(), voiceMode: "off" })
        .where(and(eq(arxAssistantConversationsTable.id, id), eq(arxAssistantConversationsTable.userId, userId)));

      // Phase 22K — same pendingAction extraction + summary update as text.
      try {
        const promise = extractPromiseFromAssistantText(assistantTranscript);
        if (promise) {
          const action: PendingAction = {
            type: promise.type, status: "open",
            userIntent: userTranscript.slice(0, 240),
            createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
            lastAssistantPromise: promise.promiseSentence,
            conversationId: id,
          };
          await setConversationPendingAction(userId, id, action);
          await pushUnresolvedAction(userId, action);
        }
      } catch { /* best-effort */ }
      void summarizeIfNeeded(userId, id).catch(() => { /* best-effort */ });
    }
  } catch { /* non-fatal */ }

  sendVoice({ type: "done" });
  cleanupVoice();
  res.end();
}));

// ───────────────────────────────────────────────────────────────────────
// POST /me/assistant/instant-trade-command
//
// Ruby AI text/voice command → instant-trade router. Frontend sends the
// raw user utterance ("buy EURUSD 0.01", "close my XAUUSD", "close all"
// "set TP on EURUSD to 1.0920"); this endpoint parses it, decides whether
// it's a CLEAR direct command or a VAGUE analysis question, and — only
// when clear — forwards through `executeInstant()` which then runs every
// existing live-trading gate (master-live access, server master switch,
// 16-gate Phase B, kill switch, max lot, daily loss, missing-SL override,
// per-user advisory lock, idempotency).
//
// VAGUE questions ("what should I trade?", "is gold bullish?") are NEVER
// executed — they return `{ok:false, classification:"VAGUE"}` so Ruby
// answers the question instead of trading.
// ───────────────────────────────────────────────────────────────────────
router.post("/me/assistant/instant-trade-command", requireUser, safe(async (req, res) => {
  const userId = (req as Request & { authUser?: { id: number } }).authUser!.id;
  const body = (req.body ?? {}) as {
    text?: string;
    accountMode?: "live" | "demo" | "paper";
    source?: "ruby_text" | "ruby_voice";
    confirm?: boolean;
  };
  const text = (body.text ?? "").trim();
  const source = body.source === "ruby_voice" ? "ruby_voice" : "ruby_text";
  const accountMode = body.accountMode ?? "live";
  const ipEarly = (req.headers["x-forwarded-for"] as string | undefined)?.split(",")[0]?.trim()
    ?? req.socket.remoteAddress ?? null;
  const uaEarly = (req.headers["user-agent"] as string | undefined) ?? null;
  if (!text) {
    await db.insert(oneClickAuditTable).values({
      userId, action: "RUBY_TRADE_COMMAND_VAGUE_REJECTED", ip: ipEarly, userAgent: uaEarly,
      metadata: JSON.stringify({ reason: "MISSING_TEXT", source }),
    });
    res.status(400).json({ ok: false, error: "MISSING_TEXT" });
    return;
  }

  // Pull per-user Ruby defaults so commands like "buy EURUSD" without a
  // size can still resolve when the user has configured a default volume.
  const settingsRows = await db.select().from(userOneClickSettingsTable)
    .where(eq(userOneClickSettingsTable.userId, userId)).limit(1);
  const settings = settingsRows[0];
  const parseDefaults = {
    defaultSymbol: settings?.defaultAiTradeSymbol ?? settings?.defaultSymbol ?? null,
    defaultVolume: settings?.defaultAiTradeVolume ?? settings?.defaultVolume ?? null,
    defaultOrderType: settings?.defaultAiOrderType ?? settings?.defaultOrderType ?? null,
  };
  const parsed = parseTradeCommand(text, parseDefaults);

  const ip = (req.headers["x-forwarded-for"] as string | undefined)?.split(",")[0]?.trim()
    ?? req.socket.remoteAddress ?? null;
  const ua = (req.headers["user-agent"] as string | undefined) ?? null;

  if (parsed.kind === "VAGUE" || parsed.kind === "UNKNOWN") {
    await db.insert(oneClickAuditTable).values({
      userId, action: "RUBY_TRADE_COMMAND_VAGUE_REJECTED", ip, userAgent: ua,
      metadata: JSON.stringify({ text, parsed, source }),
    });
    res.json({
      ok: false, classification: parsed.kind,
      message: parsed.kind === "VAGUE"
        ? "I won't trade off a vague question — ask me to analyse it or give me a direct command (e.g. \"buy EURUSD 0.01\")."
        : "I didn't catch a clear trade command in that. Try \"buy EURUSD 0.01\" or \"close all\".",
    });
    return;
  }
  if (parsed.kind === "MISSING_VOLUME") {
    await db.insert(oneClickAuditTable).values({
      userId, action: "RUBY_TRADE_COMMAND_VAGUE_REJECTED", ip, userAgent: ua,
      metadata: JSON.stringify({ text, reason: "MISSING_VOLUME", symbol: parsed.symbol, source }),
    });
    res.json({
      ok: false, classification: "MISSING_VOLUME",
      message: `How much ${parsed.symbol}? Tell me a lot size like 0.01.`,
    });
    return;
  }
  if (parsed.kind === "MISSING_SYMBOL") {
    await db.insert(oneClickAuditTable).values({
      userId, action: "RUBY_TRADE_COMMAND_VAGUE_REJECTED", ip, userAgent: ua,
      metadata: JSON.stringify({ text, reason: "MISSING_SYMBOL", source }),
    });
    res.json({
      ok: false, classification: "MISSING_SYMBOL",
      message: "Which market? Say e.g. EURUSD or XAUUSD.",
    });
    return;
  }

  await db.insert(oneClickAuditTable).values({
    userId, action: "RUBY_TRADE_COMMAND_PARSED", ip, userAgent: ua,
    metadata: JSON.stringify({ text, parsed, source }),
  });

  // Map parsed command → InstantTradeIntent
  let intent: InstantTradeIntent;
  switch (parsed.kind) {
    case "OPEN":
      intent = {
        source, action: parsed.side, accountMode, symbol: parsed.symbol,
        volume: parsed.volume, orderType: parsed.orderType,
        aiCommand: true, parsedByRuby: true, rawUserCommand: text,
      };
      break;
    case "CLOSE_ONE": {
      // Resolve a single open position for that symbol; if multiple,
      // refuse and let the user disambiguate. NEVER pick one silently.
      const open = await db.select().from(arxLivePositionsTable).where(and(
        eq(arxLivePositionsTable.userId, userId),
        eq(arxLivePositionsTable.symbol, parsed.symbol),
        isNull(arxLivePositionsTable.closedAt),
      ));
      if (open.length === 0) {
        await db.insert(oneClickAuditTable).values({
          userId, action: "INSTANT_CLOSE_REJECTED", ip, userAgent: ua,
          metadata: JSON.stringify({ text, reason: "NO_OPEN_POSITION", symbol: parsed.symbol, source }),
        });
        res.json({ ok: false, classification: "NO_OPEN_POSITION", message: `No open ${parsed.symbol} position to close.` });
        return;
      }
      if (open.length > 1) {
        await db.insert(oneClickAuditTable).values({
          userId, action: "INSTANT_CLOSE_REJECTED", ip, userAgent: ua,
          metadata: JSON.stringify({ text, reason: "AMBIGUOUS_POSITION", symbol: parsed.symbol, count: open.length, source }),
        });
        res.json({
          ok: false, classification: "AMBIGUOUS_POSITION",
          message: `You have ${open.length} open ${parsed.symbol} positions — tell me which ticket to close.`,
        });
        return;
      }
      intent = {
        source, action: "CLOSE", accountMode, symbol: parsed.symbol,
        positionId: open[0]!.brokerTicket,
        aiCommand: true, parsedByRuby: true, rawUserCommand: text,
      };
      break;
    }
    case "CLOSE_ALL":
      intent = { source, action: "CLOSE_ALL", accountMode, aiCommand: true, parsedByRuby: true, rawUserCommand: text };
      break;
    case "CLOSE_ALL_SYMBOL_UNSUPPORTED":
      await db.insert(oneClickAuditTable).values({
        userId, action: "INSTANT_CLOSE_REJECTED", ip, userAgent: ua,
        metadata: JSON.stringify({ text, reason: "CLOSE_ALL_SYMBOL_UNSUPPORTED", symbol: parsed.symbol, source }),
      });
      res.json({
        ok: false, classification: "CLOSE_ALL_SYMBOL_UNSUPPORTED",
        message: `"Close all ${parsed.symbol}" isn't supported yet — say "close all" to close every open position, or close them one at a time by ticket.`,
      });
      return;
    case "CLOSE_PROFITABLE":
    case "CLOSE_LOSING":
      // Not auto-executed — defer to user; Ruby will offer it as a list.
      await db.insert(oneClickAuditTable).values({
        userId, action: "INSTANT_CLOSE_REJECTED", ip, userAgent: ua,
        metadata: JSON.stringify({ text, reason: parsed.kind, source }),
      });
      res.json({
        ok: false, classification: parsed.kind,
        message: `Selective bulk-close (${parsed.kind === "CLOSE_PROFITABLE" ? "winners" : "losers"}) isn't auto-executed yet — close them one-by-one for now.`,
      });
      return;
    case "MODIFY": {
      const sym = parsed.positionRef.symbol;
      if (!sym) {
        await db.insert(oneClickAuditTable).values({
          userId, action: "INSTANT_EXECUTE_REJECTED", ip, userAgent: ua,
          metadata: JSON.stringify({ text, reason: "MODIFY_NEEDS_SYMBOL", source }),
        });
        res.json({ ok: false, classification: "MODIFY_NEEDS_SYMBOL", message: "Which market should I modify?" });
        return;
      }
      const open = await db.select().from(arxLivePositionsTable).where(and(
        eq(arxLivePositionsTable.userId, userId),
        eq(arxLivePositionsTable.symbol, sym),
        isNull(arxLivePositionsTable.closedAt),
      ));
      if (open.length === 0) {
        await db.insert(oneClickAuditTable).values({
          userId, action: "INSTANT_EXECUTE_REJECTED", ip, userAgent: ua,
          metadata: JSON.stringify({ text, reason: "NO_OPEN_POSITION", symbol: sym, modify: true, source }),
        });
        res.json({ ok: false, classification: "NO_OPEN_POSITION", message: `No open ${sym} position to modify.` });
        return;
      }
      if (open.length > 1) {
        await db.insert(oneClickAuditTable).values({
          userId, action: "INSTANT_EXECUTE_REJECTED", ip, userAgent: ua,
          metadata: JSON.stringify({ text, reason: "AMBIGUOUS_POSITION", symbol: sym, count: open.length, modify: true, source }),
        });
        res.json({ ok: false, classification: "AMBIGUOUS_POSITION", message: `Multiple ${sym} positions — please specify the ticket.` });
        return;
      }
      const row = open[0]!;
      const newSl = parsed.newStopLoss === "BREAK_EVEN"
        ? Number(row.entryPrice)
        : (typeof parsed.newStopLoss === "number" ? parsed.newStopLoss : null);
      intent = {
        source, action: "MODIFY_SL_TP", accountMode, symbol: sym,
        positionId: row.brokerTicket,
        newStopLoss: newSl, newTakeProfit: parsed.newTakeProfit ?? null,
        aiCommand: true, parsedByRuby: true, rawUserCommand: text,
      };
      break;
    }
  }

  const result = await executeInstant({ userId, intent, ip, ua });
  if (result.ok) {
    res.json({
      ok: true, classification: parsed.kind, action: intent.action,
      commandId: result.commandId,
      message: `Executed: ${intent.action}${intent.symbol ? " " + intent.symbol : ""}${intent.volume ? " @ " + intent.volume : ""}.`,
    });
    return;
  }
  res.status(result.httpStatus).json({
    ok: false, classification: parsed.kind, error: result.error,
    primaryReason: result.primaryReason ?? null,
    message: `I couldn't execute: ${result.error}.`,
  });
}));

export { router as meAssistantRouter };
