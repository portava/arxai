import { Router } from "express";
import { z } from "zod/v4";
import { analyzeMarket } from "../brain/marketBrain.js";
import { getAllSymbols, getSymbolInfo, getSymbolsByCategory } from "../brain/symbols/symbolRegistry.js";

const router = Router();

const AnalyzeBody = z.object({
  symbol: z.string().min(1),
  minConfidence: z.number().min(0).max(100).optional(),
  enableNewsFilter: z.boolean().optional(),
  enableSessionFilter: z.boolean().optional(),
});

const SymbolsQuery = z.object({ category: z.enum(["forex", "indices", "stocks", "synthetic"]).optional() });

router.post("/brain/analyze", async (req, res) => {
  const parsed = AnalyzeBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid request", details: parsed.error.issues }); return; }
  const { symbol, ...settings } = parsed.data;
  const result = analyzeMarket(symbol, undefined, undefined, settings);
  res.json(result);
});

router.get("/brain/symbols", (req, res) => {
  const q = SymbolsQuery.safeParse(req.query);
  if (!q.success) { res.status(400).json({ error: "Invalid query" }); return; }
  if (q.data.category) {
    res.json(getSymbolsByCategory(q.data.category));
  } else {
    res.json(getAllSymbols().map((s) => ({ symbol: s, ...getSymbolInfo(s) })));
  }
});

router.get("/brain/symbol/:symbol", (req, res) => {
  const info = getSymbolInfo(req.params.symbol);
  if (!info) { res.status(404).json({ error: "Symbol not found in registry" }); return; }
  res.json({ symbol: req.params.symbol, ...info });
});

export default router;
