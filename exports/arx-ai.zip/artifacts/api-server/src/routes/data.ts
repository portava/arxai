import { Router } from "express";
import { GetMarketCandlesQueryParams, GetMarketQuoteQueryParams } from "@workspace/api-zod";
import { getMarketData, getLatestQuote, getProviderStatus } from "../lib/data/dataManager.js";

const router = Router();

router.get("/data/providers/status", async (_req, res) => {
  res.json(await getProviderStatus());
});

router.get("/data/candles", async (req, res) => {
  try {
    const q = GetMarketCandlesQueryParams.parse({
      symbol: req.query["symbol"],
      timeframe: req.query["timeframe"] ?? "1m",
      limit: req.query["limit"] ? Number(req.query["limit"]) : 100,
    });
    const candles = await getMarketData(q.symbol, q.timeframe ?? "1m", q.limit ?? 100);
    res.json(candles);
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid candles request" });
  }
});

router.get("/data/quote", async (req, res) => {
  try {
    const q = GetMarketQuoteQueryParams.parse({ symbol: req.query["symbol"] });
    res.json(await getLatestQuote(q.symbol));
  } catch (err) {
    req.log.error(err);
    res.status(400).json({ error: "Invalid quote request" });
  }
});

export default router;
