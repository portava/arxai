// Admin Reconciliation Center — aggregator + 4 audited actions.
//
// All routes are admin-gated. All actions require a non-empty trimmed reason
// and write an admin_action_audit_log row before responding (fail-CLOSED).
// No route ever writes to arx_live_commands or to any live execution table.

import { Router, type Request, type Response } from "express";
import { db } from "@workspace/db";
import { adminActionAuditLogTable } from "@workspace/db/schema";
import {
  aggregateReconciliationIssues,
  issueId,
  RECONCILIATION_ISSUE_TYPES,
  type ReconciliationIssueType,
} from "../lib/reconciliation/detect.js";

const router = Router();

function requireAdmin(req: Request, res: Response): "ADMIN" | "OWNER" | null {
  const u = (req as Request & { authUser?: { id?: number; role?: string } }).authUser;
  const role = String(u?.role ?? "").toUpperCase();
  if (role !== "ADMIN" && role !== "OWNER") {
    res.status(403).json({ ok: false, error: "ADMIN_OR_OWNER_REQUIRED" });
    return null;
  }
  return role as "ADMIN" | "OWNER";
}

function getAdminId(req: Request): number | null {
  return (req as Request & { authUser?: { id?: number } }).authUser?.id ?? null;
}

function clientIp(req: Request): string | null {
  const xf = req.headers["x-forwarded-for"];
  if (typeof xf === "string" && xf.length > 0) return xf.split(",")[0]!.trim();
  return req.ip ?? null;
}

interface AuditArgs {
  adminId: number | null;
  role: "ADMIN" | "OWNER";
  action: string;
  targetUserId: number | null;
  reason: string | null;
  beforeState?: Record<string, unknown>;
  afterState: Record<string, unknown>;
  ipAddress: string | null;
}

async function writeAudit(args: AuditArgs): Promise<void> {
  // Fail-CLOSED: any audit failure must bubble up so the caller refuses.
  await db.insert(adminActionAuditLogTable).values({
    adminId: args.adminId,
    adminRole: args.role,
    action: args.action,
    targetUserId: args.targetUserId,
    beforeState: args.beforeState ?? {},
    afterState: args.afterState,
    reason: args.reason,
    ipAddress: args.ipAddress,
  });
}

function isReconciliationType(t: unknown): t is ReconciliationIssueType {
  return typeof t === "string" && (RECONCILIATION_ISSUE_TYPES as readonly string[]).includes(t);
}

interface ActionBody {
  reason?: unknown;
  type?: unknown;
  naturalKey?: unknown;
  targetUserId?: unknown;
}

async function validateActionBody(
  req: Request,
  res: Response,
  paramId: string,
  actionCode: string,
  role: "ADMIN" | "OWNER",
): Promise<null | { reason: string; type: ReconciliationIssueType; naturalKey: string; targetUserId: number | null }> {
  const body = (req.body ?? {}) as ActionBody;
  const reasonRaw = typeof body.reason === "string" ? body.reason.trim() : "";
  if (reasonRaw.length < 3) {
    // Audit the block itself, then 400. Fail-CLOSED on audit too.
    try {
      await writeAudit({
        adminId: getAdminId(req), role,
        action: "RECONCILIATION_ACTION_BLOCKED_REASON_REQUIRED",
        targetUserId: null, reason: null,
        afterState: { attemptedAction: actionCode, issueId: paramId },
        ipAddress: clientIp(req),
      });
    } catch {
      res.status(500).json({ ok: false, error: "AUDIT_WRITE_FAILED" });
      return null;
    }
    res.status(400).json({ ok: false, error: "REASON_REQUIRED" });
    return null;
  }
  if (!isReconciliationType(body.type)) {
    res.status(400).json({ ok: false, error: "INVALID_ISSUE_TYPE" });
    return null;
  }
  const naturalKey = typeof body.naturalKey === "string" ? body.naturalKey : "";
  if (naturalKey.length === 0) {
    res.status(400).json({ ok: false, error: "NATURAL_KEY_REQUIRED" });
    return null;
  }
  const expected = issueId(body.type, naturalKey);
  if (expected !== paramId) {
    res.status(400).json({ ok: false, error: "ISSUE_ID_MISMATCH" });
    return null;
  }
  const tuid = body.targetUserId == null ? null : Number(body.targetUserId);
  return { reason: reasonRaw, type: body.type, naturalKey, targetUserId: Number.isFinite(tuid) ? tuid : null };
}

// ─── GET /api/admin/reconciliation-center/issues ──────────────────────────
router.get("/admin/reconciliation-center/issues", async (req, res) => {
  const role = requireAdmin(req, res); if (!role) return;
  try {
    const agg = await aggregateReconciliationIssues();
    await writeAudit({
      adminId: getAdminId(req), role,
      action: "ADMIN_VIEWED_RECONCILIATION_CENTER",
      targetUserId: null, reason: null,
      afterState: { total: agg.total, countsBySeverity: agg.countsBySeverity },
      ipAddress: clientIp(req),
    });
    res.json({ ok: true, ...agg, categories: RECONCILIATION_ISSUE_TYPES });
  } catch (e) {
    res.status(500).json({ ok: false, error: "reconciliation_failed", reason: (e as Error).message.slice(0, 200) });
  }
});

async function handleAction(
  req: Request, res: Response,
  actionCode:
    | "RECONCILIATION_ISSUE_DISMISSED"
    | "RECONCILIATION_ISSUE_REVIEWED"
    | "RECONCILIATION_ATTRIBUTION_LINKED"
    | "RECONCILIATION_MANUAL_RESOLUTION",
): Promise<void> {
  const role = requireAdmin(req, res); if (!role) return;
  const paramId = String(req.params.id ?? "");
  const v = await validateActionBody(req, res, paramId, actionCode, role);
  if (!v) return;
  try {
    await writeAudit({
      adminId: getAdminId(req), role,
      action: actionCode,
      targetUserId: v.targetUserId,
      reason: v.reason,
      afterState: { issueId: paramId, type: v.type, naturalKey: v.naturalKey },
      ipAddress: clientIp(req),
    });
  } catch {
    res.status(500).json({ ok: false, error: "AUDIT_WRITE_FAILED" });
    return;
  }
  res.json({ ok: true, action: actionCode, issueId: paramId });
}

router.post("/admin/reconciliation-center/issues/:id/dismiss",
  (req, res) => { void handleAction(req, res, "RECONCILIATION_ISSUE_DISMISSED"); });
router.post("/admin/reconciliation-center/issues/:id/mark-reviewed",
  (req, res) => { void handleAction(req, res, "RECONCILIATION_ISSUE_REVIEWED"); });
router.post("/admin/reconciliation-center/issues/:id/link-attribution",
  (req, res) => { void handleAction(req, res, "RECONCILIATION_ATTRIBUTION_LINKED"); });
router.post("/admin/reconciliation-center/issues/:id/resolve-manually",
  (req, res) => { void handleAction(req, res, "RECONCILIATION_MANUAL_RESOLUTION"); });

export default router;
