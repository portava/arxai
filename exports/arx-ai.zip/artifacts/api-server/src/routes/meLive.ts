// Phase B — Live trading routes (per-user).
//
// SAFETY:
// - The dispatch endpoint now calls the 15-gate Phase B evaluator. On PASS
//   the row transitions to SENT_TO_MT5_LIVE and waits for EA pickup. On
//   BLOCKED the row goes to LIVE_BLOCKED with the exact failing reason.
// - The legacy literal `BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED` is still
//   appended to `blockReasons` whenever the server master switch
//   `ARX_LIVE_BROKER_EXECUTION_ENABLED` is false. The CI guard
//   `live-trading-readiness-lock` (scoped to `lib/liveTrading/`) is
//   unaffected — Phase B lives in `lib/live/`.
// - Controlled live test endpoint (`/controlled-test-trigger`) is the ONLY
//   server-side path that arranges a fresh draft → confirm → dispatch in
//   one POST. It is gated by an exact typed phrase and pins symbol=EURUSD
//   + volume=0.01. It NEVER auto-runs; the UI must call it explicitly.
//
// Mount path: /api/me/live/*

import { Router, type Request, type Response } from "express";
import { and, eq, isNull } from "drizzle-orm";
import { requireUser } from "../lib/auth/middleware.js";
import {
  evaluateLiveArmingGate,
  armLiveForUser,
  disarmLiveForUser,
  engageKillSwitchForUser,
  releaseKillSwitchForUser,
  getMyArming,
  LIVE_CONFIRMATION_PHRASE,
  ARX_LIVE_HARD_WEEKLY_DRAWDOWN_PCT,
} from "../lib/live/liveArming.js";
import {
  createLiveDraft,
  createLiveOpsDraft,
  confirmLiveCommand,
  dispatchLiveCommand,
  cancelLiveCommand,
  listMyLiveCommands,
  getMyLiveCommand,
  getOrCreateUserSettings,
  updateUserSettings,
} from "../lib/live/liveCommandPipeline.js";
import { liveBrokerExecutionEnabled } from "../lib/live/phaseBConfig.js";
import { db, arxLivePositionsTable, mt5ConnectionTable } from "@workspace/db";

const router = Router();

const CONTROLLED_LIVE_TEST_PHRASE = "ENABLE LIVE TRADING" as const;

function uid(req: Request): number | null {
  const u = (req as Request & { authUser?: { id?: number } }).authUser;
  return u?.id ?? null;
}
function isAdmin(req: Request): boolean {
  const u = (req as Request & { authUser?: { role?: string } }).authUser;
  return u?.role === "ADMIN" || u?.role === "OWNER";
}

const SAFETY_ENVELOPE = {
  safetyMode: "phase_b_live_runtime_gated" as const,
  liveBrokerExecutionEnabled: false as boolean,
  liveDispatchEvaluator: "evaluateLivePhaseBDispatchGate" as const,
  liveExecutionDefaultDeny: true as const,
};
function envelope() {
  return { ...SAFETY_ENVELOPE, liveBrokerExecutionEnabled: liveBrokerExecutionEnabled() };
}

// ── Arming ─────────────────────────────────────────────────────────────────

router.post("/me/live/arming/preview", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const b = req.body ?? {};
  const gate = await evaluateLiveArmingGate({
    userId,
    isAdmin: isAdmin(req),
    confirmationPhrase: String(b.confirmationPhrase ?? ""),
    riskAcknowledged: b.riskAcknowledged === true,
    accountNumberConfirmed: String(b.accountNumberConfirmed ?? ""),
    brokerConfirmed: b.brokerConfirmed != null ? String(b.brokerConfirmed) : undefined,
    serverConfirmed: b.serverConfirmed != null ? String(b.serverConfirmed) : undefined,
    brokerServerConfirmed: b.brokerServerConfirmed != null ? String(b.brokerServerConfirmed) : undefined,
    maxLotConfirmed: Number(b.maxLotConfirmed ?? 0),
    dailyLossLimitConfirmed: Number(b.dailyLossLimitConfirmed ?? 0),
    killSwitchAcknowledged: b.killSwitchAcknowledged === true,
  });
  // phraseDebug only goes back to admin sessions.
  const gateOut = isAdmin(req) ? gate : { ...gate, phraseDebug: undefined };
  res.json({ gate: gateOut, confirmationPhrase: LIVE_CONFIRMATION_PHRASE, ...envelope() });
});

router.post("/me/live/arming/arm", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const b = req.body ?? {};
  const ip = (req.headers["x-forwarded-for"] as string | undefined)?.split(",")[0]?.trim() ?? req.ip;
  const result = await armLiveForUser({
    userId, isAdmin: isAdmin(req),
    confirmationPhrase: String(b.confirmationPhrase ?? ""),
    riskAcknowledged: b.riskAcknowledged === true,
    accountNumberConfirmed: String(b.accountNumberConfirmed ?? ""),
    brokerConfirmed: b.brokerConfirmed != null ? String(b.brokerConfirmed) : undefined,
    serverConfirmed: b.serverConfirmed != null ? String(b.serverConfirmed) : undefined,
    brokerServerConfirmed: b.brokerServerConfirmed != null ? String(b.brokerServerConfirmed) : undefined,
    maxLotConfirmed: Number(b.maxLotConfirmed ?? 0),
    dailyLossLimitConfirmed: Number(b.dailyLossLimitConfirmed ?? 0),
    killSwitchAcknowledged: b.killSwitchAcknowledged === true,
    ip,
  });
  // phraseDebug only goes back to admin sessions (matches preview behaviour).
  const sanitized = isAdmin(req) || result.gate == null
    ? result
    : { ...result, gate: { ...result.gate, phraseDebug: undefined } };
  res.status(result.ok ? 200 : 409).json({ ...sanitized, ...envelope() });
});

router.post("/me/live/arming/disarm", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const reason = String((req.body ?? {}).reason ?? "user_disarm");
  const result = await disarmLiveForUser({ userId, reason });
  res.json({ ...result, ...envelope() });
});

router.get("/me/live/arming", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const arming = await getMyArming(userId);
  res.json({
    arming: arming ? {
      isArmed: arming.isArmed,
      armedAt: arming.armedAt,
      accountNumberConfirmed: arming.accountNumberConfirmed,
      brokerServerConfirmed: arming.brokerServerConfirmed,
      maxLotConfirmed: arming.maxLotConfirmed,
      dailyLossLimitConfirmed: arming.dailyLossLimitConfirmed,
      killSwitchEngaged: arming.killSwitchEngaged,
      killSwitchEngagedAt: arming.killSwitchEngagedAt,
      killSwitchReason: arming.killSwitchReason,
      disarmedAt: arming.disarmedAt,
      disarmedReason: arming.disarmedReason,
    } : null,
    confirmationPhrase: LIVE_CONFIRMATION_PHRASE,
    hardWeeklyDrawdownPct: ARX_LIVE_HARD_WEEKLY_DRAWDOWN_PCT,
    ...envelope(),
  });
});

// ── Kill switch ────────────────────────────────────────────────────────────

router.post("/me/live/kill-switch/engage", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const reason = String((req.body ?? {}).reason ?? "manual_engage");
  const result = await engageKillSwitchForUser({ userId, reason });
  res.json({ ...result, ...envelope() });
});

router.post("/me/live/kill-switch/release", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const result = await releaseKillSwitchForUser({ userId });
  res.json({ ...result, ...envelope() });
});

// ── Live commands ──────────────────────────────────────────────────────────

router.post("/me/live/commands", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const b = req.body ?? {};
  const ip = (req.headers["x-forwarded-for"] as string | undefined)?.split(",")[0]?.trim() ?? req.ip;
  const result = await createLiveDraft({
    userId,
    commandType: b.commandType,
    symbol: String(b.symbol ?? ""),
    side: b.side,
    orderType: String(b.orderType ?? "MARKET_BUY"),
    requestedVolume: Number(b.requestedVolume ?? b.volume ?? 0),
    stopLoss: b.stopLoss != null ? Number(b.stopLoss) : null,
    takeProfit: b.takeProfit != null ? Number(b.takeProfit) : null,
    sourcePage: b.sourcePage ?? b.source ?? "LIVE_TRADE_TICKET",
    rubyExplanationSummary: b.rubyExplanationSummary ?? null,
    payload: b.payload ?? {},
    ip,
  });
  res.status(result.ok ? 201 : 409).json({ ...result, ...envelope() });
});

router.post("/me/live/commands/:commandId/confirm", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const result = await confirmLiveCommand({ userId, commandId: String(req.params.commandId ?? "") });
  res.status(result.ok ? 200 : 409).json({ ...result, ...envelope() });
});

router.post("/me/live/commands/:commandId/dispatch", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const result = await dispatchLiveCommand({ userId, commandId: String(req.params.commandId ?? "") });
  // Phase B: result.ok may be true (PASS path → SENT_TO_MT5_LIVE) or false
  // (BLOCKED with the exact failing gate reason). Surface 200 either way so
  // the UI renders the full state-machine outcome including LIVE_BLOCKED.
  res.status(200).json({ ...result, ...envelope() });
});

router.post("/me/live/commands/:commandId/cancel", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const reason = String((req.body ?? {}).reason ?? "user_cancel");
  const result = await cancelLiveCommand({ userId, commandId: String(req.params.commandId ?? ""), reason });
  res.status(result.ok ? 200 : 409).json({ ...result, ...envelope() });
});

router.get("/me/live/commands", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const limit = Math.min(Math.max(Number(req.query.limit ?? 50), 1), 200);
  const items = await listMyLiveCommands({ userId, limit });
  res.json({ items, count: items.length, ...envelope() });
});

router.get("/me/live/commands/:commandId", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const row = await getMyLiveCommand(userId, String(req.params.commandId ?? ""));
  if (!row) { res.status(404).json({ error: "COMMAND_NOT_FOUND" }); return; }
  res.json({ command: row, ...envelope() });
});

// ── Live positions — Phase B reads `arx_live_positions` (EA-synced) ────────

router.get("/me/live/positions", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const rows = await db.select().from(arxLivePositionsTable)
    .where(eq(arxLivePositionsTable.userId, userId));
  // Map DB shape → UI-stable shape (kept compatible with existing
  // OpenLivePositions component fields).
  const items = rows.map((r) => ({
    id: r.id,
    brokerPositionId: r.brokerTicket,
    symbol: r.symbol,
    direction: r.side,
    lotSize: Number(r.volume),
    entryPrice: Number(r.entryPrice),
    currentPrice: r.currentPrice != null ? Number(r.currentPrice) : null,
    stopLoss: r.stopLoss != null ? Number(r.stopLoss) : null,
    takeProfit: r.takeProfit != null ? Number(r.takeProfit) : null,
    unrealizedProfitLoss: r.floatingPl != null ? Number(r.floatingPl) : null,
    openedAt: r.openedAt,
    status: r.closedAt ? "CLOSED" : "OPEN",
    sourceCommandId: r.sourceCommandId,
    lastSyncedAt: r.lastSyncedAt,
  }));
  res.json({ items, count: items.length, ...envelope() });
});

// Close a live position by ticket — creates a CLOSE_LIVE_POSITION command,
// auto-confirms, and dispatches through the 15-gate Phase B evaluator.
router.post("/me/live/positions/:ticket/close", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const ticket = String(req.params.ticket ?? "");
  req.log.info({ action: "CLOSE_TRADE_REQUESTED", userId, ticket, scope: "live" }, "trade.close.requested");
  const rows = await db.select().from(arxLivePositionsTable)
    .where(and(eq(arxLivePositionsTable.userId, userId), eq(arxLivePositionsTable.brokerTicket, ticket)))
    .limit(1);
  const pos = rows[0];
  if (!pos) { res.status(404).json({ error: "POSITION_NOT_FOUND" }); return; }

  const draft = await createLiveOpsDraft({
    userId, commandType: "CLOSE_LIVE_POSITION",
    brokerTicket: ticket, symbol: pos.symbol, side: pos.side as "BUY" | "SELL",
    volume: Number(pos.volume), sourcePage: "LIVE_POSITIONS_CLOSE",
  });
  if (!draft.ok) {
    req.log.warn({ action: "SAFETY_GATE_BLOCKED", userId, ticket, stage: "draft", reason: (draft as { error?: string }).error ?? null }, "trade.close.blocked");
    res.status(409).json({ ...draft, ...envelope() }); return;
  }
  const conf = await confirmLiveCommand({ userId, commandId: draft.command.commandId });
  if (!conf.ok) {
    req.log.warn({ action: "SAFETY_GATE_BLOCKED", userId, ticket, stage: "confirm", reason: (conf as { error?: string }).error ?? null }, "trade.close.blocked");
    res.status(409).json({ ...conf, ...envelope() }); return;
  }
  const disp = await dispatchLiveCommand({ userId, commandId: draft.command.commandId });
  if ((disp as { ok?: boolean }).ok === false) {
    req.log.warn({ action: "SAFETY_GATE_BLOCKED", userId, ticket, stage: "dispatch", reason: (disp as { primaryReason?: string }).primaryReason ?? null }, "trade.close.blocked");
  } else {
    req.log.info({ action: "COMMAND_SUBMITTED_AFTER_APPROVAL", userId, ticket, commandType: "CLOSE_LIVE_POSITION" }, "trade.close.dispatched");
  }
  res.json({ ...disp, ...envelope() });
});

/**
 * POST /me/live/positions/close-all — reduce-only "close every open live
 * position". Iterates each open `arx_live_positions` row for the caller,
 * funnels each one through the same `createLiveOpsDraft → confirm →
 * dispatch` path as the single-ticket close. The 16-gate evaluator runs
 * per-ticket; CLOSE commands bypass MISSING_STOP_LOSS via the existing
 * isOpsCommand bypass. NOTE: kill-switch still blocks at preflight —
 * even reduce-only ops require user-armed + kill-switch off (see
 * `createLiveOpsDraft`). One-click-toggle's reduceOnlyCloseAllowed flag
 * is informational only; the gate truth is in the pipeline.
 */
router.post("/me/live/positions/close-all", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const open = await db.select().from(arxLivePositionsTable)
    .where(and(
      eq(arxLivePositionsTable.userId, userId),
      isNull(arxLivePositionsTable.closedAt),
    ));
  req.log.info({ action: "CLOSE_ALL_REQUESTED", userId, openCount: open.length }, "trade.close-all.requested");
  const results: Array<{ ticket: string; ok: boolean; reason?: string }> = [];
  for (const pos of open) {
    const ticket = pos.brokerTicket ?? "";
    if (!ticket) {
      results.push({ ticket: String(pos.id), ok: false, reason: "NO_BROKER_TICKET" });
      continue;
    }
    const draft = await createLiveOpsDraft({
      userId, commandType: "CLOSE_LIVE_POSITION",
      brokerTicket: ticket, symbol: pos.symbol, side: pos.side as "BUY" | "SELL",
      volume: Number(pos.volume), sourcePage: "LIVE_POSITIONS_CLOSE_ALL",
    });
    if (!draft.ok) {
      results.push({ ticket, ok: false, reason: (draft as { reason?: string }).reason });
      continue;
    }
    const conf = await confirmLiveCommand({ userId, commandId: draft.command.commandId });
    if (!conf.ok) {
      results.push({ ticket, ok: false, reason: (conf as { reason?: string }).reason });
      continue;
    }
    const disp = await dispatchLiveCommand({ userId, commandId: draft.command.commandId });
    const ok = (disp as { ok?: boolean }).ok === true;
    results.push({ ticket, ok, reason: ok ? undefined : ((disp as { primaryReason?: string; reason?: string }).primaryReason ?? (disp as { reason?: string }).reason) });
  }
  const closed = results.filter((r) => r.ok).length;
  req.log.info({ action: "CLOSE_ALL_COMPLETED", userId, total: results.length, closed }, "trade.close-all.completed");
  res.json({ ok: true, total: results.length, closed, results, ...envelope() });
});

router.post("/me/live/positions/:ticket/modify", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const ticket = String(req.params.ticket ?? "");
  const b = req.body ?? {};
  const newSL = b.newStopLoss != null ? Number(b.newStopLoss) : null;
  const newTP = b.newTakeProfit != null ? Number(b.newTakeProfit) : null;
  req.log.info({ action: "SLTP_EDIT_REQUESTED", userId, ticket, hasNewSL: newSL != null, hasNewTP: newTP != null }, "trade.modify.requested");
  if (newSL == null && newTP == null) {
    res.status(400).json({ error: "NO_CHANGES", detail: "Provide newStopLoss or newTakeProfit" }); return;
  }
  const rows = await db.select().from(arxLivePositionsTable)
    .where(and(eq(arxLivePositionsTable.userId, userId), eq(arxLivePositionsTable.brokerTicket, ticket)))
    .limit(1);
  const pos = rows[0];
  if (!pos) { res.status(404).json({ error: "POSITION_NOT_FOUND" }); return; }

  const draft = await createLiveOpsDraft({
    userId, commandType: "MODIFY_LIVE_SLTP",
    brokerTicket: ticket, symbol: pos.symbol, side: pos.side as "BUY" | "SELL",
    volume: Number(pos.volume), newStopLoss: newSL, newTakeProfit: newTP,
    sourcePage: "LIVE_POSITIONS_MODIFY",
  });
  if (!draft.ok) {
    req.log.warn({ action: "SAFETY_GATE_BLOCKED", userId, ticket, stage: "draft", reason: (draft as { error?: string }).error ?? null }, "trade.modify.blocked");
    res.status(409).json({ ...draft, ...envelope() }); return;
  }
  const conf = await confirmLiveCommand({ userId, commandId: draft.command.commandId });
  if (!conf.ok) {
    req.log.warn({ action: "SAFETY_GATE_BLOCKED", userId, ticket, stage: "confirm", reason: (conf as { error?: string }).error ?? null }, "trade.modify.blocked");
    res.status(409).json({ ...conf, ...envelope() }); return;
  }
  const disp = await dispatchLiveCommand({ userId, commandId: draft.command.commandId });
  if ((disp as { ok?: boolean }).ok === false) {
    req.log.warn({ action: "SAFETY_GATE_BLOCKED", userId, ticket, stage: "dispatch", reason: (disp as { primaryReason?: string }).primaryReason ?? null }, "trade.modify.blocked");
  } else {
    req.log.info({ action: "COMMAND_SUBMITTED_AFTER_APPROVAL", userId, ticket, commandType: "MODIFY_LIVE_SLTP" }, "trade.modify.dispatched");
  }
  res.json({ ...disp, ...envelope() });
});

// ── Controlled live test — EURUSD 0.01, typed-phrase gated, never auto-runs.
router.post("/me/live/controlled-test-trigger", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const b = req.body ?? {};
  if (String(b.confirmationPhrase ?? "") !== CONTROLLED_LIVE_TEST_PHRASE) {
    res.status(400).json({
      error: "CONFIRMATION_PHRASE_MISMATCH",
      detail: `Type exactly: ${CONTROLLED_LIVE_TEST_PHRASE}`,
      requiredPhrase: CONTROLLED_LIVE_TEST_PHRASE,
    });
    return;
  }
  const side = b.side === "SELL" ? "SELL" : "BUY";
  const sl = b.stopLoss != null ? Number(b.stopLoss) : null;
  if (sl == null || sl <= 0) {
    res.status(400).json({ error: "STOP_LOSS_REQUIRED", detail: "Controlled live test requires explicit SL" });
    return;
  }
  const ip = (req.headers["x-forwarded-for"] as string | undefined)?.split(",")[0]?.trim() ?? req.ip;
  const draft = await createLiveDraft({
    userId,
    commandType: "PLACE_LIVE_MARKET_ORDER",
    symbol: "EURUSD",          // pinned
    side, orderType: side === "SELL" ? "MARKET_SELL" : "MARKET_BUY",
    requestedVolume: 0.01,     // pinned
    stopLoss: sl,
    takeProfit: b.takeProfit != null ? Number(b.takeProfit) : null,
    sourcePage: "CONTROLLED_LIVE_TEST",
    rubyExplanationSummary: "Controlled live test trigger (EURUSD 0.01)",
    payload: { controlledTest: true },
    ip,
  });
  if (!draft.ok) { res.status(409).json({ ...draft, ...envelope() }); return; }
  const conf = await confirmLiveCommand({ userId, commandId: draft.command.commandId });
  if (!conf.ok) { res.status(409).json({ ...conf, ...envelope() }); return; }
  const disp = await dispatchLiveCommand({ userId, commandId: draft.command.commandId });
  res.json({ ...disp, commandId: draft.command.commandId, ...envelope() });
});

// ── User trading-style settings ────────────────────────────────────────────

router.get("/me/live/settings", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const settings = await getOrCreateUserSettings(userId);
  res.json({ settings, hardWeeklyDrawdownPct: ARX_LIVE_HARD_WEEKLY_DRAWDOWN_PCT, ...envelope() });
});

router.put("/me/live/settings", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const b = req.body ?? {};
  // SAFETY: `requireStopLoss` is intentionally NOT user-mutable. Allowing
  // a user to disable their own SL requirement would void the Phase B
  // MISSING_STOP_LOSS gate. The flag defaults to true at the schema layer
  // and may only be overridden by an admin via `adminAllowNoStopLoss`
  // (admin-only path, not exposed on this endpoint). Any `requireStopLoss`
  // field in the request body is silently dropped.
  const updated = await updateUserSettings({
    userId,
    weeklyDrawdownCeilingPct: b.weeklyDrawdownCeilingPct != null ? Number(b.weeklyDrawdownCeilingPct) : undefined,
    dailyLossLimitUsd: b.dailyLossLimitUsd != null ? Number(b.dailyLossLimitUsd) : undefined,
    maxLotPerMarket: b.maxLotPerMarket,
    allowedSymbols: Array.isArray(b.allowedSymbols) ? b.allowedSymbols.map(String) : undefined,
  });
  res.json({ settings: updated, hardWeeklyDrawdownPct: ARX_LIVE_HARD_WEEKLY_DRAWDOWN_PCT, ...envelope() });
});

// ── Live EA heartbeat debug — surfaces the freshest non-revoked bridge for
// this user with v1.27 live-readiness fields + an explicit MOCK warning.
// Read-only. No safety state can be changed from this endpoint.
router.get("/me/live/bridge-debug", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const rows = await db.select().from(mt5ConnectionTable)
    .where(eq(mt5ConnectionTable.userId, userId));
  const nonRevoked = rows.filter((r) => !r.tokenRevokedAt);
  const byFreshness = (a: typeof nonRevoked[number], b: typeof nonRevoked[number]) => {
    const ah = a.lastHeartbeat ? new Date(a.lastHeartbeat).getTime() : 0;
    const bh = b.lastHeartbeat ? new Date(b.lastHeartbeat).getTime() : 0;
    return bh - ah;
  };
  // Selection priority: freshest real LIVE bridge → freshest real DEMO bridge
  // → freshest MOCK row (so the UI can show "you only have a MOCK placeholder").
  const liveReal = nonRevoked.filter((r) => r.mode === "LIVE").sort(byFreshness)[0] ?? null;
  const demoReal = nonRevoked.filter((r) => r.mode === "DEMO").sort(byFreshness)[0] ?? null;
  const anyMock  = nonRevoked.filter((r) => r.mode === "MOCK").sort(byFreshness)[0] ?? null;
  const picked = liveReal ?? demoReal ?? anyMock ?? null;

  if (!picked) {
    res.json({
      bridge: null,
      bridgeKind: "NONE" as const,
      message: "No MT5 bridge connection exists for this user. Create one in MT5 Setup → Bridge Tokens.",
      counts: { live: 0, demo: 0, mock: 0 },
      ...envelope(),
    });
    return;
  }
  const caps = (picked.capabilities ?? {}) as { eaInputs?: Record<string, unknown>; bridgeVersion?: string };
  const ea = (caps.eaInputs ?? {}) as Record<string, unknown>;
  const hbAgeSec = picked.lastHeartbeat
    ? Math.max(0, Math.floor((Date.now() - new Date(picked.lastHeartbeat).getTime()) / 1000))
    : null;
  const bridgeKind = picked.mode === "LIVE" ? ("REAL_LIVE" as const)
    : picked.mode === "DEMO" ? ("REAL_DEMO" as const)
    : ("MOCK" as const);
  res.json({
    bridge: {
      id: picked.id,
      mode: picked.mode,
      bridgeKind,
      accountType: picked.accountType,
      accountNumber: picked.accountNumber,
      brokerName: picked.brokerName,
      serverName: picked.serverName,
      eaVersion: picked.eaVersion,
      bridgeVersion: caps.bridgeVersion ?? null,
      lastHeartbeatAt: picked.lastHeartbeat?.toISOString() ?? null,
      heartbeatAgeSeconds: hbAgeSec,
      heartbeatFresh: hbAgeSec !== null && hbAgeSec <= 15,
      readOnlyMode: picked.readOnlyMode,
      // EA v1.27 reported runtime fields (null = EA build pre-dates the
      // heartbeat extension or did not include the field on this poll)
      eaInputs: {
        readOnlyMode: typeof ea["readOnlyMode"] === "boolean" ? ea["readOnlyMode"] : null,
        enableDemoExecution: typeof ea["enableDemoExecution"] === "boolean" ? ea["enableDemoExecution"] : null,
        enableLiveExecution: typeof ea["enableLiveExecution"] === "boolean" ? ea["enableLiveExecution"] : null,
        terminalConnected: typeof ea["terminalConnected"] === "boolean" ? ea["terminalConnected"] : null,
        algoTradingAllowed: typeof ea["algoTradingAllowed"] === "boolean" ? ea["algoTradingAllowed"] : null,
        maxLiveLot: typeof ea["maxLiveLot"] === "number" ? ea["maxLiveLot"] : null,
        reportedAt: typeof ea["reportedAt"] === "string" ? ea["reportedAt"] : null,
      },
    },
    bridgeKind,
    counts: {
      live: nonRevoked.filter((r) => r.mode === "LIVE").length,
      demo: nonRevoked.filter((r) => r.mode === "DEMO").length,
      mock: nonRevoked.filter((r) => r.mode === "MOCK").length,
    },
    ...envelope(),
  });
});

// EA configuration helper — exposes the exact server base URL + header name
// the EA should use, plus tokenLast4 of the freshest non-revoked bridge for
// disambiguation. NEVER returns the raw token (raw token is shown exactly
// once at /me/mt5-connections POST creation and never re-served).
router.get("/me/live/ea-inputs", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const rows = await db.select().from(mt5ConnectionTable)
    .where(eq(mt5ConnectionTable.userId, userId));
  const nonRevoked = rows.filter((r) => !r.tokenRevokedAt);
  const fresh = nonRevoked
    .slice()
    .sort((a, b) => {
      const ah = a.lastHeartbeat ? new Date(a.lastHeartbeat).getTime() : 0;
      const bh = b.lastHeartbeat ? new Date(b.lastHeartbeat).getTime() : 0;
      return bh - ah;
    })[0] ?? null;
  const protoHeader = (req.headers["x-forwarded-proto"] as string | undefined)?.split(",")[0]?.trim();
  const proto = protoHeader ?? req.protocol ?? "https";
  const host = (req.headers["x-forwarded-host"] as string | undefined) ?? req.get("host") ?? "";
  const serverBaseUrl = host ? `${proto}://${host}` : "";
  res.json({
    serverBaseUrl,
    heartbeatEndpoint: `${serverBaseUrl}/api/mt5/heartbeat`,
    bridgeTokenHeader: "X-MT5-Bridge-Token",
    tokenLast4: fresh?.tokenLast4 ?? null,
    bridgeConnectionId: fresh?.id ?? null,
    rawTokenPolicy: "Raw tokens are shown exactly once at creation and never re-served. To rotate, create a new connection in MT5 Setup.",
    requiredEaInputs: {
      ServerBaseUrl: serverBaseUrl,
      BridgeToken: "<paste raw token from MT5 Setup at creation time>",
      EnableLiveExecution: false,
      MaxLiveLot: 0.01,
      ReadOnlyMode: true,
    },
    note: "ARX_LIVE_BROKER_EXECUTION_ENABLED on the server, plus EnableLiveExecution=true on the EA, plus all 16 Phase B gates passing, are all required before a live order can be dispatched.",
    ...envelope(),
  });
});

export default router;
export { Response };
