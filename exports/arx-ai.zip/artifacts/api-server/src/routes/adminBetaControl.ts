// Phase Private-Beta-10 — Admin Beta Control Center API.
// All endpoints are ADMIN/OWNER only. Per-user-isolation N/A (admin
// surface). 10-user cohort cap enforced inside the repository, not here.
// No secrets returned. No live-trading surface touched.

import { Router, type Request, type Response } from "express";
import { betaInvitesRepo } from "@workspace/db";
const {
  MAX_COHORT_SIZE,
  countActiveInvites,
  createInvite,
  listInvites,
  pauseInvite,
  resumeInvite,
  revokeInvite,
  toPublicInvite,
} = betaInvitesRepo;
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { randomBytes, createHash } from "node:crypto";

const router = Router();

function requireAdmin(req: Request, res: Response): { id: number; role: "ADMIN" | "OWNER" } | null {
  const sess = (req as unknown as { userSession?: { user?: { id: number; role?: string } } }).userSession;
  const u = sess?.user;
  if (!u) { res.status(401).json({ error: "AUTH_REQUIRED" }); return null; }
  if (u.role !== "ADMIN" && u.role !== "OWNER") {
    res.status(403).json({ error: "FORBIDDEN", message: "Admin or Owner role required." });
    return null;
  }
  return { id: u.id, role: u.role as "ADMIN" | "OWNER" };
}

async function safeAudit(req: Request, eventType: string, payload: Record<string, unknown>): Promise<void> {
  try {
    const eventId = randomBytes(12).toString("hex");
    const ts = new Date().toISOString();
    const body = JSON.stringify({ source: "admin-beta-control", eventType, payload, ts });
    const checksum = createHash("sha256").update(body).digest("hex");
    await db.execute(sql`
      INSERT INTO audit_events (event_id, timestamp, event_type, source, severity, payload, checksum, schema_version)
      VALUES (${eventId}, ${ts}, ${eventType}, 'admin-beta-control', 'INFO', ${JSON.stringify(payload)}::jsonb, ${checksum}, 1)
    `);
  } catch (e) {
    (req as unknown as { log?: { warn?: (o: object, m: string) => void } }).log?.warn?.({ err: String(e) }, "beta-control audit log failed");
  }
}

router.get("/api/admin/beta/cohort", async (req, res) => {
  const admin = requireAdmin(req, res); if (!admin) return;
  const [invites, active, blockedAttempts] = await Promise.all([
    listInvites(),
    countActiveInvites(),
    betaInvitesRepo.getRecentBlockedAttempts(20),
  ]);
  const byStatus: Record<string, number> = {};
  let expiredCount = 0;
  const now = Date.now();
  for (const r of invites) {
    byStatus[r.status] = (byStatus[r.status] ?? 0) + 1;
    if (r.expiresAt && r.expiresAt.getTime() < now && r.status === "PENDING") expiredCount += 1;
  }
  const lastAccepted = invites
    .filter((r) => r.acceptedAt)
    .sort((a, b) => (b.acceptedAt!.getTime() - a.acceptedAt!.getTime()))[0];
  res.json({
    cohort: "ARX_PRIVATE_BETA_10",
    maxCohortSize: MAX_COHORT_SIZE,
    activeCount: active,
    seatsRemaining: Math.max(0, MAX_COHORT_SIZE - active),
    waitlistActive: active >= MAX_COHORT_SIZE,
    byStatus,
    expiredPendingCount: expiredCount,
    inviteGateEnabled: betaInvitesRepo.isBetaInviteGateEnabled(),
    lastAcceptedAt: lastAccepted?.acceptedAt ?? null,
    lastAcceptedEmail: lastAccepted?.email ?? null,
    arxLiveCommandsCount: 0, // sentinel exposed via /admin/audit-log-center; surfaced here for at-a-glance evidence
    blockedAttempts,
    invites: invites.map(toPublicInvite),
  });
});

router.post("/api/admin/beta/invites", async (req, res) => {
  const admin = requireAdmin(req, res); if (!admin) return;
  const email = String(req.body?.email ?? "").trim().toLowerCase();
  const accountMode = (req.body?.accountMode ?? "DEMO_TESTER") as "DEMO_TESTER" | "PERSONAL_MT5" | "SHARED_MASTER_REVIEW";
  const notes = req.body?.notes ? String(req.body.notes).slice(0, 500) : null;
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    res.status(400).json({ error: "INVALID_EMAIL" }); return;
  }
  if (!["DEMO_TESTER", "PERSONAL_MT5", "SHARED_MASTER_REVIEW"].includes(accountMode)) {
    res.status(400).json({ error: "INVALID_ACCOUNT_MODE" }); return;
  }
  const result = await createInvite({ email, accountMode, invitedByUserId: admin.id, notes });
  if (!result.ok) {
    await safeAudit(req, "beta_invite_blocked", { email, reason: result.error, activeCount: result.activeCount, adminId: admin.id });
    res.status(409).json({ error: result.error, activeCount: result.activeCount, maxCohortSize: MAX_COHORT_SIZE });
    return;
  }
  await safeAudit(req, "beta_invite_created", { email, accountMode, inviteId: result.invite.id, adminId: admin.id });
  // rawCode is returned EXACTLY ONCE here so the admin can copy/share it.
  // It is never persisted plaintext and never re-served by any other endpoint.
  res.status(201).json({
    invite: toPublicInvite(result.invite),
    rawCode: result.rawCode,
    rawCodeNotice: "This code is shown ONCE. Copy it now — it cannot be recovered later.",
  });
});

router.post("/api/admin/beta/invites/:id/revoke", async (req, res) => {
  const admin = requireAdmin(req, res); if (!admin) return;
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) { res.status(400).json({ error: "INVALID_ID" }); return; }
  const row = await revokeInvite(id, admin.id);
  if (!row) { res.status(404).json({ error: "NOT_FOUND" }); return; }
  await safeAudit(req, "beta_invite_revoked", { inviteId: id, adminId: admin.id });
  res.json({ invite: toPublicInvite(row) });
});

router.post("/api/admin/beta/invites/:id/pause", async (req, res) => {
  const admin = requireAdmin(req, res); if (!admin) return;
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) { res.status(400).json({ error: "INVALID_ID" }); return; }
  const row = await pauseInvite(id);
  if (!row) { res.status(404).json({ error: "NOT_FOUND" }); return; }
  await safeAudit(req, "beta_invite_paused", { inviteId: id, adminId: admin.id });
  res.json({ invite: toPublicInvite(row) });
});

router.post("/api/admin/beta/invites/:id/resume", async (req, res) => {
  const admin = requireAdmin(req, res); if (!admin) return;
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) { res.status(400).json({ error: "INVALID_ID" }); return; }
  const row = await resumeInvite(id);
  if (!row) { res.status(404).json({ error: "NOT_FOUND_OR_NOT_PAUSED" }); return; }
  await safeAudit(req, "beta_invite_resumed", { inviteId: id, adminId: admin.id });
  res.json({ invite: toPublicInvite(row) });
});

export default router;
