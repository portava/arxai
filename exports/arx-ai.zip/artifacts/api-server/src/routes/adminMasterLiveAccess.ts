// Admin — Master Live User Access (per-user approval gate)
//
// Routes:
//   GET    /api/admin/master-live/users              — paginated list
//   GET    /api/admin/master-live/users/:userId      — single user
//   POST   /api/admin/master-live/users/:userId/approve   { reason? }
//   POST   /api/admin/master-live/users/:userId/disable   { reason? }
//   POST   /api/admin/master-live/users/:userId/suspend   { reason? }
//   POST   /api/admin/master-live/users/:userId/risk-lock { reason? }
//   POST   /api/admin/master-live/users/:userId/toggle    { enabled: bool, reason? }
//   POST   /api/admin/master-live/users/:userId/limits    { allowedSymbols?, maxLot?, dailyLossLimitUsd?, requireStopLoss?, scannerLiveEnabled?, reason? }
//   GET    /api/admin/master-live/users/:userId/audit     — last 200 audit rows
//
// SECURITY:
//   - Every handler is requireAdmin.
//   - Every mutation writes a master_live_access_audit row in the same
//     transaction-equivalent flow (insert + update happen sequentially;
//     audit insert MUST succeed before the response is returned).
//   - No raw token, apiKeyHash, password hash, or session secret is ever
//     surfaced. Email is shown to operators (they need to identify the
//     user); on the user-facing /me endpoint email is NOT exposed.
import express, { type IRouter, Router, type Request, type Response } from "express";
import { and, desc, eq, sql } from "drizzle-orm";
import { z } from "zod/v4";
import {
  isUserAcceptedBeta,
} from "../lib/live/operatorFundedPilotGate.js";
import {
  OPERATOR_FUNDED_PILOT_APPROVE_LOCK_KEY,
  OPERATOR_FUNDED_PILOT_MAX_USERS,
} from "../lib/live/operatorFundedPilotConfig.js";
import {
  db,
  usersTable,
  userMasterLiveAccessTable,
  masterLiveAccessAuditTable,
  arxLiveCommandsTable,
  arxLivePositionsTable,
  MASTER_LIVE_ACCESS_ACTIONS,
  type MasterLiveAccessAction,
  type MasterLiveStatus,
} from "@workspace/db";

const router: IRouter = Router();
router.use(express.json());

function requireAdmin(req: Request, res: Response): { id: number; role: "ADMIN" | "OWNER" } | null {
  const sess = (req as Request & { authUser?: { id: number; role?: string } }).authUser;
  if (!sess?.id) {
    res.status(401).json({ ok: false, error: "AUTH_REQUIRED" });
    return null;
  }
  const role = sess.role ?? null;
  if (role !== "ADMIN" && role !== "OWNER") {
    res.status(403).json({ ok: false, error: "ADMIN_REQUIRED" });
    return null;
  }
  return { id: sess.id, role };
}

async function getOrInsertAccess(userId: number) {
  const existing = await db.select().from(userMasterLiveAccessTable)
    .where(eq(userMasterLiveAccessTable.userId, userId)).limit(1);
  if (existing[0]) return existing[0];
  const [row] = await db.insert(userMasterLiveAccessTable).values({
    userId,
    approvedForMasterLive: false,
    masterLiveTradingEnabled: false,
    masterLiveStatus: "NOT_APPROVED",
  }).returning();
  return row!;
}

async function writeAudit(args: {
  adminId: number;
  targetUserId: number;
  action: MasterLiveAccessAction;
  reason?: string;
  before: unknown;
  after: unknown;
  ip?: string | null;
}) {
  await db.insert(masterLiveAccessAuditTable).values({
    adminUserId: args.adminId,
    targetUserId: args.targetUserId,
    action: args.action,
    reason: args.reason ?? null,
    metadata: {
      before: args.before ?? null,
      after: args.after ?? null,
      adminSourceIp: args.ip ?? null,
    },
  });
}

const reasonBody = z.object({ reason: z.string().max(500).optional() });

// ── LIST ─────────────────────────────────────────────────────────────────
router.get("/admin/master-live/users", async (req, res) => {
  const admin = requireAdmin(req, res); if (!admin) return;
  const limit = Math.min(200, Math.max(1, parseInt(String(req.query.limit ?? "100"), 10) || 100));
  const offset = Math.max(0, parseInt(String(req.query.offset ?? "0"), 10) || 0);

  const users = await db.select({
    id: usersTable.id, email: usersTable.email, name: usersTable.name,
    role: usersTable.role, createdAt: usersTable.createdAt,
  }).from(usersTable).orderBy(desc(usersTable.id)).limit(limit).offset(offset);

  // Aggregate access rows + per-user exposure / daily P/L. Join in JS to
  // avoid a multi-table aggregate. Acceptable at limit≤200.
  const userIds = users.map((u) => u.id);
  const accessRows = userIds.length === 0 ? []
    : await db.select().from(userMasterLiveAccessTable);
  const accessByUser = new Map(accessRows.map((r) => [r.userId, r]));

  const result = await Promise.all(users.map(async (u) => {
    const a = accessByUser.get(u.id);
    const exposureRows = await db.select({
      open: sql<number>`COALESCE(SUM(${arxLivePositionsTable.volume}), 0)`,
      pnl: sql<number>`COALESCE(SUM(${arxLivePositionsTable.floatingPl}), 0)`,
    }).from(arxLivePositionsTable).where(and(
      eq(arxLivePositionsTable.userId, u.id),
      sql`${arxLivePositionsTable.closedAt} IS NULL`,
    ));
    const lastTradeRows = await db.select({ at: arxLiveCommandsTable.createdAt })
      .from(arxLiveCommandsTable).where(eq(arxLiveCommandsTable.userId, u.id))
      .orderBy(desc(arxLiveCommandsTable.createdAt)).limit(1);
    return {
      userId: u.id,
      email: u.email,
      name: u.name,
      role: u.role,
      access: a ? {
        status: a.masterLiveStatus,
        approvedForMasterLive: a.approvedForMasterLive,
        masterLiveTradingEnabled: a.masterLiveTradingEnabled,
        approvedAt: a.masterLiveApprovedAt,
        approvedBy: a.masterLiveApprovedBy,
        disabledAt: a.masterLiveDisabledAt,
        disabledBy: a.masterLiveDisabledBy,
        allowedSymbols: a.allowedSymbols ?? [],
        maxLot: a.maxLot,
        dailyLossLimitUsd: a.dailyLossLimitUsd,
        maxOpenPositions: a.maxOpenPositions,
        maxExposurePerSymbolLots: a.maxExposurePerSymbolLots,
        requireStopLoss: a.requireStopLoss,
        scannerLiveEnabled: a.scannerLiveEnabled,
        riskDisclosureAcceptedAt: a.riskDisclosureAcceptedAt,
        riskSettingsConfiguredAt: a.riskSettingsConfiguredAt,
      } : {
        status: "NOT_APPROVED" as MasterLiveStatus,
        approvedForMasterLive: false,
        masterLiveTradingEnabled: false,
      },
      currentExposureLots: Number(exposureRows[0]?.open ?? 0),
      currentDailyPnlUsd: Number(exposureRows[0]?.pnl ?? 0),
      lastTradeAt: lastTradeRows[0]?.at ?? null,
    };
  }));

  return res.json({ ok: true, users: result, limit, offset });
});

// ── HELPER for status-change endpoints ──────────────────────────────────
async function changeStatus(
  req: Request, res: Response,
  newStatus: MasterLiveStatus, action: MasterLiveAccessAction,
  mutator: (current: typeof userMasterLiveAccessTable.$inferSelect) => Partial<typeof userMasterLiveAccessTable.$inferInsert>,
) {
  const admin = requireAdmin(req, res); if (!admin) return;
  const targetUserId = parseInt(String(req.params.userId ?? ""), 10);
  if (!Number.isFinite(targetUserId) || targetUserId <= 0) {
    return res.status(400).json({ ok: false, error: "BAD_USER_ID" });
  }
  const parsed = reasonBody.safeParse(req.body ?? {});
  if (!parsed.success) {
    return res.status(400).json({ ok: false, error: "BAD_BODY" });
  }
  const before = await getOrInsertAccess(targetUserId);
  const patch = mutator(before);
  const [after] = await db.update(userMasterLiveAccessTable)
    .set({ ...patch, masterLiveStatus: newStatus, updatedAt: new Date() })
    .where(eq(userMasterLiveAccessTable.userId, targetUserId)).returning();
  await writeAudit({
    adminId: admin.id, targetUserId, action,
    reason: parsed.data.reason,
    before, after,
    ip: (req.ip ?? null),
  });
  return res.json({ ok: true, access: after });
}

router.post("/admin/master-live/users/:userId/approve", async (req, res) => {
  const admin = requireAdmin(req, res); if (!admin) return;
  const targetUserId = parseInt(String(req.params.userId ?? ""), 10);
  if (!Number.isFinite(targetUserId) || targetUserId <= 0) {
    return res.status(400).json({ ok: false, error: "BAD_USER_ID" });
  }
  const parsed = reasonBody.safeParse(req.body ?? {});
  if (!parsed.success) {
    return res.status(400).json({ ok: false, error: "BAD_BODY" });
  }
  // Beta-cohort check runs outside the txn — read-only and cheap.
  if (!(await isUserAcceptedBeta(targetUserId))) {
    return res.status(403).json({
      ok: false,
      error: "OPERATOR_FUNDED_PILOT_USER_NOT_IN_BETA_COHORT",
      message: "User must be an accepted ARX_PRIVATE_BETA_10 invitee.",
    });
  }

  // ── ATOMIC CAP ENFORCEMENT ───────────────────────────────────────────
  // pg_advisory_xact_lock serializes ALL concurrent /approve requests on
  // the same key. The cap re-check, the access-row upsert, and the audit
  // write all happen inside a single SERIALIZABLE-equivalent window. The
  // lock auto-releases at COMMIT/ROLLBACK.
  type ApproveOutcome =
    | { kind: "ok"; before: unknown; after: typeof userMasterLiveAccessTable.$inferSelect }
    | { kind: "cap"; approvedCount: number };
  const outcome: ApproveOutcome = await db.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(${OPERATOR_FUNDED_PILOT_APPROVE_LOCK_KEY})`);

    const existingRows = await tx.select()
      .from(userMasterLiveAccessTable)
      .where(eq(userMasterLiveAccessTable.userId, targetUserId))
      .limit(1);
    let before = existingRows[0] ?? null;
    if (!before) {
      const [inserted] = await tx.insert(userMasterLiveAccessTable).values({
        userId: targetUserId,
        approvedForMasterLive: false,
        masterLiveTradingEnabled: false,
        masterLiveStatus: "NOT_APPROVED",
      }).returning();
      before = inserted!;
    }

    const isReApproval = before.masterLiveStatus === "APPROVED";
    if (!isReApproval) {
      const countRows = await tx.select({ n: sql<number>`count(*)` })
        .from(userMasterLiveAccessTable)
        .where(and(
          eq(userMasterLiveAccessTable.masterLiveStatus, "APPROVED"),
          eq(userMasterLiveAccessTable.approvedForMasterLive, true),
        ));
      const approvedCount = Number(countRows[0]?.n ?? 0);
      if (approvedCount >= OPERATOR_FUNDED_PILOT_MAX_USERS) {
        return { kind: "cap", approvedCount };
      }
    }

    const [after] = await tx.update(userMasterLiveAccessTable)
      .set({
        approvedForMasterLive: true,
        masterLiveApprovedBy: admin.id,
        masterLiveApprovedAt: isReApproval ? before.masterLiveApprovedAt ?? new Date() : new Date(),
        masterLiveStatus: "APPROVED",
        updatedAt: new Date(),
      })
      .where(eq(userMasterLiveAccessTable.userId, targetUserId))
      .returning();

    await tx.insert(masterLiveAccessAuditTable).values({
      adminUserId: admin.id,
      targetUserId,
      action: "APPROVED",
      reason: parsed.data.reason ?? null,
      metadata: {
        before, after: after ?? null, adminSourceIp: req.ip ?? null,
      },
    });

    return { kind: "ok", before, after: after! };
  });

  if (outcome.kind === "cap") {
    return res.status(409).json({
      ok: false,
      error: "OPERATOR_FUNDED_PILOT_COHORT_CAP_REACHED",
      message: `Operator-funded pilot cap reached (${OPERATOR_FUNDED_PILOT_MAX_USERS}/${OPERATOR_FUNDED_PILOT_MAX_USERS}).`,
      approvedCount: outcome.approvedCount,
      cap: OPERATOR_FUNDED_PILOT_MAX_USERS,
    });
  }
  return res.json({ ok: true, access: outcome.after });
});

router.post("/admin/master-live/users/:userId/disable", (req, res) =>
  changeStatus(req, res, "DISABLED", "DISABLED", () => ({
    masterLiveTradingEnabled: false,
    approvedForMasterLive: false,
    masterLiveDisabledBy: (req as Request & { authUser?: { id: number } }).authUser!.id,
    masterLiveDisabledAt: new Date(),
  })),
);

router.post("/admin/master-live/users/:userId/suspend", (req, res) =>
  changeStatus(req, res, "SUSPENDED", "SUSPENDED", () => ({
    masterLiveTradingEnabled: false,
    masterLiveDisabledBy: (req as Request & { authUser?: { id: number } }).authUser!.id,
    masterLiveDisabledAt: new Date(),
  })),
);

router.post("/admin/master-live/users/:userId/risk-lock", (req, res) =>
  changeStatus(req, res, "RISK_LOCKED", "RISK_LOCKED", () => ({
    masterLiveTradingEnabled: false,
    masterLiveDisabledBy: (req as Request & { authUser?: { id: number } }).authUser!.id,
    masterLiveDisabledAt: new Date(),
  })),
);

// ── TOGGLE on/off (separate from status; user must already be APPROVED) ──
const toggleBody = z.object({ enabled: z.boolean(), reason: z.string().max(500).optional() });
router.post("/admin/master-live/users/:userId/toggle", async (req, res) => {
  const admin = requireAdmin(req, res); if (!admin) return;
  const targetUserId = parseInt(String(req.params.userId ?? ""), 10);
  const parsed = toggleBody.safeParse(req.body ?? {});
  if (!parsed.success) return res.status(400).json({ ok: false, error: "BAD_BODY" });

  const before = await getOrInsertAccess(targetUserId);
  // Refuse turning toggle ON when not APPROVED — defence-in-depth so the
  // gate cannot be subverted by toggling a NOT_APPROVED/SUSPENDED row.
  if (parsed.data.enabled && before.masterLiveStatus !== "APPROVED") {
    return res.status(409).json({
      ok: false,
      error: "TOGGLE_REQUIRES_APPROVED_STATUS",
      currentStatus: before.masterLiveStatus,
    });
  }
  const [after] = await db.update(userMasterLiveAccessTable)
    .set({
      masterLiveTradingEnabled: parsed.data.enabled,
      updatedAt: new Date(),
      ...(parsed.data.enabled ? {} : {
        masterLiveDisabledBy: admin.id,
        masterLiveDisabledAt: new Date(),
      }),
    })
    .where(eq(userMasterLiveAccessTable.userId, targetUserId)).returning();
  await writeAudit({
    adminId: admin.id, targetUserId,
    action: parsed.data.enabled ? "TOGGLE_ON" : "TOGGLE_OFF",
    reason: parsed.data.reason, before, after, ip: req.ip ?? null,
  });
  return res.json({ ok: true, access: after });
});

// ── LIMITS — per-user caps (symbols, max lot, daily loss, etc.) ─────────
const limitsBody = z.object({
  allowedSymbols: z.array(z.string()).optional(),
  maxLot: z.number().positive().optional(),
  dailyLossLimitUsd: z.number().nonnegative().optional(),
  // New concurrency + exposure caps (per-user, enforced by dispatch pipeline).
  // Integer >= 1; null/omitted leaves the column unset (no per-user cap).
  maxOpenPositions: z.number().int().min(1).max(1000).nullable().optional(),
  // Positive lots; null/omitted leaves the column unset (no per-user cap).
  maxExposurePerSymbolLots: z.number().positive().nullable().optional(),
  requireStopLoss: z.boolean().optional(),
  scannerLiveEnabled: z.boolean().optional(),
  reason: z.string().max(500).optional(),
});
router.post("/admin/master-live/users/:userId/limits", async (req, res) => {
  const admin = requireAdmin(req, res); if (!admin) return;
  const targetUserId = parseInt(String(req.params.userId ?? ""), 10);
  const parsed = limitsBody.safeParse(req.body ?? {});
  if (!parsed.success) return res.status(400).json({ ok: false, error: "BAD_BODY" });
  // Audit reason is required when caps are being changed — admins must
  // record WHY each per-user cap shift happened so the audit log is useful.
  const isCapChange =
    parsed.data.maxOpenPositions !== undefined ||
    parsed.data.maxExposurePerSymbolLots !== undefined ||
    parsed.data.maxLot != null ||
    parsed.data.dailyLossLimitUsd != null;
  if (isCapChange && (!parsed.data.reason || parsed.data.reason.trim().length === 0)) {
    return res.status(400).json({ ok: false, error: "REASON_REQUIRED" });
  }
  const before = await getOrInsertAccess(targetUserId);
  const patch: Partial<typeof userMasterLiveAccessTable.$inferInsert> = { updatedAt: new Date() };
  if (parsed.data.allowedSymbols != null) patch.allowedSymbols = parsed.data.allowedSymbols;
  if (parsed.data.maxLot != null) patch.maxLot = parsed.data.maxLot;
  if (parsed.data.dailyLossLimitUsd != null) patch.dailyLossLimitUsd = parsed.data.dailyLossLimitUsd;
  if (parsed.data.maxOpenPositions !== undefined) patch.maxOpenPositions = parsed.data.maxOpenPositions;
  if (parsed.data.maxExposurePerSymbolLots !== undefined) patch.maxExposurePerSymbolLots = parsed.data.maxExposurePerSymbolLots;
  if (parsed.data.requireStopLoss != null) patch.requireStopLoss = parsed.data.requireStopLoss;
  if (parsed.data.scannerLiveEnabled != null) patch.scannerLiveEnabled = parsed.data.scannerLiveEnabled;
  const [after] = await db.update(userMasterLiveAccessTable)
    .set(patch).where(eq(userMasterLiveAccessTable.userId, targetUserId)).returning();
  await writeAudit({
    adminId: admin.id, targetUserId, action: "LIMITS_UPDATED",
    reason: parsed.data.reason, before, after, ip: req.ip ?? null,
  });
  return res.json({ ok: true, access: after });
});

// ── AUDIT LOG read ──────────────────────────────────────────────────────
router.get("/admin/master-live/users/:userId/audit", async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const targetUserId = parseInt(String(req.params.userId ?? ""), 10);
  if (!Number.isFinite(targetUserId)) return res.status(400).json({ ok: false, error: "BAD_USER_ID" });
  const rows = await db.select().from(masterLiveAccessAuditTable)
    .where(eq(masterLiveAccessAuditTable.targetUserId, targetUserId))
    .orderBy(desc(masterLiveAccessAuditTable.createdAt)).limit(200);
  return res.json({ ok: true, audit: rows, validActions: MASTER_LIVE_ACCESS_ACTIONS });
});

export default router;
