// Admin — Live Gates Diagnostic
//
// GET /api/admin/live-gates/diagnostic
//
// One-stop, gate-by-gate, plain-English readout of the live execution
// pipeline state. Each entry is { id, label, status: pass|fail|info,
// detail, rawCode }. Sorted in the order an operator should read them.
//
// SECURITY:
//   - requireAdmin (ADMIN or OWNER session). Anonymous or regular user
//     requests get 403.
//   - NEVER returns raw bridge tokens, key hashes, credential hashes,
//     server secrets, the legacy server-wide bridge env value, or full
//     broker account numbers. Account number is masked to the last 4
//     digits; broker name and server name ARE returned (admins need
//     them to identify the bridge), but only to admin sessions.
//   - No write side-effects. Pure read.
import express, { type IRouter, Router, type Request, type Response } from "express";
import { db, globalTradingSettingsTable } from "@workspace/db";
import {
  derivePlatformBridgeMode,
} from "@workspace/domain/safety-contracts";
import { detectCurrentConnectedBridge } from "../lib/mt5/currentConnectedBridgeDetector.js";
import { liveBrokerExecutionEnabled } from "../lib/live/phaseBConfig.js";
import { loadAndEvaluateMasterLiveBridgeGate } from "../lib/mt5/masterLiveBridgeGate.js";

const router: IRouter = Router();
router.use(express.json());

function requireAdmin(req: Request, res: Response): boolean {
  const sess = (req as Request & { authUser?: { id: number; role?: string } }).authUser;
  if (!sess?.id) {
    res.status(401).json({ ok: false, error: "AUTH_REQUIRED" });
    return false;
  }
  const role = sess.role ?? null;
  if (role !== "ADMIN" && role !== "OWNER") {
    res.status(403).json({ ok: false, error: "ADMIN_REQUIRED" });
    return false;
  }
  return true;
}

type GateStatus = "pass" | "fail" | "info";
interface GateRow {
  id: string;
  label: string;
  status: GateStatus;
  detail: string;
  rawCode?: string;
}

function maskAccount(n: string | null): string {
  if (!n) return "—";
  const s = String(n);
  if (s.length <= 4) return `••••${s}`;
  return `••••${s.slice(-4)}`;
}

router.get("/admin/live-gates/diagnostic", async (req, res) => {
  if (!requireAdmin(req, res)) return;

  const settingsRows = await db.select().from(globalTradingSettingsTable).limit(1);
  const s = settingsRows[0];
  const switchOn = liveBrokerExecutionEnabled();
  const platform = derivePlatformBridgeMode({
    platformMode: s?.platformMode,
    accountRoutingMode: s?.accountRoutingMode,
    masterBridgeLiveEnabled: !!s?.masterBridgeLiveEnabled,
    sharedLiveTradingEnabled: !!s?.sharedLiveTradingEnabled,
    liveBrokerExecutionEnabled: switchOn,
  });

  const detector = await detectCurrentConnectedBridge();
  const masterGate = await loadAndEvaluateMasterLiveBridgeGate();

  const rows: GateRow[] = [];

  rows.push({
    id: "platform_bridge_mode",
    label: "Platform bridge mode",
    status: "info",
    detail: platform.headline,
    rawCode: platform.mode,
  });

  rows.push({
    id: "server_master_switch",
    label: "Server master switch (ARX_LIVE_BROKER_EXECUTION_ENABLED)",
    status: switchOn ? "pass" : "fail",
    detail: switchOn
      ? "Server master switch is ON. The 16-gate evaluator is allowed to consider PASSing."
      : "Server master switch is OFF. Every live dispatch is refused with BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED.",
    rawCode: switchOn ? "LIVE_BROKER_EXECUTION_ENABLED" : "BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED",
  });

  rows.push({
    id: "kill_switch",
    label: "Operator kill switch",
    status: s?.killSwitchEngagedAt ? "fail" : "pass",
    detail: s?.killSwitchEngagedAt
      ? `Kill switch engaged at ${new Date(s.killSwitchEngagedAt).toISOString()}${s.killSwitchReason ? ` — ${s.killSwitchReason}` : ""}.`
      : "Kill switch is not engaged.",
    rawCode: s?.killSwitchEngagedAt ? "KILL_SWITCH_ENGAGED" : "KILL_SWITCH_CLEAR",
  });

  rows.push({
    id: "trading_mode",
    label: "Global trading mode",
    status: (s?.platformMode ?? "OFF").toUpperCase() === "LIVE" ? "pass" : "info",
    detail: `Currently ${(s?.platformMode ?? "OFF").toUpperCase()}.`,
    rawCode: s?.platformMode ?? "OFF",
  });

  rows.push({
    id: "account_routing_mode",
    label: "Account routing mode",
    status: "info",
    detail: (s?.accountRoutingMode ?? "USER_OWNED_MT5") === "SHARED_MASTER_MT5"
      ? "Shared master MT5 bridge (admin operator-funded pilot)."
      : "Each user runs their own MT5 bridge.",
    rawCode: s?.accountRoutingMode ?? "USER_OWNED_MT5",
  });

  rows.push({
    id: "shared_live_trading_enabled",
    label: "shared_live_trading_enabled",
    status: s?.sharedLiveTradingEnabled ? "pass" : "fail",
    detail: s?.sharedLiveTradingEnabled
      ? "Shared live trading is enabled."
      : "Shared live trading is disabled — master bridge stays read-only.",
    rawCode: s?.sharedLiveTradingEnabled ? "SHARED_LIVE_ON" : "SHARED_LIVE_TRADING_DISABLED",
  });

  rows.push({
    id: "master_bridge_live_enabled",
    label: "master_bridge_live_enabled",
    status: s?.masterBridgeLiveEnabled ? "pass" : "fail",
    detail: s?.masterBridgeLiveEnabled
      ? "Master bridge is allowed to execute live (subject to all other gates)."
      : "Master bridge is read-only (admin has not enabled live execution).",
    rawCode: s?.masterBridgeLiveEnabled ? "MASTER_BRIDGE_LIVE_ON" : "MASTER_BRIDGE_LIVE_NOT_ENABLED",
  });

  rows.push({
    id: "master_bridge_binding",
    label: "Master bridge binding",
    status: masterGate.decision === "PASS" ? "pass" : "fail",
    detail: masterGate.decision === "PASS"
      ? `Bound to bridge id ${masterGate.boundBridgeId}.`
      : `Bridge gate refusing: ${masterGate.primaryReason}.`,
    rawCode: masterGate.decision === "PASS" ? "MASTER_BRIDGE_BOUND" : masterGate.primaryReason,
  });

  // EA evidence — only render when detector saw a bridge. Mask account.
  const ev = detector.ok ? detector.bridge : detector.latestHint;
  if (ev) {
    rows.push({
      id: "ea_version",
      label: "EA version",
      status: ev.eaVersion ? "info" : "fail",
      detail: ev.eaVersion ? `EA reports v${ev.eaVersion}.` : "EA has not reported a version yet.",
      rawCode: ev.eaVersion ?? "EA_VERSION_UNKNOWN",
    });
    rows.push({
      id: "ea_account_type",
      label: "Account type",
      status: ev.accountType === "LIVE" || ev.accountType === "REAL" ? "pass" : "fail",
      detail: `Reported as ${ev.accountType}. Live dispatch requires LIVE/REAL.`,
      rawCode: ev.accountType,
    });
    rows.push({
      id: "ea_heartbeat",
      label: "EA heartbeat age",
      status: ev.heartbeatAgeSec != null && ev.heartbeatAgeSec <= 15 ? "pass" : "fail",
      detail: ev.heartbeatAgeSec == null
        ? "No heartbeat received yet."
        : `Last heartbeat ${ev.heartbeatAgeSec}s ago (must be ≤15s for live).`,
      rawCode: ev.heartbeatAgeSec != null && ev.heartbeatAgeSec <= 15 ? "EA_HEARTBEAT_FRESH" : "MASTER_BRIDGE_HEARTBEAT_STALE",
    });
    rows.push({
      id: "ea_read_only",
      label: "EA input: ReadOnlyMode",
      status: ev.eaInputs.readOnlyMode === false ? "pass" : "fail",
      detail: ev.eaInputs.readOnlyMode == null
        ? "EA has not reported ReadOnlyMode."
        : ev.eaInputs.readOnlyMode
          ? "EA is in ReadOnlyMode — operator must set ReadOnlyMode=false in MT5."
          : "EA reports ReadOnlyMode=false.",
      rawCode: ev.eaInputs.readOnlyMode === false ? "EA_READ_ONLY_OFF" : "REJECTED_READ_ONLY_MODE_ACTIVE",
    });
    rows.push({
      id: "ea_enable_live_execution",
      label: "EA input: EnableLiveExecution",
      status: ev.eaInputs.enableLiveExecution === true ? "pass" : "fail",
      detail: ev.eaInputs.enableLiveExecution == null
        ? "EA has not reported EnableLiveExecution."
        : ev.eaInputs.enableLiveExecution
          ? "EA reports EnableLiveExecution=true."
          : "EA input EnableLiveExecution is false — operator must enable in MT5.",
      rawCode: ev.eaInputs.enableLiveExecution === true ? "EA_LIVE_ENABLED" : "EA_LIVE_DISABLED",
    });
    rows.push({
      id: "ea_terminal_connected",
      label: "EA input: terminalConnected",
      status: ev.eaInputs.terminalConnected === true ? "pass" : "fail",
      detail: ev.eaInputs.terminalConnected === true
        ? "MT5 terminal reports connected to broker."
        : "MT5 terminal is not connected to broker.",
      rawCode: ev.eaInputs.terminalConnected === true ? "TERMINAL_CONNECTED" : "TERMINAL_DISCONNECTED",
    });
    rows.push({
      id: "ea_algo_trading_allowed",
      label: "EA input: algoTradingAllowed",
      status: ev.eaInputs.algoTradingAllowed === true ? "pass" : "fail",
      detail: ev.eaInputs.algoTradingAllowed === true
        ? "Algorithmic trading is allowed in MT5."
        : "Algorithmic trading is disabled in MT5 — operator must enable it.",
      rawCode: ev.eaInputs.algoTradingAllowed === true ? "ALGO_TRADING_ALLOWED" : "ALGO_TRADING_DISABLED",
    });
    rows.push({
      id: "ea_max_live_lot",
      label: "EA input: MaxLiveLot",
      status: "info",
      detail: ev.eaInputs.maxLiveLot != null ? `MaxLiveLot=${ev.eaInputs.maxLiveLot}.` : "MaxLiveLot not reported.",
      rawCode: ev.eaInputs.maxLiveLot != null ? `MAX_LIVE_LOT_${ev.eaInputs.maxLiveLot}` : "MAX_LIVE_LOT_UNSET",
    });
    rows.push({
      id: "broker_account",
      label: "Broker account",
      status: "info",
      detail: `Broker=${ev.brokerName ?? "—"}, server=${ev.serverName ?? "—"}, account=${maskAccount(ev.accountNumber)}.`,
      rawCode: `BROKER_ID_${ev.bridgeId}`,
    });
  } else {
    rows.push({
      id: "ea_present",
      label: "EA bridge presence",
      status: "fail",
      detail: "No connected bridge detected.",
      rawCode: detector.ok ? "EA_PRESENT" : detector.primaryReason,
    });
  }

  rows.push({
    id: "broker_placement_layer",
    label: "Broker placement layer",
    status: switchOn ? "pass" : "fail",
    detail: switchOn
      ? "Phase B broker dispatch layer is wired and the master switch is ON."
      : "Phase B broker dispatch layer is wired but the master switch is OFF. No real money can leave.",
    rawCode: switchOn ? "BROKER_PLACEMENT_LAYER_ACTIVE" : "BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED",
  });

  return res.json({
    ok: true,
    platformBridgeMode: platform.mode,
    platformHeadline: platform.headline,
    nextPlatformStep: platform.nextPlatformStep,
    gates: rows,
  });
});

export default router;
