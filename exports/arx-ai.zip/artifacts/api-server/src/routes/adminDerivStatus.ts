// Admin-only Deriv feed diagnostics endpoint.
//
// Returns the same structured status surface the scanner empty-state
// uses, plus boolean-only env detection. Never returns the raw
// DERIV_APP_ID / DERIV_API_TOKEN values.

import { Router, type Request, type Response } from "express";
import { getDerivFeedStatus } from "../lib/data/providers/derivProvider.js";

const router = Router();

function requireAdmin(req: Request, res: Response): { id: number; role: "ADMIN" | "OWNER" } | null {
  const sess = (req as unknown as { userSession?: { user?: { id: number; role?: string } } }).userSession;
  const u = sess?.user;
  if (!u) { res.status(401).json({ error: "AUTH_REQUIRED" }); return null; }
  if (u.role !== "ADMIN" && u.role !== "OWNER") {
    res.status(403).json({ error: "FORBIDDEN", message: "Admin or Owner role required." });
    return null;
  }
  return { id: u.id, role: u.role as "ADMIN" | "OWNER" };
}

router.get("/api/admin/deriv-status", async (req, res) => {
  const admin = requireAdmin(req, res); if (!admin) return;
  const status = getDerivFeedStatus();
  res.json(status);
});

export default router;
