// Phase B (T004) — User-facing live shared-account trade endpoints.
//
// Mount path: /api/trades/live-shared/*
//
// SAFETY (inviolable):
// - Every endpoint goes through the existing Phase B pipeline
//   (createLiveDraft → confirmLiveCommand → dispatchLiveCommand) which
//   internally runs the 16-gate evaluator. NO direct broker calls.
// - Default-deny preserved: when ARX_LIVE_BROKER_EXECUTION_ENABLED is
//   unset/false, dispatch returns LIVE_BLOCKED with the legacy sentinel
//   BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED appended.
// - /validate is a true dry-run: it creates a draft to exercise preflight,
//   then IMMEDIATELY cancels it. No row can ever transition to
//   SENT_TO_MT5_LIVE from this endpoint. Validate rows always end in
//   LIVE_CANCELLED with rejectionReason="VALIDATE_DRYRUN".
// - /execute requires a typed confirmation phrase: "EXECUTE LIVE SHARED".
// - Per-user isolation: every load uses userId from req.authUser.
// - Modify/close go through createLiveOpsDraft (entry-only gates bypassed,
//   but kill-switch / master-switch / EA readiness still enforced).
// - shared_trade_attribution row is best-effort: written only when the
//   routing resolver returns both virtualAccountId and sharedMasterAccountId;
//   otherwise an audit-warn row is logged and the dispatch result is still
//   returned to the caller (the EA can still poll + execute).

import { Router, type Request } from "express";
import { and, eq, desc } from "drizzle-orm";
import { requireUser } from "../lib/auth/middleware.js";
import {
  db,
  arxLiveCommandsTable,
  arxLivePositionsTable,
  sharedTradeAttributionTable,
  liveTradingAuditTable,
} from "@workspace/db";
import {
  createLiveDraft,
  createLiveOpsDraft,
  confirmLiveCommand,
  dispatchLiveCommand,
  cancelLiveCommand,
  listMyLiveCommands,
  getMyLiveCommand,
} from "../lib/live/liveCommandPipeline.js";
import { liveBrokerExecutionEnabled, resolveLiveBrokerExecutionEnabledAsync } from "../lib/live/phaseBConfig.js";
import { resolveRouting } from "../lib/adminTrading/routingResolver.js";
import { randomUUID } from "node:crypto";

const router = Router();

const EXECUTE_PHRASE = "EXECUTE LIVE SHARED" as const;

function uid(req: Request): number | null {
  const u = (req as Request & { authUser?: { id?: number } }).authUser;
  return u?.id ?? null;
}

function envelope() {
  return {
    safetyMode: "phase_b_live_runtime_gated" as const,
    liveBrokerExecutionEnabled: liveBrokerExecutionEnabled(),
    liveDispatchEvaluator: "evaluateLivePhaseBDispatchGate" as const,
    liveExecutionDefaultDeny: true as const,
  };
}

async function auditWarn(args: {
  userId: number; eventType: string; message: string;
  symbol?: string; metadata?: Record<string, unknown>;
}) {
  try {
    await db.insert(liveTradingAuditTable).values({
      eventId: randomUUID(),
      eventType: args.eventType,
      severity: "WARNING",
      mode: "READ_ONLY",
      symbol: args.symbol ?? null,
      message: args.message,
      actorRole: "user",
      metadata: { userId: args.userId, ...(args.metadata ?? {}) },
    });
  } catch { /* audit-only failure */ }
}

// ── Shared-routing precondition. This router is the LIVE-SHARED surface;
// it must refuse any user whose effective routing is not
// SHARED_MASTER_MT5 with both sharedMasterAccountId and virtualAccountId
// resolved. Returning the routing object lets the caller reuse the IDs.
async function requireSharedRouting(userId: number) {
  const routing = await resolveRouting({ userId, mode: "LIVE" });
  if (!routing.ok) {
    return { ok: false as const, status: 409, body: {
      error: "ROUTING_NOT_RESOLVED",
      detail: routing.blockReason ?? "resolveRouting returned ok=false",
      ...envelope(),
    } };
  }
  if (routing.effectiveRoutingMode !== "SHARED_MASTER_MT5") {
    return { ok: false as const, status: 409, body: {
      error: "ROUTING_NOT_SHARED_MASTER",
      detail: `Live shared route requires SHARED_MASTER_MT5, got ${routing.effectiveRoutingMode}`,
      ...envelope(),
    } };
  }
  if (routing.sharedMasterAccountId == null || routing.virtualAccountId == null || routing.connectionId == null) {
    return { ok: false as const, status: 409, body: {
      error: "SHARED_ROUTING_MISSING_IDS",
      detail: "shared_master_account_id / virtual_account_id / connection_id must all be resolved",
      ...envelope(),
    } };
  }
  return { ok: true as const, routing };
}

// ── POST /validate — dry-run via draft+cancel. No SENT_TO_MT5_LIVE row ever.
router.post("/trades/live-shared/validate", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const shared = await requireSharedRouting(userId);
  if (!shared.ok) { res.status(shared.status).json(shared.body); return; }
  const b = req.body ?? {};
  const side = b.side === "SELL" ? "SELL" : "BUY";
  const symbol = String(b.symbol ?? "").toUpperCase();
  const volume = Number(b.volume ?? 0);
  if (!symbol) { res.status(400).json({ error: "SYMBOL_REQUIRED", ...envelope() }); return; }
  if (!Number.isFinite(volume) || volume <= 0) {
    res.status(400).json({ error: "VOLUME_REQUIRED", ...envelope() }); return;
  }
  const stopLoss = b.stopLoss != null ? Number(b.stopLoss) : null;
  const takeProfit = b.takeProfit != null ? Number(b.takeProfit) : null;

  const draft = await createLiveDraft({
    userId,
    commandType: "PLACE_LIVE_MARKET_ORDER",
    symbol, side,
    orderType: side === "SELL" ? "MARKET_SELL" : "MARKET_BUY",
    requestedVolume: volume,
    stopLoss, takeProfit,
    sourcePage: "TRADES_LIVE_SHARED_VALIDATE",
    rubyExplanationSummary: "validate dry-run",
    payload: { validateDryRun: true },
  });
  if (!draft.ok) {
    res.status(200).json({
      ok: false, stage: "preflight",
      reason: draft.reason, detail: draft.detail ?? null,
      ...envelope(),
    });
    return;
  }
  // Immediately cancel so the row never reaches dispatch. If cancel fails
  // for any reason, we MUST report failure so the operator knows a draft
  // row is sitting in LIVE_CONFIRMATION_REQUIRED.
  const cancelled = await cancelLiveCommand({
    userId, commandId: draft.command.commandId,
    reason: "VALIDATE_DRYRUN",
  });
  if (!cancelled.ok) {
    await auditWarn({
      userId, eventType: "VALIDATE_CANCEL_FAILED", symbol,
      message: `Validate dry-run cancel failed; draft left in non-terminal state`,
      metadata: { commandId: draft.command.commandId, cancelReason: cancelled.reason },
    });
    res.status(500).json({
      ok: false, stage: "validate_cancel_failed",
      commandId: draft.command.commandId,
      cancelResult: cancelled,
      detail: "Draft created but could not be cancelled. Call /cancel manually.",
      ...envelope(),
    });
    return;
  }
  res.status(200).json({
    ok: true, stage: "preflight_passed",
    commandId: draft.command.commandId,
    cancelled: true,
    note: "Preflight gates passed. Run /execute with confirmationIntent to actually dispatch.",
    ...envelope(),
  });
});

// ── POST /execute — typed-phrase gated; draft → confirm → dispatch; writes
// shared_trade_attribution as a required step on dispatch success.
router.post("/trades/live-shared/execute", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const shared = await requireSharedRouting(userId);
  if (!shared.ok) { res.status(shared.status).json(shared.body); return; }
  const routing = shared.routing;
  const b = req.body ?? {};
  if (String(b.confirmationIntent ?? "") !== EXECUTE_PHRASE) {
    res.status(400).json({
      error: "CONFIRMATION_INTENT_MISMATCH",
      detail: `Type exactly: ${EXECUTE_PHRASE}`,
      requiredPhrase: EXECUTE_PHRASE,
      ...envelope(),
    });
    return;
  }
  const side = b.side === "SELL" ? "SELL" : "BUY";
  const symbol = String(b.symbol ?? "").toUpperCase();
  const volume = Number(b.volume ?? 0);
  if (!symbol) { res.status(400).json({ error: "SYMBOL_REQUIRED", ...envelope() }); return; }
  if (!Number.isFinite(volume) || volume <= 0) {
    res.status(400).json({ error: "VOLUME_REQUIRED", ...envelope() }); return;
  }
  const stopLoss = b.stopLoss != null ? Number(b.stopLoss) : null;
  const takeProfit = b.takeProfit != null ? Number(b.takeProfit) : null;
  if (stopLoss == null || stopLoss <= 0) {
    res.status(400).json({
      error: "STOP_LOSS_REQUIRED",
      detail: "Live shared dispatch requires an explicit stopLoss > 0.",
      ...envelope(),
    });
    return;
  }

  // QA enrichment: every queued shared-live command must carry an
  // internalTradeId + accountMode + tradingMode + risk snapshot in payload.
  // Validation snapshot (dispatchGateSnapshot) and confirmation timestamp
  // (confirmedAt) are set by the pipeline; we attach the rest here.
  const internalTradeId = `arx_trade_${randomUUID()}`;
  const riskSnapshot = {
    symbol, side, requestedVolume: volume,
    stopLoss, takeProfit,
    riskRewardRatio: (stopLoss != null && takeProfit != null && stopLoss > 0)
      ? Math.abs((takeProfit - 0) / Math.max(stopLoss, 1e-9))
      : null,
    capturedAt: new Date().toISOString(),
  };
  const draft = await createLiveDraft({
    userId,
    commandType: "PLACE_LIVE_MARKET_ORDER",
    symbol, side,
    orderType: side === "SELL" ? "MARKET_SELL" : "MARKET_BUY",
    requestedVolume: volume,
    stopLoss, takeProfit,
    sourcePage: "TRADES_LIVE_SHARED_EXECUTE",
    rubyExplanationSummary: typeof b.rubyExplanationSummary === "string"
      ? b.rubyExplanationSummary : null,
    payload: {
      tradesLiveShared: true,
      internalTradeId,
      accountMode: "SHARED" as const,
      tradingMode: "LIVE" as const,
      sharedMasterAccountId: routing.sharedMasterAccountId,
      virtualAccountId: routing.virtualAccountId,
      masterConnectionId: routing.connectionId,
      riskSnapshot,
    },
  });
  if (!draft.ok) {
    res.status(409).json({ stage: "preflight", ...draft, ...envelope() });
    return;
  }
  const conf = await confirmLiveCommand({ userId, commandId: draft.command.commandId });
  if (!conf.ok) {
    res.status(409).json({ stage: "confirm", ...conf, commandId: draft.command.commandId, ...envelope() });
    return;
  }

  // FAIL-CLOSED ATTRIBUTION: insert shared_trade_attribution BEFORE dispatch.
  // If the insert fails, the command is still LIVE_APPROVED (not yet
  // SENT_TO_MT5_LIVE) so we can safely cancel it; the EA can never pick up
  // a command that has no attribution row. After dispatch we update the
  // attribution row to 'open' on PASS or 'rejected' on BLOCK.
  let attributionId: number | null = null;
  try {
    const [attr] = await db.insert(sharedTradeAttributionTable).values({
      userId,
      virtualAccountId: routing.virtualAccountId!,
      sharedMasterAccountId: routing.sharedMasterAccountId!,
      masterConnectionId: routing.connectionId!,
      symbol, side, lotSize: volume,
      stopLoss, takeProfit,
      status: "pending",
    }).returning({ id: sharedTradeAttributionTable.id });
    attributionId = attr?.id ?? null;
    if (attributionId == null) throw new Error("attribution insert returned no id");
  } catch (e) {
    const msg = (e as Error).message;
    await auditWarn({
      userId, eventType: "ATTRIBUTION_PRE_DISPATCH_FAILED", symbol,
      message: `shared_trade_attribution insert failed before dispatch: ${msg}`,
      metadata: { commandId: draft.command.commandId },
    });
    // FAIL-CLOSED CASCADE: render the LIVE_APPROVED command permanently
    // non-dispatchable so the alternate dispatch path (/me/live/commands/:id/dispatch)
    // cannot pick it up. Three layers:
    //   1) cancelLiveCommand (clean transition)
    //   2) direct DB UPDATE to LIVE_BLOCKED (legal transition from LIVE_APPROVED)
    //   3) HIGH-severity audit if both fail
    let madeTerminal = false;
    const cancelRes = await cancelLiveCommand({
      userId, commandId: draft.command.commandId,
      reason: "ATTRIBUTION_INSERT_FAILED",
    }).catch(() => ({ ok: false as const, reason: "CANCEL_THREW" as const }));
    if (cancelRes.ok) { madeTerminal = true; }
    else {
      try {
        await db.update(arxLiveCommandsTable).set({
          status: "LIVE_BLOCKED",
          rejectionReason: "ATTRIBUTION_INSERT_FAILED",
          rejectedAt: new Date(),
        }).where(and(
          eq(arxLiveCommandsTable.commandId, draft.command.commandId),
          eq(arxLiveCommandsTable.userId, userId),
        ));
        madeTerminal = true;
      } catch (e2) {
        await db.insert(liveTradingAuditTable).values({
          eventId: randomUUID(),
          eventType: "ATTRIBUTION_FAILSAFE_CASCADE_FAILED",
          severity: "HIGH",
          mode: "READ_ONLY",
          symbol,
          message: `CRITICAL: attribution insert AND cancel AND force-block all failed for ${draft.command.commandId}. Manual ops intervention required.`,
          actorRole: "user",
          metadata: {
            userId, commandId: draft.command.commandId,
            attributionError: msg,
            cancelReason: (cancelRes as { reason?: string }).reason,
            forceBlockError: (e2 as Error).message,
          },
        }).catch(() => undefined);
      }
    }
    res.status(500).json({
      ok: false, stage: "attribution_pre_dispatch_failed",
      commandId: draft.command.commandId,
      reason: "ATTRIBUTION_INSERT_FAILED",
      detail: msg,
      commandRenderedTerminal: madeTerminal,
      ...envelope(),
    });
    return;
  }

  const disp = await dispatchLiveCommand({ userId, commandId: draft.command.commandId });

  // Reflect dispatch outcome into the attribution row.
  try {
    await db.update(sharedTradeAttributionTable).set({
      status: disp.ok ? "open" : "rejected",
      rejectionReason: disp.ok ? null
        : ((disp as { primaryReason?: string }).primaryReason ?? "DISPATCH_BLOCKED"),
      updatedAt: new Date(),
    }).where(eq(sharedTradeAttributionTable.id, attributionId));
  } catch (e) {
    await auditWarn({
      userId, eventType: "ATTRIBUTION_POST_DISPATCH_UPDATE_FAILED", symbol,
      message: `attribution post-dispatch status update failed: ${(e as Error).message}`,
      metadata: { commandId: draft.command.commandId, attributionId },
    });
  }

  res.status(disp.ok ? 200 : 409).json({
    ...disp,
    commandId: draft.command.commandId,
    attributionId,
    ...envelope(),
  });
});

// ── POST /cancel — cancel an in-flight draft/confirmation.
router.post("/trades/live-shared/cancel", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const commandId = String(req.body?.commandId ?? "");
  if (!commandId) { res.status(400).json({ error: "COMMAND_ID_REQUIRED", ...envelope() }); return; }
  const reason = String(req.body?.reason ?? "USER_CANCELLED");
  const result = await cancelLiveCommand({ userId, commandId, reason });
  res.status(result.ok ? 200 : 409).json({ ...result, ...envelope() });
});

// ── POST /positions/:ticket/close — emergency close via createLiveOpsDraft.
router.post("/trades/live-shared/positions/:ticket/close", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const sharedC = await requireSharedRouting(userId);
  if (!sharedC.ok) { res.status(sharedC.status).json(sharedC.body); return; }
  const ticket = String(req.params.ticket);
  const rows = await db.select().from(arxLivePositionsTable)
    .where(and(
      eq(arxLivePositionsTable.userId, userId),
      eq(arxLivePositionsTable.brokerTicket, ticket),
    )).limit(1);
  const pos = rows[0];
  if (!pos) { res.status(404).json({ error: "POSITION_NOT_FOUND", ...envelope() }); return; }
  const draft = await createLiveOpsDraft({
    userId,
    commandType: "CLOSE_LIVE_POSITION",
    brokerTicket: ticket,
    symbol: pos.symbol,
    side: pos.side === "SELL" ? "SELL" : "BUY",
    volume: Number(pos.volume),
    sourcePage: "TRADES_LIVE_SHARED_CLOSE",
  });
  if (!draft.ok) { res.status(409).json({ ...draft, ...envelope() }); return; }
  const conf = await confirmLiveCommand({ userId, commandId: draft.command.commandId });
  if (!conf.ok) { res.status(409).json({ ...conf, commandId: draft.command.commandId, ...envelope() }); return; }
  const disp = await dispatchLiveCommand({ userId, commandId: draft.command.commandId });
  res.status(disp.ok ? 200 : 409).json({ ...disp, commandId: draft.command.commandId, ...envelope() });
});

// ── POST /positions/:ticket/modify — SL/TP modify.
router.post("/trades/live-shared/positions/:ticket/modify", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const sharedM = await requireSharedRouting(userId);
  if (!sharedM.ok) { res.status(sharedM.status).json(sharedM.body); return; }
  const ticket = String(req.params.ticket);
  const b = req.body ?? {};
  const newStopLoss = b.stopLoss != null ? Number(b.stopLoss) : null;
  const newTakeProfit = b.takeProfit != null ? Number(b.takeProfit) : null;
  if (newStopLoss == null && newTakeProfit == null) {
    res.status(400).json({ error: "NO_FIELDS_TO_MODIFY", detail: "Provide stopLoss and/or takeProfit", ...envelope() });
    return;
  }
  const rows = await db.select().from(arxLivePositionsTable)
    .where(and(
      eq(arxLivePositionsTable.userId, userId),
      eq(arxLivePositionsTable.brokerTicket, ticket),
    )).limit(1);
  const pos = rows[0];
  if (!pos) { res.status(404).json({ error: "POSITION_NOT_FOUND", ...envelope() }); return; }
  const draft = await createLiveOpsDraft({
    userId,
    commandType: "MODIFY_LIVE_SLTP",
    brokerTicket: ticket,
    symbol: pos.symbol,
    side: pos.side === "SELL" ? "SELL" : "BUY",
    volume: Number(pos.volume),
    newStopLoss, newTakeProfit,
    sourcePage: "TRADES_LIVE_SHARED_MODIFY",
  });
  if (!draft.ok) { res.status(409).json({ ...draft, ...envelope() }); return; }
  const conf = await confirmLiveCommand({ userId, commandId: draft.command.commandId });
  if (!conf.ok) { res.status(409).json({ ...conf, commandId: draft.command.commandId, ...envelope() }); return; }
  const disp = await dispatchLiveCommand({ userId, commandId: draft.command.commandId });
  res.status(disp.ok ? 200 : 409).json({ ...disp, commandId: draft.command.commandId, ...envelope() });
});

// ── GET /commands — per-user list (read-only).
router.get("/trades/live-shared/commands", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const limit = req.query.limit ? Number(req.query.limit) : 50;
  const rows = await listMyLiveCommands({ userId, limit });
  res.json({ commands: rows, ...envelope() });
});

// ── GET /commands/:commandId — per-user single (read-only).
router.get("/trades/live-shared/commands/:commandId", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const cmd = await getMyLiveCommand(userId, String(req.params.commandId));
  if (!cmd) { res.status(404).json({ error: "COMMAND_NOT_FOUND", ...envelope() }); return; }
  res.json({ command: cmd, ...envelope() });
});

// ── GET /attributions — per-user attribution rows (read-only).
router.get("/trades/live-shared/attributions", requireUser, async (req, res) => {
  const userId = uid(req);
  if (!userId) { res.status(401).json({ error: "AUTH_REQUIRED" }); return; }
  const limit = req.query.limit ? Math.min(Math.max(Number(req.query.limit), 1), 200) : 50;
  const rows = await db.select().from(sharedTradeAttributionTable)
    .where(eq(sharedTradeAttributionTable.userId, userId))
    .orderBy(desc(sharedTradeAttributionTable.id))
    .limit(limit);
  res.json({ attributions: rows, ...envelope() });
});

export default router;
