// Global Instant Trade Router — POST /api/trades/instant/*
//
// Single shared backend used by every trade-capable surface in the
// app: trade panel, scanner, chart, watchlist, position card, dashboard,
// alert click-through, and Ruby AI (text + voice). All callers send the
// same `InstantTradeIntent` shape so audit logs and source attribution
// are uniform.
//
// SAFETY: zero new gate logic lives here. Every decision (live one-click
// enabled, master-live access, server master switch, 16-gate Phase B,
// kill switch, max lot, daily loss, symbol allowlist, missing SL unless
// override) is enforced inside `executeInstant()` in
// `lib/live/instantTrade.ts`, which calls the existing
// `createLiveDraft → confirmLiveCommand → dispatchLiveCommand` pipeline.
//
// What this route file adds:
//   - HTTP surface area
//   - Zod input validation
//   - Pulls IP / User-Agent off req for audit row
//   - Maps `InstantTradeResult` → HTTP status code
import express, { type IRouter, Router, type Request } from "express";
import { z } from "zod/v4";
import { requireUser } from "../lib/auth/middleware.js";
import {
  executeInstant, validateInstant,
  INSTANT_TRADE_SOURCES, INSTANT_TRADE_ACTIONS,
  type InstantTradeIntent,
} from "../lib/live/instantTrade.js";

const router: IRouter = Router();
router.use(express.json());

const userOf = (req: Request) =>
  (req as Request & { authUser?: { id: number } }).authUser!.id;

const ipOf = (req: Request) =>
  (req.headers["x-forwarded-for"] as string | undefined)?.split(",")[0]?.trim()
  ?? req.socket.remoteAddress ?? null;
const uaOf = (req: Request) => (req.headers["user-agent"] as string | undefined) ?? null;

const IntentSchema = z.object({
  source: z.enum(INSTANT_TRADE_SOURCES),
  action: z.enum(INSTANT_TRADE_ACTIONS),
  accountMode: z.enum(["live", "demo", "paper"]),
  symbol: z.string().min(1).max(32).optional(),
  volume: z.number().positive().optional(),
  orderType: z.string().min(1).max(32).optional(),
  stopLoss: z.number().nullable().optional(),
  takeProfit: z.number().nullable().optional(),
  positionId: z.string().min(1).max(64).optional(),
  newStopLoss: z.number().nullable().optional(),
  newTakeProfit: z.number().nullable().optional(),
  oneClick: z.boolean().optional(),
  aiCommand: z.boolean().optional(),
  rawUserCommand: z.string().max(1024).nullable().optional(),
  parsedByRuby: z.boolean().optional(),
}) satisfies z.ZodType<InstantTradeIntent>;

function parseIntent(req: Request, defaultAction?: "BUY" | "SELL" | "CLOSE" | "CLOSE_ALL" | "MODIFY_SL_TP") {
  const body = (req.body ?? {}) as Record<string, unknown>;
  if (defaultAction && !body.action) body.action = defaultAction;
  const r = IntentSchema.safeParse(body);
  return r;
}

router.post("/trades/instant/execute", requireUser, async (req, res) => {
  const userId = userOf(req);
  const parsed = parseIntent(req);
  if (!parsed.success) {
    res.status(400).json({ ok: false, error: "INVALID_INTENT", issues: parsed.error.issues });
    return;
  }
  const result = await executeInstant({
    userId, intent: parsed.data, ip: ipOf(req), ua: uaOf(req),
  });
  if (result.ok) {
    res.json({ ok: true, action: result.action, commandId: result.commandId, detail: result.detail });
    return;
  }
  res.status(result.httpStatus).json({
    ok: false, error: result.error, primaryReason: result.primaryReason ?? null, detail: result.detail,
  });
});

router.post("/trades/instant/close", requireUser, async (req, res) => {
  const userId = userOf(req);
  const parsed = parseIntent(req, "CLOSE");
  if (!parsed.success) {
    res.status(400).json({ ok: false, error: "INVALID_INTENT", issues: parsed.error.issues });
    return;
  }
  const intent: InstantTradeIntent = { ...parsed.data, action: "CLOSE" };
  const result = await executeInstant({ userId, intent, ip: ipOf(req), ua: uaOf(req) });
  if (result.ok) {
    res.json({ ok: true, action: "CLOSE", commandId: result.commandId, detail: result.detail });
    return;
  }
  res.status(result.httpStatus).json({ ok: false, error: result.error, primaryReason: result.primaryReason ?? null, detail: result.detail });
});

router.post("/trades/instant/close-all", requireUser, async (req, res) => {
  const userId = userOf(req);
  const parsed = parseIntent(req, "CLOSE_ALL");
  if (!parsed.success) {
    res.status(400).json({ ok: false, error: "INVALID_INTENT", issues: parsed.error.issues });
    return;
  }
  const intent: InstantTradeIntent = { ...parsed.data, action: "CLOSE_ALL" };
  const result = await executeInstant({ userId, intent, ip: ipOf(req), ua: uaOf(req) });
  if (result.ok) {
    res.json({ ok: true, action: "CLOSE_ALL", detail: result.detail });
    return;
  }
  res.status(result.httpStatus).json({ ok: false, error: result.error, primaryReason: result.primaryReason ?? null, detail: result.detail });
});

router.post("/trades/instant/validate", requireUser, async (req, res) => {
  const userId = userOf(req);
  const parsed = parseIntent(req);
  if (!parsed.success) {
    res.status(400).json({ ok: false, error: "INVALID_INTENT", issues: parsed.error.issues });
    return;
  }
  const result = await validateInstant({ userId, intent: parsed.data, ip: ipOf(req), ua: uaOf(req) });
  if (result.ok) { res.json({ ok: true, detail: result.detail }); return; }
  res.status(result.httpStatus).json({ ok: false, error: result.error, primaryReason: result.primaryReason ?? null });
});

export default router;
