// Market Scanner / Opportunity / Session Plan / Decision Stream / Alerts HTTP.
//
// SAFETY: Scanner is read-only over the simulator. Mutating endpoints
// (scanner start/stop/scan, alert actions) require ADMIN. Nothing here
// touches live_positions, mt5_commands, or placeLiveOrderGuarded().
import { Router, type Request, type Response, type NextFunction } from "express";
import { z } from "zod/v4";
import { readRoleFromRequest } from "../lib/security/middleware.js";
import {
  scanOnce, scannerStart, scannerStop, scannerStatus, scannerOpportunities,
  opportunityScore, sessionPlan, decisionStream, listAlerts, alertAction, alertCount,
  decorateOpportunitiesWithHistory, decorateOpportunitiesWithNewsRisk,
  decorateOpportunitiesWithFinalRead,
  DEFAULT_SYMBOLS, DEFAULT_TIMEFRAMES, UNIVERSES, UNIVERSE_IDS, type UniverseId,
} from "../lib/marketScanner.js";
import { analyzeMarket, generateTradeCard } from "../lib/aiBrain.js";
import { getSelectedMarketSnapshot } from "../lib/scannerSelected/selectedMarket.js";
import { SUPPORTED_SYMBOLS, normalizeSymbol } from "../lib/scannerSelected/symbolNormalize.js";

const router = Router();

function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  const role = readRoleFromRequest(req);
  if (role !== "ADMIN" && role !== "OWNER") {
    res.status(403).json({ error: "Forbidden", requiredRole: "ADMIN" });
    return;
  }
  next();
}

// ── Scanner ────────────────────────────────────────────────────────────────
router.get("/market-scanner/status", (_req, res) => res.json(scannerStatus()));
router.get("/market-scanner/opportunities", async (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 50, 200);
  const status = scannerStatus();
  const base = scannerOpportunities(limit);
  const withHistory = await decorateOpportunitiesWithHistory(base);
  const withNews = await decorateOpportunitiesWithNewsRisk(withHistory);
  const decorated = decorateOpportunitiesWithFinalRead(withNews);
  return res.json({
    opportunities: decorated,
    universe: status.universe,
    universeSymbols: status.universeSymbols,
    defaults: { symbols: DEFAULT_SYMBOLS, timeframes: DEFAULT_TIMEFRAMES },
    dataSource: "SIMULATOR",
    feedNote: status.feedNote,
  });
});

router.get("/market-scanner/universes", (_req, res) => {
  return res.json({
    universes: UNIVERSE_IDS.map((id) => ({
      id,
      label: ({
        all: "All Markets", forex: "Forex", metals: "Metals",
        crypto: "Crypto", stocks: "Stocks", synthetic: "Synthetic Indices",
      } as const)[id],
      symbols: UNIVERSES[id],
      available: UNIVERSES[id].length > 0,
      note: id === "synthetic"
        ? "Volatility / Boom / Crash indices need a live broker feed (Deriv or MT5)."
        : null,
    })),
    dataSource: "SIMULATOR",
  });
});

const UniverseEnum = z.enum(UNIVERSE_IDS as [UniverseId, ...UniverseId[]]);

router.post("/market-scanner/start", requireAdmin, (req, res) => {
  const Body = z.object({
    intervalMs: z.number().int().min(1000).optional(),
    universe: UniverseEnum.optional(),
  });
  const p = Body.safeParse(req.body ?? {});
  return res.json(scannerStart(p.success ? p.data : {}));
});

router.post("/market-scanner/stop", requireAdmin, (_req, res) => res.json(scannerStop()));

router.post("/market-scanner/scan", requireAdmin, async (req, res) => {
  const Body = z.object({
    symbols: z.array(z.string()).optional(),
    timeframes: z.array(z.string()).optional(),
    universe: UniverseEnum.optional(),
  });
  const p = Body.safeParse(req.body ?? {});
  const opps = scanOnce(p.success ? p.data : {});
  const withHistory = await decorateOpportunitiesWithHistory(opps);
  const withNews = await decorateOpportunitiesWithNewsRisk(withHistory);
  const decorated = decorateOpportunitiesWithFinalRead(withNews);
  const status = scannerStatus();
  return res.json({
    opportunities: decorated,
    count: decorated.length,
    universe: status.universe,
    universeSymbols: status.universeSymbols,
    dataSource: "SIMULATOR",
    feedNote: status.feedNote,
  });
});

// ── AI helpers ─────────────────────────────────────────────────────────────
router.post("/ai/opportunity-score", (req, res) => {
  const Body = z.object({ symbol: z.string(), timeframe: z.string().optional(), strategyMatch: z.number().optional() });
  const p = Body.safeParse(req.body ?? {});
  if (!p.success) return res.status(400).json({ error: "symbol required" });
  const a = analyzeMarket(p.data.symbol, p.data.timeframe);
  const opp = opportunityScore(a, p.data.strategyMatch ?? 7);
  return res.json({ ...opp, symbol: p.data.symbol, timeframe: a.timeframe, dataSource: "SIMULATOR" });
});

router.post("/ai/setup-analysis", (req, res) => {
  const Body = z.object({ symbol: z.string(), timeframe: z.string().optional() });
  const p = Body.safeParse(req.body ?? {});
  if (!p.success) return res.status(400).json({ error: "symbol required" });
  const a = analyzeMarket(p.data.symbol, p.data.timeframe);
  const opp = opportunityScore(a);
  const card = generateTradeCard(p.data.symbol, p.data.timeframe);
  return res.json({ analysis: a, opportunity: opp, card, dataSource: "SIMULATOR" });
});

router.post("/ai/session-plan", (_req, res) => res.json(sessionPlan()));
router.get("/ai/session-plan", (_req, res) => res.json(sessionPlan()));

// ── Decision stream ────────────────────────────────────────────────────────
router.get("/decision-stream", (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 50, 200);
  return res.json({ decisions: decisionStream(limit), dataSource: "SIMULATOR" });
});

// ── Alert engine (in-memory; coexists with persistent /api/alerts) ─────────
router.get("/alerts/scanner", (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 100, 200);
  const unackedOnly = req.query.unackedOnly === "true";
  return res.json({
    alerts: listAlerts({ limit, unackedOnly }),
    count: alertCount(),
    dataSource: "SIMULATOR",
  });
});

router.post("/alerts/acknowledge", requireAdmin, (req, res) => {
  const Body = z.object({ alertId: z.string() });
  const p = Body.safeParse(req.body ?? {});
  if (!p.success) return res.status(400).json({ error: "alertId required" });
  const a = alertAction(p.data.alertId, "acknowledge");
  if (!a) return res.status(404).json({ error: "alert not found" });
  return res.json(a);
});

router.post("/alerts/dismiss", requireAdmin, (req, res) => {
  const Body = z.object({ alertId: z.string() });
  const p = Body.safeParse(req.body ?? {});
  if (!p.success) return res.status(400).json({ error: "alertId required" });
  const a = alertAction(p.data.alertId, "dismiss");
  if (!a) return res.status(404).json({ error: "alert not found" });
  return res.json(a);
});

router.post("/alerts/snooze", requireAdmin, (req, res) => {
  const Body = z.object({ alertId: z.string(), minutes: z.number().int().min(1).max(120).optional() });
  const p = Body.safeParse(req.body ?? {});
  if (!p.success) return res.status(400).json({ error: "alertId required" });
  const a = alertAction(p.data.alertId, "snooze", (p.data.minutes ?? 10) * 60_000);
  if (!a) return res.status(404).json({ error: "alert not found" });
  return res.json(a);
});

// ── Selected-market panel ──────────────────────────────────────────────────
// SAFETY: read-only over the simulator + economic_events table. Never
// dispatches a trade. Output is user-facing language only — no secrets,
// no bridge tokens, no raw event IDs are exposed beyond their public
// externalId.
router.get("/market-scanner/supported-symbols", (_req, res) => {
  return res.json({
    supported: SUPPORTED_SYMBOLS,
    suggestions: ["EURUSD", "GBPUSD", "XAUUSD", "US30", "NAS100", "BTCUSDT", "TSLA"],
    dataSource: "SIMULATOR",
  });
});

router.get("/market-scanner/selected-market", async (req, res) => {
  const rawSymbol = String(req.query.symbol ?? "").trim();
  const timeframe = (typeof req.query.timeframe === "string" ? req.query.timeframe : "M15") || "M15";
  const refresh = req.query.refresh === "true" || req.query.refresh === "1";
  if (!rawSymbol) {
    return res.status(400).json({
      ok: false,
      error: "SYMBOL_REQUIRED",
      message: "Type a symbol like EURUSD, XAUUSD, or US30.",
    });
  }
  try {
    const snapshot = await getSelectedMarketSnapshot({ symbolRaw: rawSymbol, timeframe, refresh });
    const normalized = normalizeSymbol(rawSymbol);
    req.log.info({
      action: refresh ? "SCANNER_SELECTED_SYMBOL_REFRESH" : "SCANNER_SELECTED_SYMBOL_VIEW",
      symbolRaw: rawSymbol, symbol: normalized, timeframe,
      ok: snapshot.ok, cacheHit: snapshot.ok ? snapshot.cacheHit : false,
    }, "scanner.selected_market");
    return res.json(snapshot);
  } catch (err) {
    req.log.error({ err: String(err), symbolRaw: rawSymbol }, "scanner.selected_market failed");
    return res.status(500).json({
      ok: false, error: "SELECTED_MARKET_UNAVAILABLE",
      message: "We couldn't load this market right now. Try again.",
    });
  }
});

export default router;
