// Phase 9E — Per-user dashboard alerts.
// SAFETY: requireUser, scope by req.authUser.id, never accept userId from client.
import { Router } from "express";
import { db, userAlertsTable } from "@workspace/db";
import { and, desc, eq, ne } from "drizzle-orm";
import { requireUser } from "../lib/auth/middleware.js";

const router = Router();

router.get("/me/alerts", requireUser, async (req, res) => {
  const userId = req.authUser!.id;
  const status = typeof req.query.status === "string" ? req.query.status : null;
  const where = status ? and(eq(userAlertsTable.userId, userId), eq(userAlertsTable.status, status))
                        : eq(userAlertsTable.userId, userId);
  const rows = await db.select().from(userAlertsTable).where(where).orderBy(desc(userAlertsTable.createdAt)).limit(200);
  const unread = rows.filter((r) => r.status === "unread").length;
  res.json({ alerts: rows, unread, isEmpty: rows.length === 0 });
});

router.post("/me/alerts/:id/read", requireUser, async (req, res): Promise<void> => {
  const userId = req.authUser!.id;
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) { res.status(400).json({ error: "invalid id" }); return; }
  const u = await db.update(userAlertsTable).set({ status: "read", readAt: new Date() })
    .where(and(eq(userAlertsTable.id, id), eq(userAlertsTable.userId, userId))).returning();
  if (!u[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json(u[0]);
});

router.post("/me/alerts/:id/dismiss", requireUser, async (req, res): Promise<void> => {
  const userId = req.authUser!.id;
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) { res.status(400).json({ error: "invalid id" }); return; }
  const u = await db.update(userAlertsTable).set({ status: "dismissed", dismissedAt: new Date() })
    .where(and(eq(userAlertsTable.id, id), eq(userAlertsTable.userId, userId))).returning();
  if (!u[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json(u[0]);
});

router.post("/me/alerts/read-all", requireUser, async (req, res) => {
  const userId = req.authUser!.id;
  const u = await db.update(userAlertsTable).set({ status: "read", readAt: new Date() })
    .where(and(eq(userAlertsTable.userId, userId), eq(userAlertsTable.status, "unread"))).returning();
  res.json({ updated: u.length });
});

// Internal helper. Strictly idempotent via DB unique (userId, alertType, hourly bucket)
// + ON CONFLICT DO NOTHING. Concurrent pollers cannot create duplicates.
export async function upsertAlertOnce(userId: number, args: {
  alertType: string; severity: "info" | "warning" | "critical";
  title: string; message?: string; source?: string;
  actionLabel?: string | null; actionTarget?: string | null;
}) {
  const bucket = Math.floor(Date.now() / (60 * 60_000)); // unix-hour bucket
  await db.insert(userAlertsTable).values({
    userId, alertType: args.alertType, severity: args.severity, title: args.title,
    message: args.message ?? "", source: args.source ?? "system",
    actionLabel: args.actionLabel ?? null, actionTarget: args.actionTarget ?? null,
    bucket,
  }).onConflictDoNothing({ target: [userAlertsTable.userId, userAlertsTable.alertType, userAlertsTable.bucket] });
  const row = await db.select().from(userAlertsTable)
    .where(and(eq(userAlertsTable.userId, userId), eq(userAlertsTable.alertType, args.alertType), eq(userAlertsTable.bucket, bucket)))
    .limit(1);
  return row[0]!;
}
void ne;

export default router;
