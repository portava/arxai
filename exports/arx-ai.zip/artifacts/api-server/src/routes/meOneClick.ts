// User-facing One-Click Trade settings.
//
// Endpoints:
//
//   GET  /api/me/one-click            — read current settings + computed
//                                       canEnableLive (depends on master-
//                                       live access gate at this moment).
//   PUT  /api/me/one-click            — enable/disable a scope. Body:
//                                         { scope: 'demo'|'live',
//                                           enable: boolean,
//                                           typedConfirmation?: string,
//                                           maxLotPerClick?: number }
//                                       Enabling EITHER scope requires the
//                                       phrase `ENABLE ONE CLICK TRADING`
//                                       (constant `REQUIRED_TYPED_PHRASE`).
//                                       Enabling LIVE additionally requires
//                                       the per-user master-live access
//                                       gate to PASS — toggling on does
//                                       NOT bypass admin approval.
//   POST /api/me/one-click/submit-live — fast-path submission used by the
//                                       Market Scanner + Live Ticket when
//                                       one-click is ON. Acquires a
//                                       per-user advisory lock, builds
//                                       the live draft, confirms it, and
//                                       dispatches it — every existing
//                                       live gate (16-gate Phase B,
//                                       master-bridge gate, user-access
//                                       gate) still runs end-to-end. The
//                                       toggle only removes the manual UI
//                                       confirmation step; it never
//                                       removes a server gate.
//
// SECURITY: requireUser on every handler. No endpoint reveals another
// user's settings or any bridge/master state.
import express, { type IRouter, Router, type Request, type Response } from "express";
import { requireUser } from "../lib/auth/middleware.js";
import { db, userOneClickSettingsTable, oneClickAuditTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { loadAndEvaluateUserMasterLiveAccessGate } from "../lib/mt5/userMasterLiveAccessGate.js";
import { ARX_LOCK_NS, withTxAdvisoryLock } from "../lib/concurrency/advisoryLock.js";
import { tryConsumeToken, checkSymbolCooldown, clampPerMinute } from "../lib/concurrency/rateLimit.js";
import {
  createLiveDraft, confirmLiveCommand, dispatchLiveCommand,
} from "../lib/live/liveCommandPipeline.js";

export const REQUIRED_TYPED_PHRASE = "ENABLE ONE CLICK TRADING";

const router: IRouter = Router();
router.use(express.json());

function userOf(req: Request): number {
  return (req as Request & { authUser?: { id: number } }).authUser!.id;
}

async function getOrCreate(userId: number) {
  const existing = await db.select().from(userOneClickSettingsTable)
    .where(eq(userOneClickSettingsTable.userId, userId)).limit(1);
  if (existing[0]) return existing[0];
  const [row] = await db.insert(userOneClickSettingsTable)
    .values({ userId }).returning();
  return row!;
}

async function writeAudit(args: {
  userId: number;
  action: string;
  typedPhrase?: string | null;
  ip?: string | null;
  ua?: string | null;
  metadata?: unknown;
}): Promise<void> {
  await db.insert(oneClickAuditTable).values({
    userId: args.userId,
    action: args.action,
    typedPhrase: args.typedPhrase ?? null,
    ip: args.ip ?? null,
    userAgent: args.ua ?? null,
    metadata: args.metadata != null ? JSON.stringify(args.metadata) : null,
  });
}

router.get("/me/one-click", requireUser, async (req, res) => {
  const userId = userOf(req);
  const row = await getOrCreate(userId);
  const access = await loadAndEvaluateUserMasterLiveAccessGate(userId);
  return res.json({
    ok: true,
    demoOneClickEnabled: row.demoOneClickEnabled,
    liveOneClickEnabled: row.liveOneClickEnabled,
    demoEnabledAt: row.demoEnabledAt,
    liveEnabledAt: row.liveEnabledAt,
    maxLotPerClick: row.maxLotPerClick,
    perUserSubmitsPerMinute: row.perUserSubmitsPerMinute,
    defaultSymbol: row.defaultSymbol,
    defaultVolume: row.defaultVolume,
    defaultOrderType: row.defaultOrderType,
    allowOrdersWithoutStopLoss: row.allowOrdersWithoutStopLoss,
    reduceOnlyCloseAllowed: row.reduceOnlyCloseAllowed,
    // Ruby AI command-execution settings (default OFF). When OFF, the
    // instant-trade router refuses any source ∈ {ruby_text, ruby_voice}.
    aiInstantTradeCommandsEnabled: row.aiInstantTradeCommandsEnabled,
    defaultAiTradeSymbol: row.defaultAiTradeSymbol,
    defaultAiTradeVolume: row.defaultAiTradeVolume,
    defaultAiOrderType: row.defaultAiOrderType,
    allowRubyOpenCommands: row.allowRubyOpenCommands,
    allowRubyCloseCommands: row.allowRubyCloseCommands,
    allowRubyModifyCommands: row.allowRubyModifyCommands,
    requiredTypedPhrase: REQUIRED_TYPED_PHRASE,
    canEnableLive: access.decision === "PASS",
    canEnableLiveBlockedReason: access.decision === "BLOCKED" ? access.primaryReason : null,
  });
});

router.put("/me/one-click", requireUser, async (req, res) => {
  const userId = userOf(req);
  const body = (req.body ?? {}) as {
    scope?: "demo" | "live";
    enable?: boolean;
    typedConfirmation?: string;
    maxLotPerClick?: number;
    perUserSubmitsPerMinute?: number;
    defaultSymbol?: string;
    defaultVolume?: number;
    defaultOrderType?: string;
    allowOrdersWithoutStopLoss?: boolean;
    reduceOnlyCloseAllowed?: boolean;
    aiInstantTradeCommandsEnabled?: boolean;
    defaultAiTradeSymbol?: string;
    defaultAiTradeVolume?: number;
    defaultAiOrderType?: string;
    allowRubyOpenCommands?: boolean;
    allowRubyCloseCommands?: boolean;
    allowRubyModifyCommands?: boolean;
  };
  if (body.scope !== "demo" && body.scope !== "live") {
    return res.status(400).json({ ok: false, error: "INVALID_SCOPE" });
  }
  if (typeof body.enable !== "boolean") {
    return res.status(400).json({ ok: false, error: "INVALID_ENABLE" });
  }
  const ip = (req.headers["x-forwarded-for"] as string | undefined)?.split(",")[0]?.trim() ?? req.socket.remoteAddress ?? null;
  const ua = (req.headers["user-agent"] as string | undefined) ?? null;

  if (body.enable === true) {
    if (body.typedConfirmation !== REQUIRED_TYPED_PHRASE) {
      return res.status(400).json({
        ok: false,
        error: "TYPED_CONFIRMATION_REQUIRED",
        message: `You must type exactly: ${REQUIRED_TYPED_PHRASE}`,
      });
    }
    if (body.scope === "live") {
      const access = await loadAndEvaluateUserMasterLiveAccessGate(userId);
      if (access.decision === "BLOCKED") {
        return res.status(403).json({
          ok: false,
          error: "LIVE_ONE_CLICK_REQUIRES_MASTER_LIVE_ACCESS",
          blockReason: access.primaryReason,
          message: "Admin approval required before live one-click can be enabled.",
        });
      }
    }
  }
  await getOrCreate(userId);
  const update: Partial<typeof userOneClickSettingsTable.$inferInsert> = {
    updatedAt: new Date(),
  };
  if (body.scope === "demo") {
    update.demoOneClickEnabled = body.enable;
    if (body.enable) {
      update.demoEnabledAt = new Date();
      update.demoTypedConfirmation = body.typedConfirmation ?? null;
    } else {
      update.demoDisabledAt = new Date();
    }
  } else {
    update.liveOneClickEnabled = body.enable;
    if (body.enable) {
      update.liveEnabledAt = new Date();
      update.liveTypedConfirmation = body.typedConfirmation ?? null;
    } else {
      update.liveDisabledAt = new Date();
    }
  }
  if (typeof body.maxLotPerClick === "number") update.maxLotPerClick = body.maxLotPerClick;
  if (typeof body.perUserSubmitsPerMinute === "number") {
    update.perUserSubmitsPerMinute = clampPerMinute(body.perUserSubmitsPerMinute);
  }
  // Fast-trade UX preferences. These are NOT safety toggles —
  // per-market max lot + symbol allowlist + 16-gate evaluator still run
  // regardless of what's saved here.
  if (typeof body.defaultSymbol === "string" && body.defaultSymbol.trim().length > 0) {
    update.defaultSymbol = body.defaultSymbol.trim().toUpperCase().slice(0, 16);
  }
  if (typeof body.defaultVolume === "number" && body.defaultVolume > 0) {
    update.defaultVolume = body.defaultVolume;
  }
  if (typeof body.defaultOrderType === "string" && body.defaultOrderType.length > 0) {
    update.defaultOrderType = body.defaultOrderType.slice(0, 32);
  }
  if (typeof body.allowOrdersWithoutStopLoss === "boolean") {
    update.allowOrdersWithoutStopLoss = body.allowOrdersWithoutStopLoss;
  }
  if (typeof body.reduceOnlyCloseAllowed === "boolean") {
    update.reduceOnlyCloseAllowed = body.reduceOnlyCloseAllowed;
  }
  // Ruby AI command-execution settings. Flipping
  // aiInstantTradeCommandsEnabled to true is the master switch that allows
  // Ruby to call /api/trades/instant/*; the three allow* flags scope WHICH
  // actions Ruby may perform. Default ON for close/modify, OFF for open.
  let aiToggleAuditAction: "AI_INSTANT_TRADE_ENABLED" | "AI_INSTANT_TRADE_DISABLED" | null = null;
  if (typeof body.aiInstantTradeCommandsEnabled === "boolean") {
    if (body.aiInstantTradeCommandsEnabled === true && body.scope === "live") {
      // Enabling Ruby trading requires the user to ALSO be approved for
      // live (master-live access PASS) — defence in depth.
      const access = await loadAndEvaluateUserMasterLiveAccessGate(userId);
      if (access.decision === "BLOCKED") {
        return res.status(403).json({
          ok: false,
          error: "RUBY_TRADING_REQUIRES_MASTER_LIVE_ACCESS",
          blockReason: access.primaryReason,
        });
      }
    }
    update.aiInstantTradeCommandsEnabled = body.aiInstantTradeCommandsEnabled;
    aiToggleAuditAction = body.aiInstantTradeCommandsEnabled
      ? "AI_INSTANT_TRADE_ENABLED" : "AI_INSTANT_TRADE_DISABLED";
  }
  if (typeof body.defaultAiTradeSymbol === "string" && body.defaultAiTradeSymbol.trim().length > 0) {
    update.defaultAiTradeSymbol = body.defaultAiTradeSymbol.trim().toUpperCase().slice(0, 16);
  }
  if (typeof body.defaultAiTradeVolume === "number" && body.defaultAiTradeVolume > 0) {
    update.defaultAiTradeVolume = body.defaultAiTradeVolume;
  }
  if (typeof body.defaultAiOrderType === "string" && body.defaultAiOrderType.length > 0) {
    update.defaultAiOrderType = body.defaultAiOrderType.slice(0, 32);
  }
  if (typeof body.allowRubyOpenCommands === "boolean") update.allowRubyOpenCommands = body.allowRubyOpenCommands;
  if (typeof body.allowRubyCloseCommands === "boolean") update.allowRubyCloseCommands = body.allowRubyCloseCommands;
  if (typeof body.allowRubyModifyCommands === "boolean") update.allowRubyModifyCommands = body.allowRubyModifyCommands;
  const [updated] = await db.update(userOneClickSettingsTable).set(update)
    .where(eq(userOneClickSettingsTable.userId, userId)).returning();
  await writeAudit({
    userId,
    action: `${body.enable ? "ENABLE" : "DISABLE"}_${body.scope === "demo" ? "DEMO" : "LIVE"}`,
    typedPhrase: body.enable ? (body.typedConfirmation ?? null) : null,
    ip, ua,
    metadata: { maxLotPerClick: body.maxLotPerClick ?? null },
  });
  if (aiToggleAuditAction) {
    await writeAudit({
      userId, action: aiToggleAuditAction, ip, ua,
      metadata: {
        allowRubyOpenCommands: body.allowRubyOpenCommands ?? null,
        allowRubyCloseCommands: body.allowRubyCloseCommands ?? null,
        allowRubyModifyCommands: body.allowRubyModifyCommands ?? null,
      },
    });
  }
  return res.json({ ok: true, settings: updated });
});

/**
 * POST /api/me/one-click/submit-live — fast-path live submit.
 *
 * Body: same shape as createLiveDraft input. The endpoint:
 *
 *  1. Verifies user.liveOneClickEnabled = true (else 412).
 *  2. Re-runs the master-live access gate (defense in depth).
 *  3. Takes a per-user advisory lock to serialize double-tap submits.
 *  4. Token-bucket rate limit (per user) + per-symbol cooldown.
 *  5. Calls createLiveDraft + confirmLiveCommand + dispatchLiveCommand.
 *     dispatchLiveCommand still runs every Phase B gate, the user-access
 *     gate, the master-bridge gate, and the atomic exposure reservation.
 *
 * Toggle ON is NOT a bypass of any server gate.
 */
router.post("/me/one-click/submit-live", requireUser, async (req: Request, res: Response) => {
  const userId = userOf(req);
  const settings = await getOrCreate(userId);
  if (!settings.liveOneClickEnabled) {
    return res.status(412).json({ ok: false, error: "LIVE_ONE_CLICK_DISABLED" });
  }
  const access = await loadAndEvaluateUserMasterLiveAccessGate(userId);
  if (access.decision === "BLOCKED") {
    return res.status(403).json({
      ok: false, error: "MASTER_LIVE_USER_ACCESS_BLOCKED",
      blockReason: access.primaryReason,
    });
  }
  const body = (req.body ?? {}) as {
    symbol?: string; side?: "BUY" | "SELL"; orderType?: string;
    commandType?: "PLACE_LIVE_MARKET_ORDER" | "PLACE_LIVE_PENDING_ORDER";
    requestedVolume?: number; stopLoss?: number | null; takeProfit?: number | null;
    sourcePage?: string; rubyExplanationSummary?: string | null;
    payload?: Record<string, unknown>;
  };
  if (!body.symbol || (body.side !== "BUY" && body.side !== "SELL") || typeof body.requestedVolume !== "number") {
    return res.status(400).json({ ok: false, error: "INVALID_TICKET" });
  }
  // Resolve commandType. Prefer explicit body.commandType; otherwise classify
  // from orderType. Frontend sends `MARKET_BUY`/`MARKET_SELL` for market and
  // names like `LIMIT_BUY`, `STOP_SELL` for pending.
  const orderTypeStr = body.orderType ?? "MARKET";
  const isMarketOrder =
    body.commandType === "PLACE_LIVE_MARKET_ORDER"
    || (!body.commandType && /MARKET/i.test(orderTypeStr));
  const resolvedCommandType: "PLACE_LIVE_MARKET_ORDER" | "PLACE_LIVE_PENDING_ORDER" =
    isMarketOrder ? "PLACE_LIVE_MARKET_ORDER" : "PLACE_LIVE_PENDING_ORDER";
  // Per-symbol cooldown — prevents instant double-fire on same symbol.
  if (!checkSymbolCooldown(body.symbol, userId)) {
    return res.status(429).json({ ok: false, error: "SYMBOL_COOLDOWN" });
  }
  // Per-user token bucket.
  if (!tryConsumeToken(`user:${userId}`, settings.perUserSubmitsPerMinute)) {
    return res.status(429).json({ ok: false, error: "USER_SUBMIT_RATE_LIMITED" });
  }

  // One-click no-SL override: takes effect ONLY when the user has
  // explicitly opted in via PUT /me/one-click {allowOrdersWithoutStopLoss:true}
  // AND submitted a draft without a stop-loss. Approval + typed-phrase +
  // master-live + per-market max-lot + 16-gate evaluator still all run.
  const noSlOverride = settings.allowOrdersWithoutStopLoss === true
    && (body.stopLoss == null || body.stopLoss <= 0);

  // Per-user advisory lock — blocks double-tap from the same user.
  const lock = await withTxAdvisoryLock(ARX_LOCK_NS.USER_SUBMIT, userId, async () => {
    const draft = await createLiveDraft({
      userId,
      commandType: resolvedCommandType,
      symbol: body.symbol!,
      side: body.side!,
      orderType: orderTypeStr,
      requestedVolume: body.requestedVolume!,
      stopLoss: body.stopLoss ?? null,
      takeProfit: body.takeProfit ?? null,
      sourcePage: body.sourcePage ?? "ONE_CLICK",
      rubyExplanationSummary: body.rubyExplanationSummary ?? null,
      payload: body.payload ?? {},
      allowNoStopLossThisDraft: noSlOverride,
    });
    if (!("ok" in draft) || draft.ok !== true) return { stage: "draft" as const, result: draft };
    const confirmed = await confirmLiveCommand({ userId, commandId: draft.command.commandId });
    if (!confirmed.ok) return { stage: "confirm" as const, result: confirmed };
    const dispatched = await dispatchLiveCommand({ userId, commandId: draft.command.commandId });
    return { stage: "dispatch" as const, result: dispatched, commandId: draft.command.commandId };
  });
  if (!lock.acquired) {
    return res.status(409).json({ ok: false, error: "USER_SUBMIT_LOCKED" });
  }
  const stageOut = lock.value;
  await writeAudit({
    userId, action: "SUBMIT_LIVE_ONE_CLICK",
    metadata: {
      stage: stageOut.stage,
      symbol: body.symbol,
      side: body.side,
      volume: body.requestedVolume,
      stopLoss: body.stopLoss ?? null,
      takeProfit: body.takeProfit ?? null,
      orderType: orderTypeStr,
      commandType: resolvedCommandType,
      noSlOverrideApplied: noSlOverride,
      oneClickLiveTradingEnabled: settings.liveOneClickEnabled,
    },
  });
  if (stageOut.stage === "dispatch") {
    const r = stageOut.result;
    return res.json({ ...r, ok: r.ok === true, commandId: stageOut.commandId });
  }
  return res.status(409).json({ ...stageOut.result, ok: false, stage: stageOut.stage });
});

export default router;
