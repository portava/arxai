// User-facing — "Am I allowed to use Master Live?" status.
//
// GET /api/me/master-live/access
//
// Returns the per-user access gate verdict the UI uses to hide/show the
// master live ticket and Market Scanner live button. Never reveals
// another user's data; never includes email or role.
import express, { type IRouter, Router } from "express";
import { requireUser } from "../lib/auth/middleware.js";
import { loadAndEvaluateUserMasterLiveAccessGate } from "../lib/mt5/userMasterLiveAccessGate.js";

const router: IRouter = Router();
router.use(express.json());

router.get("/me/master-live/access", requireUser, async (req, res) => {
  const userId = req.authUser!.id;
  const v = await loadAndEvaluateUserMasterLiveAccessGate(userId);
  if (v.decision === "PASS") {
    return res.json({
      ok: true,
      canTrade: true,
      status: v.access.masterLiveStatus,
      masterLiveTradingEnabled: v.access.masterLiveTradingEnabled,
      scannerLiveEnabled: !!v.access.scannerLiveEnabled,
      limits: {
        allowedSymbols: v.access.allowedSymbols ?? [],
        maxLot: v.access.maxLot,
        dailyLossLimitUsd: v.access.dailyLossLimitUsd,
        requireStopLoss: v.access.requireStopLoss,
      },
      blockReason: null,
      message: null,
    });
  }
  const message =
    v.primaryReason === "USER_NOT_APPROVED_FOR_MASTER_LIVE"
      ? "Your account is not approved for master live trading."
      : v.primaryReason === "USER_MASTER_LIVE_TOGGLE_OFF"
      ? "Master live trading is currently disabled for your account."
      : v.primaryReason === "USER_MASTER_LIVE_SUSPENDED"
      ? "Master live trading is suspended for your account."
      : v.primaryReason === "USER_MASTER_LIVE_RISK_LOCKED"
      ? "Master live trading is risk-locked for your account."
      : v.primaryReason === "USER_MISSING_RISK_DISCLOSURE"
      ? "You must accept the live risk disclosure before master live trading."
      : "Master live trading requires admin approval.";
  return res.json({
    ok: true,
    canTrade: false,
    status: v.status,
    masterLiveTradingEnabled: false,
    scannerLiveEnabled: false,
    blockReason: v.primaryReason,
    blockReasons: v.blockReasons,
    message,
  });
});

export default router;
