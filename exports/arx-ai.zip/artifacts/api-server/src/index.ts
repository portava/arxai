import app from "./app";
import { logger } from "./lib/logger";
import { ensureSafetyCoreInitialized } from "./lib/safetyCore";
import { bootstrapOwnerUser } from "./lib/auth/ownerBootstrap";
import { startStuckCommandWatchdog } from "./lib/mt5/stuckCommandWatchdog";
import { computeEnvChecklist, summarizeEnvChecklist } from "./lib/startup/envChecklist";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// Initialize the Phase 1 Safety Core singleton row before accepting requests.
// This eliminates the loadOrCreate() race window for the safety_core table.
ensureSafetyCoreInitialized()
  .then(() => bootstrapOwnerUser().catch((err) => {
    logger.error({ err }, "Owner bootstrap failed (non-fatal); continuing");
  }))
  .then(() => {
    app.listen(port, (err) => {
      if (err) {
        logger.error({ err }, "Error listening on port");
        process.exit(1);
      }
      logger.info({ port }, "Server listening (Safety Core initialized)");
      try {
        const summary = summarizeEnvChecklist(computeEnvChecklist());
        logger.info(
          {
            envTotal: summary.total,
            envPresent: summary.presentCount,
            missingRequired: summary.missingRequired,
            missingOptional: summary.missingOptional,
            liveMasterSwitchEnabled: summary.liveMasterSwitchEnabled,
            legacyBridgeTokenPresent: summary.legacyBridgeTokenPresent,
          },
          "Production Launch Readiness — env checklist (presence only, no values)",
        );
        if (summary.missingRequired.length > 0) {
          logger.warn({ missingRequired: summary.missingRequired }, "Required env vars missing — launch readiness is BLOCKED");
        }
        if (summary.legacyBridgeTokenPresent) {
          logger.warn({}, "LEGACY MT5_BRIDGE_TOKEN env value is set — it is rejected on every EA endpoint and must be removed before public launch");
        }
      } catch (e) {
        logger.error({ err: String(e) }, "Env checklist computation failed (non-fatal)");
      }
      startStuckCommandWatchdog();
    });
  })
  .catch((err) => {
    logger.error({ err }, "Failed to initialize Safety Core; refusing to start");
    process.exit(1);
  });
