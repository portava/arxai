// Deriv WebSocket client — lazy singleton.
//
// Connects to wss://ws.derivws.com/websockets/v3?app_id=<APP_ID> only
// when DERIV_APP_ID is set. Supports:
//   - request/response by req_id correlation (ticks_history, candles)
//   - tick subscription (forget on unsubscribe)
//   - ping keepalive every 30s
//   - exponential reconnect backoff (1s → 30s)
//   - bounded last-tick cache per symbol
//
// SAFETY:
//   - Never logs DERIV_APP_ID or DERIV_API_TOKEN values.
//   - On config absence, every public method returns a not-configured
//     envelope without attempting connection.
//   - Never fabricates candles. If the WS round-trip fails or times
//     out, returns { ok:false, reason }.

import WebSocket, { type RawData } from "ws";

const DEFAULT_WS_URL = "wss://ws.derivws.com/websockets/v3";
const PING_MS = 30_000;
const REQUEST_TIMEOUT_MS = 8_000;
const MAX_BACKOFF_MS = 30_000;
const INITIAL_BACKOFF_MS = 1_000;

export type DerivGranularity = 60 | 120 | 180 | 300 | 600 | 900 | 1800 | 3600 | 7200 | 14400 | 28800 | 86400;

export interface DerivCandle {
  epoch: number; // unix seconds
  open: number;
  high: number;
  low: number;
  close: number;
}

export interface DerivTick {
  symbol: string;
  epoch: number;
  quote: number;
}

interface PendingRequest {
  resolve: (msg: Record<string, unknown>) => void;
  reject: (err: Error) => void;
  timer: NodeJS.Timeout;
}

class DerivWsClient {
  private ws: WebSocket | null = null;
  private connecting = false;
  private connected = false;
  private appId = "";
  private wsUrl = DEFAULT_WS_URL;
  private nextReqId = 1;
  private pending = new Map<number, PendingRequest>();
  private lastTickBySymbol = new Map<string, DerivTick>();
  private subscribedSymbols = new Set<string>();
  private subscriptionIdBySymbol = new Map<string, string>();
  private reconnectCount = 0;
  private backoffMs = INITIAL_BACKOFF_MS;
  private lastErrorMessage: string | null = null;
  private pingTimer: NodeJS.Timeout | null = null;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private lastTickAt: number | null = null;
  private connectedAt: number | null = null;

  configured(): boolean {
    const id = (process.env.DERIV_APP_ID ?? "").trim();
    return id.length > 0;
  }

  isConnected(): boolean { return this.connected; }
  getReconnectCount(): number { return this.reconnectCount; }
  getLastErrorMessage(): string | null { return this.lastErrorMessage; }
  getSubscribedSymbols(): string[] { return [...this.subscribedSymbols]; }
  getLastTickAt(): string | null { return this.lastTickAt ? new Date(this.lastTickAt).toISOString() : null; }
  getConnectedAt(): string | null { return this.connectedAt ? new Date(this.connectedAt).toISOString() : null; }

  /** Idempotent: ensures the WS is connected or in-flight. */
  ensureConnection(): void {
    if (!this.configured()) return;
    if (this.connected || this.connecting) return;
    this.connecting = true;
    this.appId = (process.env.DERIV_APP_ID ?? "").trim();
    this.wsUrl = (process.env.DERIV_WS_URL ?? "").trim() || DEFAULT_WS_URL;
    const url = `${this.wsUrl}?app_id=${encodeURIComponent(this.appId)}`;
    try {
      const ws = new WebSocket(url, { handshakeTimeout: 5_000 });
      this.ws = ws;
      ws.on("open", () => {
        this.connected = true;
        this.connecting = false;
        this.connectedAt = Date.now();
        this.backoffMs = INITIAL_BACKOFF_MS;
        this.lastErrorMessage = null;
        this.startPing();
      });
      ws.on("message", (data: RawData) => this.handleMessage(data));
      ws.on("close", () => this.handleClose());
      ws.on("error", (err) => {
        // Never include credentials/url in the error message.
        this.lastErrorMessage = `ws_error: ${err.message}`.replace(this.appId, "<redacted>");
      });
    } catch (err) {
      this.connecting = false;
      this.lastErrorMessage = `connect_throw: ${(err as Error).message}`.replace(this.appId, "<redacted>");
      this.scheduleReconnect();
    }
  }

  private startPing(): void {
    if (this.pingTimer) clearInterval(this.pingTimer);
    this.pingTimer = setInterval(() => {
      if (!this.connected || !this.ws) return;
      // Deriv expects ping as a JSON `ping` request, not a WS-frame ping.
      this.sendRaw({ ping: 1 });
    }, PING_MS);
  }

  private handleClose(): void {
    this.connected = false;
    this.connecting = false;
    if (this.pingTimer) { clearInterval(this.pingTimer); this.pingTimer = null; }
    for (const [, p] of this.pending) {
      clearTimeout(p.timer);
      p.reject(new Error("ws_closed"));
    }
    this.pending.clear();
    this.subscribedSymbols.clear();
    this.subscriptionIdBySymbol.clear();
    this.scheduleReconnect();
  }

  private scheduleReconnect(): void {
    if (!this.configured()) return;
    if (this.reconnectTimer) return;
    this.reconnectCount += 1;
    const wait = Math.min(this.backoffMs, MAX_BACKOFF_MS);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.backoffMs = Math.min(this.backoffMs * 2, MAX_BACKOFF_MS);
      this.ensureConnection();
    }, wait);
  }

  private sendRaw(payload: Record<string, unknown>): void {
    if (!this.ws || !this.connected) return;
    try { this.ws.send(JSON.stringify(payload)); } catch { /* ignore */ }
  }

  /** Send a request with req_id correlation. Rejects on timeout/close. */
  private request<T extends Record<string, unknown>>(payload: Omit<T, "req_id">): Promise<Record<string, unknown>> {
    return new Promise((resolve, reject) => {
      if (!this.configured()) {
        reject(new Error("deriv_not_configured")); return;
      }
      this.ensureConnection();
      if (!this.connected || !this.ws) {
        reject(new Error("ws_not_connected")); return;
      }
      const reqId = this.nextReqId++;
      const timer = setTimeout(() => {
        this.pending.delete(reqId);
        reject(new Error("request_timeout"));
      }, REQUEST_TIMEOUT_MS);
      this.pending.set(reqId, { resolve, reject, timer });
      this.sendRaw({ ...(payload as object), req_id: reqId });
    });
  }

  private handleMessage(data: RawData): void {
    let msg: Record<string, unknown>;
    try {
      msg = JSON.parse(typeof data === "string" ? data : data.toString()) as Record<string, unknown>;
    } catch { return; }

    // Subscription stream (tick).
    const tick = msg.tick as Record<string, unknown> | undefined;
    if (tick && typeof tick.symbol === "string" && typeof tick.quote === "number" && typeof tick.epoch === "number") {
      const sym = tick.symbol as string;
      this.lastTickBySymbol.set(sym, { symbol: sym, epoch: tick.epoch as number, quote: tick.quote as number });
      this.lastTickAt = Date.now();
      const subId = (msg.subscription as Record<string, unknown> | undefined)?.id;
      if (typeof subId === "string") this.subscriptionIdBySymbol.set(sym, subId);
    }

    // Correlated response.
    const reqId = msg.req_id;
    if (typeof reqId === "number" && this.pending.has(reqId)) {
      const p = this.pending.get(reqId)!;
      clearTimeout(p.timer);
      this.pending.delete(reqId);
      if (msg.error) {
        const err = msg.error as Record<string, unknown>;
        p.reject(new Error(typeof err.message === "string" ? err.message : "deriv_error"));
      } else {
        p.resolve(msg);
      }
    }
  }

  /** Fetch historical candles for a Deriv symbol. */
  async getCandles(derivSymbol: string, granularity: DerivGranularity, count: number): Promise<DerivCandle[]> {
    const resp = await this.request({
      ticks_history: derivSymbol,
      adjust_start_time: 1,
      count: Math.max(1, Math.min(5000, count)),
      end: "latest",
      style: "candles",
      granularity,
    });
    const arr = resp.candles as Array<{ epoch: number; open: number; high: number; low: number; close: number }> | undefined;
    if (!Array.isArray(arr)) return [];
    return arr.map((c) => ({ epoch: c.epoch, open: c.open, high: c.high, low: c.low, close: c.close }));
  }

  /** Subscribe to live ticks for a symbol. */
  async subscribeTicks(derivSymbol: string): Promise<DerivTick | null> {
    if (this.subscribedSymbols.has(derivSymbol)) {
      return this.lastTickBySymbol.get(derivSymbol) ?? null;
    }
    const resp = await this.request({ ticks: derivSymbol, subscribe: 1 });
    this.subscribedSymbols.add(derivSymbol);
    const tick = resp.tick as { symbol?: string; epoch?: number; quote?: number } | undefined;
    if (tick && typeof tick.epoch === "number" && typeof tick.quote === "number") {
      const t: DerivTick = { symbol: derivSymbol, epoch: tick.epoch, quote: tick.quote };
      this.lastTickBySymbol.set(derivSymbol, t);
      this.lastTickAt = Date.now();
      return t;
    }
    return null;
  }

  getCachedTick(derivSymbol: string): DerivTick | null {
    return this.lastTickBySymbol.get(derivSymbol) ?? null;
  }
}

let _client: DerivWsClient | null = null;
export function getDerivWsClient(): DerivWsClient {
  if (!_client) _client = new DerivWsClient();
  return _client;
}
