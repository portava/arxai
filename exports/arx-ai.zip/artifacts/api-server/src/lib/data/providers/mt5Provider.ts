import type { Candle, DataProvider, MarketQuote } from "../types.js";

// Holds candle/quote data pushed from the MT5 bridge.
const candleStore = new Map<string, Candle[]>();
const quoteStore = new Map<string, MarketQuote>();
let lastUpdate = 0;

export function updateCandlesFromMT5(symbol: string, candles: Candle[]) {
  candleStore.set(symbol, candles);
  lastUpdate = Date.now();
}

export function updateQuoteFromMT5(symbol: string, quote: MarketQuote) {
  quoteStore.set(symbol, quote);
  lastUpdate = Date.now();
}

export class Mt5Provider implements DataProvider {
  name = "mt5";

  async getCandles(symbol: string, _timeframe: string, limit: number): Promise<Candle[]> {
    const all = candleStore.get(symbol) ?? [];
    return all.slice(-limit);
  }

  async getQuote(symbol: string): Promise<MarketQuote> {
    const q = quoteStore.get(symbol);
    if (q) return q;
    return { symbol, timestamp: new Date().toISOString() };
  }

  async isConnected(): Promise<boolean> {
    // Considered connected if we've received any update in the last 30s.
    return lastUpdate > 0 && Date.now() - lastUpdate < 30_000;
  }
}

export const mt5Provider = new Mt5Provider();
