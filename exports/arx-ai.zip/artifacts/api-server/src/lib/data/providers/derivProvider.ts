// Deriv synthetic-index feed adapter — config, status, and data surface.
//
// Wraps the lazy WebSocket client (`derivWsClient.ts`) and exposes a
// clean, candle-shaped interface to the rest of the app:
//
//   getDerivFeedStatus()                  — diagnostics (no secrets)
//   getDerivCandles(symbol, tf, count)    — historical OHLC via WS
//   getDerivTick(symbol)                  — cached/subscribed last tick
//   resolveDerivSymbol(label)             — clean label → Deriv id
//
// Inviolables:
//   - Never logs DERIV_APP_ID or DERIV_API_TOKEN.
//   - Returns booleans for env presence — never raw values.
//   - When unconfigured, getDerivCandles returns `{ ok:false }` and
//     never fabricates synthetic candles.

import { getDerivWsClient, type DerivCandle, type DerivGranularity } from "./derivWsClient.js";

export interface DerivSyntheticSymbol {
  symbol: string;          // ARX-internal label
  derivId: string;         // Deriv WS symbol id
  displayName: string;     // friendly name
  oneHertz: boolean;       // 1Hz tick stream
}

/** Canonical synthetic-index symbol map. */
export const DERIV_SYNTHETIC_SYMBOLS: DerivSyntheticSymbol[] = [
  { symbol: "V10",      derivId: "R_10",      displayName: "Volatility 10 Index",       oneHertz: false },
  { symbol: "V25",      derivId: "R_25",      displayName: "Volatility 25 Index",       oneHertz: false },
  { symbol: "V50",      derivId: "R_50",      displayName: "Volatility 50 Index",       oneHertz: false },
  { symbol: "V75",      derivId: "R_75",      displayName: "Volatility 75 Index",       oneHertz: false },
  { symbol: "V100",     derivId: "R_100",     displayName: "Volatility 100 Index",      oneHertz: false },
  { symbol: "V10_1S",   derivId: "1HZ10V",    displayName: "Volatility 10 (1s) Index",  oneHertz: true  },
  { symbol: "V25_1S",   derivId: "1HZ25V",    displayName: "Volatility 25 (1s) Index",  oneHertz: true  },
  { symbol: "V50_1S",   derivId: "1HZ50V",    displayName: "Volatility 50 (1s) Index",  oneHertz: true  },
  { symbol: "V75_1S",   derivId: "1HZ75V",    displayName: "Volatility 75 (1s) Index",  oneHertz: true  },
  { symbol: "V100_1S",  derivId: "1HZ100V",   displayName: "Volatility 100 (1s) Index", oneHertz: true  },
  { symbol: "BOOM500",  derivId: "BOOM500",   displayName: "Boom 500 Index",            oneHertz: false },
  { symbol: "BOOM1000", derivId: "BOOM1000",  displayName: "Boom 1000 Index",           oneHertz: false },
  { symbol: "CRASH500", derivId: "CRASH500",  displayName: "Crash 500 Index",           oneHertz: false },
  { symbol: "CRASH1000",derivId: "CRASH1000", displayName: "Crash 1000 Index",          oneHertz: false },
  { symbol: "STEP",     derivId: "stpRNG",    displayName: "Step Index",                oneHertz: false },
];

export interface DerivFeedStatus {
  configured: boolean;
  connected: boolean;
  appIdConfigured: boolean;
  apiTokenConfigured: boolean;
  wsUrl: string;
  knownSyntheticSymbolCount: number;
  activeSymbolCount: number;
  subscribedSymbols: string[];
  lastTickAt: string | null;
  connectedAt: string | null;
  reconnectCount: number;
  message: string;
  errorMessage: string | null;
}

const DEFAULT_DERIV_WS_URL = "wss://ws.derivws.com/websockets/v3";

/** Map clean ARX label → Deriv WS symbol id, or null when unknown. */
export function resolveDerivSymbol(symbolOrLabel: string): DerivSyntheticSymbol | null {
  const up = symbolOrLabel.trim().toUpperCase();
  for (const s of DERIV_SYNTHETIC_SYMBOLS) {
    if (s.symbol === up || s.derivId.toUpperCase() === up) return s;
  }
  // Tolerant: accept "VOLATILITY 75", "VOLATILITY 75 1S", "BOOM 1000", "CRASH 1000".
  const compact = up.replace(/\s+/g, "");
  for (const s of DERIV_SYNTHETIC_SYMBOLS) {
    const name = s.displayName.toUpperCase().replace(/\s+/g, "").replace(/INDEX$/, "");
    if (compact === name || compact === name + "INDEX") return s;
  }
  return null;
}

export function isDerivSyntheticSymbol(symbol: string): boolean {
  return resolveDerivSymbol(symbol) !== null;
}

/** Map an ARX timeframe (M1/M5/M15/H1/H4/D1) → Deriv `granularity` seconds. */
export function toDerivGranularity(tf: string): DerivGranularity | null {
  switch (tf.toUpperCase()) {
    case "M1":  return 60;
    case "M2":  return 120;
    case "M3":  return 180;
    case "M5":  return 300;
    case "M10": return 600;
    case "M15": return 900;
    case "M30": return 1800;
    case "H1":  return 3600;
    case "H2":  return 7200;
    case "H4":  return 14400;
    case "H8":  return 28800;
    case "D1":  return 86400;
    default:    return null;
  }
}

export function getDerivFeedStatus(): DerivFeedStatus {
  const appIdConfigured = Boolean(process.env.DERIV_APP_ID && process.env.DERIV_APP_ID.trim());
  const apiTokenConfigured = Boolean(process.env.DERIV_API_TOKEN && process.env.DERIV_API_TOKEN.trim());
  const wsUrl = (process.env.DERIV_WS_URL && process.env.DERIV_WS_URL.trim()) || DEFAULT_DERIV_WS_URL;
  const client = getDerivWsClient();
  // Kick the connection if configured but not yet connected — non-blocking.
  if (appIdConfigured) client.ensureConnection();
  const subs = client.getSubscribedSymbols();
  const connected = client.isConnected();
  const message = !appIdConfigured
    ? "Deriv feed not configured. Add DERIV_APP_ID to enable synthetic index data."
    : connected
      ? "Deriv feed connected."
      : "Deriv feed configured. Connecting…";
  return {
    configured: appIdConfigured,
    connected,
    appIdConfigured,
    apiTokenConfigured,
    wsUrl,
    knownSyntheticSymbolCount: DERIV_SYNTHETIC_SYMBOLS.length,
    activeSymbolCount: subs.length,
    subscribedSymbols: subs,
    lastTickAt: client.getLastTickAt(),
    connectedAt: client.getConnectedAt(),
    reconnectCount: client.getReconnectCount(),
    message,
    errorMessage: client.getLastErrorMessage(),
  };
}

export interface DerivCandlesResult {
  ok: boolean;
  reason: string | null;
  candles: DerivCandle[];
  symbol: string;
  derivSymbol: string | null;
  granularitySeconds: number | null;
}

/** Fetch candles for a synthetic symbol via the WS client. */
export async function getDerivCandles(symbol: string, timeframe: string, count: number): Promise<DerivCandlesResult> {
  const map = resolveDerivSymbol(symbol);
  if (!map) {
    return { ok: false, reason: "SYMBOL_UNAVAILABLE_FROM_DERIV_FEED", candles: [], symbol, derivSymbol: null, granularitySeconds: null };
  }
  const granularity = toDerivGranularity(timeframe);
  if (!granularity) {
    return { ok: false, reason: "TIMEFRAME_UNSUPPORTED", candles: [], symbol, derivSymbol: map.derivId, granularitySeconds: null };
  }
  const client = getDerivWsClient();
  if (!client.configured()) {
    return { ok: false, reason: "DERIV_NOT_CONFIGURED", candles: [], symbol, derivSymbol: map.derivId, granularitySeconds: granularity };
  }
  client.ensureConnection();
  try {
    const candles = await client.getCandles(map.derivId, granularity, count);
    return { ok: candles.length > 0, reason: candles.length > 0 ? null : "NO_CANDLES_RETURNED", candles, symbol, derivSymbol: map.derivId, granularitySeconds: granularity };
  } catch (err) {
    return { ok: false, reason: (err as Error).message.replace(/app_id=[^&\s]+/gi, "app_id=<redacted>"), candles: [], symbol, derivSymbol: map.derivId, granularitySeconds: granularity };
  }
}

export interface DerivTickResult {
  ok: boolean;
  reason: string | null;
  tick: { symbol: string; derivSymbol: string; epoch: number; quote: number } | null;
}

export async function getDerivTick(symbol: string): Promise<DerivTickResult> {
  const map = resolveDerivSymbol(symbol);
  if (!map) return { ok: false, reason: "SYMBOL_UNAVAILABLE_FROM_DERIV_FEED", tick: null };
  const client = getDerivWsClient();
  if (!client.configured()) return { ok: false, reason: "DERIV_NOT_CONFIGURED", tick: null };
  client.ensureConnection();
  try {
    const t = await client.subscribeTicks(map.derivId);
    if (!t) {
      const cached = client.getCachedTick(map.derivId);
      if (!cached) return { ok: false, reason: "NO_TICK_AVAILABLE", tick: null };
      return { ok: true, reason: null, tick: { symbol, derivSymbol: map.derivId, epoch: cached.epoch, quote: cached.quote } };
    }
    return { ok: true, reason: null, tick: { symbol, derivSymbol: map.derivId, epoch: t.epoch, quote: t.quote } };
  } catch (err) {
    return { ok: false, reason: (err as Error).message.replace(/app_id=[^&\s]+/gi, "app_id=<redacted>"), tick: null };
  }
}
