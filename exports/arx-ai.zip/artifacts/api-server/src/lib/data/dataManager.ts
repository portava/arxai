import type { Candle, MarketQuote } from "./types.js";
import { mockProvider } from "./providers/mockProvider.js";
import { mt5Provider } from "./providers/mt5Provider.js";
import { alphaVantageProvider } from "./providers/alphaVantageProvider.js";
import { twelveDataProvider } from "./providers/twelveDataProvider.js";

async function pickProvider() {
  if (await mt5Provider.isConnected()) return mt5Provider;
  if (await twelveDataProvider.isConnected()) return twelveDataProvider;
  if (await alphaVantageProvider.isConnected()) return alphaVantageProvider;
  return mockProvider;
}

export async function getMarketData(symbol: string, timeframe = "1m", limit = 250): Promise<Candle[]> {
  const provider = await pickProvider();
  const candles = await provider.getCandles(symbol, timeframe, limit);
  if (candles.length === 0 && provider.name !== "mock") {
    return mockProvider.getCandles(symbol, timeframe, limit);
  }
  return candles;
}

export async function getLatestQuote(symbol: string): Promise<MarketQuote> {
  const provider = await pickProvider();
  return provider.getQuote(symbol);
}

export async function getProviderStatus() {
  const providers = [mt5Provider, twelveDataProvider, alphaVantageProvider, mockProvider];
  const active = (await pickProvider()).name;
  return Promise.all(
    providers.map(async (p) => ({
      name: p.name,
      connected: await p.isConnected(),
      active: p.name === active,
    })),
  );
}
