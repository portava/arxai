// Selected-market analysis assembler.
//
// Pure data-shaping over existing read-only modules:
//   - analyzeMarket()        (lib/aiBrain.ts)               — bias, SR, SL/TP
//   - scoreNewsRisk()        (lib/news/calendar/newsRiskScorer.ts)
//   - economic_events table  (@workspace/db)                — upcoming events
//
// Output is user-facing trading language. Never returns secrets. Never
// dispatches anything. The function is idempotent and cheap to call.

import { and, gte, lte } from "drizzle-orm";
import { db, economicEventsTable } from "@workspace/db";
import { analyzeMarket, type MarketAnalysis } from "../aiBrain.js";
import { scoreNewsRisk } from "../news/calendar/newsRiskScorer.js";
import type { EconomicEvent } from "../news/calendar/economicEvents.js";
import { isSupported, normalizeSymbol } from "./symbolNormalize.js";
import { getCache } from "../cache/cacheAdapter.js";

// Namespace + TTL are intentionally hard-coded so the cache shape stays
// predictable even after a Redis adapter is swapped in.
const SELECTED_MARKET_CACHE_NS = "scanner-selected-market";
const SELECTED_MARKET_CACHE_TTL_MS = 30_000;
export const SELECTED_MARKET_CACHE_META = {
  namespace: SELECTED_MARKET_CACHE_NS,
  ttlMs: SELECTED_MARKET_CACHE_TTL_MS,
} as const;

export interface SelectedMarketHighlights {
  bias: "BUY" | "SELL" | "NEUTRAL" | "WAIT";
  confidenceLabel: "Very Low" | "Low" | "Medium" | "High";
  confidenceScore: number;
  volatilityLabel: "Calm" | "Normal" | "Elevated" | "Choppy";
  trendState: "bullish" | "bearish" | "neutral" | "choppy";
  entryZone: { low: number; high: number };
  suggestedStop: number;
  suggestedTakeProfit: number;
  riskRewardRatio: number;
  riskWarnings: string[];
}

export interface SelectedMarketEvent {
  externalId: string;
  title: string;
  currency: string;
  impactLevel: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
  eventTime: string;
  minutesUntil: number;
}

export interface SelectedMarketExplanation {
  hedge: string;
  why: string;
  whyItMatters: string;
  risk: string;
  invalidation: string;
  cautions: string[];
  disclaimer: string;
}

export interface SelectedMarketResult {
  ok: true;
  symbolRaw: string;
  symbol: string;
  timeframe: string;
  highlights: SelectedMarketHighlights;
  explanation: SelectedMarketExplanation;
  upcomingEvents: SelectedMarketEvent[];
  newsRisk: {
    riskLevel: "none" | "low" | "medium" | "high";
    blockTrading: boolean;
    summary: string;
  };
  dataSource: "SIMULATOR";
  generatedAt: string;
  cacheHit: boolean;
}

export interface SelectedMarketUnavailable {
  ok: false;
  symbolRaw: string;
  symbol: string;
  reason: "SYMBOL_NOT_SUPPORTED" | "NO_MARKET_DATA";
  message: string;
}

export type SelectedMarketEnvelope = SelectedMarketResult | SelectedMarketUnavailable;

// ── Cache (pluggable adapter, ~30s TTL, refresh bypasses) ─────────────────
// The adapter is selected by `ARX_CACHE_MODE` env at process start.
// Today this is always an in-process Map; a Redis-backed adapter can be
// dropped in without touching this file.
function cache() {
  return getCache(SELECTED_MARKET_CACHE_NS, SELECTED_MARKET_CACHE_TTL_MS);
}

export function clearSelectedMarketCache(): void {
  cache().clear();
}

function cacheKey(symbol: string, timeframe: string): string {
  return `${symbol}|${timeframe}`;
}

// ── Helpers ───────────────────────────────────────────────────────────────
function confidenceLabel(score: number): SelectedMarketHighlights["confidenceLabel"] {
  if (score >= 75) return "High";
  if (score >= 50) return "Medium";
  if (score >= 25) return "Low";
  return "Very Low";
}

function volatilityLabel(riskScore: number, bias: MarketAnalysis["marketBias"]): SelectedMarketHighlights["volatilityLabel"] {
  if (bias === "choppy") return "Choppy";
  if (riskScore >= 70) return "Elevated";
  if (riskScore >= 40) return "Normal";
  return "Calm";
}

function biasFromAction(a: MarketAnalysis["recommendedAction"]): SelectedMarketHighlights["bias"] {
  if (a === "BUY" || a === "SELL") return a;
  if (a === "WAIT") return "WAIT";
  return "NEUTRAL";
}

function impactDbToLower(level: string): "low" | "medium" | "high" {
  const v = String(level).toUpperCase();
  if (v === "HIGH" || v === "CRITICAL") return "high";
  if (v === "MEDIUM") return "medium";
  return "low";
}

function buildExplanation(a: MarketAnalysis, newsBlocking: boolean, newsReason: string): SelectedMarketExplanation {
  const side = biasFromAction(a.recommendedAction);
  const hedge = side === "BUY"
    ? "This looks like a possible buy setup right now."
    : side === "SELL"
    ? "This setup currently leans toward sellers."
    : side === "WAIT"
    ? "No clear directional edge — better to wait for confirmation."
    : "The market is neutral. Nothing actionable yet.";
  const whyParts: string[] = [];
  if (a.reasonForTrade && a.reasonForTrade !== "no data") whyParts.push(a.reasonForTrade);
  if (a.trendStrength > 0) whyParts.push(`trend strength ${Math.round(a.trendStrength)}/100`);
  const why = whyParts.join(" · ").slice(0, 240)
    || "Scanner detected a tradable structure on the current timeframe.";
  const whyItMattersBits: string[] = [];
  if (newsBlocking) {
    whyItMattersBits.push("A high-impact event is near — large moves are possible.");
  }
  if (a.riskScore >= 70) whyItMattersBits.push("Volatility is elevated, so position sizing matters.");
  if (a.confidenceScore < 50) whyItMattersBits.push("Confidence is not high — wait for confirmation before sizing up.");
  if (!whyItMattersBits.length) whyItMattersBits.push("Conditions look stable for the scanner's read.");
  const whyItMatters = whyItMattersBits.join(" ");
  const risk = a.reasonToAvoid && a.reasonToAvoid !== "n/a"
    ? a.reasonToAvoid.slice(0, 180)
    : a.stopLoss > 0
    ? `Idea weakens if price closes ${side === "SELL" ? "above" : "below"} ${a.stopLoss}.`
    : "Idea weakens if momentum stalls or structure breaks against the bias.";
  const invalidation = a.stopLoss > 0
    ? `Invalidates ${side === "SELL" ? "above" : "below"} ${a.stopLoss}.`
    : "Invalidates if price closes through the opposing structure.";
  const cautions: string[] = [];
  if (newsReason) cautions.push(newsReason);
  if (a.confidenceScore < 50) cautions.push("Confidence is low — confirm with price action.");
  if (a.riskScore >= 70) cautions.push("Size smaller than usual while volatility is elevated.");
  if (a.marketBias === "choppy") cautions.push("Market is choppy — wait for a clear direction.");
  return {
    hedge, why, whyItMatters, risk, invalidation, cautions,
    disclaimer: "Educational only — not financial advice. Test in demo first.",
  };
}

async function loadEventRows(symbol: string, currencyHints: string[]): Promise<{
  events: SelectedMarketEvent[];
  scorerInput: EconomicEvent[];
}> {
  const now = new Date();
  const until = new Date(now.getTime() + 24 * 3600 * 1000);
  const rows = await db.select().from(economicEventsTable)
    .where(and(
      gte(economicEventsTable.eventTime, now),
      lte(economicEventsTable.eventTime, until),
    ));
  const matching = rows.filter((r) => {
    if (currencyHints.length === 0) return true;
    if (currencyHints.includes(r.currency)) return true;
    const affected = (r.affectedSymbols ?? []) as unknown as string[];
    return Array.isArray(affected) && affected.some((s) => s.toUpperCase() === symbol);
  });
  const sorted = matching
    .filter((r) => ["MEDIUM", "HIGH", "CRITICAL"].includes(String(r.impactLevel)))
    .sort((a, b) => +new Date(a.eventTime) - +new Date(b.eventTime));
  const events: SelectedMarketEvent[] = sorted.slice(0, 8).map((r) => ({
    externalId: r.externalId,
    title: r.eventName,
    currency: r.currency,
    impactLevel: r.impactLevel as SelectedMarketEvent["impactLevel"],
    eventTime: new Date(r.eventTime).toISOString(),
    minutesUntil: Math.round((+new Date(r.eventTime) - Date.now()) / 60000),
  }));
  const scorerInput: EconomicEvent[] = sorted.map((r) => ({
    id: r.externalId,
    title: r.eventName,
    country: r.country,
    currency: r.currency,
    impact: impactDbToLower(String(r.impactLevel)),
    actual: r.actual ?? null,
    forecast: r.forecast ?? null,
    previous: r.previous ?? null,
    eventTime: new Date(r.eventTime).toISOString(),
    affectedMarkets: (r.affectedSymbols ?? []) as unknown as string[],
    source: r.source ?? "db",
  }));
  return { events, scorerInput };
}

function currencyHintsFor(symbol: string): string[] {
  if (/^[A-Z]{6}$/.test(symbol)) return [symbol.slice(0, 3), symbol.slice(3, 6)];
  if (symbol === "XAUUSD" || symbol === "XAGUSD") return ["USD"];
  if (symbol === "US30" || symbol === "NAS100" || symbol === "SPX500") return ["USD"];
  return [];
}

// ── Public ────────────────────────────────────────────────────────────────
export async function getSelectedMarketSnapshot(args: {
  symbolRaw: string;
  timeframe?: string;
  refresh?: boolean;
}): Promise<SelectedMarketEnvelope> {
  const symbol = normalizeSymbol(args.symbolRaw);
  const timeframe = args.timeframe ?? "M15";
  if (!symbol) {
    return {
      ok: false, symbolRaw: args.symbolRaw, symbol: "",
      reason: "SYMBOL_NOT_SUPPORTED",
      message: "Please enter a symbol like EURUSD, XAUUSD, US30, or BTCUSDT.",
    };
  }
  if (!isSupported(symbol)) {
    return {
      ok: false, symbolRaw: args.symbolRaw, symbol,
      reason: "SYMBOL_NOT_SUPPORTED",
      message: `${symbol} is not available in the scanner yet. Try a major pair, gold, an index, or a top crypto.`,
    };
  }
  const key = cacheKey(symbol, timeframe);
  if (!args.refresh) {
    const hit = cache().get<SelectedMarketEnvelope>(key);
    if (hit.hit) {
      const cached = hit.value;
      if (cached.ok) return { ...cached, cacheHit: true };
      return cached;
    }
  }
  const a = analyzeMarket(symbol, timeframe);
  if (a.recommendedAction === "REJECT" && a.reasonForTrade === "no data") {
    const envelope: SelectedMarketUnavailable = {
      ok: false, symbolRaw: args.symbolRaw, symbol,
      reason: "NO_MARKET_DATA",
      message: `${symbol} has no live data right now. Try again in a moment.`,
    };
    cache().set(key, envelope);
    return envelope;
  }
  const hints = currencyHintsFor(symbol);
  const { events, scorerInput } = await loadEventRows(symbol, hints);
  const news = scoreNewsRisk(symbol, scorerInput);
  const highlights: SelectedMarketHighlights = {
    bias: biasFromAction(a.recommendedAction),
    confidenceLabel: confidenceLabel(a.confidenceScore),
    confidenceScore: Math.round(a.confidenceScore),
    volatilityLabel: volatilityLabel(a.riskScore, a.marketBias),
    trendState: a.marketBias,
    entryZone: a.entryZone,
    suggestedStop: a.stopLoss,
    suggestedTakeProfit: a.takeProfit,
    riskRewardRatio: a.riskRewardRatio,
    riskWarnings: news.blockTrading ? [news.reason] : [],
  };
  const explanation = buildExplanation(a, news.blockTrading, news.reason);
  const result: SelectedMarketResult = {
    ok: true,
    symbolRaw: args.symbolRaw,
    symbol,
    timeframe,
    highlights,
    explanation,
    upcomingEvents: events,
    newsRisk: { riskLevel: news.riskLevel, blockTrading: news.blockTrading, summary: news.reason },
    dataSource: "SIMULATOR",
    generatedAt: new Date().toISOString(),
    cacheHit: false,
  };
  cache().set(key, result);
  return result;
}
