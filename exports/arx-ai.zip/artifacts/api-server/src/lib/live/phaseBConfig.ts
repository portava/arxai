// Phase B — Server master switch + idempotency helpers.
//
// SAFETY (inviolable):
// - `LIVE_BROKER_EXECUTION_ENABLED` defaults to FALSE. The only way to
//   flip it true is the env var `ARX_LIVE_BROKER_EXECUTION_ENABLED=true`.
//   When false, the Phase B dispatch gate ALWAYS returns BLOCKED with
//   reason `LIVE_BROKER_EXECUTION_DISABLED` + the legacy chokepoint
//   sentinel `BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED` appended.
// - Idempotency key is SHA-256 of (userId|symbol|side|lot|sl|tp|minuteBucket).
//   The partial unique index `arx_live_commands_idem_active_uq` blocks a
//   second SENT_TO_MT5_LIVE for the same key while the previous attempt is
//   in flight or filled.

import { createHash } from "node:crypto";
import { db, globalTradingSettingsTable } from "@workspace/db";

/**
 * Env-only master switch (legacy). Defaults to FALSE. Read once per call
 * (no caching). The gate ALWAYS appends `BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED`
 * to the blockReasons list when this returns false, preserving the legacy
 * chokepoint literal for audit/CI greps even after Phase B ships.
 *
 * Most callers should prefer `resolveLiveBrokerExecutionEnabledAsync()` which
 * additionally consults the admin-controllable DB flag.
 */
export function liveBrokerExecutionEnabled(): boolean {
  return process.env["ARX_LIVE_BROKER_EXECUTION_ENABLED"] === "true";
}

/**
 * Synchronous resolver used when the caller already loaded the
 * `global_trading_settings` row. Returns TRUE when EITHER the env var is
 * `"true"` OR the admin-controllable DB flag `liveBrokerExecutionArmed`
 * is true. Defaults to FALSE.
 *
 * The DB flag is the operator-facing arm switch (see
 * /api/admin/live-shared/arm-live-execution). The env var remains a server-
 * side hard kill (set it to anything other than "true" — or unset it — to
 * deny live execution regardless of DB state).
 */
export function resolveLiveBrokerExecutionEnabled(
  settingsRow: { liveBrokerExecutionArmed?: boolean | null } | null | undefined,
): boolean {
  if (process.env["ARX_LIVE_BROKER_EXECUTION_ENABLED"] === "true") return true;
  return settingsRow?.liveBrokerExecutionArmed === true;
}

/**
 * Async variant for callers that don't already have the settings row. Reads
 * the singleton row and returns the effective value. Defaults to FALSE if
 * the row is missing.
 */
export async function resolveLiveBrokerExecutionEnabledAsync(): Promise<boolean> {
  if (process.env["ARX_LIVE_BROKER_EXECUTION_ENABLED"] === "true") return true;
  const row = (await db.select().from(globalTradingSettingsTable).limit(1))[0] ?? null;
  return row?.liveBrokerExecutionArmed === true;
}

export function buildLiveIdempotencyKey(args: {
  userId: number;
  symbol: string;
  side: "BUY" | "SELL";
  volume: number;
  stopLoss?: number | null;
  takeProfit?: number | null;
  /** Defaults to current minute. Override only in tests. */
  minuteBucket?: number;
}): string {
  const bucket = args.minuteBucket ?? Math.floor(Date.now() / 60_000);
  const fields = [
    args.userId,
    args.symbol.toUpperCase(),
    args.side,
    args.volume.toFixed(4),
    args.stopLoss != null ? args.stopLoss.toFixed(5) : "_",
    args.takeProfit != null ? args.takeProfit.toFixed(5) : "_",
    bucket,
  ].join("|");
  return createHash("sha256").update(fields).digest("hex").slice(0, 32);
}

export const PHASE_B_LIVE_LOG_PREFIX = "[arx-live-phaseB]" as const;
