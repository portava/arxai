// instantTrade.ts — shared helper used by:
//   - POST /api/trades/instant/{execute,close,close-all,validate}
//   - POST /api/me/assistant/instant-trade-command (Ruby text/voice)
//   - any future trade-capable widget
//
// SAFETY: this is a thin orchestrator. Every actual safety decision
// remains in the existing pipeline:
//   - createLiveDraft → preflight (master-live access, kill switch,
//     server master switch, EA freshness, missing SL unless override)
//   - confirmLiveCommand
//   - dispatchLiveCommand → 16-gate evaluator + atomic exposure
//     reservation + bridge dispatch
//
// What this helper adds is SOURCE-AWARENESS:
//   - When `intent.source ∈ {ruby_text, ruby_voice}` it also requires
//     `aiInstantTradeCommandsEnabled = true` AND the action-appropriate
//     allowRuby* flag. This is a per-user Ruby authorization layer that
//     sits on TOP of every other live gate, never replacing them.
//
// `accountMode: "demo" | "paper"` is recognized for API symmetry but
// the helper returns `UNSUPPORTED_ACCOUNT_MODE_FOR_INSTANT_LIVE` —
// demo/paper continue to flow through their existing endpoints
// (`/api/mt5/demo-*`, paper sim). That keeps the live blast radius
// minimal and the demo path byte-for-byte unchanged.
import { db, userOneClickSettingsTable, oneClickAuditTable, arxLivePositionsTable } from "@workspace/db";
import { and, eq, isNull } from "drizzle-orm";
import { loadAndEvaluateUserMasterLiveAccessGate } from "../mt5/userMasterLiveAccessGate.js";
import { ARX_LOCK_NS, withTxAdvisoryLock } from "../concurrency/advisoryLock.js";
import { tryConsumeToken, checkSymbolCooldown } from "../concurrency/rateLimit.js";
import {
  createLiveDraft, confirmLiveCommand, dispatchLiveCommand,
  createLiveOpsDraft,
} from "./liveCommandPipeline.js";
import { liveBrokerExecutionEnabled } from "./phaseBConfig.js";

export const INSTANT_TRADE_SOURCES = [
  "trade_panel", "scanner", "chart", "watchlist", "position_card",
  "dashboard", "alert", "ruby_text", "ruby_voice",
] as const;
export type InstantTradeSource = (typeof INSTANT_TRADE_SOURCES)[number];

export const INSTANT_TRADE_ACTIONS = [
  "BUY", "SELL", "CLOSE", "CLOSE_ALL", "MODIFY_SL_TP",
] as const;
export type InstantTradeAction = (typeof INSTANT_TRADE_ACTIONS)[number];

export type InstantTradeIntent = {
  source: InstantTradeSource;
  action: InstantTradeAction;
  accountMode: "live" | "demo" | "paper";
  symbol?: string;
  volume?: number;
  orderType?: string;
  stopLoss?: number | null;
  takeProfit?: number | null;
  positionId?: string;
  newStopLoss?: number | null;
  newTakeProfit?: number | null;
  oneClick?: boolean;
  aiCommand?: boolean;
  rawUserCommand?: string | null;
  parsedByRuby?: boolean;
};

export type InstantTradeResult =
  | { ok: true; commandId?: string; action: InstantTradeAction; detail?: unknown }
  | { ok: false; error: string; primaryReason?: string; detail?: unknown; httpStatus: number };

async function writeAudit(args: {
  userId: number; action: string; ip?: string | null; ua?: string | null; metadata?: unknown;
}): Promise<void> {
  await db.insert(oneClickAuditTable).values({
    userId: args.userId, action: args.action,
    ip: args.ip ?? null, userAgent: args.ua ?? null,
    metadata: args.metadata != null ? JSON.stringify(args.metadata) : null,
  });
}

async function getSettings(userId: number) {
  const rows = await db.select().from(userOneClickSettingsTable)
    .where(eq(userOneClickSettingsTable.userId, userId)).limit(1);
  if (rows[0]) return rows[0];
  const [row] = await db.insert(userOneClickSettingsTable).values({ userId }).returning();
  return row!;
}

/**
 * Ruby authorization — runs only when source is ruby_text/ruby_voice.
 * AND-gated against every other live gate.
 */
function rubyAuthCheck(
  intent: InstantTradeIntent,
  settings: { aiInstantTradeCommandsEnabled: boolean; allowRubyOpenCommands: boolean; allowRubyCloseCommands: boolean; allowRubyModifyCommands: boolean },
): { ok: true } | { ok: false; reason: string } {
  if (intent.source !== "ruby_text" && intent.source !== "ruby_voice") return { ok: true };
  if (!settings.aiInstantTradeCommandsEnabled) return { ok: false, reason: "RUBY_TRADING_NOT_ENABLED" };
  if ((intent.action === "BUY" || intent.action === "SELL") && !settings.allowRubyOpenCommands) {
    return { ok: false, reason: "RUBY_OPEN_COMMANDS_NOT_ENABLED" };
  }
  if ((intent.action === "CLOSE" || intent.action === "CLOSE_ALL") && !settings.allowRubyCloseCommands) {
    return { ok: false, reason: "RUBY_CLOSE_COMMANDS_NOT_ENABLED" };
  }
  if (intent.action === "MODIFY_SL_TP" && !settings.allowRubyModifyCommands) {
    return { ok: false, reason: "RUBY_MODIFY_COMMANDS_NOT_ENABLED" };
  }
  return { ok: true };
}

export async function executeInstant(args: {
  userId: number;
  intent: InstantTradeIntent;
  ip?: string | null;
  ua?: string | null;
}): Promise<InstantTradeResult> {
  const { userId, intent, ip, ua } = args;

  if (intent.accountMode !== "live") {
    await writeAudit({
      userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua,
      metadata: { intent, blockReason: "UNSUPPORTED_ACCOUNT_MODE_FOR_INSTANT_LIVE" },
    });
    return {
      ok: false, httpStatus: 400, error: "UNSUPPORTED_ACCOUNT_MODE_FOR_INSTANT_LIVE",
      detail: "Use the existing demo/paper endpoints for non-live execution.",
    };
  }

  const settings = await getSettings(userId);
  // One-click toggle only gates NEW open-risk orders. Reduce-only actions
  // (CLOSE/CLOSE_ALL/MODIFY_SL_TP) must remain available regardless of
  // the one-click toggle so users can always reduce live risk — this
  // matches the legacy `/api/me/live/positions/:ticket/close` behavior
  // and is required for the "kill switch active → CLOSE ONLY" flow.
  const isOpenAction = intent.action === "BUY" || intent.action === "SELL";
  if (isOpenAction && !settings.liveOneClickEnabled) {
    await writeAudit({
      userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua,
      metadata: { intent, blockReason: "LIVE_ONE_CLICK_DISABLED" },
    });
    return { ok: false, httpStatus: 412, error: "LIVE_ONE_CLICK_DISABLED" };
  }

  const rubyCheck = rubyAuthCheck(intent, settings);
  if (!rubyCheck.ok) {
    await writeAudit({
      userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua,
      metadata: { intent, blockReason: rubyCheck.reason },
    });
    return { ok: false, httpStatus: 403, error: rubyCheck.reason, primaryReason: rubyCheck.reason };
  }

  const access = await loadAndEvaluateUserMasterLiveAccessGate(userId);
  if (access.decision === "BLOCKED") {
    await writeAudit({
      userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua,
      metadata: { intent, blockReason: access.primaryReason },
    });
    return {
      ok: false, httpStatus: 403, error: "MASTER_LIVE_USER_ACCESS_BLOCKED",
      primaryReason: access.primaryReason,
    };
  }

  // Per-user submit rate limit (tokens/min).
  if (!tryConsumeToken(`user:${userId}`, settings.perUserSubmitsPerMinute)) {
    await writeAudit({
      userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua,
      metadata: { intent, blockReason: "USER_SUBMIT_RATE_LIMITED" },
    });
    return { ok: false, httpStatus: 429, error: "USER_SUBMIT_RATE_LIMITED" };
  }

  switch (intent.action) {
    case "BUY":
    case "SELL":
      return executeOpen({ userId, intent, settings, ip, ua });
    case "CLOSE":
      return executeClose({ userId, intent, ip, ua });
    case "CLOSE_ALL":
      return executeCloseAll({ userId, ip, ua });
    case "MODIFY_SL_TP":
      return executeModify({ userId, intent, ip, ua });
    default:
      await writeAudit({
        userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua,
        metadata: { intent, blockReason: "UNKNOWN_ACTION" },
      });
      return { ok: false, httpStatus: 400, error: "UNKNOWN_ACTION" };
  }
}

async function executeOpen(args: {
  userId: number;
  intent: InstantTradeIntent;
  settings: { allowOrdersWithoutStopLoss: boolean; perUserSubmitsPerMinute: number };
  ip?: string | null; ua?: string | null;
}): Promise<InstantTradeResult> {
  const { userId, intent, settings, ip, ua } = args;
  const symbol = (intent.symbol ?? "").trim().toUpperCase();
  if (!symbol) {
    await writeAudit({ userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua, metadata: { intent, blockReason: "MISSING_SYMBOL" } });
    return { ok: false, httpStatus: 400, error: "MISSING_SYMBOL" };
  }
  if (typeof intent.volume !== "number" || intent.volume <= 0) {
    await writeAudit({ userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua, metadata: { intent, blockReason: "MISSING_VOLUME" } });
    return { ok: false, httpStatus: 400, error: "MISSING_VOLUME" };
  }
  const orderType = intent.orderType ?? (intent.action === "BUY" ? "MARKET_BUY" : "MARKET_SELL");
  const isMarket = /MARKET/i.test(orderType);
  const commandType: "PLACE_LIVE_MARKET_ORDER" | "PLACE_LIVE_PENDING_ORDER" =
    isMarket ? "PLACE_LIVE_MARKET_ORDER" : "PLACE_LIVE_PENDING_ORDER";

  if (!checkSymbolCooldown(symbol, userId)) {
    await writeAudit({ userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua, metadata: { intent, blockReason: "SYMBOL_COOLDOWN" } });
    return { ok: false, httpStatus: 429, error: "SYMBOL_COOLDOWN" };
  }

  const noSlOverride = settings.allowOrdersWithoutStopLoss === true
    && (intent.stopLoss == null || intent.stopLoss <= 0);

  const lock = await withTxAdvisoryLock(ARX_LOCK_NS.USER_SUBMIT, userId, async () => {
    const draft = await createLiveDraft({
      userId, commandType, symbol, side: intent.action as "BUY" | "SELL", orderType,
      requestedVolume: intent.volume!, stopLoss: intent.stopLoss ?? null, takeProfit: intent.takeProfit ?? null,
      sourcePage: `INSTANT_${intent.source.toUpperCase()}`,
      rubyExplanationSummary: intent.rawUserCommand ?? null,
      payload: {},
      allowNoStopLossThisDraft: noSlOverride,
    });
    if (!("ok" in draft) || draft.ok !== true) return { stage: "draft" as const, result: draft };
    const confirmed = await confirmLiveCommand({ userId, commandId: draft.command.commandId });
    if (!confirmed.ok) return { stage: "confirm" as const, result: confirmed, commandId: draft.command.commandId };
    const dispatched = await dispatchLiveCommand({ userId, commandId: draft.command.commandId });
    return { stage: "dispatch" as const, result: dispatched, commandId: draft.command.commandId };
  });
  if (!lock.acquired) {
    await writeAudit({ userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua, metadata: { intent, blockReason: "USER_SUBMIT_LOCKED" } });
    return { ok: false, httpStatus: 409, error: "USER_SUBMIT_LOCKED" };
  }
  const stage = lock.value;
  const draftR = stage.result as { ok?: boolean; reason?: string; primaryReason?: string; blockReason?: string };
  const accepted = draftR?.ok === true;
  await writeAudit({
    userId, action: accepted ? "INSTANT_EXECUTE_ACCEPTED" : "INSTANT_EXECUTE_REJECTED",
    ip, ua,
    metadata: {
      intent, stage: stage.stage, commandId: (stage as { commandId?: string }).commandId ?? null,
      noSlOverrideApplied: noSlOverride, serverLiveExecutionEnabled: liveBrokerExecutionEnabled(),
      primaryReason: draftR?.primaryReason ?? draftR?.blockReason ?? draftR?.reason ?? null,
    },
  });
  if (accepted) {
    return { ok: true, action: intent.action, commandId: (stage as { commandId?: string }).commandId, detail: draftR };
  }
  return {
    ok: false, httpStatus: 409,
    error: draftR?.blockReason ?? draftR?.reason ?? draftR?.primaryReason ?? "EXECUTE_REJECTED",
    primaryReason: draftR?.primaryReason ?? draftR?.blockReason ?? draftR?.reason,
    detail: draftR,
  };
}

async function executeClose(args: {
  userId: number;
  intent: InstantTradeIntent;
  ip?: string | null; ua?: string | null;
}): Promise<InstantTradeResult> {
  const { userId, intent, ip, ua } = args;
  if (!intent.positionId) {
    await writeAudit({ userId, action: "INSTANT_CLOSE_REJECTED", ip, ua, metadata: { intent, blockReason: "MISSING_POSITION_ID" } });
    return { ok: false, httpStatus: 400, error: "MISSING_POSITION_ID" };
  }
  const pos = await db.select().from(arxLivePositionsTable)
    .where(and(
      eq(arxLivePositionsTable.userId, userId),
      eq(arxLivePositionsTable.brokerTicket, intent.positionId),
    )).limit(1);
  const row = pos[0];
  if (!row) {
    await writeAudit({ userId, action: "INSTANT_CLOSE_REJECTED", ip, ua, metadata: { intent, blockReason: "POSITION_NOT_FOUND" } });
    return { ok: false, httpStatus: 404, error: "POSITION_NOT_FOUND" };
  }

  const r = await closeOnePosition({ userId, position: row });
  await writeAudit({
    userId, action: r.ok ? "INSTANT_CLOSE_ACCEPTED" : "INSTANT_CLOSE_REJECTED", ip, ua,
    metadata: {
      intent, positionId: intent.positionId, symbol: row.symbol, volume: Number(row.volume),
      primaryReason: r.ok ? null : r.error,
    },
  });
  return r;
}

async function executeCloseAll(args: {
  userId: number; ip?: string | null; ua?: string | null;
}): Promise<InstantTradeResult> {
  const { userId, ip, ua } = args;
  const positions = await db.select().from(arxLivePositionsTable)
    .where(and(
      eq(arxLivePositionsTable.userId, userId),
      isNull(arxLivePositionsTable.closedAt),
    ));
  let closed = 0;
  const failures: Array<{ positionId: string | null; reason: string }> = [];
  for (const p of positions) {
    const r = await closeOnePosition({ userId, position: p });
    if (r.ok) closed += 1;
    else failures.push({ positionId: p.brokerTicket, reason: r.error });
  }
  const allOk = failures.length === 0;
  await writeAudit({
    userId, action: allOk ? "INSTANT_CLOSE_ALL_ACCEPTED" : "INSTANT_CLOSE_ALL_REJECTED", ip, ua,
    metadata: { total: positions.length, closed, failures },
  });
  return allOk
    ? { ok: true, action: "CLOSE_ALL", detail: { total: positions.length, closed } }
    : { ok: false, httpStatus: 207, error: "PARTIAL_CLOSE_ALL", detail: { total: positions.length, closed, failures } };
}

async function executeModify(args: {
  userId: number; intent: InstantTradeIntent; ip?: string | null; ua?: string | null;
}): Promise<InstantTradeResult> {
  const { userId, intent, ip, ua } = args;
  if (!intent.positionId) {
    await writeAudit({ userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua, metadata: { intent, blockReason: "MISSING_POSITION_ID" } });
    return { ok: false, httpStatus: 400, error: "MISSING_POSITION_ID" };
  }
  const pos = await db.select().from(arxLivePositionsTable)
    .where(and(
      eq(arxLivePositionsTable.userId, userId),
      eq(arxLivePositionsTable.brokerTicket, intent.positionId),
    )).limit(1);
  const row = pos[0];
  if (!row) {
    await writeAudit({ userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua, metadata: { intent, blockReason: "POSITION_NOT_FOUND" } });
    return { ok: false, httpStatus: 404, error: "POSITION_NOT_FOUND" };
  }

  const draft = await createLiveOpsDraft({
    userId,
    commandType: "MODIFY_LIVE_SLTP",
    brokerTicket: intent.positionId,
    symbol: row.symbol,
    side: row.side as "BUY" | "SELL",
    volume: Number(row.volume),
    newStopLoss: intent.newStopLoss ?? (row.stopLoss != null ? Number(row.stopLoss) : null),
    newTakeProfit: intent.newTakeProfit ?? (row.takeProfit != null ? Number(row.takeProfit) : null),
    sourcePage: `INSTANT_MODIFY_${intent.source.toUpperCase()}`,
  });
  if (!("ok" in draft) || draft.ok !== true) {
    const d = draft as { reason?: string; primaryReason?: string };
    await writeAudit({ userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua, metadata: { intent, modify: true, blockReason: d.primaryReason ?? d.reason ?? "MODIFY_DRAFT_REJECTED" } });
    return { ok: false, httpStatus: 409, error: d.primaryReason ?? d.reason ?? "MODIFY_REJECTED", detail: d };
  }
  const confirmed = await confirmLiveCommand({ userId, commandId: draft.command.commandId });
  if (!confirmed.ok) {
    await writeAudit({ userId, action: "INSTANT_EXECUTE_REJECTED", ip, ua, metadata: { intent, modify: true, blockReason: confirmed.reason ?? "MODIFY_CONFIRM_FAILED", commandId: draft.command.commandId } });
    return { ok: false, httpStatus: 409, error: confirmed.reason ?? "CONFIRM_FAILED" };
  }
  const dispatched = await dispatchLiveCommand({ userId, commandId: draft.command.commandId });
  const accepted = dispatched.ok === true;
  const dispatchBlockReason = accepted
    ? null
    : ((dispatched as { primaryReason?: string; reason?: string }).primaryReason
      ?? (dispatched as { reason?: string }).reason
      ?? "MODIFY_DISPATCH_REJECTED");
  await writeAudit({
    userId, action: accepted ? "INSTANT_EXECUTE_ACCEPTED" : "INSTANT_EXECUTE_REJECTED", ip, ua,
    metadata: { intent, modify: true, commandId: draft.command.commandId, blockReason: dispatchBlockReason },
  });
  return accepted
    ? { ok: true, action: "MODIFY_SL_TP", commandId: draft.command.commandId }
    : { ok: false, httpStatus: 409, error: dispatched.primaryReason ?? dispatched.reason ?? "MODIFY_DISPATCH_REJECTED", detail: dispatched };
}

// Internal: dispatch ONE reduce-only CLOSE for a given position row.
// Uses createLiveOpsDraft so MISSING_STOP_LOSS is bypassed (close is
// reduce-only, the SL gate doesn't apply).
async function closeOnePosition(args: {
  userId: number;
  position: typeof arxLivePositionsTable.$inferSelect;
}): Promise<InstantTradeResult> {
  const { userId, position } = args;
  if (!position.brokerTicket) return { ok: false, httpStatus: 400, error: "POSITION_MISSING_BROKER_TICKET" };
  const draft = await createLiveOpsDraft({
    userId,
    commandType: "CLOSE_LIVE_POSITION",
    brokerTicket: position.brokerTicket,
    symbol: position.symbol,
    side: position.side as "BUY" | "SELL",
    volume: Number(position.volume),
    sourcePage: "INSTANT_CLOSE",
  });
  if (!("ok" in draft) || draft.ok !== true) {
    const d = draft as { reason?: string; primaryReason?: string };
    return { ok: false, httpStatus: 409, error: d.primaryReason ?? d.reason ?? "CLOSE_REJECTED", detail: d };
  }
  const confirmed = await confirmLiveCommand({ userId, commandId: draft.command.commandId });
  if (!confirmed.ok) return { ok: false, httpStatus: 409, error: confirmed.reason ?? "CONFIRM_FAILED" };
  const dispatched = await dispatchLiveCommand({ userId, commandId: draft.command.commandId });
  return dispatched.ok === true
    ? { ok: true, action: "CLOSE", commandId: draft.command.commandId }
    : { ok: false, httpStatus: 409, error: dispatched.primaryReason ?? dispatched.reason ?? "CLOSE_DISPATCH_REJECTED", detail: dispatched };
}

/**
 * Dry-run validator — never inserts a command. Builds a draft and
 * immediately tears it down so callers (preview UI, Ruby preview) can
 * see whether dispatch WOULD pass without committing. Re-uses the same
 * preflight gates as the real path.
 */
export async function validateInstant(args: {
  userId: number; intent: InstantTradeIntent; ip?: string | null; ua?: string | null;
}): Promise<InstantTradeResult> {
  const { userId, intent, ip, ua } = args;
  // Always audit validate — it's a dry-run that still surfaces user
  // intent and the resulting decision (PASS or BLOCKED + reason).
  const audit = (decision: string, blockReason?: string) =>
    writeAudit({ userId, action: "INSTANT_VALIDATE", ip, ua, metadata: { intent, decision, blockReason: blockReason ?? null } });

  if (intent.accountMode !== "live") {
    await audit("BLOCKED", "UNSUPPORTED_ACCOUNT_MODE_FOR_INSTANT_LIVE");
    return { ok: false, httpStatus: 400, error: "UNSUPPORTED_ACCOUNT_MODE_FOR_INSTANT_LIVE" };
  }
  const settings = await getSettings(userId);
  // Mirror executeInstant(): the one-click toggle only gates BUY/SELL
  // open-risk previews. Reduce-only previews (CLOSE/CLOSE_ALL/
  // MODIFY_SL_TP) must remain available regardless of one-click.
  const isOpenAction = intent.action === "BUY" || intent.action === "SELL";
  if (isOpenAction && !settings.liveOneClickEnabled) {
    await audit("BLOCKED", "LIVE_ONE_CLICK_DISABLED");
    return { ok: false, httpStatus: 412, error: "LIVE_ONE_CLICK_DISABLED" };
  }
  const ruby = rubyAuthCheck(intent, settings);
  if (!ruby.ok) {
    await audit("BLOCKED", ruby.reason);
    return { ok: false, httpStatus: 403, error: ruby.reason };
  }
  const access = await loadAndEvaluateUserMasterLiveAccessGate(userId);
  if (access.decision === "BLOCKED") {
    await audit("BLOCKED", "MASTER_LIVE_USER_ACCESS_BLOCKED");
    return { ok: false, httpStatus: 403, error: "MASTER_LIVE_USER_ACCESS_BLOCKED", primaryReason: access.primaryReason };
  }
  await audit("PASS");
  return { ok: true, action: intent.action, detail: { validate: true, serverLiveExecutionEnabled: liveBrokerExecutionEnabled() } };
}
