// Phase A — Live command pipeline (per-user).
//
// PIPELINE: LIVE_DRAFT → LIVE_CONFIRMATION_REQUIRED → LIVE_APPROVED → dispatch
//
// DISPATCH: evaluateLiveDispatchGate() ALWAYS returns canDispatchLive=false
// in Phase A, so every dispatched command transitions to LIVE_BLOCKED with
// reason BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED (the CI-pinned literal).
//
// IMPORTANT: this pipeline is intentionally separate from the demo pipeline
// (`mt5DemoCommandsTable`). A demo command can never accidentally route as
// live and vice versa.

import { randomUUID } from "node:crypto";
import { and, desc, eq, isNull, sql } from "drizzle-orm";
import {
  db,
  arxLiveCommandsTable,
  arxLivePositionsTable,
  arxLiveUserSettingsTable,
  liveTradingAuditTable,
  mt5ConnectionTable,
  userMasterLiveAccessTable,
  type ArxLiveCommand,
  type ArxLiveCommandStatus,
  type ArxLiveCommandType,
  ARX_LIVE_COMMAND_TYPES,
} from "@workspace/db";
import { evaluateLiveDispatchGate } from "@workspace/domain/safety-contracts/liveDispatchGate";
import {
  evaluateLivePhaseBDispatchGate,
  type LivePhaseBGateResult,
} from "@workspace/domain/safety-contracts/livePhaseBDispatchGate";
import { getMyArming } from "./liveArming.js";
import {
  ARX_LIVE_DEFAULT_MAX_LOT_PER_MARKET,
  ARX_LIVE_DEFAULT_ALLOWED_SYMBOLS,
  ARX_LIVE_HARD_WEEKLY_DRAWDOWN_PCT,
} from "./liveArming.js";
import { liveBrokerExecutionEnabled, resolveLiveBrokerExecutionEnabledAsync, buildLiveIdempotencyKey, PHASE_B_LIVE_LOG_PREFIX } from "./phaseBConfig.js";
import { getEnvelope } from "../adminTrading/safetyEnvelope.js";
import { logger } from "../logger.js";
import { globalTradingSettingsTable, liveRiskDisclosureAcceptancesTable } from "@workspace/db";

// Gap A — Phase B disclosure gate input loader. Returns true iff the user
// has ANY append-only row in live_risk_disclosure_acceptances. Default-deny.
async function hasUserAcceptedDisclosure(userId: number): Promise<boolean> {
  const r = await db.select({ id: liveRiskDisclosureAcceptancesTable.id })
    .from(liveRiskDisclosureAcceptancesTable)
    .where(eq(liveRiskDisclosureAcceptancesTable.userId, userId))
    .limit(1);
  return r.length > 0;
}
import { loadAndEvaluateMasterLiveBridgeGate } from "../mt5/masterLiveBridgeGate.js";
import { loadAndEvaluateUserMasterLiveAccessGate } from "../mt5/userMasterLiveAccessGate.js";
import { evaluateOperatorFundedPilotGate } from "./operatorFundedPilotGate.js";

const ALLOWED_TRANSITIONS: Record<ArxLiveCommandStatus, ArxLiveCommandStatus[]> = {
  LIVE_DRAFT: ["LIVE_CONFIRMATION_REQUIRED", "LIVE_CANCELLED", "LIVE_BLOCKED"],
  LIVE_CONFIRMATION_REQUIRED: ["LIVE_APPROVED", "LIVE_CANCELLED", "LIVE_BLOCKED"],
  LIVE_APPROVED: ["SENT_TO_MT5_LIVE", "LIVE_BLOCKED", "LIVE_CANCELLED"],
  SENT_TO_MT5_LIVE: ["LIVE_FILLED", "LIVE_REJECTED", "LIVE_FAILED", "LIVE_BLOCKED"],
  LIVE_FILLED: ["LIVE_CLOSED"],
  LIVE_REJECTED: [], LIVE_FAILED: [], LIVE_BLOCKED: [], LIVE_CANCELLED: [], LIVE_CLOSED: [],
};

async function audit(args: {
  eventType: string; userId: number; message: string;
  symbol?: string; severity?: string; metadata?: Record<string, unknown>;
}) {
  await db.insert(liveTradingAuditTable).values({
    eventId: randomUUID(),
    eventType: args.eventType,
    severity: args.severity ?? "INFO",
    mode: "READ_ONLY",
    symbol: args.symbol ?? null,
    message: args.message,
    actorRole: "user",
    metadata: { userId: args.userId, ...(args.metadata ?? {}) },
  });
}

export interface LiveDraftInput {
  userId: number;
  commandType: ArxLiveCommandType;
  symbol: string;
  side: "BUY" | "SELL";
  orderType: string;
  requestedVolume: number;
  stopLoss?: number | null;
  takeProfit?: number | null;
  sourcePage?: string;
  rubyExplanationSummary?: string | null;
  payload?: Record<string, unknown>;
  ip?: string;
  /**
   * One-click fast-path SL override. Set ONLY by `/me/one-click/submit-live`
   * after verifying the user has `userOneClickSettings.allowOrdersWithoutStopLoss = true`
   * AND `liveOneClickEnabled = true` AND `approvedForMasterLive = true`.
   * When true the SL pre-flight is skipped AND the dispatch-time
   * `MISSING_STOP_LOSS` gate is treated as `adminAllowNoStopLoss = true`
   * for THIS draft only. Persisted on `payload.allowNoStopLossThisDraft`
   * so the dispatch-time eval can read it back.
   */
  allowNoStopLossThisDraft?: boolean;
}

export interface LiveDraftRefusal {
  ok: false;
  reason:
    | "USER_NOT_ARMED_FOR_LIVE" | "KILL_SWITCH_ENGAGED"
    | "INVALID_COMMAND_TYPE" | "INVALID_SIDE"
    | "VOLUME_EXCEEDS_USER_MAX_LOT" | "VOLUME_EXCEEDS_MARKET_MAX_LOT"
    | "SYMBOL_NOT_ALLOWED" | "MISSING_STOP_LOSS"
    | "NO_ACTIVE_BRIDGE";
  detail?: string;
}

/**
 * Pre-flight check: refuses the draft if the user is not armed, the kill
 * switch is engaged, the volume exceeds the per-user or per-market max,
 * the symbol is not allowed, or SL is missing (when required).
 */
async function preflight(input: LiveDraftInput): Promise<LiveDraftRefusal | { ok: true }> {
  if (!(ARX_LIVE_COMMAND_TYPES as readonly string[]).includes(input.commandType)) {
    return { ok: false, reason: "INVALID_COMMAND_TYPE", detail: input.commandType };
  }
  if (input.side !== "BUY" && input.side !== "SELL") {
    return { ok: false, reason: "INVALID_SIDE", detail: input.side };
  }

  const arming = await getMyArming(input.userId);
  if (!arming || !arming.isArmed) return { ok: false, reason: "USER_NOT_ARMED_FOR_LIVE" };
  if (arming.killSwitchEngaged) return { ok: false, reason: "KILL_SWITCH_ENGAGED" };

  // Per-user max lot from arming.
  if (arming.maxLotConfirmed != null && input.requestedVolume > arming.maxLotConfirmed) {
    return { ok: false, reason: "VOLUME_EXCEEDS_USER_MAX_LOT",
      detail: `requested ${input.requestedVolume} > user max ${arming.maxLotConfirmed}` };
  }

  // Per-market max lot from user settings (or defaults).
  const settings = await getOrCreateUserSettings(input.userId);
  const perMarketMap = (settings.maxLotPerMarket as Record<string, number>) ?? {};
  const marketMax = perMarketMap[input.symbol] ?? ARX_LIVE_DEFAULT_MAX_LOT_PER_MARKET[input.symbol];
  if (marketMax != null && input.requestedVolume > marketMax) {
    return { ok: false, reason: "VOLUME_EXCEEDS_MARKET_MAX_LOT",
      detail: `requested ${input.requestedVolume} > ${input.symbol} max ${marketMax}` };
  }

  // Allowed symbols list.
  const allowed = ((settings.allowedSymbols as string[]) ?? []).length > 0
    ? (settings.allowedSymbols as string[])
    : ARX_LIVE_DEFAULT_ALLOWED_SYMBOLS;
  if (!allowed.includes(input.symbol)) {
    return { ok: false, reason: "SYMBOL_NOT_ALLOWED", detail: input.symbol };
  }

  // Stop-loss required unless admin override OR this is an explicit
  // one-click fast-path draft whose per-user setting permits no-SL.
  if (
    settings.requireStopLoss &&
    !settings.adminAllowNoStopLoss &&
    !input.allowNoStopLossThisDraft &&
    (input.stopLoss == null || input.stopLoss <= 0) &&
    (input.commandType === "PLACE_LIVE_MARKET_ORDER" || input.commandType === "PLACE_LIVE_PENDING_ORDER")
  ) {
    return { ok: false, reason: "MISSING_STOP_LOSS" };
  }

  return { ok: true };
}

/**
 * Phase B — Create a draft for CLOSE_LIVE_POSITION or MODIFY_LIVE_SLTP.
 * These ops are bound to an existing live position (ticket) and skip the
 * place-only preflight (SL requirement, market-allowlist for new entries).
 * Still requires user-armed + kill-switch off; volume + symbol come from
 * the position row.
 */
export async function createLiveOpsDraft(input: {
  userId: number;
  commandType: "CLOSE_LIVE_POSITION" | "MODIFY_LIVE_SLTP";
  brokerTicket: string;
  symbol: string;
  side: "BUY" | "SELL";
  volume: number;
  newStopLoss?: number | null;
  newTakeProfit?: number | null;
  sourcePage?: string;
}): Promise<{ ok: true; command: ArxLiveCommand } | { ok: false; reason: string; detail?: string }> {
  const arming = await getMyArming(input.userId);
  if (!arming || !arming.isArmed) return { ok: false, reason: "USER_NOT_ARMED_FOR_LIVE" };
  if (arming.killSwitchEngaged) return { ok: false, reason: "KILL_SWITCH_ENGAGED" };

  const bridge = (await db.select().from(mt5ConnectionTable)
    .where(eq(mt5ConnectionTable.userId, input.userId))).find((b) => !b.tokenRevokedAt) ?? null;

  const commandId = `lvcmd_${randomUUID()}`;
  const [row] = await db.insert(arxLiveCommandsTable).values({
    commandId,
    userId: input.userId,
    bridgeConnectionId: bridge?.id ?? null,
    accountLogin: bridge?.accountNumber ?? null,
    brokerServer: bridge?.brokerName ?? null,
    accountNumber: arming.accountNumberConfirmed,
    commandType: input.commandType,
    status: "LIVE_CONFIRMATION_REQUIRED",
    symbol: input.symbol,
    side: input.side,
    orderType: input.commandType === "CLOSE_LIVE_POSITION" ? "CLOSE" : "MODIFY",
    requestedVolume: input.volume,
    stopLoss: input.newStopLoss ?? null,
    takeProfit: input.newTakeProfit ?? null,
    sourcePage: input.sourcePage ?? "LIVE_POSITION_OPS",
    payload: {
      brokerTicket: input.brokerTicket,
      newStopLoss: input.newStopLoss ?? null,
      newTakeProfit: input.newTakeProfit ?? null,
    },
  }).returning();

  await audit({
    eventType: "LIVE_DRAFT_CREATED", userId: input.userId, symbol: input.symbol,
    message: `Live ops draft created: ${input.commandType} ticket=${input.brokerTicket}`,
    metadata: { commandId, commandType: input.commandType, brokerTicket: input.brokerTicket },
  });

  return { ok: true, command: row };
}

export async function createLiveDraft(
  input: LiveDraftInput,
): Promise<{ ok: true; command: ArxLiveCommand } | LiveDraftRefusal> {
  const pre = await preflight(input);
  if (!pre.ok) {
    await audit({
      eventType: "LIVE_DRAFT_REFUSED",
      severity: "WARNING",
      userId: input.userId,
      symbol: input.symbol,
      message: `Live draft refused: ${pre.reason}${pre.detail ? ` (${pre.detail})` : ""}`,
      metadata: { reason: pre.reason, detail: pre.detail, commandType: input.commandType, requestedVolume: input.requestedVolume },
    });
    return pre;
  }

  const arming = (await getMyArming(input.userId))!;
  const bridge = arming
    ? (await db.select().from(mt5ConnectionTable)
        .where(eq(mt5ConnectionTable.userId, input.userId))).find((b) => !b.tokenRevokedAt) ?? null
    : null;

  const commandId = `lvcmd_${randomUUID()}`;
  const [row] = await db.insert(arxLiveCommandsTable).values({
    commandId,
    userId: input.userId,
    bridgeConnectionId: bridge?.id ?? null,
    accountLogin: bridge?.accountNumber ?? null,
    brokerServer: bridge?.brokerName ?? null,
    accountNumber: arming.accountNumberConfirmed,
    commandType: input.commandType,
    status: "LIVE_CONFIRMATION_REQUIRED",
    symbol: input.symbol,
    side: input.side,
    orderType: input.orderType,
    requestedVolume: input.requestedVolume,
    stopLoss: input.stopLoss ?? null,
    takeProfit: input.takeProfit ?? null,
    sourcePage: input.sourcePage ?? "LIVE_TRADE_TICKET",
    rubyExplanationSummary: input.rubyExplanationSummary ?? null,
    // SAFETY: scrub the override key from any client-supplied payload —
    // only this server-side path may set it, and only from the dedicated
    // `input.allowNoStopLossThisDraft` argument (which itself is gated
    // by `/me/one-click/submit-live` verifying liveOneClickEnabled +
    // allowOrdersWithoutStopLoss + master-live access). A client cannot
    // smuggle the bit through `payload`.
    payload: (() => {
      const raw = (input.payload ?? {}) as Record<string, unknown>;
      const { allowNoStopLossThisDraft: _stripped, ...safe } = raw;
      return input.allowNoStopLossThisDraft === true
        ? { ...safe, allowNoStopLossThisDraft: true as const }
        : safe;
    })(),
  }).returning();

  await audit({
    eventType: "LIVE_DRAFT_CREATED", userId: input.userId, symbol: input.symbol,
    message: `Live draft created (awaiting confirmation): ${commandId}`,
    metadata: { commandId, requestedVolume: input.requestedVolume, side: input.side },
  });

  return { ok: true, command: row };
}

function assertCanTransition(from: ArxLiveCommandStatus, to: ArxLiveCommandStatus) {
  if (!ALLOWED_TRANSITIONS[from].includes(to)) {
    throw new Error(`Illegal live command transition: ${from} -> ${to}`);
  }
}

export async function confirmLiveCommand(args: { userId: number; commandId: string }) {
  const row = await loadOwned(args.userId, args.commandId);
  if (!row) return { ok: false as const, reason: "COMMAND_NOT_FOUND" as const };
  if (row.status !== "LIVE_CONFIRMATION_REQUIRED") {
    return { ok: false as const, reason: "BAD_STATE" as const, currentStatus: row.status };
  }
  assertCanTransition(row.status as ArxLiveCommandStatus, "LIVE_APPROVED");
  const [updated] = await db.update(arxLiveCommandsTable)
    .set({ status: "LIVE_APPROVED", confirmedAt: new Date() })
    .where(eq(arxLiveCommandsTable.commandId, args.commandId))
    .returning();
  await audit({
    eventType: "LIVE_CONFIRMED", userId: args.userId, symbol: row.symbol,
    message: `Live command confirmed: ${args.commandId}`,
  });
  return { ok: true as const, command: updated };
}

/**
 * Phase B dispatch — runs the 15-gate live dispatch evaluator. On PASS, the
 * row transitions to `SENT_TO_MT5_LIVE`, sets `sentToMt5At` + `idempotencyKey`,
 * and waits for EA pickup at `POST /api/mt5/live-commands-poll`. On BLOCKED,
 * the row transitions to `LIVE_BLOCKED` with the exact primary failing reason.
 *
 * SAFETY:
 * - The Phase A `evaluateLiveDispatchGate` literal is still computed and
 *   attached to the audit snapshot (for grep/CI continuity).
 * - All 15 gates are re-checked at dispatch (TOCTOU guard): user-armed,
 *   kill-switch, bridge facts, settings, idempotency, master switch.
 * - When the server master switch is off, the legacy chokepoint sentinel
 *   `BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED` is appended to `blockReasons`.
 */
export async function dispatchLiveCommand(args: { userId: number; commandId: string }) {
  const row = await loadOwned(args.userId, args.commandId);
  if (!row) return { ok: false as const, reason: "COMMAND_NOT_FOUND" as const };
  if (row.status !== "LIVE_APPROVED") {
    return { ok: false as const, reason: "BAD_STATE" as const, currentStatus: row.status };
  }

  // ── OPERATOR-FUNDED PILOT GATE (runs BEFORE everything else) ───────────
  // Enforces: master pilot switch on + user in ARX_PRIVATE_BETA_10 +
  // beta invite accepted + compliance flag on + allocation > 0 +
  // operator-funded disclosure (versioned) accepted. PASS here only
  // ADDS to existing requirements; Phase B 16-gate still runs after.
  const pilotGate = await evaluateOperatorFundedPilotGate({ userId: args.userId });
  if (pilotGate.decision === "BLOCKED") {
    const reason = pilotGate.primaryReason ?? "OPERATOR_FUNDED_PILOT_DISABLED";
    const [blocked] = await db.update(arxLiveCommandsTable).set({
      status: "LIVE_BLOCKED",
      rejectionReason: reason,
      rejectedAt: new Date(),
      dispatchGateSnapshot: {
        decision: "BLOCKED",
        primaryReason: reason,
        blockReasons: [...pilotGate.blockReasons, "BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED"],
        operatorFundedPilotGate: true,
        at: pilotGate.evaluatedAt,
      } as unknown as Record<string, unknown>,
    }).where(eq(arxLiveCommandsTable.commandId, args.commandId)).returning();
    await audit({
      eventType: "OPERATOR_FUNDED_PILOT_BLOCKED", severity: "HIGH",
      userId: args.userId, symbol: row.symbol,
      message: `Operator-funded pilot dispatch BLOCKED: ${reason}`,
      metadata: { commandId: args.commandId, blockReasons: pilotGate.blockReasons },
    });
    logger.warn({
      [PHASE_B_LIVE_LOG_PREFIX]: true,
      event: "OPERATOR_FUNDED_PILOT_BLOCKED",
      commandId: args.commandId, userId: args.userId,
      primaryReason: reason, blockReasons: pilotGate.blockReasons,
    }, "Operator-funded pilot blocked");
    return { ok: false as const, reason: "LIVE_BLOCKED" as const, primaryReason: reason, blockReasons: pilotGate.blockReasons, command: blocked };
  }

  const arming = await getMyArming(args.userId);

  // Phase A gate still computed for the audit snapshot (CI literal continuity).
  const phaseAGate = evaluateLiveDispatchGate({
    userId: args.userId,
    userArmed: !!arming?.isArmed,
    killSwitchEngaged: !!arming?.killSwitchEngaged,
  });

  // Assemble Phase B inputs from live sources at this exact moment.
  const settings = await getOrCreateUserSettings(args.userId);
  const env = await getEnvelope(args.userId);

  // ── MASTER BRIDGE LIVE — routing-mode-aware bridge selection ───────────
  // When account_routing_mode=SHARED_MASTER_MT5, every live command MUST
  // bind to the platform_master_bridge_connection_id (the detector's
  // current connected real bridge). The master-live gate runs BEFORE the
  // existing Phase B 16-gate and short-circuits with a specific reason
  // (MASTER_LIVE_REQUIRES_REAL_BRIDGE / MASTER_BRIDGE_HEARTBEAT_STALE /
  // BRIDGE_BINDING_MISMATCH / etc.) so the operator sees the exact failing
  // bridge-binding rule. When PASS, we override the bridge selection
  // below with the bound bridge so pickupNextLiveCommand and
  // recordLiveCommandResult both validate against the same row.
  const gtsRows = await db.select().from(globalTradingSettingsTable).limit(1);
  const gts = gtsRows[0] ?? null;
  const routingMode = (gts?.accountRoutingMode as "USER_OWNED_MT5" | "SHARED_MASTER_MT5") ?? "USER_OWNED_MT5";
  let masterBoundBridgeId: number | null = null;
  if (routingMode === "SHARED_MASTER_MT5") {
    // ── PER-USER ACCESS GATE — admin must explicitly approve + toggle
    // ── this user before any master live command can be created. Runs
    // ── BEFORE the bridge gate so we never reveal bridge state to an
    // ── unapproved user.
    const userAccess = await loadAndEvaluateUserMasterLiveAccessGate(args.userId);
    if (userAccess.decision === "BLOCKED") {
      const reason = userAccess.primaryReason;
      const [blocked] = await db.update(arxLiveCommandsTable).set({
        status: "LIVE_BLOCKED",
        rejectionReason: reason,
        rejectedAt: new Date(),
        dispatchGateSnapshot: {
          decision: "BLOCKED",
          primaryReason: reason,
          blockReasons: userAccess.blockReasons,
          userMasterLiveAccessGate: true,
          userMasterLiveStatus: userAccess.status,
          routingMode,
          at: new Date().toISOString(),
        } as unknown as Record<string, unknown>,
      }).where(eq(arxLiveCommandsTable.commandId, args.commandId)).returning();
      await audit({
        eventType: "MASTER_LIVE_USER_ACCESS_BLOCKED", severity: "HIGH",
        userId: args.userId, symbol: row.symbol,
        message: `Master live user-access BLOCKED: ${reason}`,
        metadata: { commandId: args.commandId, blockReasons: userAccess.blockReasons, status: userAccess.status },
      });
      logger.warn({
        [PHASE_B_LIVE_LOG_PREFIX]: true,
        event: "MASTER_LIVE_USER_ACCESS_BLOCKED",
        commandId: args.commandId, userId: args.userId,
        primaryReason: reason, blockReasons: userAccess.blockReasons,
      }, "Master live user-access blocked");
      return { ok: false as const, reason: "LIVE_BLOCKED" as const, primaryReason: reason, blockReasons: userAccess.blockReasons, command: blocked };
    }
    const mlg = await loadAndEvaluateMasterLiveBridgeGate();
    if (mlg.decision === "BLOCKED") {
      const reason = mlg.primaryReason;
      const [blocked] = await db.update(arxLiveCommandsTable).set({
        status: "LIVE_BLOCKED",
        rejectionReason: reason,
        rejectedAt: new Date(),
        dispatchGateSnapshot: {
          decision: "BLOCKED",
          primaryReason: reason,
          blockReasons: mlg.blockReasons,
          masterLiveGate: true,
          routingMode,
          at: new Date().toISOString(),
        } as unknown as Record<string, unknown>,
      }).where(eq(arxLiveCommandsTable.commandId, args.commandId)).returning();
      await audit({
        eventType: "MASTER_LIVE_DISPATCH_BLOCKED", severity: "HIGH",
        userId: args.userId, symbol: row.symbol,
        message: `Master live dispatch BLOCKED: ${reason}`,
        metadata: { commandId: args.commandId, blockReasons: mlg.blockReasons },
      });
      logger.warn({
        [PHASE_B_LIVE_LOG_PREFIX]: true,
        event: "MASTER_LIVE_DISPATCH_BLOCKED",
        commandId: args.commandId, userId: args.userId,
        primaryReason: reason, blockReasons: mlg.blockReasons,
      }, "Master live dispatch blocked");
      return { ok: false as const, reason: "LIVE_BLOCKED" as const, primaryReason: reason, blockReasons: mlg.blockReasons, command: blocked };
    }
    masterBoundBridgeId = mlg.boundBridgeId;
  }

  // Active bridge — in SHARED_MASTER_MT5 mode this is the master-live
  // gate's bound bridge (the current connected real bridge). In
  // USER_OWNED_MT5 mode it is the freshest non-revoked LIVE-mode bridge
  // for THIS user. Fall back to whatever exists ONLY so downstream gates
  // can surface their specific failure reason instead of "no bridge".
  // The explicit MOCK short-circuit below refuses dispatch before the
  // evaluator runs, so a MOCK row cannot ever satisfy live readiness.
  const bridgePool = masterBoundBridgeId != null
    ? await db.select().from(mt5ConnectionTable).where(eq(mt5ConnectionTable.id, masterBoundBridgeId))
    : await db.select().from(mt5ConnectionTable).where(eq(mt5ConnectionTable.userId, args.userId));
  const nonRevoked = bridgePool.filter((b) => !b.tokenRevokedAt);
  const byFreshness = (a: typeof nonRevoked[number], b: typeof nonRevoked[number]) => {
    const ah = a.lastHeartbeat ? new Date(a.lastHeartbeat).getTime() : 0;
    const bh = b.lastHeartbeat ? new Date(b.lastHeartbeat).getTime() : 0;
    return bh - ah;
  };
  const liveModeBridges = nonRevoked.filter((b) => b.mode === "LIVE").sort(byFreshness);
  const bridge = liveModeBridges[0] ?? nonRevoked.sort(byFreshness)[0] ?? null;

  // Phase B MOCK short-circuit (TOCTOU guard layer). The Phase B evaluator
  // does NOT inspect bridge.mode (it is a pure function over the heartbeat
  // facts) — we enforce the "MOCK is never live-capable" rule here so a
  // MOCK placeholder row with accountType='live' cannot slip a real
  // broker dispatch through. Distinct reason for operator clarity.
  if (bridge && bridge.mode === "MOCK") {
    const mockBlockReasons = ["MOCK_BRIDGE_NOT_LIVE_CAPABLE", "BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED"] as const;
    const blocked = await db.update(arxLiveCommandsTable)
      .set({
        status: "LIVE_BLOCKED",
        rejectionReason: "MOCK_BRIDGE_NOT_LIVE_CAPABLE",
        dispatchGateSnapshot: {
          decision: "BLOCKED",
          primaryReason: "MOCK_BRIDGE_NOT_LIVE_CAPABLE",
          blockReasons: [...mockBlockReasons],
          bridgeId: bridge.id,
          bridgeMode: bridge.mode,
          shortCircuit: "pipeline_pre_evaluator_mock_refusal",
          at: new Date().toISOString(),
        },
        rejectedAt: new Date(),
        brokerMessage: `Bridge ${bridge.id} is a MOCK placeholder, not a real MT5 EA heartbeat. Attach EA v1.27 from your live MT5 terminal so a real heartbeat replaces the MOCK row.`,
      })
      .where(eq(arxLiveCommandsTable.commandId, args.commandId))
      .returning();
    await audit({
      eventType: "LIVE_BLOCKED", userId: args.userId, symbol: row.symbol,
      message: `Live dispatch refused: MOCK_BRIDGE_NOT_LIVE_CAPABLE (bridge id=${bridge.id})`,
    });
    return {
      ok: false as const,
      reason: "LIVE_BLOCKED" as const,
      primaryReason: "MOCK_BRIDGE_NOT_LIVE_CAPABLE" as const,
      blockReasons: mockBlockReasons,
      command: blocked[0],
    };
  }

  const hbAge = bridge?.lastHeartbeat
    ? Math.max(0, Math.floor((Date.now() - new Date(bridge.lastHeartbeat).getTime()) / 1000))
    : null;
  const caps = (bridge?.capabilities ?? {}) as { eaInputs?: Record<string, unknown> };
  const ea = (caps.eaInputs ?? {}) as Record<string, unknown>;

  // CLOSE_LIVE_POSITION and MODIFY_LIVE_SLTP must bypass entry-only gates
  // (symbol allowlist, per-symbol lot cap, stop-loss requirement). Blocking
  // an emergency close because the position's symbol left the allowlist —
  // or because its size exceeds the current per-symbol cap — would trap
  // real money in a losing trade. Authz, kill switch, master switch, EA
  // readiness, account-type, daily-loss gates still apply.
  const isOpsCommand = row.commandType === "CLOSE_LIVE_POSITION"
    || row.commandType === "MODIFY_LIVE_SLTP";

  const perMarketMap = (settings.maxLotPerMarket as Record<string, number>) ?? {};
  const allowed = isOpsCommand
    ? [row.symbol]
    : (((settings.allowedSymbols as string[]) ?? []).length > 0
        ? (settings.allowedSymbols as string[])
        : ARX_LIVE_DEFAULT_ALLOWED_SYMBOLS);
  const maxLotForSymbol = isOpsCommand
    ? Number.POSITIVE_INFINITY
    : (perMarketMap[row.symbol]
        ?? ARX_LIVE_DEFAULT_MAX_LOT_PER_MARKET[row.symbol]
        ?? 0.01);

  // Daily loss snapshot = unrealised negative floating P/L on currently
  // open positions  +  realised negative P/L on positions CLOSED since
  // start-of-day (UTC). Including the closed-today bucket prevents the
  // "close losers and re-trade past the cap" bypass: once a losing
  // position closes its floatingPl no longer counts as open, but its
  // realised loss still counts against today's limit.
  const startOfDayUtc = new Date(); startOfDayUtc.setUTCHours(0, 0, 0, 0);
  const openLossRows = await db.select({
    totalNegFloat: sql<number>`COALESCE(SUM(CASE WHEN ${arxLivePositionsTable.floatingPl} < 0 THEN ${arxLivePositionsTable.floatingPl} ELSE 0 END), 0)`,
  }).from(arxLivePositionsTable).where(and(
    eq(arxLivePositionsTable.userId, args.userId),
    isNull(arxLivePositionsTable.closedAt),
  ));
  const closedTodayLossRows = await db.select({
    totalNegRealised: sql<number>`COALESCE(SUM(CASE WHEN ${arxLivePositionsTable.floatingPl} < 0 THEN ${arxLivePositionsTable.floatingPl} ELSE 0 END), 0)`,
  }).from(arxLivePositionsTable).where(and(
    eq(arxLivePositionsTable.userId, args.userId),
    sql`${arxLivePositionsTable.closedAt} IS NOT NULL`,
    sql`${arxLivePositionsTable.closedAt} >= ${startOfDayUtc.toISOString()}`,
  ));
  const realisedDailyLossUsd =
    Math.abs(Number(openLossRows[0]?.totalNegFloat ?? 0)) +
    Math.abs(Number(closedTodayLossRows[0]?.totalNegRealised ?? 0));

  // ── PER-USER EXPOSURE GATES (run BEFORE the 16-gate Phase B evaluator) ─
  // Standardized audit codes emitted on block:
  //   MAX_OPEN_POSITIONS_REACHED        — concurrency cap exceeded
  //   MAX_EXPOSURE_PER_SYMBOL_REACHED   — per-symbol post-trade lots > cap
  // Both gates only apply to entry orders; CLOSE/MODIFY ops bypass to
  // avoid trapping money in a losing trade when an admin tightens caps.
  if (!isOpsCommand) {
    const accessRows = await db.select({
      maxOpenPositions: userMasterLiveAccessTable.maxOpenPositions,
      maxExposurePerSymbolLots: userMasterLiveAccessTable.maxExposurePerSymbolLots,
    }).from(userMasterLiveAccessTable)
      .where(eq(userMasterLiveAccessTable.userId, args.userId)).limit(1);
    const userCaps = accessRows[0] ?? null;
    const userMaxOpen = userCaps?.maxOpenPositions ?? null;
    const userMaxExposurePerSymbol = userCaps?.maxExposurePerSymbolLots ?? null;

    if (userMaxOpen != null || userMaxExposurePerSymbol != null) {
      // Count both EA-reported open positions AND in-flight live commands
      // (SENT_TO_MT5_LIVE that haven't filled/rejected yet) so two parallel
      // dispatches cannot both pass the cap before either reaches the EA.
      // This closes the TOCTOU window between this check and the
      // SENT_TO_MT5_LIVE write below; the minute-bucket idempotency key on
      // arx_live_commands already prevents identical duplicates.
      const openPositions = await db.select({
        symbol: arxLivePositionsTable.symbol,
        volume: arxLivePositionsTable.volume,
      }).from(arxLivePositionsTable).where(and(
        eq(arxLivePositionsTable.userId, args.userId),
        isNull(arxLivePositionsTable.closedAt),
      ));
      const inFlight = await db.select({
        symbol: arxLiveCommandsTable.symbol,
        volume: arxLiveCommandsTable.requestedVolume,
      }).from(arxLiveCommandsTable).where(and(
        eq(arxLiveCommandsTable.userId, args.userId),
        eq(arxLiveCommandsTable.status, "SENT_TO_MT5_LIVE"),
        isNull(arxLiveCommandsTable.filledAt),
        isNull(arxLiveCommandsTable.rejectedAt),
      ));
      const openCount = openPositions.length + inFlight.length;
      const perSymbolLots =
        openPositions.filter((p) => p.symbol === row.symbol)
          .reduce((s, p) => s + Number(p.volume ?? 0), 0) +
        inFlight.filter((c) => c.symbol === row.symbol)
          .reduce((s, c) => s + Number(c.volume ?? 0), 0);

      const exposureFail = (reason: "MAX_OPEN_POSITIONS_REACHED" | "MAX_EXPOSURE_PER_SYMBOL_REACHED", detail: string) =>
        ({ reason, detail, openCount, perSymbolLots });

      let block: { reason: "MAX_OPEN_POSITIONS_REACHED" | "MAX_EXPOSURE_PER_SYMBOL_REACHED"; detail: string; openCount: number; perSymbolLots: number } | null = null;
      if (userMaxOpen != null && openCount >= userMaxOpen) {
        block = exposureFail("MAX_OPEN_POSITIONS_REACHED",
          `Open positions ${openCount} >= cap ${userMaxOpen}`);
      } else if (userMaxExposurePerSymbol != null
        && (perSymbolLots + Number(row.requestedVolume)) > userMaxExposurePerSymbol) {
        block = exposureFail("MAX_EXPOSURE_PER_SYMBOL_REACHED",
          `${row.symbol} post-trade exposure ${(perSymbolLots + Number(row.requestedVolume)).toFixed(2)} lots > cap ${userMaxExposurePerSymbol}`);
      }

      if (block) {
        const [blocked] = await db.update(arxLiveCommandsTable).set({
          status: "LIVE_BLOCKED",
          rejectionReason: block.reason,
          rejectedAt: new Date(),
          dispatchGateSnapshot: {
            decision: "BLOCKED",
            primaryReason: block.reason,
            blockReasons: [block.reason, "BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED"],
            perUserExposureGate: true,
            detail: block.detail,
            openCount: block.openCount,
            perSymbolLots: block.perSymbolLots,
            userMaxOpenPositions: userMaxOpen,
            userMaxExposurePerSymbolLots: userMaxExposurePerSymbol,
            at: new Date().toISOString(),
          } as unknown as Record<string, unknown>,
        }).where(eq(arxLiveCommandsTable.commandId, args.commandId)).returning();
        await audit({
          eventType: "LIVE_TRADE_BLOCKED_EXPOSURE_LIMIT", severity: "HIGH",
          userId: args.userId, symbol: row.symbol,
          message: `Live dispatch BLOCKED: ${block.reason} (${block.detail})`,
          metadata: {
            commandId: args.commandId,
            primaryReason: block.reason,
            blockReasons: [block.reason, "BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED"],
            openCount: block.openCount,
            perSymbolLots: block.perSymbolLots,
            userMaxOpenPositions: userMaxOpen,
            userMaxExposurePerSymbolLots: userMaxExposurePerSymbol,
          },
        });
        logger.warn({
          [PHASE_B_LIVE_LOG_PREFIX]: true,
          event: "LIVE_TRADE_BLOCKED_EXPOSURE_LIMIT",
          commandId: args.commandId, userId: args.userId,
          primaryReason: block.reason, detail: block.detail,
        }, "Per-user exposure gate blocked");
        return {
          ok: false as const,
          reason: "LIVE_BLOCKED" as const,
          primaryReason: block.reason,
          blockReasons: [block.reason, "BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED"],
          command: blocked,
        };
      }
    }
  }

  const phaseBGate: LivePhaseBGateResult = evaluateLivePhaseBDispatchGate({
    liveBrokerExecutionEnabled: await resolveLiveBrokerExecutionEnabledAsync(),
    globalLiveEnabled: !!env.globalLiveEnabled,
    userLiveApproved: !!env.userLiveApproved,
    userArmed: !!arming?.isArmed,
    killSwitchEngaged: !!arming?.killSwitchEngaged,
    bridgeAccountType: bridge?.accountType ?? null,
    bridgeHeartbeatAgeSec: hbAge,
    bridgeEaVersion: bridge?.eaVersion ?? null,
    bridgeEnableLiveExecution: typeof ea["enableLiveExecution"] === "boolean" ? (ea["enableLiveExecution"] as boolean) : null,
    bridgeReadOnlyMode: typeof ea["readOnlyMode"] === "boolean" ? (ea["readOnlyMode"] as boolean) : null,
    bridgeTerminalConnected: typeof ea["terminalConnected"] === "boolean" ? (ea["terminalConnected"] as boolean) : null,
    bridgeAlgoTradingAllowed: typeof ea["algoTradingAllowed"] === "boolean" ? (ea["algoTradingAllowed"] as boolean) : null,
    commandSymbol: row.symbol,
    commandVolume: Number(row.requestedVolume),
    commandHasStopLoss: row.stopLoss != null && Number(row.stopLoss) > 0,
    allowedSymbols: allowed,
    maxLotForSymbol,
    dailyLossLimitUsd: Number(settings.dailyLossLimitUsd ?? 0),
    realisedDailyLossUsd,
    requireStopLoss: !!settings.requireStopLoss && !isOpsCommand,
    adminAllowNoStopLoss:
      !!settings.adminAllowNoStopLoss
      || isOpsCommand
      || (row.payload != null
          && typeof row.payload === "object"
          && (row.payload as { allowNoStopLossThisDraft?: boolean }).allowNoStopLossThisDraft === true),
    // Gap A — risk disclosure check (default-deny if no accepted row).
    disclosureAccepted: await hasUserAcceptedDisclosure(args.userId),
  });

  const snapshot = {
    phaseA: phaseAGate,
    phaseB: phaseBGate,
    bridgeConnectionId: bridge?.id ?? null,
    evaluatedAt: new Date().toISOString(),
  };

  if (phaseBGate.decision === "BLOCKED") {
    const reason = phaseBGate.primaryReason ?? "BROKER_PLACEMENT_LAYER_NOT_IMPLEMENTED";
    const [blocked] = await db.update(arxLiveCommandsTable).set({
      status: "LIVE_BLOCKED",
      rejectionReason: reason,
      rejectedAt: new Date(),
      dispatchGateSnapshot: snapshot as unknown as Record<string, unknown>,
    }).where(eq(arxLiveCommandsTable.commandId, args.commandId)).returning();
    await audit({
      eventType: "LIVE_DISPATCH_BLOCKED", severity: "HIGH",
      userId: args.userId, symbol: row.symbol,
      message: `Live dispatch BLOCKED: ${reason}`,
      metadata: { commandId: args.commandId, blockReasons: phaseBGate.blockReasons },
    });
    logger.warn({
      [PHASE_B_LIVE_LOG_PREFIX]: true,
      event: "LIVE_DISPATCH_BLOCKED",
      commandId: args.commandId, userId: args.userId,
      primaryReason: reason, blockReasons: phaseBGate.blockReasons,
      bridgeConnectionId: bridge?.id ?? null,
    }, "Phase B dispatch blocked");
    return { ok: false as const, reason, command: blocked, gate: phaseBGate };
  }

  // ── ATOMIC MASTER EXPOSURE RESERVATION (SHARED_MASTER_MT5 only) ────────
  // After all gates PASS but before the SENT_TO_MT5_LIVE transition, take
  // an advisory-locked reservation of `requestedVolume` lots against the
  // bound shared master account. Two parallel submissions cannot both
  // pass the cap-check; the loser surfaces
  // `MASTER_ACCOUNT_EXPOSURE_LIMIT_REACHED`. Released on any failure path.
  let reservationId: number | null = null;
  if (routingMode === "SHARED_MASTER_MT5" && bridge?.id) {
    const { sharedMasterAccountsTable } = await import("@workspace/db");
    const [sma] = await db.select({ id: sharedMasterAccountsTable.id })
      .from(sharedMasterAccountsTable)
      .where(eq(sharedMasterAccountsTable.connectionId, bridge.id))
      .limit(1);
    if (!sma?.id) {
      // FAIL CLOSED — SHARED_MASTER_MT5 routing requires a mapped
      // shared_master_accounts row; without it we cannot atomically
      // reserve exposure, so refusing is the only safe outcome.
      const reason = "MASTER_ACCOUNT_NOT_MAPPED" as const;
      const [blocked] = await db.update(arxLiveCommandsTable).set({
        status: "LIVE_BLOCKED",
        rejectionReason: reason,
        rejectedAt: new Date(),
        dispatchGateSnapshot: {
          decision: "BLOCKED",
          primaryReason: reason,
          blockReasons: [reason],
          routingMode,
          at: new Date().toISOString(),
        } as unknown as Record<string, unknown>,
      }).where(eq(arxLiveCommandsTable.commandId, args.commandId)).returning();
      await audit({
        eventType: "LIVE_DISPATCH_BLOCKED", severity: "HIGH",
        userId: args.userId, symbol: row.symbol,
        message: `SHARED_MASTER_MT5 dispatch refused: ${reason}`,
        metadata: { commandId: args.commandId, bridgeConnectionId: bridge.id },
      });
      return { ok: false as const, reason, command: blocked, gate: phaseBGate };
    }
    {
      const { reserveExposureAtomic } = await import("../concurrency/exposureReservation.js");
      const r = await reserveExposureAtomic({
        sharedMasterAccountId: sma.id,
        addingLot: Number(row.requestedVolume),
        userId: args.userId,
        commandId: args.commandId,
        symbol: row.symbol,
      });
      if (!r.ok) {
        const [blocked] = await db.update(arxLiveCommandsTable).set({
          status: "LIVE_BLOCKED",
          rejectionReason: r.reason,
          rejectedAt: new Date(),
          dispatchGateSnapshot: {
            decision: "BLOCKED",
            primaryReason: r.reason,
            blockReasons: [r.reason],
            currentOpenLots: r.currentOpenLots,
            reservedLots: r.reservedLots,
            cap: r.cap,
            routingMode,
            at: new Date().toISOString(),
          } as unknown as Record<string, unknown>,
        }).where(eq(arxLiveCommandsTable.commandId, args.commandId)).returning();
        await audit({
          eventType: "LIVE_DISPATCH_BLOCKED", severity: "HIGH",
          userId: args.userId, symbol: row.symbol,
          message: `Master exposure reservation refused: ${r.reason}`,
          metadata: { commandId: args.commandId, currentOpenLots: r.currentOpenLots, reservedLots: r.reservedLots, cap: r.cap },
        });
        return { ok: false as const, reason: r.reason, command: blocked, gate: phaseBGate };
      }
      reservationId = r.reservationId;
    }
  }

  // PASS path — transition to SENT_TO_MT5_LIVE atomically. Idempotency key
  // is enforced by the DB partial unique index `arx_live_commands_idem_active_uq`.
  const idemKey = buildLiveIdempotencyKey({
    userId: args.userId,
    symbol: row.symbol,
    side: row.side as "BUY" | "SELL",
    volume: Number(row.requestedVolume),
    stopLoss: row.stopLoss != null ? Number(row.stopLoss) : null,
    takeProfit: row.takeProfit != null ? Number(row.takeProfit) : null,
  });
  try {
    const [sent] = await db.update(arxLiveCommandsTable).set({
      status: "SENT_TO_MT5_LIVE",
      sentToMt5At: new Date(),
      idempotencyKey: idemKey,
      bridgeConnectionId: bridge!.id,
      accountLogin: bridge!.accountNumber,
      brokerServer: bridge!.brokerName,
      dispatchGateSnapshot: snapshot as unknown as Record<string, unknown>,
    }).where(eq(arxLiveCommandsTable.commandId, args.commandId)).returning();
    await audit({
      eventType: "LIVE_DISPATCH_SENT", severity: "CRITICAL",
      userId: args.userId, symbol: row.symbol,
      message: `Live dispatch SENT_TO_MT5_LIVE: ${args.commandId} (bridge ${bridge!.id})`,
      metadata: { commandId: args.commandId, bridgeConnectionId: bridge!.id, idempotencyKey: idemKey, requestedVolume: Number(row.requestedVolume) },
    });
    logger.warn({
      [PHASE_B_LIVE_LOG_PREFIX]: true,
      event: "LIVE_DISPATCH_SENT",
      commandId: args.commandId, userId: args.userId,
      bridgeConnectionId: bridge!.id,
      symbol: row.symbol, side: row.side, volume: Number(row.requestedVolume),
      idempotencyKey: idemKey,
    }, "Phase B dispatch SENT_TO_MT5_LIVE — awaiting EA pickup");
    return { ok: true as const, command: sent, gate: phaseBGate, idempotencyKey: idemKey };
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : String(e);
    const isDup = /arx_live_commands_idem_active_uq|duplicate key/.test(msg);
    const reason = isDup ? "DUPLICATE_LIVE_IDEMPOTENCY_KEY" : "DB_INSERT_FAILED";
    // Release the reservation we just took — the live command did not
    // make it to SENT_TO_MT5_LIVE so the master account should not be
    // attributed those lots.
    if (reservationId != null) {
      try {
        const { releaseReservation } = await import("../concurrency/exposureReservation.js");
        await releaseReservation(reservationId);
      } catch { /* audit-only failure */ }
    }
    const [blocked] = await db.update(arxLiveCommandsTable).set({
      status: "LIVE_BLOCKED",
      rejectionReason: reason,
      rejectedAt: new Date(),
      dispatchGateSnapshot: { ...snapshot, dbError: msg } as unknown as Record<string, unknown>,
    }).where(eq(arxLiveCommandsTable.commandId, args.commandId)).returning();
    await audit({
      eventType: "LIVE_DISPATCH_BLOCKED", severity: "HIGH",
      userId: args.userId, symbol: row.symbol,
      message: `Live dispatch BLOCKED at DB writeback: ${reason}`,
      metadata: { commandId: args.commandId, dbError: msg },
    });
    return { ok: false as const, reason, command: blocked, gate: phaseBGate };
  }
}

/** Phase B — EA picks up the next SENT_TO_MT5_LIVE command for this bridge. */
export async function pickupNextLiveCommand(args: {
  userId: number;
  bridgeConnectionId: number;
  bridgeAccountType: string | null;
}): Promise<{ command: ArxLiveCommand | null; refusalReason: string | null }> {
  // Re-validate accountType=LIVE at pickup.
  const acct = (args.bridgeAccountType ?? "").toLowerCase();
  if (acct !== "live" && acct !== "real") {
    return { command: null, refusalReason: "BRIDGE_NOT_LIVE_ACCOUNT" };
  }

  // Atomic single-consumer claim. We RETURNING the row that was
  // transitioned in a single SQL update so two concurrent polls (or a
  // replayed poll) cannot both receive the same command. The claim
  // requires `pickedByEaAt IS NULL` so a previously-served command is
  // never re-served.
  //
  // We select the candidate commandId first (oldest unpicked
  // SENT_TO_MT5_LIVE for this user), then CAS-update it with both the
  // status and the NULL pickedByEaAt guard. The update returns 0 rows
  // if another poll won the race — we then return "no command" so the
  // EA simply tries again next poll.
  // Bridge-binding invariant: a command dispatched and stamped with
  // bridgeConnectionId=B may ONLY be picked up by bridge B. Any other
  // live bridge for the same user polling /live-commands-poll receives
  // "no command" — never another bridge's payload. This closes the
  // cross-bridge account-mix-up risk where user U has two live MT5
  // bridges (e.g. two terminals on the same login) and the wrong one
  // races to claim the command.
  const candidates = await db.select({ commandId: arxLiveCommandsTable.commandId })
    .from(arxLiveCommandsTable)
    .where(and(
      eq(arxLiveCommandsTable.userId, args.userId),
      eq(arxLiveCommandsTable.status, "SENT_TO_MT5_LIVE"),
      isNull(arxLiveCommandsTable.pickedByEaAt),
      eq(arxLiveCommandsTable.bridgeConnectionId, args.bridgeConnectionId),
    ))
    .orderBy(arxLiveCommandsTable.id)
    .limit(1);
  const cand = candidates[0];
  if (!cand) return { command: null, refusalReason: null };

  // Atomic CAS claim — re-asserts the same bridge binding so a concurrent
  // poll from a different bridge cannot win the race. We do NOT rewrite
  // bridgeConnectionId on claim (would defeat the binding); we only stamp
  // pickedByEaAt to mark the row as served exactly once.
  const claimed = await db.update(arxLiveCommandsTable).set({
    pickedByEaAt: new Date(),
  }).where(and(
    eq(arxLiveCommandsTable.commandId, cand.commandId),
    eq(arxLiveCommandsTable.status, "SENT_TO_MT5_LIVE"),
    isNull(arxLiveCommandsTable.pickedByEaAt),
    eq(arxLiveCommandsTable.bridgeConnectionId, args.bridgeConnectionId),
  )).returning();
  const updated = claimed[0];
  if (!updated) return { command: null, refusalReason: null };
  const row = updated;

  logger.warn({
    [PHASE_B_LIVE_LOG_PREFIX]: true,
    event: "LIVE_COMMAND_PICKED_BY_EA",
    commandId: row.commandId, userId: args.userId,
    bridgeConnectionId: args.bridgeConnectionId,
  }, "Phase B live command picked up by EA");

  return { command: updated, refusalReason: null };
}

/** Phase B — EA posts result for a SENT_TO_MT5_LIVE command. */
export async function recordLiveCommandResult(args: {
  userId: number;
  commandId: string;
  outcome: "LIVE_FILLED" | "LIVE_REJECTED" | "LIVE_FAILED";
  reportingBridgeConnectionId: number;
  brokerTicket?: string | null;
  fillPrice?: number | null;
  executedVolume?: number | null;
  mt5Retcode?: number | null;
  brokerMessage?: string | null;
}): Promise<{ ok: boolean; command: ArxLiveCommand | null; reason?: string }> {
  const row = await loadOwned(args.userId, args.commandId);
  if (!row) return { ok: false, command: null, reason: "COMMAND_NOT_FOUND" };
  if (row.status !== "SENT_TO_MT5_LIVE") {
    return { ok: false, command: null, reason: "BAD_STATE" };
  }
  // Bridge-binding invariant: only the bridge that the command was
  // dispatched to (and that picked it up) may write its result. This
  // closes the cross-bridge result-spoof window where bridge X could
  // post FILLED for a command actually executed by bridge Y.
  if (row.bridgeConnectionId != null && row.bridgeConnectionId !== args.reportingBridgeConnectionId) {
    return { ok: false, command: null, reason: "BRIDGE_BINDING_MISMATCH" };
  }
  // Validate transition is legal.
  assertCanTransition(row.status as ArxLiveCommandStatus, args.outcome);

  const updates: Partial<typeof arxLiveCommandsTable.$inferInsert> = {
    status: args.outcome,
    brokerTicket: args.brokerTicket ?? null,
    fillPrice: args.fillPrice ?? null,
    executedVolume: args.executedVolume ?? null,
    mt5Retcode: args.mt5Retcode ?? null,
    brokerMessage: args.brokerMessage ?? null,
  };
  if (args.outcome === "LIVE_FILLED") updates.filledAt = new Date();
  else updates.rejectedAt = new Date();

  const [updated] = await db.update(arxLiveCommandsTable).set(updates)
    .where(eq(arxLiveCommandsTable.commandId, args.commandId)).returning();

  // Settle the master-exposure reservation taken at dispatch time.
  // LIVE_FILLED → FULFILLED (lots remain attributed via shared_trade_attribution).
  // LIVE_REJECTED / LIVE_FAILED → RELEASED (lots return to the pool).
  // Both helpers act only on rows still in RESERVED, so duplicate EA
  // callbacks are idempotent.
  try {
    const { fulfillReservationByCommandId, releaseReservationByCommandId } =
      await import("../concurrency/exposureReservation.js");
    if (args.outcome === "LIVE_FILLED") {
      await fulfillReservationByCommandId(args.commandId);
    } else {
      await releaseReservationByCommandId(args.commandId);
    }
  } catch (e) {
    logger.error({
      [PHASE_B_LIVE_LOG_PREFIX]: true,
      event: "RESERVATION_SETTLEMENT_FAILED",
      commandId: args.commandId, outcome: args.outcome,
      error: e instanceof Error ? e.message : String(e),
    }, "failed to settle exposure reservation — manual reconciliation required");
  }

  await audit({
    eventType: `LIVE_RESULT_${args.outcome}`,
    severity: args.outcome === "LIVE_FILLED" ? "CRITICAL" : "HIGH",
    userId: args.userId, symbol: row.symbol,
    message: `Live result ${args.outcome}: ticket=${args.brokerTicket ?? "?"} retcode=${args.mt5Retcode ?? "?"}`,
    metadata: { commandId: args.commandId, brokerTicket: args.brokerTicket, mt5Retcode: args.mt5Retcode, brokerMessage: args.brokerMessage },
  });
  logger.warn({
    [PHASE_B_LIVE_LOG_PREFIX]: true,
    event: `LIVE_RESULT_${args.outcome}`,
    commandId: args.commandId, userId: args.userId,
    brokerTicket: args.brokerTicket, mt5Retcode: args.mt5Retcode,
  }, "Phase B live result recorded");
  return { ok: true, command: updated };
}

export async function cancelLiveCommand(args: { userId: number; commandId: string; reason: string }) {
  const row = await loadOwned(args.userId, args.commandId);
  if (!row) return { ok: false as const, reason: "COMMAND_NOT_FOUND" as const };
  if (!ALLOWED_TRANSITIONS[row.status as ArxLiveCommandStatus].includes("LIVE_CANCELLED")) {
    return { ok: false as const, reason: "BAD_STATE" as const, currentStatus: row.status };
  }
  const [updated] = await db.update(arxLiveCommandsTable).set({
    status: "LIVE_CANCELLED",
    rejectionReason: args.reason,
    rejectedAt: new Date(),
  }).where(eq(arxLiveCommandsTable.commandId, args.commandId)).returning();
  // Release any reservation tied to this command (no-op if absent).
  try {
    const { releaseReservationByCommandId } =
      await import("../concurrency/exposureReservation.js");
    await releaseReservationByCommandId(args.commandId);
  } catch { /* audit-only failure */ }
  await audit({ eventType: "LIVE_CANCELLED", userId: args.userId, symbol: row.symbol, message: args.reason });
  return { ok: true as const, command: updated };
}

async function loadOwned(userId: number, commandId: string) {
  const rows = await db.select().from(arxLiveCommandsTable)
    .where(and(eq(arxLiveCommandsTable.commandId, commandId), eq(arxLiveCommandsTable.userId, userId)))
    .limit(1);
  return rows[0] ?? null;
}

export async function listMyLiveCommands(args: { userId: number; limit?: number }) {
  const limit = Math.min(Math.max(args.limit ?? 50, 1), 200);
  return db.select().from(arxLiveCommandsTable)
    .where(eq(arxLiveCommandsTable.userId, args.userId))
    .orderBy(desc(arxLiveCommandsTable.id))
    .limit(limit);
}

export async function getMyLiveCommand(userId: number, commandId: string) {
  return loadOwned(userId, commandId);
}

export async function getOrCreateUserSettings(userId: number) {
  const rows = await db.select().from(arxLiveUserSettingsTable)
    .where(eq(arxLiveUserSettingsTable.userId, userId)).limit(1);
  if (rows[0]) return rows[0];
  const [created] = await db.insert(arxLiveUserSettingsTable).values({
    userId,
    weeklyDrawdownCeilingPct: ARX_LIVE_HARD_WEEKLY_DRAWDOWN_PCT,
    maxLotPerMarket: ARX_LIVE_DEFAULT_MAX_LOT_PER_MARKET as unknown as Record<string, number>,
    allowedSymbols: ARX_LIVE_DEFAULT_ALLOWED_SYMBOLS as unknown as string[],
  }).returning();
  return created;
}

export async function updateUserSettings(args: {
  userId: number;
  weeklyDrawdownCeilingPct?: number;
  dailyLossLimitUsd?: number;
  maxLotPerMarket?: Record<string, number>;
  allowedSymbols?: string[];
  requireStopLoss?: boolean;
}) {
  await getOrCreateUserSettings(args.userId);
  const updates: Record<string, unknown> = { updatedAt: new Date() };

  if (args.weeklyDrawdownCeilingPct != null) {
    // Server hard cap: never above 10%.
    updates.weeklyDrawdownCeilingPct = Math.min(args.weeklyDrawdownCeilingPct, ARX_LIVE_HARD_WEEKLY_DRAWDOWN_PCT);
  }
  if (args.dailyLossLimitUsd != null) updates.dailyLossLimitUsd = Math.max(0, args.dailyLossLimitUsd);
  if (args.maxLotPerMarket) {
    // Cap each per-market value at its default ceiling.
    const sanitized: Record<string, number> = {};
    for (const [sym, lot] of Object.entries(args.maxLotPerMarket)) {
      const cap = ARX_LIVE_DEFAULT_MAX_LOT_PER_MARKET[sym] ?? 0.1;
      sanitized[sym] = Math.max(0, Math.min(Number(lot), cap));
    }
    updates.maxLotPerMarket = sanitized;
  }
  if (args.allowedSymbols) {
    updates.allowedSymbols = args.allowedSymbols.filter((s) => ARX_LIVE_DEFAULT_ALLOWED_SYMBOLS.includes(s));
  }
  if (args.requireStopLoss !== undefined) updates.requireStopLoss = args.requireStopLoss;

  await db.update(arxLiveUserSettingsTable).set(updates)
    .where(eq(arxLiveUserSettingsTable.userId, args.userId));
  return getOrCreateUserSettings(args.userId);
}
