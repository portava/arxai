// Build NN — security events + access logs (append-only).

import { db, securityEventsTable, securityAccessLogsTable } from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { scrub, scrubString } from "./redact.js";

export interface SecurityEventInput {
  eventType: string;
  severity: "INFO" | "WARNING" | "HIGH" | "CRITICAL";
  status: "ALLOWED" | "DENIED" | "ATTEMPTED" | "TRIGGERED";
  actorRole?: string | null;
  actorUserId?: number | null;
  permissionKey?: string | null;
  route?: string | null;
  method?: string | null;
  ipAddress?: string | null;
  userAgent?: string | null;
  message?: string;
  metadata?: Record<string, unknown>;
}

export async function recordSecurityEvent(input: SecurityEventInput): Promise<{ securityEventId: string; id: number }> {
  const securityEventId = `secevt_${randomUUID()}`;
  const [row] = await db.insert(securityEventsTable).values({
    securityEventId,
    eventType: input.eventType,
    severity: input.severity,
    status: input.status,
    actorUserId: input.actorUserId ?? null,
    actorRole: input.actorRole ?? null,
    permissionKey: input.permissionKey ?? null,
    route: input.route ?? null,
    method: input.method ?? null,
    ipAddress: input.ipAddress ?? null,
    userAgent: input.userAgent ? scrubString(input.userAgent).slice(0, 500) : null,
    message: input.message ?? null,
    metadata: scrub(input.metadata ?? {}),
  }).returning();
  return { securityEventId, id: row.id };
}

export interface AccessLogInput {
  requestId?: string | null;
  role?: string | null;
  userId?: number | null;
  route: string;
  method: string;
  statusCode?: number | null;
  permissionRequired?: string | null;
  allowed: boolean;
  reason?: string | null;
  metadata?: Record<string, unknown>;
}

export async function recordAccessLog(input: AccessLogInput): Promise<void> {
  await db.insert(securityAccessLogsTable).values({
    requestId: input.requestId ?? null,
    userId: input.userId ?? null,
    role: input.role ?? null,
    route: input.route,
    method: input.method,
    statusCode: input.statusCode ?? null,
    permissionRequired: input.permissionRequired ?? null,
    allowed: input.allowed,
    reason: input.reason ?? null,
    metadata: scrub(input.metadata ?? {}),
  });
}

export async function listEvents(limit = 50, eventType?: string) {
  const max = Math.min(Math.max(limit, 1), 500);
  if (eventType) {
    return db.select().from(securityEventsTable).where(eq(securityEventsTable.eventType, eventType))
      .orderBy(desc(securityEventsTable.createdAt)).limit(max);
  }
  return db.select().from(securityEventsTable).orderBy(desc(securityEventsTable.createdAt)).limit(max);
}

export async function listAccessLogs(limit = 50) {
  const max = Math.min(Math.max(limit, 1), 500);
  return db.select().from(securityAccessLogsTable).orderBy(desc(securityAccessLogsTable.createdAt)).limit(max);
}

// Detect repeated denied requests by role+route within the last N records.
export async function repeatedDeniedCount(role: string, route: string, lookback = 50): Promise<number> {
  const recent = await db.select().from(securityAccessLogsTable)
    .orderBy(desc(securityAccessLogsTable.createdAt)).limit(lookback);
  return recent.filter((r) => !r.allowed && r.role === role && r.route === route).length;
}
