// MarketNewsIntelligenceService — fuses existing news provider + economic
// calendar + news risk scorer into a single normalized pack for the scanner,
// Ruby, and the trade-ticket news-risk panel.
//
// SAFETY:
//   - Pure read-side. Never places trades, never writes to live tables.
//   - Real providers only. If a feed is unavailable, fields are marked
//     unavailable — we never fabricate headlines or events.
//   - 60s in-memory cache per symbol to respect provider rate limits.

import { getMarketProvider } from "../assistant/marketProvider.js";
import type { NewsItem } from "../assistant/marketProvider.js";
import { getMockEvents, type EconomicEvent } from "./calendar/economicEvents.js";
import { scoreNewsRisk, type NewsRisk } from "./calendar/newsRiskScorer.js";

export type NewsRiskLevel = "none" | "low" | "medium" | "high" | "critical";
export type NewsBias = "bullish" | "bearish" | "mixed" | "unclear";

export interface NewsHeadline {
  headline: string;
  source: string;
  url: string | null;
  publishedAt: string;
}

export interface UpcomingEventSummary {
  title: string;
  currency: string;
  impact: "low" | "medium" | "high";
  eventTimeIso: string;
  minutesUntil: number;
}

export interface NewsIntelligencePack {
  symbol: string;
  generatedAt: string;
  riskLevel: NewsRiskLevel;
  bias: NewsBias;
  timing: "now" | "upcoming" | "recent" | "quiet";
  warningSummary: string;
  recommendation: "watch" | "wait" | "avoid" | "proceed_with_caution";
  upcomingEvent: UpcomingEventSummary | null;
  recentHeadlines: NewsHeadline[];
  affectedCurrencies: string[];
  dataSources: {
    headlines: { connected: boolean; provider: string; count: number };
    calendar: { connected: boolean; provider: string; note: string };
    social: { connected: boolean; provider: string; note: string };
  };
  safetyNote: string;
}

const CACHE = new Map<string, { at: number; pack: NewsIntelligencePack }>();
const CACHE_TTL_MS = 60 * 1000;

const BULL_WORDS = ["surge", "rally", "soar", "jump", "beat", "rise", "gain", "strong", "bullish", "hawkish", "upside"];
const BEAR_WORDS = ["plunge", "fall", "drop", "miss", "weak", "bearish", "dovish", "decline", "slump", "tumble", "downside", "crash"];

function deriveBiasFromHeadlines(items: NewsHeadline[]): NewsBias {
  if (items.length === 0) return "unclear";
  let bull = 0, bear = 0;
  for (const h of items.slice(0, 8)) {
    const t = h.headline.toLowerCase();
    if (BULL_WORDS.some((w) => t.includes(w))) bull++;
    if (BEAR_WORDS.some((w) => t.includes(w))) bear++;
  }
  if (bull === 0 && bear === 0) return "unclear";
  if (bull > 0 && bear === 0) return "bullish";
  if (bear > 0 && bull === 0) return "bearish";
  return "mixed";
}

function mapRiskLevel(r: NewsRisk): NewsRiskLevel {
  if (r.blockTrading) return "critical";
  return r.riskLevel;
}

function deriveTiming(r: NewsRisk): NewsIntelligencePack["timing"] {
  if (r.minutesUntilEvent == null) return "quiet";
  const m = r.minutesUntilEvent;
  if (m >= -15 && m <= 15) return "now";
  if (m < -15) return "recent";
  return "upcoming";
}

function deriveRecommendation(
  risk: NewsRiskLevel,
  timing: NewsIntelligencePack["timing"],
): NewsIntelligencePack["recommendation"] {
  if (risk === "critical") return "avoid";
  if (risk === "high" && timing === "now") return "wait";
  if (risk === "high") return "watch";
  if (risk === "medium") return "proceed_with_caution";
  return "watch";
}

function summarizeWarning(
  symbol: string,
  riskLevel: NewsRiskLevel,
  upcoming: UpcomingEventSummary | null,
  bias: NewsBias,
): string {
  if (riskLevel === "critical" && upcoming) {
    return `${upcoming.impact.toUpperCase()}-impact ${upcoming.title} window active for ${symbol}. Wait for the dust to settle.`;
  }
  if (upcoming && riskLevel !== "none") {
    const when = upcoming.minutesUntil >= 0
      ? `in ${upcoming.minutesUntil}m`
      : `${Math.abs(upcoming.minutesUntil)}m ago`;
    return `${upcoming.title} (${upcoming.currency}) ${when} — ${riskLevel} news risk on ${symbol}. Bias from headlines: ${bias}.`;
  }
  if (riskLevel === "none") {
    return `No major scheduled news for ${symbol} in the current window.`;
  }
  return `${riskLevel.toUpperCase()} news risk on ${symbol}. Headline bias: ${bias}.`;
}

function summarizeUpcoming(e: EconomicEvent, minutesUntil: number): UpcomingEventSummary {
  return {
    title: e.title,
    currency: e.currency,
    impact: e.impact,
    eventTimeIso: e.eventTime,
    minutesUntil,
  };
}

export async function getNewsIntelligence(
  symbolRaw: string,
): Promise<NewsIntelligencePack> {
  const symbol = symbolRaw.trim().toUpperCase();
  const cached = CACHE.get(symbol);
  if (cached && Date.now() - cached.at < CACHE_TTL_MS) {
    return cached.pack;
  }

  const provider = getMarketProvider();
  let headlineFetch: { connected: boolean; items: NewsItem[]; provider: string };
  try {
    headlineFetch = await provider.getMarketNews(symbol, 8);
  } catch {
    headlineFetch = { connected: false, items: [], provider: "error" };
  }

  // Honest-data invariant: if the provider reports disconnected, never
  // surface its payload — emit empty headlines and count=0 regardless of
  // what bytes came back. Prevents stale/synthetic items leaking through.
  const recentHeadlines: NewsHeadline[] = headlineFetch.connected
    ? headlineFetch.items.map((i) => ({
        headline: i.headline,
        source: i.source,
        url: i.url || null,
        publishedAt: i.publishedAt,
      }))
    : [];

  // Economic calendar: today's mockNewsProvider is the only source wired —
  // tag it honestly so users see it's not yet a live calendar feed.
  const calendarEvents = getMockEvents(2);
  const newsRisk = scoreNewsRisk(symbol, calendarEvents);

  const upcoming = newsRisk.upcomingEvent && newsRisk.minutesUntilEvent != null
    ? summarizeUpcoming(newsRisk.upcomingEvent, newsRisk.minutesUntilEvent)
    : null;

  const riskLevel = mapRiskLevel(newsRisk);
  const timing = deriveTiming(newsRisk);
  const bias = deriveBiasFromHeadlines(recentHeadlines);
  const recommendation = deriveRecommendation(riskLevel, timing);
  const warningSummary = summarizeWarning(symbol, riskLevel, upcoming, bias);

  const pack: NewsIntelligencePack = {
    symbol,
    generatedAt: new Date().toISOString(),
    riskLevel,
    bias,
    timing,
    warningSummary,
    recommendation,
    upcomingEvent: upcoming,
    recentHeadlines,
    affectedCurrencies: newsRisk.affectedSymbols,
    dataSources: {
      headlines: {
        connected: headlineFetch.connected,
        provider: headlineFetch.provider,
        count: recentHeadlines.length,
      },
      calendar: {
        connected: false,
        provider: "mock_economic_calendar",
        note: "Economic calendar is a built-in event schedule. Live provider (Trading Economics / FRED) not configured.",
      },
      social: {
        connected: false,
        provider: "none",
        note: "Social/X feed monitoring is not configured. Configure X API to enable.",
      },
    },
    safetyNote:
      "Decision support only. Do not invent headlines or events beyond what is listed here. If a feed is marked unavailable, say so honestly.",
  };

  CACHE.set(symbol, { at: Date.now(), pack });
  return pack;
}
