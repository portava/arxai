// Global per-user auth gate.
//
// PHASE-1 SAFETY NET: Until every route is individually wrapped in
// `requireUser` (Phase 3 of the per-user isolation refactor), this middleware
// 401s any /api/* request that does not have an authenticated user, EXCEPT
// for an explicit allowlist of paths that must remain public:
//
//   - health checks
//   - the auth router (register/login/logout/session)
//   - MT5 bridge endpoints (which have their own X-MT5-Bridge-Token guard
//     and stay fail-closed when the token env is unset)
//   - app version + release info (used by the splash page before login)
//
// Once Phase 3 lands `requireUser` + per-user `where(userId = ...)` on every
// route, this gate becomes belt-and-braces. It is intentionally written as
// an allowlist (deny-by-default) so a forgotten route fails closed.
//
// IMPORTANT: this gate does NOT replace per-user query scoping. A logged-in
// User A can still see User B's data on routes that do not yet filter by
// req.authUser.id. That is Phase 3 work.

import type { Request, Response, NextFunction } from "express";

// Paths are matched relative to the /api mount point (i.e. req.path here is
// "/trades", not "/api/trades", because this middleware runs inside the /api
// router). Use exact matches and prefix matches.
const PUBLIC_EXACT = new Set<string>([
  "/healthz",
  "/health",
  "/version",
  // MT5 bridge endpoints — gated by X-MT5-Bridge-Token, fail-closed when
  // MT5_BRIDGE_TOKEN env is unset.
  "/mt5/heartbeat",
  "/mt5/commands",
  "/mt5/command-result",
  "/mt5/sync-account",
  "/mt5/sync-positions",
  "/mt5/sync-positions-per-user",
  // Phase 28-MT5-DEMO-ARMING sub-phase 3B: EA-side demo dispatch endpoints.
  // Both are gated by bridgeAuthPerUserOnly inside the route handler — the
  // global gate must let them through so the per-user token check can run.
  "/mt5/demo-commands-poll",
  "/mt5/demo-command-result",
  "/mt5/execution-result",
  // Phase B EA-side LIVE endpoints. Same contract as the demo endpoints:
  // they're gated by `bridgeAuthPerUserOnly` inside the route handler so the
  // global session gate must allow them through (the EA has no session
  // cookie). Without these entries the EA receives HTTP 401 AUTH_REQUIRED
  // on /live-commands-poll even when the per-user bridge token is valid —
  // the bridge auth middleware never runs because the global gate already
  // rejected the request. Token verification, accountType=live/real check,
  // mock-bridge refusal, and the full 16-gate Phase B dispatch pipeline
  // still apply on every request.
  "/mt5/live-commands-poll",
  "/mt5/live-command-result",
  "/mt5/sync-live-positions",
]);

const PUBLIC_PREFIXES: readonly string[] = [
  "/health/",       // any nested health check
  "/auth/",         // register, login, logout, user-logout, session (role layer)
  "/auth",          // bare /auth for safety
  "/release/",      // release info shown pre-login
  "/release",
];

function isPublic(pathname: string): boolean {
  if (PUBLIC_EXACT.has(pathname)) return true;
  for (const prefix of PUBLIC_PREFIXES) {
    if (pathname === prefix || pathname.startsWith(prefix)) return true;
  }
  return false;
}

export function requireAuthOrPublic(req: Request, res: Response, next: NextFunction): void {
  // Allow CORS preflight unconditionally.
  if (req.method === "OPTIONS") {
    next();
    return;
  }
  if (req.authUser) {
    next();
    return;
  }
  // path is the request path WITHOUT the /api prefix (router-relative).
  const pathname = req.path || "/";
  if (isPublic(pathname)) {
    next();
    return;
  }
  res.status(401).json({ error: "AUTH_REQUIRED", message: "Sign in required." });
}
