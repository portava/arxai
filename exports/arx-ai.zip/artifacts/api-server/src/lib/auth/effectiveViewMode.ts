// Effective view-mode middleware.
//
// When an admin-capable user has toggled into "user" view-mode on the
// frontend, every outbound fetch carries `X-Arx-View-Mode: user`. This
// middleware reads that header AFTER `attachAuthUser` has populated
// `req.authUser`, and — when the real role is ADMIN/OWNER — downgrades
// the request's effective role to "USER" for the remainder of the
// request lifecycle.
//
// Effect: every existing `requireAdmin` / role check in the route layer
// naturally returns 403 without needing per-route changes. The real
// session and DB role are NOT mutated; only the per-request mirror on
// `req.authUser` is downgraded.
//
// SAFETY:
// - Only admins (ADMIN/OWNER) can be downgraded. Sending the header on
//   a regular-user session is a no-op (their role was never elevated).
// - The downgrade is per-request — the next request from the same
//   session re-evaluates from scratch.
// - This middleware does NOT change MT5, kill-switch, or live-trading
//   rules. It only narrows what the role-check layer sees.

import type { Request, Response, NextFunction } from "express";

export const VIEW_MODE_HEADER_LOWER = "x-arx-view-mode";

export function applyEffectiveViewMode(req: Request, _res: Response, next: NextFunction): void {
  try {
    const raw = req.headers[VIEW_MODE_HEADER_LOWER];
    const headerValue = Array.isArray(raw) ? raw[0] : raw;
    if (headerValue !== "user") return next();

    const r = req as Request & {
      authUser?: { role?: string; realRole?: string };
      userSession?: { user?: { role?: string; realRole?: string } };
      securityRole?: string;
      realSecurityRole?: string;
      viewModeDowngradedToUser?: boolean;
    };

    const u = r.authUser;
    if (!u) return next();
    const realRole = String(u.role ?? "").toUpperCase();
    if (realRole !== "ADMIN" && realRole !== "OWNER") return next();

    // Stash real role + flag so audit/logging contexts (and the identity
    // endpoint) can recover the real authority. Then downgrade every
    // role surface a route layer might consult so EVERY `requireAdmin`
    // check naturally returns 403 — no per-route patches needed.
    u.realRole = realRole;
    u.role = "USER";

    if (r.userSession?.user && typeof r.userSession.user.role === "string") {
      r.userSession.user.realRole = r.userSession.user.role;
      r.userSession.user.role = "USER";
    }

    if (typeof r.securityRole === "string") {
      r.realSecurityRole = r.securityRole;
      // The security layer's RoleKey enum doesn't include "USER"; "VIEWER"
      // is its lowest-privilege role and is what regular users resolve to.
      r.securityRole = "VIEWER";
    }

    r.viewModeDowngradedToUser = true;
  } catch {
    /* never throw from middleware — fall through on any malformed input */
  }
  next();
}
