// Market Scanner + Opportunity Scorer + Session Plan + Decision Stream.
//
// SAFETY: Pure read-side intelligence over the in-memory market simulator.
// Never calls placeLiveOrderGuarded(). Never writes to live_positions or
// mt5_commands. Every output is tagged dataSource="SIMULATOR".

import { analyzeMarket, type MarketAnalysis } from "./aiBrain.js";
import { marketSimulator } from "./marketSimulator.js";
import { DERIV_SYNTHETIC_SYMBOLS, getDerivFeedStatus } from "./data/providers/derivProvider.js";

export const DEFAULT_SYMBOLS = [
  "EURUSD", "GBPUSD", "USDJPY", "XAUUSD",
  "BTCUSDT", "ETHUSDT", "AAPL", "TSLA",
] as const;
export const DEFAULT_TIMEFRAMES = ["M1", "M5", "M15", "H1", "H4"] as const;

// Scanner universes. Each universe is a strict whitelist — the scanner will
// ONLY analyze symbols belonging to the selected universe. "synthetic" now
// holds the Deriv synthetic-index labels; the scanner branches to the
// DerivFeedAdapter for these and NEVER falls back to the in-memory
// simulator for synthetic/volatility markets (no fabricated candles).
const SYNTHETIC_LABELS = DERIV_SYNTHETIC_SYMBOLS.map((s) => s.symbol);
export const UNIVERSES = {
  all:       ["EURUSD", "GBPUSD", "USDJPY", "XAUUSD", "BTCUSDT", "ETHUSDT", "AAPL", "TSLA"],
  forex:     ["EURUSD", "GBPUSD", "USDJPY"],
  metals:    ["XAUUSD"],
  crypto:    ["BTCUSDT", "ETHUSDT"],
  stocks:    ["AAPL", "TSLA"],
  synthetic: SYNTHETIC_LABELS,
} as const;
export type UniverseId = keyof typeof UNIVERSES;
export const UNIVERSE_IDS: UniverseId[] = ["all", "forex", "metals", "crypto", "stocks", "synthetic"];

export function symbolsForUniverse(u: UniverseId): string[] {
  return [...UNIVERSES[u]];
}

export type StatusBadge =
  | "HOT_SETUP" | "WATCHLIST" | "WAIT_FOR_CONFIRMATION"
  | "REJECTED_BY_RISK" | "CHOPPY_MARKET" | "LOW_CONFIDENCE"
  | "SPREAD_TOO_HIGH" | "PENDING_MT5_CONNECTION";

export type OpportunityLabel = "ELITE" | "STRONG" | "ACCEPTABLE" | "WEAK" | "REJECT";

export interface OpportunityScore {
  score: number;
  label: OpportunityLabel;
  factors: {
    trendAlignment: number;
    supportResistanceQuality: number;
    entryTiming: number;
    riskRewardQuality: number;
    volatilityCondition: number;
    spreadCondition: number;
    strategyMatch: number;
    aiConfidenceCalibration: number;
  };
}

function clamp(n: number, lo: number, hi: number) {
  if (!Number.isFinite(n)) return lo;
  return Math.max(lo, Math.min(hi, n));
}

export function opportunityScore(a: MarketAnalysis, strategyMatch = 7): OpportunityScore {
  const trend = clamp(Math.round((a.trendStrength / 100) * 15), 0, 15);
  const sr = clamp(Math.round((a.entryQualityScore / 100) * 15), 0, 15);
  const timing = clamp(Math.round((a.entryQualityScore / 100) * 15), 0, 15);
  const rr = clamp(Math.round(Math.min(a.riskRewardRatio / 3, 1) * 15), 0, 15);
  const vol = a.marketBias === "choppy" ? 2 : 8;
  const spread = clamp(10 - Math.round((a.riskScore / 100) * 10), 0, 10);
  const stratMatch = clamp(Math.round(strategyMatch), 0, 10);
  const calib = clamp(Math.round((a.confidenceScore / 100) * 10), 0, 10);
  const score = trend + sr + timing + rr + vol + spread + stratMatch + calib;
  let label: OpportunityLabel;
  if (score >= 90) label = "ELITE";
  else if (score >= 80) label = "STRONG";
  else if (score >= 70) label = "ACCEPTABLE";
  else if (score >= 60) label = "WEAK";
  else label = "REJECT";
  return {
    score, label,
    factors: {
      trendAlignment: trend, supportResistanceQuality: sr, entryTiming: timing,
      riskRewardQuality: rr, volatilityCondition: vol, spreadCondition: spread,
      strategyMatch: stratMatch, aiConfidenceCalibration: calib,
    },
  };
}

export interface ScannerHistoricalContext {
  available: boolean;
  bias: "BULLISH" | "BEARISH" | "MIXED" | "INSUFFICIENT_DATA";
  confidence: "LOW" | "MEDIUM" | "HIGH";
  sampleSize: number;
  winRate: number | null;
  avgMovePct: number | null;
  worstDrawdownPct: number | null;
  alignsWithScanner: boolean | null;
  note: string;
}

export interface ScannerOpportunity {
  symbol: string; timeframe: string;
  bias: MarketAnalysis["marketBias"];
  recommendedAction: MarketAnalysis["recommendedAction"];
  setupType: string;
  confidenceScore: number;
  riskScore: number;
  entrySniperScore: number;
  riskRewardRatio: number;
  reasonForTrade: string;
  reasonToAvoid: string;
  rulesPassed: string[];
  rulesFailed: string[];
  statusBadge: StatusBadge;
  opportunity: OpportunityScore;
  entry: number; stopLoss: number; takeProfit: number;
  generatedAt: string;
  dataSource: "SIMULATOR";
  historicalContext?: ScannerHistoricalContext;
  newsContext?: ScannerNewsContext;
  finalRead?: ScannerFinalRead;
}

// Phase News-Decision — fused decision read across technical + news + history.
// Honest by design: when news/history are unavailable, the read reflects that
// uncertainty rather than faking certainty.
export type FinalReadLabel =
  | "TRADE_WATCH"
  | "WAIT_FOR_CONFIRMATION"
  | "AVOID_FOR_NOW"
  | "NO_TRADE";

export interface ScannerFinalRead {
  label: FinalReadLabel;
  headline: string;
  reasons: string[];
  technicalScore: number;
  historicalScore: number | null;
  newsRiskLevel: "none" | "low" | "medium" | "high" | "critical";
  conflict: boolean;
  confidence: "LOW" | "MEDIUM" | "HIGH";
}

export function computeFinalRead(
  opp: ScannerOpportunity,
): ScannerFinalRead {
  const techScore = opp.confidenceScore;
  const hist = opp.historicalContext ?? null;
  const news = opp.newsContext ?? null;
  const reasons: string[] = [];
  const histScore = hist && hist.available && hist.winRate != null ? hist.winRate : null;
  const newsLevel = news?.riskLevel ?? "none";
  const newsAvail = !!news;
  const histAvail = !!hist?.available;

  // Conflict = scanner direction opposes either news bias or historical bias.
  const conflict =
    (hist?.alignsWithScanner === false) ||
    (news?.alignsWithScanner === false);

  // Start with WAIT for any non-actionable technical signal.
  let label: FinalReadLabel = "TRADE_WATCH";

  // 1. Critical news / event-risk window → AVOID or NO_TRADE.
  if (newsLevel === "critical") {
    label = "NO_TRADE";
    reasons.push("Major event nearby. Volatility may spike.");
  } else if (newsLevel === "high") {
    label = news?.timing === "now" ? "AVOID_FOR_NOW" : "WAIT_FOR_CONFIRMATION";
    reasons.push("News risk is high. Waiting may be safer.");
  } else if (newsLevel === "medium") {
    label = "WAIT_FOR_CONFIRMATION";
    reasons.push("News risk is elevated. Confirm before acting.");
  }

  // 2. Conflict between technical and news/history → downgrade.
  if (conflict) {
    if (label === "TRADE_WATCH") label = "WAIT_FOR_CONFIRMATION";
    if (label === "WAIT_FOR_CONFIRMATION" && newsLevel !== "none") label = "AVOID_FOR_NOW";
    reasons.push("Technicals and news/history are conflicting.");
  }

  // 3. Weak technical signal → no trade regardless of news.
  if (opp.statusBadge === "REJECTED_BY_RISK" || opp.statusBadge === "CHOPPY_MARKET") {
    label = "NO_TRADE";
    reasons.push("No clean trade right now — setup rejected by risk rules.");
  } else if (opp.statusBadge === "LOW_CONFIDENCE" && label === "TRADE_WATCH") {
    label = "WAIT_FOR_CONFIRMATION";
    reasons.push("Technical confidence is low.");
  } else if (opp.statusBadge === "WAIT_FOR_CONFIRMATION" && label === "TRADE_WATCH") {
    label = "WAIT_FOR_CONFIRMATION";
    reasons.push("Technical setup wants confirmation.");
  }

  // 4. Honest uncertainty when feeds are missing.
  let confidence: "LOW" | "MEDIUM" | "HIGH";
  if (!newsAvail && !histAvail) {
    confidence = "LOW";
    reasons.push("News and history feeds are unavailable — read is technicals-only.");
  } else if (!newsAvail || !histAvail) {
    confidence = "MEDIUM";
  } else {
    confidence = techScore >= 75 && newsLevel === "none" && !conflict ? "HIGH" : "MEDIUM";
  }

  if (reasons.length === 0) {
    reasons.push("Technicals clean and no major news catalyst.");
  }

  const headline =
    label === "NO_TRADE" ? "No trade right now." :
    label === "AVOID_FOR_NOW" ? "Avoid for now." :
    label === "WAIT_FOR_CONFIRMATION" ? "Wait for confirmation." :
    "Watchlist candidate.";

  return {
    label,
    headline,
    reasons,
    technicalScore: techScore,
    historicalScore: histScore,
    newsRiskLevel: newsLevel,
    conflict,
    confidence,
  };
}

export function decorateOpportunitiesWithFinalRead(
  opps: ScannerOpportunity[],
): ScannerOpportunity[] {
  return opps.map((o) => ({ ...o, finalRead: computeFinalRead(o) }));
}

export interface ScannerNewsContext {
  riskLevel: "none" | "low" | "medium" | "high" | "critical";
  bias: "bullish" | "bearish" | "mixed" | "unclear";
  timing: "now" | "upcoming" | "recent" | "quiet";
  recommendation: "watch" | "wait" | "avoid" | "proceed_with_caution";
  headlineCount: number;
  headlinesConnected: boolean;
  upcomingEventTitle: string | null;
  minutesUntilEvent: number | null;
  warning: string;
  alignsWithScanner: boolean | null;
}

// Phase News — decorate scanner opportunities with news intelligence. Pure
// additive: existing fields untouched, decoration failures fall back to an
// explicit "unavailable" marker (never fabricated).
export async function decorateOpportunitiesWithNewsRisk(
  opps: ScannerOpportunity[],
): Promise<ScannerOpportunity[]> {
  if (opps.length === 0) return opps;
  const { getNewsIntelligence } = await import("./news/newsIntelligenceService.js");
  const uniqueSymbols = Array.from(new Set(opps.map((o) => o.symbol)));
  const ctxBySymbol = new Map<string, ScannerNewsContext>();
  await Promise.all(
    uniqueSymbols.map(async (sym) => {
      try {
        const pack = await getNewsIntelligence(sym);
        const scannerDir = opps.find((o) => o.symbol === sym)?.recommendedAction;
        const wantsUp = scannerDir === "BUY";
        const wantsDown = scannerDir === "SELL";
        const aligns =
          pack.bias === "bullish" && wantsUp ? true :
          pack.bias === "bearish" && wantsDown ? true :
          pack.bias === "bullish" && wantsDown ? false :
          pack.bias === "bearish" && wantsUp ? false :
          null;
        ctxBySymbol.set(sym, {
          riskLevel: pack.riskLevel,
          bias: pack.bias,
          timing: pack.timing,
          recommendation: pack.recommendation,
          headlineCount: pack.dataSources.headlines.count,
          headlinesConnected: pack.dataSources.headlines.connected,
          upcomingEventTitle: pack.upcomingEvent?.title ?? null,
          minutesUntilEvent: pack.upcomingEvent?.minutesUntil ?? null,
          warning: pack.warningSummary,
          alignsWithScanner: aligns,
        });
      } catch {
        ctxBySymbol.set(sym, {
          riskLevel: "none",
          bias: "unclear",
          timing: "quiet",
          recommendation: "watch",
          headlineCount: 0,
          headlinesConnected: false,
          upcomingEventTitle: null,
          minutesUntilEvent: null,
          warning: "News intelligence temporarily unavailable.",
          alignsWithScanner: null,
        });
      }
    }),
  );
  return opps.map((o) => {
    const ctx = ctxBySymbol.get(o.symbol);
    return ctx ? { ...o, newsContext: ctx } : o;
  });
}

// Phase Historical — decorate scanner opportunities with same-time historical
// context. Pure additive: existing fields untouched, decoration failures fall
// back to an explicit "unavailable" marker (never fabricated).
export async function decorateOpportunitiesWithHistory(
  opps: ScannerOpportunity[],
): Promise<ScannerOpportunity[]> {
  if (opps.length === 0) return opps;
  const { getHistoricalAnalysis } = await import("./marketData/historicalAnalysis.js");
  const unique = new Map<string, { symbol: string; timeframe: string }>();
  for (const o of opps) {
    const key = `${o.symbol}|${o.timeframe}`;
    if (!unique.has(key)) unique.set(key, { symbol: o.symbol, timeframe: o.timeframe });
  }
  const results = new Map<string, ScannerHistoricalContext>();
  await Promise.all(
    Array.from(unique.entries()).map(async ([key, q]) => {
      try {
        const r = await getHistoricalAnalysis({ symbol: q.symbol, timeframe: q.timeframe });
        const scannerDir = opps.find((o) => `${o.symbol}|${o.timeframe}` === key)?.recommendedAction;
        const scannerWantsUp = scannerDir === "BUY";
        const scannerWantsDown = scannerDir === "SELL";
        const aligns =
          r.bias.label === "BULLISH" && scannerWantsUp ? true :
          r.bias.label === "BEARISH" && scannerWantsDown ? true :
          r.bias.label === "BULLISH" && scannerWantsDown ? false :
          r.bias.label === "BEARISH" && scannerWantsUp ? false :
          null;
        results.set(key, {
          available: r.bias.label !== "INSUFFICIENT_DATA",
          bias: r.bias.label,
          confidence: r.bias.confidence,
          sampleSize: r.setupSummary.sampleSize,
          winRate: r.setupSummary.winRate,
          avgMovePct: r.setupSummary.avgMovePct,
          worstDrawdownPct: r.setupSummary.worstDrawdownPct,
          alignsWithScanner: aligns,
          note: r.bias.explanation,
        });
      } catch {
        results.set(key, {
          available: false,
          bias: "INSUFFICIENT_DATA",
          confidence: "LOW",
          sampleSize: 0,
          winRate: null,
          avgMovePct: null,
          worstDrawdownPct: null,
          alignsWithScanner: null,
          note: "Historical data temporarily unavailable.",
        });
      }
    }),
  );
  return opps.map((o) => {
    const ctx = results.get(`${o.symbol}|${o.timeframe}`);
    return ctx ? { ...o, historicalContext: ctx } : o;
  });
}

function setupTypeFor(a: MarketAnalysis): string {
  if (a.marketBias === "choppy") return "Range / chop";
  if (a.marketBias === "neutral") return "Consolidation";
  return a.recommendedAction === "WAIT" ? "Pullback watch" : "Trend continuation";
}

function statusBadgeFor(a: MarketAnalysis, opp: OpportunityScore): StatusBadge {
  if (a.recommendedAction === "REJECT" || opp.label === "REJECT") {
    if (a.marketBias === "choppy") return "CHOPPY_MARKET";
    if (a.riskScore > 65) return "SPREAD_TOO_HIGH";
    return "REJECTED_BY_RISK";
  }
  if (a.confidenceScore < 50) return "LOW_CONFIDENCE";
  if (a.recommendedAction === "WAIT") return "WAIT_FOR_CONFIRMATION";
  if (opp.label === "ELITE" || opp.label === "STRONG") return "HOT_SETUP";
  return "WATCHLIST";
}

// ── Scanner state ──────────────────────────────────────────────────────────
interface ScannerState {
  running: boolean;
  universe: UniverseId;
  symbols: string[];
  timeframes: string[];
  intervalMs: number;
  lastScanAt: string | null;
  lastResults: ScannerOpportunity[];
  loop: NodeJS.Timeout | null;
}
const scannerState: ScannerState = {
  running: false,
  universe: "all",
  symbols: [...DEFAULT_SYMBOLS],
  timeframes: [...DEFAULT_TIMEFRAMES],
  intervalMs: 10_000,
  lastScanAt: null,
  lastResults: [],
  loop: null,
};

export function scannerStatus() {
  return {
    running: scannerState.running,
    universe: scannerState.universe,
    universeSymbols: scannerState.symbols,
    symbols: scannerState.symbols,
    timeframes: scannerState.timeframes,
    intervalMs: scannerState.intervalMs,
    lastScanAt: scannerState.lastScanAt,
    opportunityCount: scannerState.lastResults.length,
    dataSource: "SIMULATOR",
    feedNote: scannerState.universe === "synthetic"
      ? (() => {
          const ds = getDerivFeedStatus();
          if (!ds.configured) return "Deriv feed not configured. Add DERIV_APP_ID to enable synthetic index data.";
          if (!ds.connected) return "Deriv feed configured. Connecting…";
          return "Deriv feed connected — synthetic indices use real Deriv candles (no simulator fallback).";
        })()
      : "Simulator data active. No live broker connection.",
  };
}

interface ScanOpts {
  symbols?: string[];
  timeframes?: string[];
  universe?: UniverseId;
}

export function scanOnce(opts: ScanOpts = {}): ScannerOpportunity[] {
  // Universe wins if provided. Otherwise use explicit symbols, otherwise
  // current scanner state.
  if (opts.universe) {
    scannerState.universe = opts.universe;
    scannerState.symbols = symbolsForUniverse(opts.universe);
  } else if (opts.symbols?.length) {
    scannerState.symbols = opts.symbols;
  }
  const syms = scannerState.symbols;
  const tfs = opts.timeframes?.length ? opts.timeframes : scannerState.timeframes;
  const out: ScannerOpportunity[] = [];
  for (const sym of syms) {
    for (const tf of tfs) {
      try {
      const a = analyzeMarket(sym, tf);
      const opp = opportunityScore(a);
      const entry = (a.entryZone.low + a.entryZone.high) / 2;
      const op: ScannerOpportunity = {
        symbol: sym, timeframe: tf, bias: a.marketBias,
        recommendedAction: a.recommendedAction,
        setupType: setupTypeFor(a),
        confidenceScore: a.confidenceScore, riskScore: a.riskScore,
        entrySniperScore: a.entryQualityScore,
        riskRewardRatio: a.riskRewardRatio,
        reasonForTrade: a.reasonForTrade, reasonToAvoid: a.reasonToAvoid,
        rulesPassed: a.rulesPassed, rulesFailed: a.rulesFailed,
        statusBadge: statusBadgeFor(a, opp),
        opportunity: opp,
        entry, stopLoss: a.stopLoss, takeProfit: a.takeProfit,
        generatedAt: a.generatedAt,
        dataSource: "SIMULATOR",
      };
      out.push(op);
      } catch { /* skip bad symbol/tf, continue */ }
    }
  }
  out.sort((x, y) => y.opportunity.score - x.opportunity.score);
  scannerState.lastResults = out;
  scannerState.lastScanAt = new Date().toISOString();
  pushDecision({
    type: "SCAN_EVENT",
    summary: `Scanned [${scannerState.universe}] ${syms.length}×${tfs.length}=${out.length}; top ${out[0]?.symbol}/${out[0]?.timeframe} score ${out[0]?.opportunity.score}`,
    payload: { count: out.length, universe: scannerState.universe, top: out[0] ?? null },
  });
  // Surface a HOT_SETUP alert for elite finds (in-memory only).
  for (const o of out.slice(0, 3)) {
    if (o.statusBadge === "HOT_SETUP") {
      pushAlert({
        severity: "info", source: "SCANNER",
        symbol: o.symbol, timeframe: o.timeframe,
        message: `HOT setup ${o.symbol} ${o.timeframe}: ${o.recommendedAction} (score ${o.opportunity.score})`,
        reason: o.reasonForTrade,
        recommendedAction: `Send ${o.symbol} to AI assist or backtest before any live intent.`,
      });
    } else if (o.statusBadge === "REJECTED_BY_RISK" || o.statusBadge === "SPREAD_TOO_HIGH") {
      pushAlert({
        severity: "warning", source: "RISK",
        symbol: o.symbol, timeframe: o.timeframe,
        message: `${o.symbol} ${o.timeframe} rejected: ${o.statusBadge}`,
        reason: o.reasonToAvoid || "Risk filter triggered.",
        recommendedAction: "Skip this symbol for now.",
      });
    }
  }
  return out;
}

export function scannerStart(opts: { intervalMs?: number; universe?: UniverseId } = {}) {
  if (opts.intervalMs && opts.intervalMs >= 1000) scannerState.intervalMs = opts.intervalMs;
  if (opts.universe) {
    scannerState.universe = opts.universe;
    scannerState.symbols = symbolsForUniverse(opts.universe);
  }
  if (scannerState.running) return scannerStatus();
  scannerState.running = true;
  scannerState.loop = setInterval(() => {
    try { scanOnce(); } catch { /* swallow */ }
  }, scannerState.intervalMs);
  scannerState.loop.unref?.();
  scanOnce();
  pushDecision({ type: "SCANNER_STARTED", summary: `Scanner started @${scannerState.intervalMs}ms universe=${scannerState.universe}`, payload: { universe: scannerState.universe } });
  return scannerStatus();
}

export function scannerStop() {
  if (scannerState.loop) clearInterval(scannerState.loop);
  scannerState.loop = null; scannerState.running = false;
  pushDecision({ type: "SCANNER_STOPPED", summary: "Scanner stopped", payload: {} });
  return scannerStatus();
}

export function scannerOpportunities(limit = 50) {
  return scannerState.lastResults.slice(0, limit);
}

// ── Session plan ───────────────────────────────────────────────────────────
export function sessionPlan() {
  const results = scannerState.lastResults.length ? scannerState.lastResults : scanOnce();
  const bestSyms = Array.from(new Set(
    results.filter((o) => o.statusBadge === "HOT_SETUP").map((o) => o.symbol),
  )).slice(0, 3);
  const avoidSyms = Array.from(new Set(
    results.filter((o) => o.statusBadge === "CHOPPY_MARKET" || o.statusBadge === "REJECTED_BY_RISK")
      .map((o) => o.symbol),
  )).slice(0, 3);

  const trendCount = results.filter((o) => o.bias === "bullish" || o.bias === "bearish").length;
  const choppyCount = results.filter((o) => o.bias === "choppy").length;
  const preferredStrategy = trendCount > choppyCount * 2 ? "Trend Continuation"
    : choppyCount > trendCount ? "No Trade Filter (range conditions)"
    : "Pullback Confirmation";

  return {
    bestSymbols: bestSyms,
    symbolsToAvoid: avoidSyms,
    preferredStrategy,
    maxTrades: 3,
    maxRiskPerTradeUsd: 20,
    maxRiskPerSessionUsd: 60,
    marketConditions: trendCount > choppyCount ? "Trending across most pairs."
      : "Mixed regime — many pairs in chop.",
    rules: [
      "Reject any setup with confidence < 60.",
      "Reject any choppy bias.",
      "Require RR >= 1.5 before any intent.",
      "Stop after 2 consecutive losers.",
    ],
    warningZones: results.filter((o) => o.riskScore > 60).slice(0, 5)
      .map((o) => `${o.symbol} ${o.timeframe} risk ${o.riskScore}`),
    focusAreas: ["Patience", "Stop placement", "Wait for confirmation candle"],
    recommendedFirstTest: bestSyms[0]
      ? `Run a paper trade on ${bestSyms[0]} via Trade Command Room.`
      : "Run a market replay on EURUSD to warm up before any live intent.",
    summary: `Today's simulator session favors ${preferredStrategy.toLowerCase()} on ${bestSyms.join(", ") || "no clear leaders"}.`
      + (avoidSyms.length ? ` Avoid ${avoidSyms.join(", ")}.` : "")
      + ` Max ${3} trades. Reject any setup below 60 confidence.`,
    dataSource: "SIMULATOR",
    generatedAt: new Date().toISOString(),
  };
}

// ── Decision stream (in-memory ring buffer) ────────────────────────────────
type Decision = {
  id: string; type: string; summary: string;
  payload: unknown; createdAt: string;
};
const decisions: Decision[] = [];
const MAX_DECISIONS = 200;

export function pushDecision(d: { type: string; summary: string; payload: unknown }) {
  decisions.unshift({
    id: `dec_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    ...d, createdAt: new Date().toISOString(),
  });
  if (decisions.length > MAX_DECISIONS) decisions.length = MAX_DECISIONS;
}
export function decisionStream(limit = 50) {
  return decisions.slice(0, limit);
}

// ── Alert engine (in-memory; can be persisted via existing alerts table) ───
type Alert = {
  alertId: string;
  severity: "info" | "warning" | "critical";
  symbol?: string; timeframe?: string;
  message: string; reason: string;
  recommendedAction: string;
  source: "SCANNER" | "AI" | "RISK" | "SYSTEM";
  createdAt: string;
  acknowledgedAt?: string | null;
  dismissedAt?: string | null;
  snoozedUntil?: string | null;
};
const alerts: Alert[] = [];
const MAX_ALERTS = 200;

export function pushAlert(a: Omit<Alert, "alertId" | "createdAt" | "acknowledgedAt" | "dismissedAt" | "snoozedUntil">) {
  // Lightweight dedupe within last minute on same source+symbol+message.
  const recent = alerts.find((x) =>
    x.source === a.source && x.symbol === a.symbol && x.message === a.message
    && Date.now() - Date.parse(x.createdAt) < 60_000);
  if (recent) return recent;
  const item: Alert = {
    alertId: `alert_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    ...a, createdAt: new Date().toISOString(),
    acknowledgedAt: null, dismissedAt: null, snoozedUntil: null,
  };
  alerts.unshift(item);
  if (alerts.length > MAX_ALERTS) alerts.length = MAX_ALERTS;
  return item;
}

export function listAlerts(opts?: { unackedOnly?: boolean; limit?: number }) {
  const now = Date.now();
  const visible = alerts.filter((a) => {
    if (a.dismissedAt) return false;
    if (a.snoozedUntil && Date.parse(a.snoozedUntil) > now) return false;
    if (opts?.unackedOnly && a.acknowledgedAt) return false;
    return true;
  });
  return visible.slice(0, opts?.limit ?? 100);
}

export function alertAction(alertId: string, action: "acknowledge" | "dismiss" | "snooze", snoozeMs = 10 * 60 * 1000) {
  const a = alerts.find((x) => x.alertId === alertId);
  if (!a) return null;
  const now = new Date().toISOString();
  if (action === "acknowledge") a.acknowledgedAt = now;
  else if (action === "dismiss") a.dismissedAt = now;
  else if (action === "snooze") a.snoozedUntil = new Date(Date.now() + snoozeMs).toISOString();
  return a;
}

export function alertCount() {
  return listAlerts({ unackedOnly: true }).length;
}
