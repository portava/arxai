// parseTradeCommand.ts — Ruby AI text/voice command → InstantTradeIntent.
//
// Ruby is allowed to act on CLEAR, DIRECT trade commands only. The parser
// returns:
//   - { kind: "OPEN", … }          — direct buy/sell/open
//   - { kind: "CLOSE_ONE", … }     — "close my EURUSD trade"
//   - { kind: "CLOSE_ALL", … }     — "close all trades"
//   - { kind: "CLOSE_PROFITABLE" } — "close all winners"
//   - { kind: "CLOSE_LOSING" }     — "close all losers"
//   - { kind: "MODIFY", … }        — "set TP to 1.0920", "move SL to break even"
//   - { kind: "MISSING_VOLUME", … } — clear intent but no lot size and no default
//   - { kind: "MISSING_SYMBOL", … } — clear intent but no symbol and no default
//   - { kind: "VAGUE" }            — analysis question, NEVER execute
//   - { kind: "UNKNOWN" }
//
// SAFETY: this parser does NOT execute anything. It returns a typed
// classification that the assistant endpoint then routes — VAGUE
// classifications NEVER reach the instant router.
export type RubyParsedCommand =
  | { kind: "OPEN"; side: "BUY" | "SELL"; symbol: string; volume: number; orderType: string }
  | { kind: "CLOSE_ONE"; symbol: string }
  | { kind: "CLOSE_ALL" }
  | { kind: "CLOSE_ALL_SYMBOL_UNSUPPORTED"; symbol: string }
  | { kind: "CLOSE_PROFITABLE" }
  | { kind: "CLOSE_LOSING" }
  | { kind: "MODIFY"; positionRef: { symbol?: string }; newStopLoss?: number | "BREAK_EVEN"; newTakeProfit?: number }
  | { kind: "MISSING_VOLUME"; side: "BUY" | "SELL"; symbol: string }
  | { kind: "MISSING_SYMBOL"; side: "BUY" | "SELL"; volume: number }
  | { kind: "VAGUE"; reason: string }
  | { kind: "UNKNOWN" };

// Vague analysis patterns Ruby must answer, NEVER execute.
const VAGUE_PATTERNS: Array<RegExp> = [
  /\bwhat\s+should\s+i\s+(trade|buy|sell|do)\b/i,
  /\bis\s+\S+\s+(good|bullish|bearish|worth)\b/i,
  /\bdo\s+you\s+think\b/i,
  /\bshould\s+i\s+(buy|sell|trade|go|enter|short|long)\b/i,
  /\bwhere\s+is\s+\S+\s+going\b/i,
  /\bfind\s+me\s+a\s+(setup|trade|signal|entry)\b/i,
  /\bwhat\s+do\s+you\s+(think|see|recommend)\b/i,
  /\b(any|got)\s+(ideas|setups|signals)\b/i,
  /\bcan\s+you\s+analyze\b/i,
  /\bwhats?\s+(your\s+)?(view|opinion|take)\b/i,
];

// Symbol canonicaliser — accepts common aliases the user might say.
function canonSymbol(raw: string): string | null {
  const s = raw.trim().toUpperCase().replace(/[^A-Z0-9_]/g, "");
  if (!s) return null;
  const aliases: Record<string, string> = {
    GOLD: "XAUUSD", SILVER: "XAGUSD", OIL: "WTIUSD",
    NAS: "NAS100", NASDAQ: "NAS100", NASDAQ100: "NAS100",
    SPX: "SPX500", SP500: "SPX500", SP: "SPX500",
    DOW: "US30", DJIA: "US30",
    DAX: "GER40", GER30: "GER40",
    V75: "VOLATILITY75", V75_1S: "VOLATILITY75_1S",
    VOLATILITY75: "VOLATILITY75", VOLATILITY751S: "VOLATILITY75_1S",
    BTC: "BTCUSD", ETH: "ETHUSD",
  };
  return aliases[s] ?? s;
}

// English stop-words that happen to be 6 letters and would otherwise
// match the FX-pair regex (e.g. "trades", "orders", "losing"). Anything
// in this list is rejected as a symbol candidate. Keep additions safe:
// never add real market codes here.
const SYMBOL_STOPWORDS = new Set([
  "TRADES", "ORDERS", "LOSING", "WINNER", "MARKET", "STOPLO", "TARGET",
  "SIGNAL", "POSIT", "SYMBOL", "TICKET", "BROKER", "ACTIVE", "PROFIT",
  "MANUAL", "BUYING", "SELLIN", "CLOSED", "CANCEL", "STOPED",
]);

// Known 3-letter currency / commodity codes used to validate FX pair
// matches. If both halves of a 6-letter token aren't real currency
// codes, it's almost certainly an English word, not a symbol.
const KNOWN_CURRENCY = new Set([
  "USD", "EUR", "GBP", "JPY", "CHF", "AUD", "NZD", "CAD",
  "XAU", "XAG", "XPT", "XPD", "BTC", "ETH",
]);

// Extract symbol by trying single tokens then multi-word symbols
// ("Volatility 75 1s" → VOLATILITY75_1S).
function extractSymbol(text: string): string | null {
  // multi-word "Volatility 75 1s" / "Volatility 75 1 s"
  const v75 = /volatility\s*75(?:\s*1\s*s)?/i.exec(text);
  if (v75) return v75[0].replace(/\s+/g, "").toUpperCase() === "VOLATILITY751S"
    ? "VOLATILITY75_1S" : "VOLATILITY75";
  // 6-letter FX-pair-shaped token. Both 3-letter halves must be a known
  // currency code, otherwise reject (e.g. "trades", "orders" never pass).
  const fxRe = /\b([A-Za-z]{6})\b/g;
  let m: RegExpExecArray | null;
  while ((m = fxRe.exec(text)) !== null) {
    const tok = m[1]!.toUpperCase();
    if (SYMBOL_STOPWORDS.has(tok)) continue;
    const a = tok.slice(0, 3), b = tok.slice(3, 6);
    if (KNOWN_CURRENCY.has(a) && KNOWN_CURRENCY.has(b)) return canonSymbol(tok);
  }
  // index / commodity name token
  const tokMatch = /\b(gold|silver|oil|nasdaq|nas100|sp500|spx500|dow|us30|dax|ger40|btcusd|ethusd|btc|eth)\b/i.exec(text);
  if (tokMatch) return canonSymbol(tokMatch[1]!);
  return null;
}

function extractVolume(text: string): number | null {
  // "0.01 lots", "0.01 lot", "0.05", "1.5 lots"
  const m = /\b(\d+(?:\.\d+)?)\s*(?:lots?|lot)?\b/i.exec(text);
  if (!m) return null;
  const v = Number(m[1]);
  if (!Number.isFinite(v) || v <= 0 || v > 100) return null;
  return v;
}

function extractPrice(text: string, label: "tp" | "sl"): number | null {
  // Permissive: allows arbitrary tokens between the label and the number,
  // e.g. "set TP on EURUSD to 1.0920" or "move SL to 1.10".
  const re = label === "tp"
    ? /(?:tp|take\s*profit)[\s\S]{0,32}?(\d+(?:\.\d+)?)/i
    : /(?:sl|stop\s*loss)[\s\S]{0,32}?(\d+(?:\.\d+)?)/i;
  const m = re.exec(text);
  if (!m) return null;
  const v = Number(m[1]);
  return Number.isFinite(v) ? v : null;
}

export type ParseDefaults = {
  defaultSymbol?: string | null;
  defaultVolume?: number | null;
  defaultOrderType?: string | null;
};

export function parseTradeCommand(rawText: string, defaults: ParseDefaults = {}): RubyParsedCommand {
  const text = rawText.trim();
  if (!text) return { kind: "UNKNOWN" };

  // Vague analysis → never execute
  for (const p of VAGUE_PATTERNS) if (p.test(text)) return { kind: "VAGUE", reason: "ANALYSIS_QUESTION" };

  // Close-all variants. CRITICAL: if a symbol is present alongside
  // "close all" (e.g. "close all EURUSD"), we MUST NOT silently fall
  // through to account-wide CLOSE_ALL — that would liquidate every
  // open position. Return CLOSE_ALL_SYMBOL_UNSUPPORTED so the caller
  // refuses with an explicit "not implemented yet" message instead of
  // a dangerous mass-close.
  if (/\bclose\s+(all|every|everything)\b/i.test(text)) {
    if (/\b(profitable|winning|winners|in\s+profit)\b/i.test(text)) return { kind: "CLOSE_PROFITABLE" };
    if (/\b(losing|losers|in\s+loss|red)\b/i.test(text)) return { kind: "CLOSE_LOSING" };
    const sym = extractSymbol(text);
    if (sym) return { kind: "CLOSE_ALL_SYMBOL_UNSUPPORTED", symbol: sym };
    return { kind: "CLOSE_ALL" };
  }

  // Modify (SL/TP) — "set TP to 1.0920", "move SL to break even"
  if (/\b(set|move|change|update)\b/i.test(text) && /\b(stop\s*loss|sl|take\s*profit|tp)\b/i.test(text)) {
    const symbol = extractSymbol(text) ?? undefined;
    const breakEven = /\bbreak\s*even\b/i.test(text);
    const newStopLoss = breakEven
      ? ("BREAK_EVEN" as const)
      : (extractPrice(text, "sl") ?? undefined);
    const newTakeProfit = extractPrice(text, "tp") ?? undefined;
    if (newStopLoss !== undefined || newTakeProfit !== undefined) {
      return {
        kind: "MODIFY",
        positionRef: symbol ? { symbol } : {},
        ...(newStopLoss !== undefined ? { newStopLoss } : {}),
        ...(newTakeProfit !== undefined ? { newTakeProfit } : {}),
      };
    }
  }

  // Close one — "close my EURUSD trade", "close EURUSD"
  if (/\bclose\b/i.test(text) && !/\b(at|when|if)\b/i.test(text)) {
    const symbol = extractSymbol(text) ?? defaults.defaultSymbol ?? null;
    if (symbol) return { kind: "CLOSE_ONE", symbol };
  }

  // Open — "buy EURUSD 0.01", "sell XAUUSD", "go long EURUSD 0.05"
  const buyMatch = /\b(buy|long|go\s+long|open\s+(?:a\s+)?(?:market\s+)?buy|enter\s+long)\b/i.test(text);
  const sellMatch = /\b(sell|short|go\s+short|open\s+(?:a\s+)?(?:market\s+)?sell|enter\s+short)\b/i.test(text);
  if (buyMatch || sellMatch) {
    const side: "BUY" | "SELL" = buyMatch ? "BUY" : "SELL";
    const symbol = extractSymbol(text) ?? defaults.defaultSymbol ?? null;
    const volume = extractVolume(text) ?? defaults.defaultVolume ?? null;
    const orderType = defaults.defaultOrderType ?? (side === "BUY" ? "MARKET_BUY" : "MARKET_SELL");
    if (!symbol && volume != null) return { kind: "MISSING_SYMBOL", side, volume };
    if (symbol && volume == null) return { kind: "MISSING_VOLUME", side, symbol };
    if (symbol && volume != null) return { kind: "OPEN", side, symbol, volume, orderType };
    return { kind: "VAGUE", reason: "MISSING_SYMBOL_AND_VOLUME" };
  }

  return { kind: "UNKNOWN" };
}
