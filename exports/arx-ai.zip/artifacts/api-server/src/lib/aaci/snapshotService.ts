// AACI Shared Truth Snapshot service.
//
// Composes a normalized AaciSharedTruthSnapshot from EXISTING read-only sources.
// Every source is read in its own try/catch and contributes honest-unknown
// (absent + listed in unavailableSystems) on any failure — never fabricated
// data. READ-ONLY, per-user, advisory only. Never an execution path.

import {
  type AaciAccountMode,
  type AaciDirectionalBias,
  type AaciHandshakeSystem,
  type AaciNewsRiskLevel,
  type AaciSharedTruthSnapshot,
} from "@workspace/domain/aaci";
import { randomUUID } from "node:crypto";
import { logger } from "../logger.js";
import { evaluateReadiness } from "../readiness/traderReadiness.js";
import { scanSymbolTimeframe } from "../marketScanner.js";
import { getNewsIntelligence } from "../news/newsIntelligenceService.js";
import { getUnreadCount } from "../alerts/alertManager.js";
import { computeFleetHealth } from "../selfTrade/selfTradeSupervisor.js";
import { computeTimingRead } from "../../brain/timing/marketTimingBrainService.js";
import {
  getCachedIntelligenceContext,
  type ChartIntelligenceState,
} from "../data/chart/chartIntelligence.js";
import { buildChartHandshake } from "../data/chart/chartHandshake.js";

export interface BuildAaciSnapshotInput {
  userId: number;
  role: string;
  symbol?: string;
  timeframe?: string;
  // Explicit operator context may include only operator agents created by this
  // caller, in addition to their user-owned agents. It never attributes a shared
  // broker account to this user; account/bridge facts remain unavailable below.
  includeMasterBroker?: boolean;
}

function mapDirectional(raw: unknown): AaciDirectionalBias | undefined {
  if (typeof raw !== "string") return undefined;
  const v = raw.toUpperCase();
  if (v.includes("BULL") || v === "BUY" || v === "UP") return "buy";
  if (v.includes("BEAR") || v === "SELL" || v === "DOWN") return "sell";
  if (v.includes("MIX")) return "mixed";
  if (v.includes("NEUTRAL") || v.includes("CHOP") || v.includes("UNCLEAR")) return "neutral";
  return undefined;
}

function mapNewsRisk(raw: unknown): AaciNewsRiskLevel | undefined {
  if (typeof raw !== "string") return undefined;
  switch (raw.toLowerCase()) {
    case "none":
    case "low":
      return "low";
    case "medium":
      return "medium";
    case "high":
      return "high";
    case "critical":
      return "critical";
    default:
      return "unknown";
  }
}

/**
 * Whether today's paper loss has reached the daily cap trader readiness
 * reports (GovernorMetrics.dailyLossLimit). A cap of 0 is used up: readiness
 * reports 0 for a percent cap on a paper risk-count equity at or below 0,
 * where the Risk Governor refuses every new trade. It is never read as "no
 * cap". undefined = no daily cap is enforced (null).
 */
export function dailyLossHitOf(m: { dailyLossLimit: number | null; dailyPnl: number }): boolean | undefined {
  const cap = m.dailyLossLimit;
  if (cap == null) return undefined;
  if (cap <= 0) return true;
  return m.dailyPnl <= -Math.abs(cap);
}

/**
 * Build the AACI Shared Truth Snapshot for a user + symbol context. Fail-open
 * per source. Pure-ish: the only side effects are read-only source reads.
 */
export async function buildAaciSnapshot(
  input: BuildAaciSnapshotInput,
): Promise<AaciSharedTruthSnapshot> {
  const { userId, role, symbol, timeframe } = input;
  const unavailable: AaciHandshakeSystem[] = [];

  const snapshot: AaciSharedTruthSnapshot = {
    snapshotId: randomUUID(),
    timestamp: new Date().toISOString(),
    user: { userId: String(userId), role },
    symbolContext: {
      selectedSymbol: symbol,
      selectedTimeframe: timeframe,
      scannerSymbol: symbol,
      chartSymbol: symbol,
      eleanorSymbol: symbol,
    },
    account: {},
    bridge: { status: "unknown" },
    positions: { openCount: 0 },
  };

  // ── Risk Governor (R + risk gate inputs) ──────────────────────────────────
  try {
    const gov = await evaluateReadiness({ persist: false, userId });
    const m = gov.metrics;
    // Readiness could not read the trader's paper book (today's loss count
    // and open positions are placeholder 0s), the risk-count equity (a
    // percent cap has no value) or the limits themselves.
    const unreadParts = m.paperRiskCountUnreadable ?? [];
    const bookUnread = unreadParts.includes("paper_book");
    const lossFactsUnread = unreadParts.length > 0 || m.riskLimitsUnreadable === true;
    // A reached cap stands (a used-up 0 cap, or a read count past the cap: a
    // placeholder 0 count never reaches a cap above 0); anything else on
    // unread facts is unknown, never "under the cap".
    const hit = dailyLossHitOf(m);
    const dailyLossHit = hit === true ? true : lossFactsUnread ? undefined : hit;
    snapshot.risk = {
      hardPass: gov.hardBlocks.length === 0,
      riskMode: gov.overallStatus,
      dailyLossHit,
      ...(lossFactsUnread ? { lossFactsUnread: true } : {}),
      marginHealth: clamp100(gov.readinessScore),
      lastUpdated: gov.generatedAt,
    };
    // An unread paper book's open count is a placeholder 0: leave it unset.
    if (!bookUnread) snapshot.positions.appOpenCount = m.openPaperTrades;
  } catch (err) {
    logger.warn({ err }, "aaci: risk governor read failed");
    unavailable.push("RiskGovernor");
  }

  // ── Account snapshot + bridge connectivity (E + account) ──────────────────
  // The broker-readonly providers are global operator diagnostics, not
  // user-bound connections. Never fold one into a per-user AACI snapshot or
  // attribute its account to input.userId. Until an owner-bound adapter exists,
  // the only honest per-user value is unknown.
  unavailable.push("AccountAnalytics");
  unavailable.push("MT5Bridge");

  // ── Scanner (M + bias) ────────────────────────────────────────────────────
  if (symbol) {
    try {
      const opp = await scanSymbolTimeframe(symbol, timeframe ?? "M15");
      if (opp) {
        snapshot.scanner = {
          bias: mapDirectional(opp.bias),
          score: clamp100(opp.confidenceScore),
          lastUpdated: opp.generatedAt,
        };
      } else {
        unavailable.push("Scanner");
      }
    } catch (err) {
      logger.warn({ err }, "aaci: scanner read failed");
      unavailable.push("Scanner");
    }
  }

  // ── Chart intelligence (smartChart + Phase 4 chart handshake) ────────────
  // Use the cached chart intelligence state (3s-cached, no provider re-probe).
  // Fail-open: if no cached entry, smartChart and chartHandshake stay absent
  // (honest unknown — never fabricate a PASS).
  if (symbol) {
    try {
      const tf = (timeframe as "M1" | "M5" | "M15" | "M30" | "H1" | "H4" | "D1") ?? "M15";
      const cached =
        getCachedIntelligenceContext(symbol, tf, 300) ??
        getCachedIntelligenceContext(symbol, tf, 200);
      if (cached) {
        const { state } = cached;
        snapshot.smartChart = smartChartFromState(state);
        snapshot.chartHandshake = buildChartHandshake(
          state.gateOutput,
          state.chartTruthScore,
        );
      } else {
        unavailable.push("SmartChart");
      }
    } catch (err) {
      logger.warn({ err }, "aaci: chart intelligence read failed");
      unavailable.push("SmartChart");
    }
  }

  // ── Timing Brain heat (M) ─────────────────────────────────────────────────
  if (symbol) {
    try {
      const heat = await computeTimingRead({
        symbol,
        timeframe: (timeframe as never) ?? ("M15" as never),
        userTimezone: null,
        persistSnapshot: false,
      });
      snapshot.heat = {
        heatScore: clamp100(heat.heatScore),
        tradeabilityScore: clamp100(heat.tradeabilityScore),
        entryPermission: heat.entryPermission,
        bestAction: heat.bestAction,
        moveStage: heat.moveStage,
        lastUpdated: heat.generatedAt,
      };
    } catch (err) {
      logger.warn({ err }, "aaci: timing brain read failed");
      unavailable.push("MarketTimingBrain");
    }
  }

  // ── News (M + uncertainty) ────────────────────────────────────────────────
  if (symbol) {
    try {
      const news = await getNewsIntelligence(symbol);
      snapshot.news = {
        riskLevel: mapNewsRisk(news.riskLevel),
        lastUpdated: news.generatedAt,
      };
    } catch (err) {
      logger.warn({ err }, "aaci: news read failed");
      unavailable.push("EconomicCalendar");
    }
  }

  // ── Alerts pipeline (A) ───────────────────────────────────────────────────
  try {
    const unread = await getUnreadCount(userId);
    snapshot.alerts = { pipelineReady: true, unreadCount: unread, lastUpdated: snapshot.timestamp };
  } catch (err) {
    logger.warn({ err }, "aaci: alerts read failed");
    unavailable.push("MyAlerts");
  }

  // ── Self-Trade fleet health (agent context) ───────────────────────────────
  try {
    // A user's advisory context cannot borrow another owner's funded/healthy
    // fleet. Explicit operator execution may include only the caller's fleet.
    const fleet = await computeFleetHealth({ userId, includeOperatorFleet: input.includeMasterBroker === true });
    snapshot.selfTradeAgent = {
      funded: fleet.fundedAgents > 0,
      active: fleet.activeAgents > 0,
      ledgerHealthy: fleet.totalAgents > 0 ? fleet.accounting.status === "RECORDED" : undefined,
    };
  } catch (err) {
    logger.warn({ err }, "aaci: self-trade fleet read failed");
    unavailable.push("SelfTradeSupervisor");
  }

  // Audit readiness is genuinely UNKNOWN at snapshot time — there is no cheap
  // health probe and the decision-service write is best-effort. Do NOT fabricate
  // `auditReady: true`; leave audit unset so the A sub-score reflects honest
  // unknown rather than asserted-healthy. (Audit is not one of the 16 real live
  // gates, so the advisory hard-gate factor remains non-blocking by design.)
  if (!snapshot.account.mode) snapshot.account.mode = "unknown" as AaciAccountMode;

  if (unavailable.length > 0) snapshot.unavailableSystems = unavailable;
  return snapshot;
}

/**
 * Map a cached chart-intelligence state onto the snapshot's smartChart block.
 * Feed timestamps are observations of the feed itself — the newest live tick
 * the server received and the newest CLOSED candle's close — never the time
 * the cached state was computed (lastUpdated), so a state built a second ago
 * over an hours-old feed cannot read as a fresh market feed.
 */
export function smartChartFromState(
  state: ChartIntelligenceState,
): NonNullable<AaciSharedTruthSnapshot["smartChart"]> {
  const builtMs = Date.parse(state.lastUpdated);
  const closedCloseTime = state.latestClosedCandle?.closeTime ?? null;
  const closedCloseMs = closedCloseTime ? Date.parse(closedCloseTime) : NaN;
  // A close time after the state was built is a forming bar's schedule, not
  // an observation: leave the candle age unknown.
  const lastCandleTime =
    Number.isFinite(closedCloseMs) && (!Number.isFinite(builtMs) || closedCloseMs <= builtMs)
      ? closedCloseTime ?? undefined
      : undefined;
  return {
    bias: state.gateOutput.confidentReadAllowed
      ? (state.decisionState.bias === "bullish"
          ? "bullish"
          : state.decisionState.bias === "bearish"
            ? "bearish"
            : "neutral")
      : undefined,
    structureScore: structureScoreFromState(state),
    lastTickTime: state.truthState.lastTickTime ?? undefined,
    lastCandleTime,
    feedStale: state.stale,
    lastUpdated: state.lastUpdated,
  };
}

/**
 * Market structure for Market Truth (M): the chart read's structure-clarity
 * metric (trend regime + mapped levels). The Chart Truth score is data quality
 * and freshness, not structure, so it is never used here. Structure is unknown
 * (undefined, so M neither gains nor loses points for it) when the engines
 * did not populate or the feed is not usable/current for analysis.
 */
function structureScoreFromState(state: ChartIntelligenceState): number | undefined {
  if (!state.marketUnderstanding.populated || !state.aiUsable || state.stale) return undefined;
  const metric = state.chartReadScore.subMetrics.find((m) => m.key === "structure_clarity");
  return metric && Number.isFinite(metric.rawScore) ? clamp100(metric.rawScore) : undefined;
}

function clamp100(n: number): number {
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(100, n));
}
