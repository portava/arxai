import express, { type Express } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { attachAuthUser } from "./lib/auth/middleware";
import { applyEffectiveViewMode } from "./lib/auth/effectiveViewMode";
import { startMonitor } from "./lib/intelligence/monitorWorker";

const app: Express = express();
app.use(cookieParser(process.env["SESSION_SECRET"] ?? "dev-fallback-secret-do-not-use-in-prod"));
// Per-user identity: attaches req.authUser when the arx_user_session cookie
// is valid. Routes that require auth wrap themselves with `requireUser`;
// public routes simply check `req.authUser` if they want to personalize.
app.use(attachAuthUser);
// Effective view-mode: when an admin-capable user has toggled into "user"
// view-mode on the frontend (X-Arx-View-Mode: user header), downgrade
// `req.authUser.role` to "USER" so every `requireAdmin` check naturally
// returns 403. Real DB role is NOT mutated. No-op for non-admins.
app.use(applyEffectiveViewMode);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

// UX4 — start the background trade-monitor worker (paper-only, read-mostly).
startMonitor();

// ── Phase 22D — JSON-only error handler ───────────────────────────────
// Guarantees the frontend never receives an HTML stack trace. Catches
// body-parser PayloadTooLargeError (413), maps common upstream failures
// to friendly codes, and hides everything else behind a generic message.
app.use(
  (err: unknown, req: express.Request, res: express.Response, _next: express.NextFunction) => {
    const e = err as { type?: string; status?: number; statusCode?: number; message?: string; name?: string; code?: string };
    // Phase 22D — multer file-size violations don't carry a status code; map
    // them to 413 so the unified JSON 413 branch picks them up.
    const isMulterTooLarge = e?.name === "MulterError" && e?.code === "LIMIT_FILE_SIZE";
    const status = isMulterTooLarge ? 413 : (e?.status ?? e?.statusCode ?? 500);
    try {
      (req as { log?: { error: (...a: unknown[]) => void } }).log?.error(
        { err: e?.message, name: e?.name, type: e?.type, status },
        "api_error",
      );
    } catch { /* noop */ }
    if (res.headersSent) { try { res.end(); } catch { /* noop */ } return; }
    const isVoice = req.path.includes("/assistant/") && req.path.endsWith("/voice");
    if (e?.type === "entity.too.large" || status === 413) {
      res.status(413).json({
        ok: false,
        error: isVoice ? "VOICE_TOO_LARGE" : "PAYLOAD_TOO_LARGE",
        message: isVoice
          ? "Voice clip is too long. Please try a shorter message."
          : "Request body is too large.",
      });
      return;
    }
    if (e?.type === "entity.parse.failed" || status === 400) {
      res.status(400).json({ ok: false, error: "BAD_REQUEST", message: "Invalid request." });
      return;
    }
    res.status(status >= 400 && status < 600 ? status : 500).json({
      ok: false,
      error: "INTERNAL_ERROR",
      message: "Something went wrong. Please try again.",
    });
  },
);

export default app;
