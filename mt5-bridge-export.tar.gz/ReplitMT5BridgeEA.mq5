//+------------------------------------------------------------------+
//| ReplitMT5BridgeEA.mq5                                            |
//| READ-ONLY MT5 -> Replit (ARX AI) bridge.                         |
//|                                                                  |
//| SAFETY:                                                          |
//|  - Default: ReadOnlyMode=true, AllowOrderExecution=false.        |
//|  - This EA NEVER calls OrderSend, OrderModify, OrderClose,       |
//|    PositionClose, or any trade.* function in v1.                 |
//|  - When the server queues a command, the EA acknowledges it      |
//|    with status="EA_READ_ONLY_MODE_ACTIVE" and does NOT execute.  |
//|  - The shared secret token is read from EA inputs at runtime.    |
//|    It is NEVER printed to the Experts log or the journal.        |
//|                                                                  |
//| v1.1 — VERBOSE HEARTBEAT DIAGNOSTICS                             |
//|  - OnInit prints a full configuration summary (no token value).  |
//|  - Every heartbeat attempt prints url, http code, GetLastError,  |
//|    response body preview, and a human-readable failure reason.   |
//|  - Detects placeholder/blank/trailing-slash ServerBaseUrl.       |
//|  - Detects WebRequest-not-allowed (err 4060 / -1 / 5203).        |
//+------------------------------------------------------------------+
#property copyright "Replit ARX AI Trading Bridge"
#property version   "1.24"
#property strict
#property description "READ-ONLY MT5 bridge for ARX AI. v1.24 uses GetTickCount64() for elapsed-time gates (not TimeCurrent) so heartbeat keeps flowing on weekends/holidays when broker time is frozen. PER-USER bridge token only. NEVER places, modifies, or closes orders."

//--- Inputs (configure on the EA chart properties dialog) ----------
input string  ServerBaseUrl           = "https://your-replit-app.replit.app"; // e.g. https://<repl>.replit.app  (no trailing slash)
input string  BridgeToken             = "";       // Paste the per-user bridge token from ARX MT5 Setup. NEVER share. Do NOT paste the system MT5_BRIDGE_TOKEN env value — it is rejected on every EA endpoint.
input string  Environment             = "demo";   // "demo" or "live" (informational only — server enforces real safety)
input string  AccountId               = "";       // Optional. If blank, EA uses AccountInfoString(ACCOUNT_LOGIN).
input bool    ReadOnlyMode            = true;     // KEEP TRUE for v1. EA refuses to execute any command when true.
input bool    AllowOrderExecution     = false;    // KEEP FALSE. v1 has no execution code path even if you flip this.
input int     PollIntervalSeconds     = 2;        // OnTimer tick period in seconds (also the command-poll period). Heartbeat and snapshot periods below should be >= this.
input int     HeartbeatPeriodSeconds  = 5;        // How often to POST /api/mt5/heartbeat. Server freshness threshold is 15s, so keep this <= 10.
input int     SnapshotPeriodSeconds   = 5;        // How often to POST /api/mt5/sync-account and /api/mt5/sync-positions.
input bool    SendHeartbeat           = true;
input bool    SendAccountSnapshot     = true;
input bool    SendPositionsSnapshot   = true;
input bool    SendOrdersSnapshot      = true;     // Reserved. v1 sends positions only (server has no /orders/snapshot endpoint).
input int     RequestTimeoutMs        = 5000;
input bool    VerboseDiagnostics      = true;     // Print full per-attempt diagnostic lines to the Experts tab.

//--- Constants -----------------------------------------------------
#define HDR_TOKEN_NAME "X-MT5-Bridge-Token"
#define PLACEHOLDER_URL "https://your-replit-app.replit.app"

//--- State ---------------------------------------------------------
// Broker-time markers (datetime). Used ONLY for diagnostic display in logs +
// for the server's heartbeat freshness window (which is server-side anyway).
// These FREEZE on weekends/holidays when no ticks arrive, so they must NEVER
// be used for elapsed-time decisions.
datetime g_lastHeartbeatAt   = 0;
datetime g_lastAccountSyncAt = 0;
datetime g_lastPositionSyncAt= 0;
datetime g_lastPollAt        = 0;
// VPS-uptime markers (ms). Driven by GetTickCount64(), monotonic, NEVER frozen
// by market closure. These are the authoritative gates inside OnTimer.
ulong    g_lastHeartbeatMs   = 0;
ulong    g_lastAccountSyncMs = 0;
ulong    g_lastPositionSyncMs= 0;
ulong    g_lastPollMs        = 0;
long     g_timerTickCount    = 0;
int      g_heartbeatPeriodS  = 5; // bound from HeartbeatPeriodSeconds in OnInit
int      g_snapshotPeriodS   = 5; // bound from SnapshotPeriodSeconds in OnInit
long     g_heartbeatAttempts = 0;
long     g_heartbeatSuccess  = 0;
long     g_heartbeatFailure  = 0;

//+------------------------------------------------------------------+
//| Helpers                                                          |
//+------------------------------------------------------------------+
string IsoNow()
{
   datetime t = TimeGMT();
   MqlDateTime mdt;
   TimeToStruct(t, mdt);
   return StringFormat("%04d-%02d-%02dT%02d:%02d:%02dZ",
      mdt.year, mdt.mon, mdt.day, mdt.hour, mdt.min, mdt.sec);
}

string EffectiveAccountId()
{
   if(StringLen(AccountId) > 0) return AccountId;
   long login = AccountInfoInteger(ACCOUNT_LOGIN);
   return IntegerToString(login);
}

string SideFromPosType(long ptype)
{
   if(ptype == POSITION_TYPE_BUY)  return "BUY";
   if(ptype == POSITION_TYPE_SELL) return "SELL";
   return "UNKNOWN";
}

// Trim trailing slashes off the configured ServerBaseUrl so url joining is safe.
string NormalizedBaseUrl()
{
   string u = ServerBaseUrl;
   while(StringLen(u) > 0 && StringGetCharacter(u, StringLen(u) - 1) == '/')
      u = StringSubstr(u, 0, StringLen(u) - 1);
   return u;
}

// Validate ServerBaseUrl. Returns "" if OK, else a human-readable reason.
string ValidateServerBaseUrl()
{
   string u = ServerBaseUrl;
   if(StringLen(u) == 0)                     return "ServerBaseUrl is BLANK. Set it in EA inputs.";
   if(u == PLACEHOLDER_URL)                  return "ServerBaseUrl is still the PLACEHOLDER value. Replace with your real Replit URL.";
   if(StringFind(u, "your-replit-app") >= 0) return "ServerBaseUrl still contains 'your-replit-app' placeholder text. Replace with the real URL.";
   if(StringFind(u, "http") != 0)            return "ServerBaseUrl must start with http:// or https://.";
   if(StringFind(u, " ") >= 0)               return "ServerBaseUrl contains whitespace. Re-paste cleanly.";
   if(StringGetCharacter(u, StringLen(u) - 1) == '/')
      return "ServerBaseUrl has a trailing slash; will be auto-trimmed but please remove it in EA inputs.";
   return "";
}

// Build common headers (token + content-type). Token never appears in log.
string BuildHeaders()
{
   return StringFormat("%s: %s\r\nContent-Type: application/json\r\n",
                       HDR_TOKEN_NAME, BridgeToken);
}

// Translate MQL WebRequest GetLastError() codes into a human reason.
string ExplainWebRequestError(int err)
{
   if(err == 4014) return "ERR_FUNCTION_NOT_ALLOWED — WebRequest disabled for this URL. Tools → Options → Expert Advisors → Allow WebRequest for listed URL, then add the exact server URL.";
   if(err == 4060) return "ERR_FUNCTION_NOT_CONFIRMED — WebRequest not confirmed. Tools → Options → Expert Advisors → tick 'Allow WebRequest for listed URL' AND add the URL.";
   if(err == 5200) return "ERR_WEBREQUEST_INVALID_ADDRESS — invalid URL. Check ServerBaseUrl scheme/host/port.";
   if(err == 5201) return "ERR_WEBREQUEST_CONNECT_FAILED — could not connect to server. Check that ServerBaseUrl is reachable from this machine.";
   if(err == 5202) return "ERR_WEBREQUEST_TIMEOUT — server did not respond in time. Increase RequestTimeoutMs or check the server.";
   if(err == 5203) return "ERR_WEBREQUEST_REQUEST_FAILED — request failed on the network layer. Often a TLS / proxy / DNS issue.";
   if(err == 0)    return "no MQL error reported (request may have completed but with non-2xx HTTP)";
   return StringFormat("unknown MQL error code %d", err);
}

// Translate server-side HTTP status to a heartbeat-specific reason.
string ExplainHeartbeatHttp(int code, const string body)
{
   if(code >= 200 && code < 300) return "ACCEPTED — heartbeat recorded by server.";
   if(code == 401)               return "REJECTED — token rejected. EA's BridgeToken does NOT match an active per-user token in ARX MT5 Setup, or X-MT5-Bridge-Token header missing. Regenerate the per-user token from MT5 Setup and re-paste it. The system MT5_BRIDGE_TOKEN env value is NOT accepted here.";
   if(code == 503)               return "REJECTED — server bridge endpoint disabled.";
   if(code == 400)               return "REJECTED — server says heartbeat body is invalid JSON or missing fields.";
   if(code == 404)               return "REJECTED — endpoint not found. Verify ServerBaseUrl and that /api/mt5/heartbeat is mounted.";
   if(code >= 500)               return "REJECTED — server error. See response body.";
   return StringFormat("UNEXPECTED HTTP %d. body[:200]=%s", code, StringSubstr(body, 0, 200));
}

string SafeBodyPreview(const string body)
{
   string s = body;
   int n = StringLen(s);
   if(n > 200) s = StringSubstr(s, 0, 200) + "...";
   return s;
}

// Generic POST returning false on failure. Body must be JSON string.
// Verbose mode prints url, http status, GetLastError, response preview.
bool HttpPost(const string path, const string jsonBody, string &responseOut, const string label)
{
   string url = NormalizedBaseUrl() + path;
   string headers = BuildHeaders();
   char post[];
   int copied = StringToCharArray(jsonBody, post, 0, -1, CP_UTF8); // includes terminal zero
   if(copied <= 1)
   {
      PrintFormat("[ARX][%s] POST body conversion failed. jsonBody length=%d copied=%d", label, StringLen(jsonBody), copied);
      return false;
   }
   ArrayResize(post, copied - 1); // remove ONLY the terminal zero, not the final JSON brace
   char result[];
   string resHeaders;
   ResetLastError();
   int code = WebRequest("POST", url, headers, RequestTimeoutMs, post, result, resHeaders);
   responseOut = (ArraySize(result) > 0) ? CharArrayToString(result, 0, ArraySize(result), CP_UTF8) : "";

   if(code == -1)
   {
      int err = GetLastError();
      PrintFormat("[ARX][%s] POST %s FAILED. http=-1 GetLastError=%d (%s)",
                  label, url, err, ExplainWebRequestError(err));
      return false;
   }
   if(VerboseDiagnostics)
   {
      PrintFormat("[ARX][%s] POST %s -> HTTP %d. body[:200]=%s",
                  label, url, code, SafeBodyPreview(responseOut));
   }
   if(code < 200 || code >= 300)
   {
      PrintFormat("[ARX][%s] POST %s rejected. %s",
                  label, url, ExplainHeartbeatHttp(code, responseOut));
      return false;
   }
   return true;
}

bool HttpGet(const string path, string &responseOut, const string label)
{
   string url = NormalizedBaseUrl() + path;
   string headers = BuildHeaders();
   char post[]; ArrayResize(post, 0);
   char result[];
   string resHeaders;
   ResetLastError();
   int code = WebRequest("GET", url, headers, RequestTimeoutMs, post, result, resHeaders);
   responseOut = (ArraySize(result) > 0) ? CharArrayToString(result, 0, ArraySize(result), CP_UTF8) : "";
   if(code == -1)
   {
      int err = GetLastError();
      PrintFormat("[ARX][%s] GET %s FAILED. http=-1 GetLastError=%d (%s)",
                  label, url, err, ExplainWebRequestError(err));
      return false;
   }
   if(code < 200 || code >= 300)
   {
      PrintFormat("[ARX][%s] GET %s -> HTTP %d. body[:200]=%s",
                  label, url, code, SafeBodyPreview(responseOut));
      return false;
   }
   return true;
}

// JSON string escape (handles ", \, control chars).
string JsonEscape(const string s)
{
   string out = "";
   int n = StringLen(s);
   for(int i = 0; i < n; i++)
   {
      ushort ch = StringGetCharacter(s, i);
      if(ch == '"')       out += "\\\"";
      else if(ch == '\\') out += "\\\\";
      else if(ch == '\n') out += "\\n";
      else if(ch == '\r') out += "\\r";
      else if(ch == '\t') out += "\\t";
      else if(ch < 0x20)  out += StringFormat("\\u%04x", ch);
      else                out += ShortToString(ch);
   }
   return out;
}

// JSON helpers — ALWAYS build payloads through these so a stray quote, NaN, or
// Inf can never produce malformed JSON the server's body-parser will reject.
string JString(const string value)
{
   return "\"" + JsonEscape(value) + "\"";
}

string JBool(const bool value)
{
   return value ? "true" : "false";
}

string JNumber(const double value, const int digits = 2)
{
   if(!MathIsValidNumber(value)) return "0.0";
   return DoubleToString(value, digits);
}

string JLong(const long value)
{
   return IntegerToString(value);
}

string JULong(const ulong value)
{
   return IntegerToString((long)value);
}

long JsonReadInt(const string json, const string field)
{
   string needle = "\"" + field + "\":";
   int pos = StringFind(json, needle);
   if(pos < 0) return -1;
   pos += StringLen(needle);
   while(pos < StringLen(json) && (StringGetCharacter(json, pos) == ' ')) pos++;
   string acc = "";
   while(pos < StringLen(json))
   {
      ushort ch = StringGetCharacter(json, pos);
      if((ch >= '0' && ch <= '9') || ch == '-') { acc += ShortToString(ch); pos++; }
      else break;
   }
   if(StringLen(acc) == 0) return -1;
   return (long)StringToInteger(acc);
}

string JsonReadString(const string json, const string field)
{
   string needle = "\"" + field + "\":\"";
   int pos = StringFind(json, needle);
   if(pos < 0) return "";
   pos += StringLen(needle);
   string acc = "";
   while(pos < StringLen(json))
   {
      ushort ch = StringGetCharacter(json, pos);
      if(ch == '"') break;
      if(ch == '\\' && pos + 1 < StringLen(json)) { pos++; acc += ShortToString(StringGetCharacter(json, pos)); pos++; continue; }
      acc += ShortToString(ch); pos++;
   }
   return acc;
}

//+------------------------------------------------------------------+
//| Heartbeat                                                        |
//+------------------------------------------------------------------+
void SendHeartbeatNow()
{
   if(!SendHeartbeat) { if(VerboseDiagnostics) Print("[ARX][HB] SendHeartbeat=false; skipping."); return; }

   g_heartbeatAttempts++;

   // Pre-flight checks (no token value ever printed) ----------------
   string urlIssue = ValidateServerBaseUrl();
   if(StringLen(urlIssue) > 0 && urlIssue != "ServerBaseUrl has a trailing slash; will be auto-trimmed but please remove it in EA inputs.")
   {
      g_heartbeatFailure++;
      PrintFormat("[ARX][HB] attempt #%I64d at %s — ABORTED. %s",
                  g_heartbeatAttempts, IsoNow(), urlIssue);
      return;
   }
   if(StringLen(BridgeToken) == 0)
   {
      g_heartbeatFailure++;
      PrintFormat("[ARX][HB] attempt #%I64d at %s — ABORTED. BridgeToken is BLANK in EA inputs.",
                  g_heartbeatAttempts, IsoNow());
      return;
   }

   double bal = AccountInfoDouble(ACCOUNT_BALANCE);
   double eq  = AccountInfoDouble(ACCOUNT_EQUITY);
   string broker = AccountInfoString(ACCOUNT_COMPANY);
   string server = AccountInfoString(ACCOUNT_SERVER);
   bool live = (AccountInfoInteger(ACCOUNT_TRADE_MODE) == ACCOUNT_TRADE_MODE_REAL);

   // Build heartbeat body strictly through JSON helpers. NaN/Inf collapse to
   // 0.0; quotes/backslashes/control chars are escaped. No trailing comma.
   string body = "{";
   body += "\"account\":"     + JString(EffectiveAccountId()) + ",";
   body += "\"broker\":"      + JString(broker)               + ",";
   body += "\"server\":"      + JString(server)               + ",";
   body += "\"balance\":"     + JNumber(bal, 2)               + ",";
   body += "\"equity\":"      + JNumber(eq, 2)                + ",";
   body += "\"liveAllowed\":" + JBool(live)                   + ",";
   body += "\"timestamp\":"   + JString(IsoNow());
   body += "}";

   if(VerboseDiagnostics)
   {
      PrintFormat("[ARX][HB] attempt #%I64d at %s — POST %s/api/mt5/heartbeat (token withheld; len=%d).",
                  g_heartbeatAttempts, IsoNow(), NormalizedBaseUrl(), StringLen(BridgeToken));
      PrintFormat("[ARX][HB] payload (len=%d): %s", StringLen(body), body);
   }

   string resp;
   if(HttpPost("/api/mt5/heartbeat", body, resp, "HB"))
   {
      g_heartbeatSuccess++;
      g_lastHeartbeatAt = TimeCurrent();
      g_lastHeartbeatMs = GetTickCount64();
      PrintFormat("[ARX][HB] ACCEPTED. attempt=#%I64d ok=%I64d fail=%I64d. server response[:200]=%s",
                  g_heartbeatAttempts, g_heartbeatSuccess, g_heartbeatFailure, SafeBodyPreview(resp));
   }
   else
   {
      g_heartbeatFailure++;
      PrintFormat("[ARX][HB] FAILED. attempt=#%I64d ok=%I64d fail=%I64d. See [ARX][HB] line above for HTTP/err.",
                  g_heartbeatAttempts, g_heartbeatSuccess, g_heartbeatFailure);
   }
}

//+------------------------------------------------------------------+
//| Account snapshot                                                 |
//+------------------------------------------------------------------+
void SendAccountSnapshotNow()
{
   if(!SendAccountSnapshot) return;
   double bal  = AccountInfoDouble(ACCOUNT_BALANCE);
   double eq   = AccountInfoDouble(ACCOUNT_EQUITY);
   double mar  = AccountInfoDouble(ACCOUNT_MARGIN);
   double fmar = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
   double mlev = AccountInfoDouble(ACCOUNT_MARGIN_LEVEL);
   string ccy  = AccountInfoString(ACCOUNT_CURRENCY);

   string body = "{";
   body += "\"account\":"     + JString(EffectiveAccountId()) + ",";
   body += "\"balance\":"     + JNumber(bal,  2)              + ",";
   body += "\"equity\":"      + JNumber(eq,   2)              + ",";
   body += "\"margin\":"      + JNumber(mar,  2)              + ",";
   body += "\"freeMargin\":"  + JNumber(fmar, 2)              + ",";
   body += "\"marginLevel\":" + JNumber(mlev, 2)              + ",";
   body += "\"currency\":"    + JString(ccy)                  + ",";
   body += "\"timestamp\":"   + JString(IsoNow());
   body += "}";
   if(VerboseDiagnostics)
      PrintFormat("[ARX][ACCT] payload (len=%d): %s", StringLen(body), body);
   string resp;
   if(HttpPost("/api/mt5/sync-account", body, resp, "ACCT"))
   {
      g_lastAccountSyncAt = TimeCurrent();
      g_lastAccountSyncMs = GetTickCount64();
   }
}

//+------------------------------------------------------------------+
//| Positions snapshot                                               |
//+------------------------------------------------------------------+
void SendPositionsSnapshotNow()
{
   if(!SendPositionsSnapshot) return;
   string items = "";
   int total = PositionsTotal();
   for(int i = 0; i < total; i++)
   {
      ulong ticket = PositionGetTicket(i);
      if(ticket == 0) continue;
      if(!PositionSelectByTicket(ticket)) continue;
      string sym  = PositionGetString(POSITION_SYMBOL);
      long   ptyp = PositionGetInteger(POSITION_TYPE);
      double lot  = PositionGetDouble(POSITION_VOLUME);
      double ent  = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl   = PositionGetDouble(POSITION_SL);
      double tp   = PositionGetDouble(POSITION_TP);
      double prof = PositionGetDouble(POSITION_PROFIT);
      string row = "{";
      row += "\"ticket\":" + JULong(ticket)                + ",";
      row += "\"symbol\":" + JString(sym)                  + ",";
      row += "\"side\":"   + JString(SideFromPosType(ptyp)) + ",";
      row += "\"lot\":"    + JNumber(lot,  2)              + ",";
      row += "\"entry\":"  + JNumber(ent,  5)              + ",";
      row += "\"sl\":"     + JNumber(sl,   5)              + ",";
      row += "\"tp\":"     + JNumber(tp,   5)              + ",";
      row += "\"profit\":" + JNumber(prof, 2);
      row += "}";
      if(StringLen(items) > 0) items += ",";
      items += row;
   }
   string body = "{\"positions\":[" + items + "],\"timestamp\":" + JString(IsoNow()) + "}";
   if(VerboseDiagnostics)
      PrintFormat("[ARX][POS] payload (len=%d, count=%d): %s", StringLen(body), total, body);
   string resp;
   if(HttpPost("/api/mt5/sync-positions", body, resp, "POS"))
   {
      g_lastPositionSyncAt = TimeCurrent();
      g_lastPositionSyncMs = GetTickCount64();
   }
}

//+------------------------------------------------------------------+
//| Command poll + (read-only) ack                                   |
//+------------------------------------------------------------------+
void PollAndAckCommands()
{
   string resp;
   if(!HttpGet("/api/mt5/commands", resp, "POLL")) return;

   int cursor = 0;
   while(true)
   {
      int idPos = StringFind(resp, "\"id\":", cursor);
      if(idPos < 0) break;
      int nextIdPos = StringFind(resp, "\"id\":", idPos + 5);
      string slice = (nextIdPos < 0) ? StringSubstr(resp, idPos)
                                     : StringSubstr(resp, idPos, nextIdPos - idPos);
      long cmdId = JsonReadInt(slice, "id");
      string action = JsonReadString(slice, "action");
      cursor = (nextIdPos < 0) ? StringLen(resp) : nextIdPos;
      if(cmdId <= 0) continue;

      string status, detail;
      if(ReadOnlyMode || !AllowOrderExecution)
      {
         status = "EA_READ_ONLY_MODE_ACTIVE";
         detail = StringFormat("EA refused %s command #%I64d. ReadOnlyMode=%s, AllowOrderExecution=%s.",
                               action, cmdId,
                               (ReadOnlyMode ? "true" : "false"),
                               (AllowOrderExecution ? "true" : "false"));
      }
      else
      {
         status = "EA_EXECUTION_NOT_IMPLEMENTED";
         detail = "EA v1 has no order execution code path. Upgrade EA to enable.";
      }

      string ackBody = "{";
      ackBody += "\"commandId\":" + JLong(cmdId)       + ",";
      ackBody += "\"status\":"    + JString(status)    + ",";
      ackBody += "\"detail\":"    + JString(detail)    + ",";
      ackBody += "\"timestamp\":" + JString(IsoNow());
      ackBody += "}";
      string ackResp;
      HttpPost("/api/mt5/command-result", ackBody, ackResp, "ACK");
      PrintFormat("[ARX][POLL] Acked command #%I64d action=%s with status=%s", cmdId, action, status);
   }
   g_lastPollAt = TimeCurrent();
   g_lastPollMs = GetTickCount64();
}

//+------------------------------------------------------------------+
//| Lifecycle                                                        |
//+------------------------------------------------------------------+
void PrintInitDiagnostics()
{
   Print("[ARX] ──────────────────────────────────────────────────────────────");
   Print("[ARX] EA initialized: ReplitMT5BridgeEA v1.21 JSON_BODY_FIX (READ-ONLY)");
   PrintFormat("[ARX] ServerBaseUrl present : %s", (StringLen(ServerBaseUrl) > 0 ? "yes" : "NO"));
   PrintFormat("[ARX] ServerBaseUrl value   : %s", ServerBaseUrl);
   PrintFormat("[ARX] Normalized base URL   : %s", NormalizedBaseUrl());
   PrintFormat("[ARX] Expected heartbeat URL: %s/api/mt5/heartbeat", NormalizedBaseUrl());
   PrintFormat("[ARX] Required header       : %s: <token withheld>", HDR_TOKEN_NAME);
   PrintFormat("[ARX] BridgeToken present   : %s (length=%d; value NEVER printed)",
               (StringLen(BridgeToken) > 0 ? "yes" : "NO"), StringLen(BridgeToken));
   PrintFormat("[ARX] Environment           : %s", Environment);
   PrintFormat("[ARX] AccountId (effective) : %s", EffectiveAccountId());
   PrintFormat("[ARX] ReadOnlyMode          : %s", (ReadOnlyMode ? "true" : "false"));
   PrintFormat("[ARX] AllowOrderExecution   : %s (v1 still refuses execution regardless)",
               (AllowOrderExecution ? "true" : "false"));
   PrintFormat("[ARX] PollIntervalSeconds   : %d (OnTimer tick period)", PollIntervalSeconds);
   PrintFormat("[ARX] HeartbeatPeriodSeconds: %d (clamped 1..10)", HeartbeatPeriodSeconds);
   PrintFormat("[ARX] SnapshotPeriodSeconds : %d", SnapshotPeriodSeconds);
   PrintFormat("[ARX] SendHeartbeat         : %s", (SendHeartbeat ? "true" : "false"));
   PrintFormat("[ARX] SendAccountSnapshot   : %s", (SendAccountSnapshot ? "true" : "false"));
   PrintFormat("[ARX] SendPositionsSnapshot : %s", (SendPositionsSnapshot ? "true" : "false"));
   PrintFormat("[ARX] RequestTimeoutMs      : %d", RequestTimeoutMs);
   PrintFormat("[ARX] VerboseDiagnostics    : %s", (VerboseDiagnostics ? "true" : "false"));

   string urlIssue = ValidateServerBaseUrl();
   if(StringLen(urlIssue) > 0)
      PrintFormat("[ARX] ServerBaseUrl WARNING : %s", urlIssue);
   else
      Print("[ARX] ServerBaseUrl validation: OK");

   Print("[ARX] If you see no [ARX][HB] POST line within ~5s, WebRequest is being blocked by MT5.");
   Print("[ARX] Tools → Options → Expert Advisors → Allow WebRequest for listed URL → add the Normalized base URL above.");
   Print("[ARX] ──────────────────────────────────────────────────────────────");
}

int OnInit()
{
   PrintInitDiagnostics();

   if(StringLen(BridgeToken) < 8)
   {
      Alert("[ARX] BridgeToken is empty or too short. Set it in EA inputs to the per-user bridge token issued from the ARX MT5 Setup page. EA will not run.");
      return INIT_PARAMETERS_INCORRECT;
   }
   string urlIssue = ValidateServerBaseUrl();
   if(StringLen(urlIssue) > 0 && urlIssue != "ServerBaseUrl has a trailing slash; will be auto-trimmed but please remove it in EA inputs.")
   {
      Alert(StringFormat("[ARX] ServerBaseUrl invalid: %s EA will not run.", urlIssue));
      return INIT_PARAMETERS_INCORRECT;
   }
   if(!ReadOnlyMode || AllowOrderExecution)
   {
      Alert("[ARX] WARNING: This v1 EA still refuses execution even when flags are flipped. Keep ReadOnlyMode=true for production safety.");
   }

   // Bind input periods to runtime state. Clamp so the server freshness
   // threshold (15s) is never exceeded by misconfiguration.
   g_heartbeatPeriodS = MathMax(1, MathMin(10, HeartbeatPeriodSeconds));
   g_snapshotPeriodS  = MathMax(1, SnapshotPeriodSeconds);

   // Timer-first wiring: arm OnTimer BEFORE first-shot sends so even if the
   // initial sends fail (e.g. WebRequest URL not allow-listed) the timer keeps
   // retrying without depending on chart ticks. Important: many VPS charts
   // (especially closed-market symbols) deliver zero OnTick events for hours
   // — heartbeat MUST NOT depend on OnTick.
   EventSetTimer(MathMax(1, PollIntervalSeconds));
   PrintFormat("[ARX] Timer armed: every %ds (heartbeat=%ds, snapshot=%ds, poll=%ds)",
               MathMax(1, PollIntervalSeconds), g_heartbeatPeriodS, g_snapshotPeriodS, MathMax(1, PollIntervalSeconds));

   // First-shot sends so the server sees us immediately. If any of these
   // fail, OnTimer retries on its own schedule.
   SendHeartbeatNow();
   SendAccountSnapshotNow();
   SendPositionsSnapshotNow();
   PollAndAckCommands();
   return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
   EventKillTimer();
   PrintFormat("[ARX] Deinitialized. reason=%d  timer_ticks=%I64d  heartbeats: attempts=%I64d ok=%I64d fail=%I64d",
               reason, g_timerTickCount, g_heartbeatAttempts, g_heartbeatSuccess, g_heartbeatFailure);
}

// Timer-driven bridge loop. This is the ONLY guaranteed cadence — it fires
// every PollIntervalSeconds regardless of incoming ticks. OnTick is no longer
// used for bridge work.
void OnTimer()
{
   g_timerTickCount++;
   // Use MONOTONIC VPS uptime (ms) for elapsed-time gates. Do NOT use
   // TimeCurrent() here — it returns broker-server time, which freezes on
   // weekends/holidays/closed sessions when no ticks arrive. That bug caused
   // v1.23 to fire OnTimer correctly but never re-issue heartbeats because
   // (now - g_lastHeartbeatAt) stayed at 0 for hours.
   ulong   nowMs        = GetTickCount64();
   ulong   hbPeriodMs   = (ulong)g_heartbeatPeriodS * 1000;
   ulong   snapPeriodMs = (ulong)g_snapshotPeriodS  * 1000;
   ulong   pollPeriodMs = (ulong)MathMax(1, PollIntervalSeconds) * 1000;

   if(VerboseDiagnostics && (g_timerTickCount % 10 == 1))
   {
      // Print VPS local wall clock (TimeLocal) for the diagnostic so it stays
      // sane on weekends; broker TimeCurrent() would print last Friday.
      PrintFormat("[ARX][TMR] tick #%I64d at %s (VPS local) — heartbeats ok=%I64d fail=%I64d, uptimeMs=%I64u (token withheld)",
                  g_timerTickCount, TimeToString(TimeLocal(), TIME_DATE|TIME_SECONDS),
                  g_heartbeatSuccess, g_heartbeatFailure, nowMs);
   }
   if(nowMs - g_lastHeartbeatMs    >= hbPeriodMs)   SendHeartbeatNow();
   if(nowMs - g_lastAccountSyncMs  >= snapPeriodMs) SendAccountSnapshotNow();
   if(nowMs - g_lastPositionSyncMs >= snapPeriodMs) SendPositionsSnapshotNow();
   if(nowMs - g_lastPollMs         >= pollPeriodMs) PollAndAckCommands();
}

void OnTick()
{
   // INTENTIONALLY EMPTY. The bridge is timer-driven (OnTimer above). Heartbeat
   // and command polls MUST NOT depend on chart ticks — many VPS charts are
   // attached to symbols whose market is closed (no ticks for hours), which
   // previously caused the bridge to go stale after the very first heartbeat.
   // Do NOT add any trading, execution, or close logic here. Read-only EA.
}
//+------------------------------------------------------------------+
