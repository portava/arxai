// artifacts/trading-dashboard/src/lib/chart-engine/smartChartAnnotationCanvas.ts
var record = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
var positive = (value) => typeof value === "number" && Number.isFinite(value) && value > 0;
var point = (value) => record(value) && positive(value.time) && positive(value.price);
var segment = (value) => record(value) && point(value.from) && point(value.to);
function cloneSmartChartAnnotation(input) {
  if (!record(input) || typeof input.id !== "string" || typeof input.color !== "string" || !/^#[a-f\d]{6}$/i.test(input.color) || typeof input.dashed !== "boolean" || !Array.isArray(input.anchors) || input.anchors.length > 8 || !input.anchors.every((anchor) => point(anchor) && typeof anchor.label === "string") || input.connectAnchors !== void 0 && typeof input.connectAnchors !== "boolean" || input.level !== void 0 && (!record(input.level) || !positive(input.level.price) || typeof input.level.label !== "string") || input.guide !== void 0 && !segment(input.guide) || input.segments !== void 0 && (!Array.isArray(input.segments) || input.segments.length > 3 || !input.segments.every((row) => segment(row) && row.from.time < row.to.time))) return null;
  return {
    id: input.id,
    color: input.color,
    dashed: input.dashed,
    anchors: input.anchors.map((anchor) => ({ time: anchor.time, price: anchor.price, label: anchor.label })),
    ...input.connectAnchors === void 0 ? {} : { connectAnchors: input.connectAnchors },
    ...input.level === void 0 ? {} : { level: { price: input.level.price, label: input.level.label } },
    ...input.guide === void 0 ? {} : { guide: { from: { ...input.guide.from }, to: { ...input.guide.to } } },
    ...input.segments === void 0 ? {} : { segments: input.segments.map((row) => ({ from: { ...row.from }, to: { ...row.to } })) }
  };
}
function paintSmartChartAnnotation(ctx, mediaSize, annotation, project) {
  if (!Number.isFinite(mediaSize.width) || !Number.isFinite(mediaSize.height) || mediaSize.width <= 0 || mediaSize.height <= 0) return;
  const a = cloneSmartChartAnnotation(annotation);
  if (!a || a.segments?.some((row) => [project.timeToX(row.from.time), project.timeToX(row.to.time)].some((value) => value === null || !Number.isFinite(value)))) return;
  const points = a.anchors.map((anchor) => {
    const x = project.timeToX(anchor.time), y = project.priceToY(anchor.price);
    return x != null && y != null && Number.isFinite(x) && Number.isFinite(y) ? { x, y, label: anchor.label } : null;
  });
  if (!points.length || points.some((point2) => point2 == null)) return;
  const p = points.filter((point2) => point2 != null);
  ctx.save();
  try {
    ctx.beginPath();
    ctx.rect(0, 0, mediaSize.width, mediaSize.height);
    ctx.clip();
    ctx.strokeStyle = a.color;
    ctx.fillStyle = a.color;
    ctx.lineWidth = 1.5;
    ctx.setLineDash(a.dashed ? [4, 4] : []);
    if (a.connectAnchors !== false) {
      ctx.beginPath();
      p.forEach((point2, i) => i ? ctx.lineTo(point2.x, point2.y) : ctx.moveTo(point2.x, point2.y));
      ctx.stroke();
    }
    for (const segment2 of a.segments ?? []) {
      const x1 = project.timeToX(segment2.from.time), x2 = project.timeToX(segment2.to.time);
      const y1 = project.priceToY(segment2.from.price), y2 = project.priceToY(segment2.to.price);
      if (x1 != null && x2 != null && y1 != null && y2 != null && [x1, x2, y1, y2].every(Number.isFinite)) {
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }
    }
    if (a.level && p.length > 1) {
      const y = project.priceToY(a.level.price);
      if (y != null && Number.isFinite(y)) {
        ctx.setLineDash([3, 5]);
        ctx.beginPath();
        ctx.moveTo(p[0].x, y);
        ctx.lineTo(p.at(-1).x, y);
        ctx.stroke();
      }
    }
    if (a.guide) {
      const x1 = project.timeToX(a.guide.from.time), x2 = project.timeToX(a.guide.to.time);
      const y1 = project.priceToY(a.guide.from.price), y2 = project.priceToY(a.guide.to.price);
      if (x1 != null && x2 != null && y1 != null && y2 != null && [x1, x2, y1, y2].every(Number.isFinite)) {
        ctx.setLineDash([3, 5]);
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }
    }
    ctx.setLineDash([]);
    ctx.font = "11px sans-serif";
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    const labels = [];
    for (const point2 of p) {
      if (point2.x < 0 || point2.x > mediaSize.width || point2.y < 0 || point2.y > mediaSize.height) continue;
      ctx.beginPath();
      ctx.arc(point2.x, point2.y, 3, 0, Math.PI * 2);
      ctx.fill();
      if (labels.length >= 3 || !point2.label) continue;
      const margin = 4, height = 16, maxWidth = mediaSize.width - 2 * margin;
      let label = point2.label.slice(0, 30);
      if (point2.label.length > 30) label = label.slice(0, -1) + "\u2026";
      while (label && ctx.measureText(label).width + 10 > maxWidth) {
        const body = label.endsWith("\u2026") ? label.slice(0, -1) : label;
        label = body.length > 1 ? body.slice(0, -1) + "\u2026" : "";
      }
      if (!label || mediaSize.height < height + 2 * margin) continue;
      const width = ctx.measureText(label).width + 10;
      const centeredX = Math.max(margin, Math.min(mediaSize.width - margin - width, point2.x - width / 2));
      const candidates = [
        { x: centeredX, y: point2.y - 24 },
        { x: centeredX, y: point2.y + 12 },
        { x: point2.x - width - 8, y: point2.y - height / 2 },
        { x: point2.x + 8, y: point2.y - height / 2 }
      ];
      const box = candidates.find((box2) => box2.x >= margin && box2.y >= margin && box2.x + width <= mediaSize.width - margin && box2.y + height <= mediaSize.height - margin && !labels.some((other) => box2.x < other.x + other.width + 4 && box2.x + width > other.x - 4 && box2.y < other.y + height + 4 && box2.y + height > other.y - 4) && !p.some((anchor) => box2.x < anchor.x + 5 && box2.x + width > anchor.x - 5 && box2.y < anchor.y + 5 && box2.y + height > anchor.y - 5));
      if (!box) continue;
      labels.push({ ...box, width });
      ctx.fillStyle = "#09090be8";
      ctx.fillRect(box.x, box.y, width, height);
      ctx.fillStyle = a.color;
      ctx.fillText(label, box.x + 5, box.y + 12);
    }
  } finally {
    ctx.restore();
  }
}
export {
  cloneSmartChartAnnotation,
  paintSmartChartAnnotation
};
