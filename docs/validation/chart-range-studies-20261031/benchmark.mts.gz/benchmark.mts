import { performance } from 'node:perf_hooks';
import { StudyCalculator as Baseline } from '/Users/areyouok/arx-chart-volume-evidence-20261031/artifacts/trading-dashboard/src/lib/chart-engine/chartStudies.ts';
import { StudyCalculator as Candidate } from '/Users/areyouok/arx-chart-range-studies-20261031/artifacts/trading-dashboard/src/lib/chart-engine/chartStudies.ts';
const data=Array.from({length:50000},(_,i)=>({time:1700000000+i*60,open:100+Math.sin(i/7),high:102+Math.sin(i/11),low:98+Math.cos(i/13),close:100+Math.cos(i/17)}));
const rows=[];
for(const kind of ['stochastic','williams'] as const)for(const period of [14,1000]){
 const config={kind,period,color:'#ffffff',smoothing:3,signal:3};
 const expected=new Baseline(config).calculate(data);const actual=new Candidate(config).calculate(data);
 if(JSON.stringify(expected)!==JSON.stringify(actual))throw Error('baseline mismatch');
 for(const n of [200,50000]){
  const bars=data.slice(0,n), samples={baseline:[] as number[],candidate:[] as number[]};
  for(let round=0;round<7;round++)for(const label of round%2?['candidate','baseline']:['baseline','candidate']){
   const C=label==='baseline'?Baseline:Candidate;global.gc?.();const calc=new C(config);const started=performance.now();calc.calculate(bars,0,false);const elapsed=performance.now()-started;
   if(round>=2)samples[label as keyof typeof samples].push(elapsed);
  }
  const summarize=(a:number[])=>{const s=[...a].sort((x,y)=>x-y);return{samples:a,median:s[2],max:s.at(-1),p95:s.at(-1),n:s.length};};
  rows.push({kind,period,bars:n,baseline:summarize(samples.baseline),candidate:summarize(samples.candidate)});
 }
}
console.log(JSON.stringify({node:process.version,baseline:'8c40032a',candidate:'cc542762d28209bf3a7e5e4eeccf7868d7f661b2',method:'Two warmups, five measured per variant alternating order, GC before each, construction excluded, calculate includes all study state/points; exact full-series equality required. Local Node synthetic data; not browser or competitor timings.',rows},null,2));
