async page => { const SCANNER_QA_EXPECTED_COMMIT='f1a47fcc791742a2c7e6ed20451a65f60bcce479'; const SCANNER_QA_OUTPUT_PREFIX='/Users/areyouok/arx-tier1-release/chart-range-studies-20261031/donchian-accepted'; return await (async page => {
 const report={passed:false,checks:[],samples:[],screenshots:[],failure:null};
 const check=(ok,label)=>{report.checks.push({label,pass:!!ok});if(!ok)throw Error(label);};
 const frames=()=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 const panel=page.getByTestId('scanner-chart-panel');
 const button=name=>panel.getByRole('button',{name,exact:true});
 const verify=async(period,label)=>{
  await frames();
  const current=await page.evaluate(()=>({state:window.__arxChartQa.snapshot(),data:window.__arxChartQa.data(),config:window.__arxChartQa.configuration(),log:window.__readFixtureLog?null:undefined}));
  const logs=await page.evaluate(()=>window.__readFixtureLog());
  const response=logs.candleResponses.filter(r=>r.requestPath==='/api/chart/candles'&&r.symbol==='EURUSD'&&r.timeframe==='M15'&&r.canonical.length===200).at(-1);
  check(response&&JSON.stringify(current.data.canonical)===JSON.stringify(response.canonical),label+' canonical source equality');
  const c=current.data.canonical,study=current.config.studies.find(s=>s.config.kind==='donchian');
  check(study?.config.period===period&&study.lines.length===3,label+' three installed series');
  for(let channel=0;channel<3;channel++){
   const expected=c.slice(period-1).map((bar,i)=>{const slice=c.slice(i,i+period),hi=Math.max(...slice.map(b=>b.high)),lo=Math.min(...slice.map(b=>b.low));return{time:bar.time,value:channel===0?hi/2+lo/2:channel===1?hi:lo};});
   const actual=study.lines[channel];
   check(actual.length===expected.length&&actual.every((p,i)=>p.time===expected[i].time&&Math.abs(p.value-expected[i].value)<1e-10),label+' plotted channel '+channel+' full-window oracle');
  }
  check(logs.errors.length===0,label+' no page exceptions');
  report.samples.push({label,period,state:current.state,lines:study.lines,canonical:c,consoleErrors:logs.consoleErrors,unknownReads:logs.unknown});
 };
 try{
  await page.setViewportSize({width:1440,height:1100});await page.goto('http://127.0.0.1:4199/market-scanner');
  report.build=await page.evaluate(async()=>fetch('/arx-scanner-qa-build-info.json').then(r=>r.json()));
  check(report.build.source.head===SCANNER_QA_EXPECTED_COMMIT&&report.build.sourceUnchanged&&!report.build.source.status,'Exact clean source fixture');
  await panel.getByTestId('arx-native-tf-M15').click();await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.barCount===200&&window.__arxChartQa?.snapshot()?.intervalSeconds===900);
  await button('Studies (0)').click();await page.getByLabel('Search studies',{exact:true}).fill('Donchian');await button('Add Donchian Channels').click();
  check(await page.getByLabel('DONCHIAN 1 Period',{exact:true}).inputValue()==='20','Default period20');
  check(await page.getByLabel('DONCHIAN 1 Source',{exact:true}).count()===0,'No misleading applied-price input');
  await button('Studies (1)').click();await verify(20,'desktop default');
  await button('Studies (1)').click();await page.getByLabel('DONCHIAN 1 Period',{exact:true}).fill('5');await page.getByLabel('DONCHIAN 1 Period',{exact:true}).blur();await button('Studies (1)').click();await verify(5,'desktop edited');
  await panel.scrollIntoViewIfNeeded();await page.screenshot({path:SCANNER_QA_OUTPUT_PREFIX+'-desktop.png'});report.screenshots.push(SCANNER_QA_OUTPUT_PREFIX+'-desktop.png');
  await page.reload();await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.barCount===200&&window.__arxChartQa?.configuration()?.studies?.some(s=>s.config.kind==='donchian'));
  await verify(5,'document reload');
  await page.setViewportSize({width:390,height:844});await frames();await verify(5,'mobile');
  check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'No mobile document overflow');
  await panel.scrollIntoViewIfNeeded();await page.screenshot({path:SCANNER_QA_OUTPUT_PREFIX+'-mobile.png'});report.screenshots.push(SCANNER_QA_OUTPUT_PREFIX+'-mobile.png');
  report.passed=true;
 }catch(e){report.failure=String(e?.stack??e);}
 return report;
}
)(page); }