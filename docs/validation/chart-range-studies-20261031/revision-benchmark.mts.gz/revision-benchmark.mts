import { performance } from 'node:perf_hooks';
import { StudyCalculator as Baseline } from '/Users/areyouok/arx-chart-volume-evidence-20261031/artifacts/trading-dashboard/src/lib/chart-engine/chartStudies.ts';
import { StudyCalculator as Candidate } from '/Users/areyouok/arx-chart-range-studies-20261031/artifacts/trading-dashboard/src/lib/chart-engine/chartStudies.ts';
const rows=[];
for(const kind of ['stochastic','williams'] as const)for(const period of [14,1000])for(const count of [200,50000]){
 const samples={baseline:[] as number[],candidate:[] as number[]};
 for(let round=0;round<7;round++)for(const label of round%2?['candidate','baseline']:['baseline','candidate']){
  const bars=Array.from({length:count},(_,i)=>({time:1700000000+i*60,open:100,high:102+Math.sin(i/11),low:98+Math.cos(i/13),close:100}));
  const config={kind,period,color:'#ffffff',smoothing:3,signal:3};const C=label==='baseline'?Baseline:Candidate;
  const calc=new C(config);calc.calculate(bars,0,false);global.gc?.();
  const started=performance.now();
  for(let n=0;n<100;n++){
   bars[count-1]={...bars[count-1]!,high:103+n/1000,low:97-n/1000,close:100+n/2000};calc.calculate(bars,count-1,false);
  }
  const elapsed=performance.now()-started;
  if(round>=2)samples[label as keyof typeof samples].push(elapsed);
  if(JSON.stringify(calc.points)!==JSON.stringify(new Baseline(config).calculate(bars)))throw Error('revision equality mismatch');
 }
 const summarize=(a:number[])=>{const s=[...a].sort((x,y)=>x-y);return{batchMilliseconds:a,medianBatchMs:s[2],maxBatchMs:s.at(-1),updatesPerBatch:100};};
 rows.push({kind,period,bars:count,baseline:summarize(samples.baseline),candidate:summarize(samples.candidate)});
}
console.log(JSON.stringify({node:process.version,method:'Two warmups, five retained100-update batches per variant; alternating order; setup and GC excluded. All final arrays match baseline. Local synthetic Node only.',rows},null,2));
