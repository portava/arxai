async page => { const log = await page.evaluate(()=>window.__readFixtureLog()); return { errors:log.errors, blocked:log.blocked }; }
