async page=>{await page.evaluate(  function installNoteObserver() {
    if(window.__arxNotesQa)throw Error('Use a fresh note observer/session');
    const clicks=[],textDraws=new Map();
    const canvasPrototype=CanvasRenderingContext2D.prototype,originalFillText=canvasPrototype.fillText;
    function observedFillText(...args) {
      const result=originalFillText.apply(this,args);
      if(this.canvas?.closest?.('[data-testid="scanner-chart-panel"] [data-testid="arx-native-canvas"]')) {
        const text=String(args[0]);
        if(!textDraws.has(text)&&textDraws.size>=4096)textDraws.delete(textDraws.keys().next().value);
        textDraws.set(text,(textDraws.get(text)??0)+1);
      }
      return result;
    }
    canvasPrototype.fillText=observedFillText;
    function engine() {
      const container=document.querySelector('[data-testid="scanner-chart-panel"] [data-testid="arx-native-canvas"]');
      if(!container)throw Error('Scanner native canvas absent');
      const key=Object.keys(container).find(key=>key.startsWith('__reactFiber$'));
      let fiber=container[key],steps=0;
      while(fiber&&!fiber.memoizedProps?.externalFeed&&steps++<100)fiber=fiber.return;
      let hook=fiber?.memoizedState,adapter;steps=0;
      while(hook&&steps++<100){if(hook.memoizedState?.current?.getScannerOverlaySurface){adapter=hook.memoizedState.current;break;}hook=hook.next;}
      if(!adapter||adapter.container!==container)throw Error('Active Scanner adapter binding unavailable');
      const surface=adapter.getScannerOverlaySurface();
      if(!surface||surface.chart!==adapter.chart||surface.series!==adapter.series||surface.container!==container)throw Error('Scanner surface binding differs');
      return {adapter,container};
    }
    const down=event=>{
      if(!(event.target instanceof HTMLCanvasElement))return;
      const {adapter,container}=engine();
      if(!container.contains(event.target))return;
      const bounds=container.getBoundingClientRect(),x=event.clientX-bounds.left,y=event.clientY-bounds.top;
      clicks.push({trusted:event.isTrusted,pointerType:event.pointerType,button:event.button,x,y,time:adapter.chart.timeScale().coordinateToTime(x),price:adapter.series.coordinateToPrice(y)});
    };
    document.addEventListener('pointerdown',down,true);
    const api={
      read(){
        const {adapter}=engine(),primitive=adapter.analysis?.drawingPrimitive;
        if(primitive&&(primitive.attachment?.chart!==adapter.chart||primitive.attachment?.series!==adapter.series))throw Error('Drawing primitive detached from active price series');
        return {drawings:primitive?.drawings??[],notes:primitive?.notes??[],dirty:primitive?.dirty??false,
          projected:(primitive?.drawings??[]).filter(d=>d.kind==='text').map(d=>({id:d.id,x:adapter.chart.timeScale().timeToCoordinate(d.start.time),y:adapter.series.priceToCoordinate(d.start.price)})),
          pane:{width:adapter.chart.timeScale().width(),height:adapter.series.getPane().getHeight()},clicks:[...clicks],textDraws:Object.fromEntries(textDraws)};
      },
      target(){
        const {adapter}=engine(),range=adapter.chart.timeScale().getVisibleLogicalRange();
        if(!range||!adapter.candles.length)throw Error('No current chart range');
        const candle=adapter.candles[Math.max(0,Math.min(adapter.candles.length-1,Math.round((range.from+range.to)/2)))];
        return {x:adapter.chart.timeScale().timeToCoordinate(candle.time),y:adapter.series.priceToCoordinate(candle.close),time:candle.time,price:candle.close};
      },
      resetTextDraws(){textDraws.clear();},
      stop(){
        document.removeEventListener('pointerdown',down,true);if(window.__arxNotesQa===api)delete window.__arxNotesQa;
        if(canvasPrototype.fillText!==observedFillText)throw Error('Canvas text observer ownership changed before restoration');
        canvasPrototype.fillText=originalFillText;
      },
    };
    window.__arxNotesQa=api;
  });try{return await page.evaluate(()=>({surface:window.__arxNotesQa.read(),state:window.__arxChartQa.snapshot()}));}finally{await page.evaluate(()=>window.__arxNotesQa.stop());}}