import { mock } from 'node:test';
mock.module('/Users/areyouok/arx-chart-support-resistance-20261101/artifacts/api-server/src/lib/marketSimulator.ts', {
 namedExports: {marketSimulator: new Proxy({}, {get(_target,key){throw new Error(`Unexpected simulator access in offline evidence tests: ${String(key)}`);}})}
});
