// artifacts/trading-dashboard/src/lib/chart-engine/chartStudies.ts
var STUDY_CATALOG = [
  { name: "Simple moving average", group: "Trend", description: "Equal weight over the selected period.", defaults: { kind: "sma", period: 20, color: "#fbbf24" }, channels: ["SMA"], pane: false, appliedPrice: true },
  { name: "Exponential moving average", group: "Trend", description: "Recent prices carry more weight; seeded with an SMA.", defaults: { kind: "ema", period: 50, color: "#38bdf8" }, channels: ["EMA"], pane: false, appliedPrice: true },
  { name: "Bollinger Bands", group: "Volatility", description: "SMA basis with population standard deviation bands.", defaults: { kind: "bollinger", period: 20, multiplier: 2, color: "#a78bfa" }, channels: ["Basis", "Upper", "Lower"], pane: false, appliedPrice: true },
  { name: "Relative strength index", group: "Momentum", description: "Wilder smoothing of gains and losses; flat markets read 50.", defaults: { kind: "rsi", period: 14, color: "#e879f9" }, channels: ["RSI"], pane: true, appliedPrice: true, levels: [30, 70], range: [0, 100] },
  { name: "MACD", group: "Momentum", description: "Fast minus slow EMA. Choose EMA or MT5-style SMA signal smoothing.", defaults: { kind: "macd", period: 12, slow: 26, signal: 9, color: "#2dd4bf" }, channels: ["MACD", "Signal", "Histogram"], pane: true, appliedPrice: true, levels: [0] },
  { name: "Smoothed moving average", group: "Trend", description: "Wilder / RMA smoothing with weight 1 \xF7 period.", defaults: { kind: "smma", period: 20, color: "#fb923c" }, channels: ["SMMA"], pane: false, appliedPrice: true },
  { name: "Weighted moving average", group: "Trend", description: "Linear weights; the newest bar has the largest weight.", defaults: { kind: "wma", period: 20, color: "#4ade80" }, channels: ["WMA"], pane: false, appliedPrice: true },
  { name: "Double exponential moving average", group: "Trend", description: "2 \xD7 EMA minus EMA of EMA; each stage warms up separately.", defaults: { kind: "dema", period: 20, color: "#f472b6" }, channels: ["DEMA"], pane: false, appliedPrice: true },
  { name: "Triple exponential moving average", group: "Trend", description: "3 \xD7 EMA \u2212 3 \xD7 EMA\xB2 + EMA\xB3; three seeded stages.", defaults: { kind: "tema", period: 20, color: "#818cf8" }, channels: ["TEMA"], pane: false, appliedPrice: true },
  { name: "Average true range", group: "Volatility", description: "Range including gaps from the previous close. Select smoothing.", defaults: { kind: "atr", period: 14, method: "smma", color: "#fb923c" }, channels: ["ATR"], pane: true, appliedPrice: false },
  { name: "Commodity channel index", group: "Momentum", description: "Distance from the mean divided by 0.015 \xD7 mean absolute deviation.", defaults: { kind: "cci", period: 20, source: "hlc3", color: "#38bdf8" }, channels: ["CCI"], pane: true, appliedPrice: true, levels: [-100, 0, 100] },
  { name: "Stochastic oscillator", group: "Momentum", description: "SMA-smoothed %K in the high/low range, followed by an SMA %D.", defaults: { kind: "stochastic", period: 14, smoothing: 3, signal: 3, color: "#2dd4bf" }, channels: ["%K", "%D"], pane: true, appliedPrice: false, levels: [20, 80], range: [0, 100] },
  { name: "Williams percent range", group: "Momentum", description: "Close within the lookback high/low range, from \u2212100 to 0.", defaults: { kind: "williams", period: 14, color: "#fbbf24" }, channels: ["%R"], pane: true, appliedPrice: false, levels: [-80, -20], range: [-100, 0] },
  { name: "Standard deviation", group: "Volatility", description: "Population deviation around the selected price's simple mean.", defaults: { kind: "stddev", period: 20, color: "#a78bfa" }, channels: ["Deviation"], pane: true, appliedPrice: true },
  { name: "Moving average envelopes", group: "Trend", description: "Percentage bands above and below a configurable moving average.", defaults: { kind: "envelopes", period: 20, multiplier: 1, method: "sma", color: "#f472b6" }, channels: ["Basis", "Upper", "Lower"], pane: false, appliedPrice: true },
  { name: "Momentum ratio", group: "Momentum", description: "Current price \xF7 price N bars ago \xD7 100 (MT5 convention).", defaults: { kind: "momentum", period: 14, color: "#4ade80" }, channels: ["Momentum"], pane: true, appliedPrice: true, levels: [100] },
  { name: "Rate of change", group: "Momentum", description: "Percentage price change over N bars.", defaults: { kind: "roc", period: 14, color: "#fbbf24" }, channels: ["ROC %"], pane: true, appliedPrice: true, levels: [0] },
  { name: "Donchian Channels", group: "Volatility", description: "Highest high, lowest low and their midpoint over the selected bars, including the forming bar. Requires a full window; channel contact alone is not a breakout signal.", defaults: { kind: "donchian", period: 20, color: "#38bdf8" }, channels: ["Midpoint", "Upper", "Lower"], pane: false, appliedPrice: false },
  { name: "Directional movement (DMI / ADX)", group: "Trend", description: "Wilder-smoothed +DI and \u2212DI show directional movement; ADX measures strength, not direction or confidence. Separate DI and ADX lengths; tied moves count as zero. Not a trade signal.", defaults: { kind: "dmi", period: 14, signal: 14, color: "#38bdf8" }, channels: ["+DI", "\u2212DI", "ADX"], pane: true, appliedPrice: false, range: [0, 100] },
  { name: "Tick volume", group: "Volume", description: "Explicit MT5 per-bar tick counts, not traded size. Only source-qualified observations are plotted; missing or partial streaming evidence stays blank, never zero-filled. No real traded-volume data is inferred.", defaults: { kind: "tick_volume", period: 1, color: "#38bdf8" }, channels: ["Ticks"], pane: true, appliedPrice: false },
  { name: "Anchored VWAP", group: "Volume", description: "Cumulative original bar price \xD7 provider-reported trade units / cumulative trade units, from an exact observed bar. HLC3 by default. Loaded observations only, not a full session or trade-by-trade average. Missing/zero/unqualified volume holds the remaining interval; no tick proxy.", defaults: { kind: "vwap", period: 1, source: "hlc3", color: "#fbbf24" }, channels: ["VWAP"], pane: false, appliedPrice: true },
  { name: "Trade volume", group: "Volume", description: "Qualified provider-reported trade units per original closed bar. These are not tick counts, proven shares or consolidated-market volume. Missing/zero/unqualified quantities stay blank.", defaults: { kind: "trade_volume", period: 1, color: "#34d399" }, channels: ["Trade units"], pane: true, appliedPrice: false },
  { name: "Estimated volume profile", group: "Volume", description: "Fixed-range price bins estimate uniform volume across original candle ranges. Qualified provider trade units only; no tick substitute, observed executions-at-price or complete-session claim.", defaults: { kind: "volume_profile", period: 1, color: "#a78bfa", profileRows: 32, profileValueAreaPercent: 70 }, channels: ["Estimated trade units"], pane: false, appliedPrice: false }
];
var STUDY_DEFAULTS = ["sma", "ema", "bollinger", "rsi", "macd"].map((kind) => STUDY_CATALOG.find((item) => item.defaults.kind === kind).defaults);

// artifacts/trading-dashboard/src/lib/chart-engine/chartTextNote.ts
var MAX_NOTE_LENGTH = 240;
var MAX_NOTE_PARAGRAPHS = 6;
var NOTE_FONT = "12px sans-serif";
var NOTE_LINE_HEIGHT = 16;
var NOTE_PADDING = 8;
var NOTE_HEADER_HEIGHT = 18;
var NOTE_MAX_WIDTH = 220;
function normalizeNoteText(value) {
  if (typeof value !== "string" || value.length > MAX_NOTE_LENGTH) return null;
  const text = value.replace(/\r\n?/g, "\n").trim();
  if (!text || /[\u0000-\u0009\u000B-\u001F\u007F-\u009F\u202A-\u202E\u2066-\u2069]/u.test(text) || text.split("\n").length > MAX_NOTE_PARAGRAPHS) return null;
  return text;
}
var context = null;
var layouts = /* @__PURE__ */ new Map();
function measureNoteText(text) {
  context ??= typeof document === "undefined" ? null : document.createElement("canvas").getContext("2d");
  if (context) {
    context.font = NOTE_FONT;
    return context.measureText(text).width;
  }
  return Array.from(text).length * 12;
}
function layoutTextNote(value, width, measure = measureNoteText) {
  const text = normalizeNoteText(value);
  if (text == null || !Number.isFinite(width) || width < 40) return null;
  const boxWidth = Math.min(NOTE_MAX_WIDTH, Math.floor(width));
  const cacheKey = `${boxWidth}:${text}`;
  if (measure === measureNoteText && layouts.has(cacheKey)) return layouts.get(cacheKey);
  const available = boxWidth - NOTE_PADDING * 2;
  const lines = [];
  const segmenter = new Intl.Segmenter(void 0, { granularity: "grapheme" });
  for (const paragraph of text.split("\n")) {
    if (measure(paragraph) <= available) {
      lines.push(paragraph);
      continue;
    }
    let line = "";
    for (const { segment } of segmenter.segment(paragraph)) {
      const next = line + segment;
      if (line && measure(next) > available) {
        const wordBreak = line.lastIndexOf(" ");
        if (wordBreak > 0) {
          lines.push(line.slice(0, wordBreak + 1));
          line = line.slice(wordBreak + 1) + segment;
        } else {
          lines.push(line);
          line = segment;
        }
      } else line = next;
    }
    lines.push(line);
  }
  const result = { lines: Object.freeze(lines), width: boxWidth, height: NOTE_PADDING * 2 + NOTE_HEADER_HEIGHT + lines.length * NOTE_LINE_HEIGHT };
  if (measure === measureNoteText) {
    if (layouts.size >= 128) layouts.delete(layouts.keys().next().value);
    layouts.set(cacheKey, result);
  }
  return result;
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartWorkspace.ts
var FIB_LEVELS = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1];
function drawingSegments(d) {
  if (!d.end) return [];
  if (["trend", "ray", "extended"].includes(d.kind)) return [{ start: d.start, end: d.end, label: "Trend" }];
  if (d.kind === "rectangle") return [
    { start: d.start, end: { time: d.end.time, price: d.start.price }, label: "" },
    { start: { time: d.end.time, price: d.start.price }, end: d.end, label: "" },
    { start: d.end, end: { time: d.start.time, price: d.end.price }, label: "" },
    { start: { time: d.start.time, price: d.end.price }, end: d.start, label: "" }
  ];
  if (d.kind !== "fibonacci") return [];
  return FIB_LEVELS.map((level) => {
    const price = d.start.price + (d.end.price - d.start.price) * level;
    return { start: { time: d.start.time, price }, end: { time: d.end.time, price }, label: `Fib ${(level * 100).toFixed(1)}%` };
  });
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartRangeMeasurement.ts
function rangeMeasurement(start, end) {
  if (![start.time, end.time, start.price, end.price].every(Number.isFinite) || start.time <= 0 || end.time <= 0 || start.price <= 0 || end.price <= 0) return null;
  const priceChange = end.price - start.price;
  const ratio = priceChange / start.price * 100;
  return { priceChange, percentChange: Number.isFinite(ratio) ? ratio : null, elapsedSeconds: Math.abs(end.time - start.time), backwards: end.time < start.time };
}
var signed = (value) => `${value > 0 ? "+" : ""}${Number(value.toPrecision(8))}`;
function measurementLabels(start, end) {
  const value = rangeMeasurement(start, end);
  if (!value) return [];
  let remaining = value.elapsedSeconds;
  const parts = [];
  for (const [seconds, label] of [[86400, "d"], [3600, "h"], [60, "m"]]) {
    const amount = Math.floor(remaining / seconds);
    remaining -= amount * seconds;
    if (amount) parts.push(`${amount}${label}`);
  }
  if (remaining || !parts.length) parts.push(`${Number(remaining.toFixed(3))}s`);
  return [
    `Price ${signed(value.priceChange)} (${value.percentChange === null ? "percentage unavailable" : signed(value.percentChange) + "%"})`,
    `${parts.join(" ")} elapsed${value.backwards ? " \xB7 earlier" : ""}`
  ];
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartDrawingCanvas.ts
function drawingNotes(drawings, project, width, height, measure) {
  const notes = [];
  if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height < NOTE_PADDING * 2 + NOTE_LINE_HEIGHT + 8) return notes;
  for (const drawing of drawings) {
    if (drawing.hidden || drawing.kind !== "text") continue;
    const point = project(drawing.start);
    if (!point || !Number.isFinite(point.x) || !Number.isFinite(point.y) || point.x < 0 || point.x > width || point.y < 0 || point.y > height) continue;
    const layout = layoutTextNote(drawing.text ?? "", width - 8, measure);
    if (!layout) continue;
    const availableHeight = height - 8;
    const truncated = layout.height > availableHeight;
    const compact = truncated && availableHeight < NOTE_PADDING * 2 + NOTE_HEADER_HEIGHT + NOTE_LINE_HEIGHT;
    const maxLines = Math.max(0, Math.floor((availableHeight - NOTE_PADDING * 2 - NOTE_HEADER_HEIGHT - NOTE_LINE_HEIGHT) / NOTE_LINE_HEIGHT));
    const lines = truncated ? layout.lines.slice(0, compact ? 0 : maxLines) : layout.lines;
    const noteHeight = !truncated ? layout.height : compact ? NOTE_PADDING * 2 + NOTE_LINE_HEIGHT : NOTE_PADDING * 2 + NOTE_HEADER_HEIGHT + (lines.length + 1) * NOTE_LINE_HEIGHT;
    notes.push({
      ...layout,
      lines,
      height: noteHeight,
      truncated,
      compact,
      id: drawing.id,
      anchor: point,
      color: drawing.color,
      x: Math.max(4, Math.min(point.x + 8, width - layout.width - 4)),
      y: Math.max(4, Math.min(point.y + 8, height - noteHeight - 4))
    });
  }
  return notes;
}
function drawingStrokes(drawings, project, width, height = 0) {
  const strokes = [];
  for (const drawing of drawings) {
    if (drawing.hidden) continue;
    const style = { id: drawing.id, color: drawing.color, width: drawing.width ?? 1, dashed: drawing.dashed ?? ["horizontal", "fibonacci"].includes(drawing.kind) };
    if (drawing.kind === "horizontal") {
      const start = project(drawing.start, true);
      if (start) strokes.push({ ...style, start: { x: 0, y: start.y }, end: { x: width, y: start.y } });
      continue;
    }
    if (drawing.kind === "vertical") {
      const point = project(drawing.start);
      if (point) strokes.push({ ...style, start: { x: point.x, y: 0 }, end: { x: point.x, y: height } });
      continue;
    }
    if (drawing.kind === "measure") {
      const start = project(drawing.start), end = drawing.end && project(drawing.end);
      if (!start || !end || !drawing.end) continue;
      const corner = { x: end.x, y: start.y };
      strokes.push(
        { ...style, start, end, measurement: measurementLabels(drawing.start, drawing.end) },
        { ...style, dashed: true, start, end: corner },
        { ...style, dashed: true, start: corner, end }
      );
      continue;
    }
    if (drawing.kind === "channel") {
      const start = project(drawing.start), end = drawing.end && project(drawing.end), offset = drawing.offset && project(drawing.offset);
      if (!start || !end || !offset || Math.abs(end.x - start.x) < 1e-3) continue;
      const shift = offset.y - (start.y + (end.y - start.y) * (offset.x - start.x) / (end.x - start.x));
      if (!Number.isFinite(shift)) continue;
      const slope = (end.y - start.y) / (end.x - start.x);
      const left = Math.min(start.x, end.x), right = Math.max(start.x, end.x);
      const x1 = drawing.extendLeft ? Math.min(0, left) : left;
      const x2 = drawing.extendRight ? Math.max(width, right) : right;
      const at = (x, delta = 0) => ({ x, y: start.y + slope * (x - start.x) + delta });
      const from = start.x <= end.x ? x1 : x2, to = start.x <= end.x ? x2 : x1;
      const first = { start: at(from), end: at(to) }, second = { start: at(from, shift), end: at(to, shift) };
      if (![first.start.y, first.end.y, second.start.y, second.end.y].every(Number.isFinite)) continue;
      strokes.push({ ...style, ...first }, { ...style, ...second });
      if (drawing.middleLine) strokes.push({ ...style, dashed: true, start: at(from, shift / 2), end: at(to, shift / 2) });
      continue;
    }
    for (const segment of drawingSegments(drawing)) {
      let start = project(segment.start), end = project(segment.end);
      if (!start || !end) continue;
      if (["ray", "extended"].includes(drawing.kind)) {
        const dx = end.x - start.x;
        if (Math.abs(dx) < 1e-3) continue;
        const slope = (end.y - start.y) / dx;
        const at = (x) => ({ x, y: start.y + slope * (x - start.x) });
        end = at(dx > 0 ? width : 0);
        if (drawing.kind === "extended") start = at(dx > 0 ? 0 : width);
      }
      strokes.push({ ...style, start, end, ...drawing.kind === "fibonacci" ? { label: segment.label } : {} });
    }
  }
  return strokes;
}
function drawingHandles(drawing, project, width, height) {
  if (drawing.hidden) return [];
  const start = project(drawing.start, drawing.kind === "horizontal");
  if (!start) return [];
  if (drawing.kind === "horizontal") return [{ part: "start", point: { x: width / 2, y: start.y } }];
  if (drawing.kind === "vertical") return [{ part: "start", point: { x: start.x, y: height / 2 } }];
  if (drawing.kind === "text") return [{ part: "start", point: start }];
  const end = drawing.end && project(drawing.end);
  if (!end) return [];
  if (drawing.kind === "channel") {
    const offset = drawing.offset && project(drawing.offset);
    return offset ? [{ part: "start", point: start }, { part: "end", point: end }, { part: "offset", point: offset }] : [];
  }
  return [{ part: "start", point: start }, { part: "end", point: end }];
}
function hitTestDrawings(drawings, selected, project, width, height, point, tolerance = 8) {
  const active = drawings.find((drawing) => drawing.id === selected && !drawing.hidden);
  if (active && !active.locked) for (const handle of drawingHandles(active, project, width, height)) {
    if (Math.hypot(point.x - handle.point.x, point.y - handle.point.y) <= tolerance + 2) return { id: active.id, part: handle.part };
  }
  for (const note of drawingNotes(drawings, project, width, height).reverse()) {
    if (point.x >= note.x && point.x <= note.x + note.width && point.y >= note.y && point.y <= Math.min(height, note.y + note.height)) return { id: note.id, part: "body" };
    if (Math.hypot(point.x - note.anchor.x, point.y - note.anchor.y) <= tolerance) return { id: note.id, part: "body" };
  }
  for (const stroke of drawingStrokes(drawings, project, width, height).reverse()) {
    const dx = stroke.end.x - stroke.start.x, dy = stroke.end.y - stroke.start.y;
    const length = dx * dx + dy * dy;
    const fraction = length ? Math.max(0, Math.min(1, ((point.x - stroke.start.x) * dx + (point.y - stroke.start.y) * dy) / length)) : 0;
    if (Math.hypot(point.x - stroke.start.x - dx * fraction, point.y - stroke.start.y - dy * fraction) <= tolerance + stroke.width / 2) return { id: stroke.id, part: "body" };
  }
  return null;
}
function paintChartDrawings(ctx, size, strokes, notes, handles) {
  ctx.save();
  try {
    ctx.beginPath();
    ctx.rect(0, 0, size.width, size.height);
    ctx.clip();
    ctx.font = "10px sans-serif";
    for (const stroke of strokes) {
      if (Math.max(stroke.start.x, stroke.end.x) < 0 || Math.min(stroke.start.x, stroke.end.x) > size.width) continue;
      if (Math.max(stroke.start.y, stroke.end.y) < 0 || Math.min(stroke.start.y, stroke.end.y) > size.height) continue;
      ctx.strokeStyle = stroke.color;
      ctx.fillStyle = stroke.color;
      ctx.lineWidth = stroke.width;
      ctx.setLineDash(stroke.dashed ? [4, 4] : []);
      ctx.beginPath();
      ctx.moveTo(stroke.start.x, stroke.start.y);
      ctx.lineTo(stroke.end.x, stroke.end.y);
      ctx.stroke();
      if (stroke.measurement?.length && size.width >= 100 && size.height >= 44) {
        const width = Math.min(size.width - 8, Math.max(...stroke.measurement.map((line) => ctx.measureText(line).width)) + 12);
        const height = stroke.measurement.length * 14 + 8;
        const x = Math.max(4, Math.min(stroke.end.x + 8, size.width - width - 4));
        const y = Math.max(4, Math.min(stroke.end.y + 8, size.height - height - 4));
        ctx.save();
        try {
          ctx.fillStyle = "#09090bee";
          ctx.fillRect(x, y, width, height);
          ctx.beginPath();
          ctx.rect(x, y, width, height);
          ctx.clip();
          ctx.fillStyle = stroke.color;
          stroke.measurement.forEach((line, index) => ctx.fillText(line, x + 6, y + 14 + index * 14));
        } finally {
          ctx.restore();
        }
      }
      if (stroke.label) {
        const left = stroke.start.x < stroke.end.x ? stroke.start : stroke.end;
        ctx.fillText(stroke.label, Math.max(3, left.x + 3), left.y - 3);
      }
    }
    ctx.font = NOTE_FONT;
    ctx.textBaseline = "top";
    ctx.textAlign = "left";
    for (const note of notes) {
      ctx.setLineDash([]);
      ctx.lineWidth = 1;
      ctx.strokeStyle = note.color;
      ctx.beginPath();
      ctx.moveTo(note.anchor.x, note.anchor.y);
      ctx.lineTo(note.x, note.y);
      ctx.stroke();
      ctx.fillStyle = "#18181bee";
      ctx.fillRect(note.x, note.y, note.width, note.height);
      ctx.strokeRect(note.x, note.y, note.width, note.height);
      ctx.fillStyle = note.color;
      ctx.fillText(note.compact ? "Your note \xB7 Objects" : "Your note", note.x + NOTE_PADDING, note.y + NOTE_PADDING, note.width - NOTE_PADDING * 2);
      ctx.fillStyle = "#f4f4f5";
      note.lines.forEach((line, index) => ctx.fillText(line, note.x + NOTE_PADDING, note.y + NOTE_PADDING + NOTE_HEADER_HEIGHT + index * NOTE_LINE_HEIGHT, note.width - NOTE_PADDING * 2));
      if (note.truncated && !note.compact) {
        ctx.fillStyle = note.color;
        ctx.fillText("More in Objects", note.x + NOTE_PADDING, note.y + NOTE_PADDING + NOTE_HEADER_HEIGHT + note.lines.length * NOTE_LINE_HEIGHT, note.width - NOTE_PADDING * 2);
      }
      ctx.beginPath();
      ctx.arc(note.anchor.x, note.anchor.y, 3, 0, Math.PI * 2);
      ctx.fillStyle = note.color;
      ctx.fill();
    }
    ctx.setLineDash([]);
    ctx.lineWidth = 2;
    ctx.strokeStyle = "#38bdf8";
    ctx.fillStyle = "#09090b";
    for (const point of handles) {
      ctx.beginPath();
      ctx.arc(point.x, point.y, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
  } finally {
    ctx.restore();
  }
}
export {
  drawingHandles,
  drawingNotes,
  drawingStrokes,
  hitTestDrawings,
  paintChartDrawings
};
