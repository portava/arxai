// artifacts/trading-dashboard/src/lib/chart-engine/candleSanitize.ts
function isValidCandlestickPoint(p) {
  return Number.isFinite(p.time) && p.time > 0 && Number.isFinite(p.open) && Number.isFinite(p.high) && Number.isFinite(p.low) && Number.isFinite(p.close) && p.high >= Math.max(p.open, p.close, p.low) && p.low <= Math.min(p.open, p.close, p.high);
}
function sanitizeCandlestickData(points) {
  const valid2 = points.filter(isValidCandlestickPoint);
  if (valid2.every((p, i) => i === 0 || p.time > valid2[i - 1].time)) return valid2;
  return [...new Map(valid2.map((p) => [p.time, p])).values()].sort((a, b) => a.time - b.time);
}

// artifacts/trading-dashboard/src/lib/chart-engine/heikinAshi.ts
var HOLLOW_UP_COLOR = "#10b981";
var HOLLOW_DOWN_COLOR = "#ef4444";
var HOLLOW_BODY = "transparent";
function heikinAshiBar(candle, previous) {
  const close = (candle.open + candle.high + candle.low + candle.close) / 4;
  const open = previous ? (previous.open + previous.close) / 2 : (candle.open + candle.close) / 2;
  return { time: candle.time, open, high: Math.max(candle.high, open, close), low: Math.min(candle.low, open, close), close };
}
function heikinAshiSuffix(candles, cache, from) {
  const start = Math.max(0, Math.min(Number.isFinite(from) ? Math.floor(from) : 0, cache.length, candles.length));
  cache.length = start;
  for (let i = start; i < candles.length; i++) cache.push(heikinAshiBar(candles[i], i > 0 ? cache[i - 1] : null));
  return cache;
}
function heikinAshi(candles) {
  return heikinAshiSuffix(candles, [], 0);
}
function hollowPoint(candle, previousClose) {
  const up = previousClose == null ? candle.close >= candle.open : candle.close >= previousClose;
  const colour = up ? HOLLOW_UP_COLOR : HOLLOW_DOWN_COLOR;
  return { ...candle, color: candle.close >= candle.open ? HOLLOW_BODY : colour, borderColor: colour, wickColor: colour };
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartVolume.ts
function observedTickVolume(evidence) {
  if (!evidence || typeof evidence !== "object") return null;
  const value = evidence;
  return value.kind === "tick_count" && value.unit === "ticks" && value.reason === null && typeof value.quantity === "number" && Number.isSafeInteger(value.quantity) && value.quantity >= 0 ? value.quantity : null;
}
var TRADE_VOLUME_AUTHORITY = "twelve-data:time-series:common-stock:regular-unadjusted:v1";
function observedTradeVolumeIdentity(evidence) {
  if (!evidence || typeof evidence !== "object") return null;
  const value = evidence;
  return value.kind === "real_volume" && value.unit === "provider_trade_units" && value.reason === null && value.authority === TRADE_VOLUME_AUTHORITY && typeof value.seriesIdentity === "string" && /^[a-f0-9]{64}$/.test(value.seriesIdentity) && typeof value.quantity === "number" && Number.isSafeInteger(value.quantity) && value.quantity > 0 ? value.seriesIdentity : null;
}
function observedTradeVolume(evidence) {
  const identity = observedTradeVolumeIdentity(evidence);
  return identity ? { quantity: evidence.quantity, seriesIdentity: identity } : null;
}
function volumeInputQuantity(evidence) {
  return observedTickVolume(evidence) ?? (observedTradeVolumeIdentity(evidence) ? evidence.quantity : -1);
}
function sameVolumeInput(a, b) {
  return volumeInputQuantity(a) === volumeInputQuantity(b) && observedTradeVolumeIdentity(a) === observedTradeVolumeIdentity(b);
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartTimeZone.ts
var CHART_TIME_ZONES = [
  "UTC",
  "local",
  "America/New_York",
  "America/Chicago",
  "Europe/London",
  "Europe/Berlin",
  "Asia/Dubai",
  "Asia/Singapore",
  "Asia/Tokyo",
  "Australia/Sydney"
];
function isChartTimeZone(value) {
  return typeof value === "string" && CHART_TIME_ZONES.includes(value);
}
var UTC_ALIASES = /* @__PURE__ */ new Set(["UTC", "Etc/UTC", "Etc/GMT", "GMT", "Etc/Universal", "Etc/Zulu", "Universal", "Zulu", "Etc/UCT", "UCT", "Etc/Greenwich", "Greenwich", "Etc/GMT0", "Etc/GMT+0", "Etc/GMT-0", "GMT0", "GMT+0", "GMT-0"]);
var cachedBrowserZone = null;
function browserZone() {
  if (cachedBrowserZone !== null) return cachedBrowserZone;
  let zone = "UTC";
  try {
    const resolved = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (typeof resolved === "string" && resolved) {
      new Intl.DateTimeFormat("en-US", { timeZone: resolved });
      zone = resolved;
    }
  } catch {
    zone = "UTC";
  }
  cachedBrowserZone = UTC_ALIASES.has(zone) ? "UTC" : zone;
  return cachedBrowserZone;
}
function resolveTimeZone(zone, bz) {
  if (zone === "local") {
    const local = bz ?? browserZone();
    if (!local || UTC_ALIASES.has(local)) return "UTC";
    return formatterFor(local) ? local : "UTC";
  }
  return isChartTimeZone(zone) ? zone : "UTC";
}
var DAILY_TIMEFRAMES = /* @__PURE__ */ new Set(["D1", "W1", "MN1"]);
function effectiveDisplayZone(zone, timeframe) {
  if (DAILY_TIMEFRAMES.has(timeframe)) return "UTC";
  return isChartTimeZone(zone) ? zone : "UTC";
}
var formatters = /* @__PURE__ */ new Map();
function formatterFor(iana) {
  let formatter = formatters.get(iana);
  if (formatter !== void 0) return formatter;
  try {
    formatter = new Intl.DateTimeFormat("en-US", {
      timeZone: iana,
      hourCycle: "h23",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      timeZoneName: "short"
    });
  } catch {
    formatter = null;
  }
  formatters.set(iana, formatter);
  return formatter;
}
var pad = (value, width = 2) => String(value).padStart(width, "0");
function utcParts(ms) {
  const d = new Date(ms);
  return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate(), hour: d.getUTCHours(), minute: d.getUTCMinutes(), second: d.getUTCSeconds(), abbr: "UTC" };
}
function wallParts(ms, iana) {
  if (iana === "UTC") return utcParts(ms);
  const formatter = formatterFor(iana);
  if (!formatter) return utcParts(ms);
  const out = { year: 0, month: 0, day: 0, hour: 0, minute: 0, second: 0, abbr: "" };
  for (const part of formatter.formatToParts(ms)) {
    switch (part.type) {
      case "year":
        out.year = Number(part.value);
        break;
      case "month":
        out.month = Number(part.value);
        break;
      case "day":
        out.day = Number(part.value);
        break;
      case "hour":
        out.hour = Number(part.value) % 24;
        break;
      case "minute":
        out.minute = Number(part.value);
        break;
      case "second":
        out.second = Number(part.value);
        break;
      case "timeZoneName":
        out.abbr = part.value;
        break;
    }
  }
  return out;
}
var wholeSecondMs = (sec) => Math.floor(sec) * 1e3;
function formatChartTime(sec, zone, options = {}) {
  if (!Number.isFinite(sec)) return "time unavailable";
  const iana = resolveTimeZone(zone);
  const ms = wholeSecondMs(sec);
  if (iana === "UTC") return `${new Date(ms).toISOString().slice(0, options.seconds ? 19 : 16).replace("T", " ")} UTC`;
  const p = wallParts(ms, iana);
  return `${pad(p.year, 4)}-${pad(p.month)}-${pad(p.day)} ${pad(p.hour)}:${pad(p.minute)}${options.seconds ? `:${pad(p.second)}` : ""} ${p.abbr}`;
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartClockEvidence.ts
function formatSourceChartTime(seconds, qualified, zone = "UTC", options = {}) {
  const text = formatChartTime(seconds, qualified ? zone : "UTC", options);
  return qualified ? text : text.replace(/ UTC$/, " source clock (UTC unverified)");
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartVolumeProfile.ts
var VOLUME_PROFILE_METHOD = "ohlc-uniform-range-v1";
var MAX_PROFILE_BARS = 5e3;
function sameProfileEvidence(a, b) {
  return a?.finality === b?.finality && a?.clockAuthority === b?.clockAuthority;
}
var time = (v) => typeof v === "number" && Number.isSafeInteger(v) && v > 0 && v < 1e11;
function validProfileRange(v) {
  const r = v;
  return !!r && r.kind === "observed_range" && time(r.fromTime) && time(r.toTime) && r.fromTime <= r.toTime && typeof r.seriesIdentity === "string" && /^[a-f0-9]{64}$/.test(r.seriesIdentity) && r.clockAuthority === TRADE_VOLUME_AUTHORITY;
}
function validProfileRows(v) {
  return typeof v === "number" && Number.isInteger(v) && v >= 8 && v <= 128;
}
function validProfileValueArea(v) {
  return typeof v === "number" && Number.isInteger(v) && v >= 1 && v <= 100;
}
var hold = (reason) => Object.freeze({ status: "held", method: VOLUME_PROFILE_METHOD, reason });
function calculateVolumeProfile(bars, range, rowCount, valueAreaPercent) {
  if (!validProfileRange(range)) return hold("Select a frozen original range with qualified traded volume and original UTC evidence.");
  if (!validProfileRows(rowCount) || !validProfileValueArea(valueAreaPercent)) return hold("Profile rows must be 8\u2013128 and value area must be an integer 1\u2013100 percent.");
  let from = -1, to = -1, previous = -Infinity;
  for (let i = 0; i < bars.length; i++) {
    const t = bars[i].time;
    if (!time(t) || t <= previous) return hold("Original candle timestamps must be unique and ascending.");
    previous = t;
    if (t === range.fromTime) from = i;
    if (t === range.toTime) to = i;
  }
  if (from < 0 || to < from) return hold("The frozen profile endpoints are not both loaded; no substitute range was used.");
  if (to - from + 1 > MAX_PROFILE_BARS) return hold(`Profile accepts at most ${MAX_PROFILE_BARS} loaded bars; this range was not downsampled.`);
  let low = Infinity, high = -Infinity, total = 0;
  for (let i = from; i <= to; i++) {
    const b = bars[i], v = observedTradeVolume(b.volumeEvidence);
    if (!v || v.seriesIdentity !== range.seriesIdentity) return hold("Every selected bar needs qualified positive traded volume from the frozen source series; ticks or missing quantities cannot substitute.");
    if (b.profileEvidence?.finality !== "closed" || b.profileEvidence.clockAuthority !== range.clockAuthority) return hold("Every selected bar needs original closed status and matching original UTC evidence; partial or withdrawn evidence holds the whole profile.");
    if (![b.open, b.high, b.low, b.close].every((n2) => Number.isFinite(n2) && n2 > 0) || b.high < Math.max(b.open, b.close, b.low) || b.low > Math.min(b.open, b.close, b.high)) return hold("Original candle prices are invalid; no partial profile was salvaged.");
    total += v.quantity;
    if (!Number.isSafeInteger(total)) return hold("Total traded quantity exceeds exact safe integer arithmetic.");
    low = Math.min(low, b.low);
    high = Math.max(high, b.high);
  }
  const span = high - low, n = span === 0 ? 1 : rowCount, step = span / n;
  if (!Number.isFinite(span) || span < 0 || !Number.isFinite(step)) return hold("Price-bin arithmetic is unsupported for this range.");
  const edges = Array.from({ length: n + 1 }, (_, i) => i === n ? high : low + i * step);
  if (span > 0 && edges.some((edge, i) => i > 0 && edge <= edges[i - 1])) return hold("Requested price bins collapse at this numeric precision; reduce rows or select a wider range.");
  const quantities = new Float64Array(n), difference = new Float64Array(n + 1);
  for (let i = from; i <= to; i++) {
    const b = bars[i], v = observedTradeVolume(b.volumeEvidence).quantity;
    const index = (price) => {
      let lo2 = 0, hi2 = n;
      while (lo2 < hi2) {
        const mid = lo2 + hi2 + 1 >>> 1;
        if (edges[mid] <= price) lo2 = mid;
        else hi2 = mid - 1;
      }
      return Math.min(n - 1, lo2);
    };
    if (span === 0) {
      quantities[0] += v;
      continue;
    }
    if (b.high === b.low) {
      quantities[index(b.low)] += v;
      continue;
    }
    const first = index(b.low), last = index(b.high), width = b.high - b.low;
    if (first === last) {
      quantities[first] += v;
      continue;
    }
    quantities[first] += v * (edges[first + 1] - b.low) / width;
    quantities[last] += v * (b.high - edges[last]) / width;
    if (last > first + 1) {
      const density2 = v / width;
      difference[first + 1] += density2;
      difference[last] -= density2;
    }
  }
  let density = 0, allocated = 0;
  const resultRows = [];
  for (let i = 0; i < n; i++) {
    density += difference[i];
    let value = quantities[i] + density * (edges[i + 1] - edges[i]);
    if (value < 0 && value > -1e-12 * total) value = 0;
    if (!Number.isFinite(value) || value < 0) return hold("Volume allocation arithmetic is non-finite or negative.");
    allocated += value;
    resultRows.push({ low: edges[i], high: edges[i + 1], estimatedTradeUnits: value });
  }
  if (!Number.isFinite(allocated) || Math.abs(allocated - total) > 1e-9 * Math.max(1, total)) return hold("Estimated allocations do not conserve the original total within numeric tolerance.");
  let poc = 0;
  for (let i = 1; i < n; i++) if (resultRows[i].estimatedTradeUnits > resultRows[poc].estimatedTradeUnits) poc = i;
  let lo = poc, hi = poc, included = resultRows[poc].estimatedTradeUnits;
  const target = total * valueAreaPercent / 100;
  while (included < target && (lo > 0 || hi < n - 1)) {
    const below = lo > 0 ? lo - 1 : null, above = hi < n - 1 ? hi + 1 : null;
    let next;
    if (below == null) next = above;
    else if (above == null) next = below;
    else {
      const a = resultRows[above].estimatedTradeUnits, b = resultRows[below].estimatedTradeUnits;
      next = a > b ? above : b > a ? below : above - poc <= poc - below ? above : below;
    }
    const extra = resultRows[next].estimatedTradeUnits;
    if (valueAreaPercent < 100 && included + extra > target) break;
    included += extra;
    if (next < lo) lo = next;
    else hi = next;
  }
  const result = { status: "ready", method: VOLUME_PROFILE_METHOD, range: { ...range }, rowCount: n, requestedRowCount: rowCount, omittedFormingTail: to === bars.length - 2 && bars[to + 1]?.profileEvidence?.finality === "forming" ? 1 : 0, barCount: to - from + 1, totalTradeUnits: total, rows: resultRows, pocIndex: poc, valueArea: { low: resultRows[lo].low, high: resultRows[hi].high, fromIndex: lo, toIndex: hi, targetPercent: valueAreaPercent, achievedPercent: included / total * 100, estimatedTradeUnits: included }, unit: "provider_trade_units", limitations: [
    "Estimated allocation: uniform traded-volume density across each original candle high\u2013low range, not observed executions at each price.",
    "Loaded closed observations only; time gaps are not zero-volume proof. No complete-session or lower-timeframe coverage claim.",
    "Provider-reported trade units, not proven shares, consolidated market volume, bid/ask liquidity or aggressor order flow.",
    "POC ties choose the lowest-price row. Value area starts with POC, adds the larger adjacent row, and stops before exceeding the target; ties choose closer to POC then above. POC alone may exceed the target."
  ] };
  Object.freeze(result.range);
  result.rows.forEach(Object.freeze);
  Object.freeze(result.rows);
  Object.freeze(result.valueArea);
  Object.freeze(result.limitations);
  return Object.freeze(result);
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartIntervals.ts
var CHART_INTERVALS = [
  "M1",
  "M2",
  "M3",
  "M4",
  "M5",
  "M6",
  "M10",
  "M12",
  "M15",
  "M20",
  "M30",
  "H1",
  "H2",
  "H3",
  "H4",
  "H6",
  "H8",
  "H12",
  "D1"
];
var SECONDS = {
  M1: 60,
  M2: 120,
  M3: 180,
  M4: 240,
  M5: 300,
  M6: 360,
  M10: 600,
  M12: 720,
  M15: 900,
  M20: 1200,
  M30: 1800,
  H1: 3600,
  H2: 7200,
  H3: 10800,
  H4: 14400,
  H6: 21600,
  H8: 28800,
  H12: 43200,
  D1: 86400
};
function isChartInterval(value) {
  return typeof value === "string" && CHART_INTERVALS.includes(value);
}
function chartIntervalSeconds(value) {
  return isChartInterval(value) ? SECONDS[value] : null;
}

// lib/domain/src/chart-indicator-math/index.ts
function advanceStudyAverage(input, period2, method, prior, expired) {
  const count = input == null ? 0 : (prior?.count ?? 0) + 1;
  const sum = input == null ? 0 : (prior?.sum ?? 0) + input - (count > period2 ? expired : 0);
  const weighted = method !== "wma" || input == null ? 0 : count <= period2 ? (prior?.weighted ?? 0) + count * input : (prior?.weighted ?? 0) - (prior?.sum ?? 0) + period2 * input;
  let value = null;
  if (input != null && count >= period2) {
    if (method === "wma") value = weighted / (period2 * (period2 + 1) / 2);
    else if (method === "sma" || prior?.value == null) value = sum / period2;
    else value = prior.value + (method === "smma" ? 1 / period2 : 2 / (period2 + 1)) * (input - prior.value);
  }
  return { input, count, sum, weighted, value };
}
function chartTrueRange(bar, previousClose) {
  return previousClose == null ? bar.high - bar.low : Math.max(bar.high - bar.low, Math.abs(bar.high - previousClose), Math.abs(bar.low - previousClose));
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartRangeWindow.ts
function scanChartRange(bars, from, to) {
  let high = -Infinity, low = Infinity;
  for (let i = from; i <= to; i++) {
    high = Math.max(high, bars[i].high);
    low = Math.min(low, bars[i].low);
  }
  return [high, low];
}
var ChartRangeWindow = class {
  constructor(period2, maximum) {
    this.period = period2;
    this.maximum = maximum;
    this.values = new Float64Array(period2);
    this.indices = new Float64Array(period2);
  }
  values;
  indices;
  head = 0;
  size = 0;
  lastNaN = -Infinity;
  push(value, index) {
    const oldest = index - this.period + 1;
    while (this.size && this.indices[this.head] < oldest) {
      this.head = (this.head + 1) % this.period;
      this.size--;
    }
    if (Number.isNaN(value)) this.lastNaN = index;
    else {
      while (this.size) {
        const tail2 = (this.head + this.size - 1) % this.period;
        const best = this.maximum ? Math.max(this.values[tail2], value) : Math.min(this.values[tail2], value);
        if (!Object.is(best, value)) break;
        this.size--;
      }
      const tail = (this.head + this.size) % this.period;
      this.values[tail] = value;
      this.indices[tail] = index;
      this.size++;
    }
    return this.lastNaN >= oldest ? NaN : this.size ? this.values[this.head] : this.maximum ? -Infinity : Infinity;
  }
};

// artifacts/trading-dashboard/src/lib/chart-engine/chartStudies.ts
var STUDY_CATALOG = [
  { name: "Simple moving average", group: "Trend", description: "Equal weight over the selected period.", defaults: { kind: "sma", period: 20, color: "#fbbf24" }, channels: ["SMA"], pane: false, appliedPrice: true },
  { name: "Exponential moving average", group: "Trend", description: "Recent prices carry more weight; seeded with an SMA.", defaults: { kind: "ema", period: 50, color: "#38bdf8" }, channels: ["EMA"], pane: false, appliedPrice: true },
  { name: "Bollinger Bands", group: "Volatility", description: "SMA basis with population standard deviation bands.", defaults: { kind: "bollinger", period: 20, multiplier: 2, color: "#a78bfa" }, channels: ["Basis", "Upper", "Lower"], pane: false, appliedPrice: true },
  { name: "Relative strength index", group: "Momentum", description: "Wilder smoothing of gains and losses; flat markets read 50.", defaults: { kind: "rsi", period: 14, color: "#e879f9" }, channels: ["RSI"], pane: true, appliedPrice: true, levels: [30, 70], range: [0, 100] },
  { name: "MACD", group: "Momentum", description: "Fast minus slow EMA. Choose EMA or MT5-style SMA signal smoothing.", defaults: { kind: "macd", period: 12, slow: 26, signal: 9, color: "#2dd4bf" }, channels: ["MACD", "Signal", "Histogram"], pane: true, appliedPrice: true, levels: [0] },
  { name: "Smoothed moving average", group: "Trend", description: "Wilder / RMA smoothing with weight 1 \xF7 period.", defaults: { kind: "smma", period: 20, color: "#fb923c" }, channels: ["SMMA"], pane: false, appliedPrice: true },
  { name: "Weighted moving average", group: "Trend", description: "Linear weights; the newest bar has the largest weight.", defaults: { kind: "wma", period: 20, color: "#4ade80" }, channels: ["WMA"], pane: false, appliedPrice: true },
  { name: "Double exponential moving average", group: "Trend", description: "2 \xD7 EMA minus EMA of EMA; each stage warms up separately.", defaults: { kind: "dema", period: 20, color: "#f472b6" }, channels: ["DEMA"], pane: false, appliedPrice: true },
  { name: "Triple exponential moving average", group: "Trend", description: "3 \xD7 EMA \u2212 3 \xD7 EMA\xB2 + EMA\xB3; three seeded stages.", defaults: { kind: "tema", period: 20, color: "#818cf8" }, channels: ["TEMA"], pane: false, appliedPrice: true },
  { name: "Average true range", group: "Volatility", description: "Range including gaps from the previous close. Select smoothing.", defaults: { kind: "atr", period: 14, method: "smma", color: "#fb923c" }, channels: ["ATR"], pane: true, appliedPrice: false },
  { name: "Commodity channel index", group: "Momentum", description: "Distance from the mean divided by 0.015 \xD7 mean absolute deviation.", defaults: { kind: "cci", period: 20, source: "hlc3", color: "#38bdf8" }, channels: ["CCI"], pane: true, appliedPrice: true, levels: [-100, 0, 100] },
  { name: "Stochastic oscillator", group: "Momentum", description: "SMA-smoothed %K in the high/low range, followed by an SMA %D.", defaults: { kind: "stochastic", period: 14, smoothing: 3, signal: 3, color: "#2dd4bf" }, channels: ["%K", "%D"], pane: true, appliedPrice: false, levels: [20, 80], range: [0, 100] },
  { name: "Williams percent range", group: "Momentum", description: "Close within the lookback high/low range, from \u2212100 to 0.", defaults: { kind: "williams", period: 14, color: "#fbbf24" }, channels: ["%R"], pane: true, appliedPrice: false, levels: [-80, -20], range: [-100, 0] },
  { name: "Standard deviation", group: "Volatility", description: "Population deviation around the selected price's simple mean.", defaults: { kind: "stddev", period: 20, color: "#a78bfa" }, channels: ["Deviation"], pane: true, appliedPrice: true },
  { name: "Moving average envelopes", group: "Trend", description: "Percentage bands above and below a configurable moving average.", defaults: { kind: "envelopes", period: 20, multiplier: 1, method: "sma", color: "#f472b6" }, channels: ["Basis", "Upper", "Lower"], pane: false, appliedPrice: true },
  { name: "Momentum ratio", group: "Momentum", description: "Current price \xF7 price N bars ago \xD7 100 (MT5 convention).", defaults: { kind: "momentum", period: 14, color: "#4ade80" }, channels: ["Momentum"], pane: true, appliedPrice: true, levels: [100] },
  { name: "Rate of change", group: "Momentum", description: "Percentage price change over N bars.", defaults: { kind: "roc", period: 14, color: "#fbbf24" }, channels: ["ROC %"], pane: true, appliedPrice: true, levels: [0] },
  { name: "Donchian Channels", group: "Volatility", description: "Highest high, lowest low and their midpoint over the selected bars, including the forming bar. Requires a full window; channel contact alone is not a breakout signal.", defaults: { kind: "donchian", period: 20, color: "#38bdf8" }, channels: ["Midpoint", "Upper", "Lower"], pane: false, appliedPrice: false },
  { name: "Directional movement (DMI / ADX)", group: "Trend", description: "Wilder-smoothed +DI and \u2212DI show directional movement; ADX measures strength, not direction or confidence. Separate DI and ADX lengths; tied moves count as zero. Not a trade signal.", defaults: { kind: "dmi", period: 14, signal: 14, color: "#38bdf8" }, channels: ["+DI", "\u2212DI", "ADX"], pane: true, appliedPrice: false, range: [0, 100] },
  { name: "Tick volume", group: "Volume", description: "Explicit MT5 per-bar tick counts, not traded size. Only source-qualified observations are plotted; missing or partial streaming evidence stays blank, never zero-filled. No real traded-volume data is inferred.", defaults: { kind: "tick_volume", period: 1, color: "#38bdf8" }, channels: ["Ticks"], pane: true, appliedPrice: false },
  { name: "Anchored VWAP", group: "Volume", description: "Cumulative original bar price \xD7 provider-reported trade units / cumulative trade units, from an exact observed bar. HLC3 by default. Loaded observations only, not a full session or trade-by-trade average. Missing/zero/unqualified volume holds the remaining interval; no tick proxy.", defaults: { kind: "vwap", period: 1, source: "hlc3", color: "#fbbf24" }, channels: ["VWAP"], pane: false, appliedPrice: true },
  { name: "Trade volume", group: "Volume", description: "Qualified provider-reported trade units per original closed bar. These are not tick counts, proven shares or consolidated-market volume. Missing/zero/unqualified quantities stay blank.", defaults: { kind: "trade_volume", period: 1, color: "#34d399" }, channels: ["Trade units"], pane: true, appliedPrice: false },
  { name: "Estimated volume profile", group: "Volume", description: "Fixed-range price bins estimate uniform volume across original candle ranges. Qualified provider trade units only; no tick substitute, observed executions-at-price or complete-session claim.", defaults: { kind: "volume_profile", period: 1, color: "#a78bfa", profileRows: 32, profileValueAreaPercent: 70 }, channels: ["Estimated trade units"], pane: false, appliedPrice: false }
];
var STUDY_DEFAULTS = ["sma", "ema", "bollinger", "rsi", "macd"].map((kind) => STUDY_CATALOG.find((item) => item.defaults.kind === kind).defaults);
var MAX_STUDIES = 12;
var studyDefinition = (kind) => STUDY_CATALOG.find((item) => item.defaults.kind === kind);
var studyId = (study) => study.id ?? study.kind;
function studyChannelColor(config, channel) {
  return config.lineStyles?.[channel]?.color ?? (config.kind === "dmi" ? channel === 0 ? "#4ade80" : channel === 1 ? "#fb7185" : config.color : channel === 1 && (config.kind === "macd" || config.kind === "stochastic") ? "#fbbf24" : config.color);
}
function formatStudyNumber(value, channel) {
  return ["Ticks", "Ticks (hidden)", "Trade units", "Trade units (hidden)", "Frozen-range total trade units", "Frozen-range total trade units (hidden)"].includes(channel) ? String(value) : String(Number(value.toPrecision(8)));
}
function studyLabel(study) {
  if (study.kind === "volume_profile") return "Estimated volume profile \xB7 provider trade units";
  if (study.kind === "trade_volume") return "Trade volume \xB7 provider-reported trade units";
  if (study.kind === "vwap") return `VWAP \xB7 ${study.source ?? "hlc3"} \xB7 observed-bar anchor ${study.vwapAnchor ? formatSourceChartTime(study.vwapAnchor.time, false, "UTC", { seconds: true }) : "not selected"}`;
  if (study.kind === "tick_volume") return "Tick volume \xB7 ticks (not traded size)";
  const parameters = [study.period];
  if (study.kind === "macd") parameters.push(study.slow ?? 26, study.signal ?? 9);
  if (study.kind === "dmi") parameters.push(study.signal ?? 14);
  if (study.kind === "stochastic") parameters.push(study.smoothing ?? 3, study.signal ?? 3);
  if (study.kind === "bollinger" || study.kind === "envelopes") parameters.push(study.multiplier ?? 2);
  const source = studyDefinition(study.kind).appliedPrice ? ` \xB7 ${study.source ?? (study.kind === "cci" ? "hlc3" : "close")}` : "";
  const method = study.kind === "macd" ? ` \xB7 ${(study.signalMethod ?? "ema").toUpperCase()} signal` : study.kind === "atr" || study.kind === "envelopes" ? ` \xB7 ${(study.method ?? (study.kind === "atr" ? "smma" : "sma")).toUpperCase()}` : "";
  return `${study.kind.toUpperCase()} (${parameters.join(", ")})${source}${method}`;
}
function appliedPrice(bar, source = "close") {
  switch (source) {
    case "hl2":
      return (bar.high + bar.low) / 2;
    case "hlc3":
      return (bar.high + bar.low + bar.close) / 3;
    case "hlcc4":
      return (bar.high + bar.low + 2 * bar.close) / 4;
    case "ohlc4":
      return (bar.open + bar.high + bar.low + bar.close) / 4;
    default:
      return bar[source];
  }
}
var StudyCalculator = class {
  constructor(currentConfig) {
    this.currentConfig = currentConfig;
  }
  states = [];
  profile;
  get profileResult() {
    return this.profile;
  }
  /** prices[i] === states[i].price for every i < states.length. The O(n*p)
   * deviation loops read this contiguous buffer instead of State objects.
   * It persists across calls: entries at index >= states.length are stale and
   * never read, because the loops only read j < i. */
  prices = new Float64Array(0);
  points = [];
  get config() {
    return this.currentConfig;
  }
  /** Preserve checkpoints only when every calculation input is unchanged. */
  updatePresentation(next) {
    const inputs = ({ color: _color, id: _id, lineStyles: _styles, ...rest }) => JSON.stringify(rest);
    if (inputs(next) !== inputs(this.currentConfig)) return false;
    this.currentConfig = next;
    return true;
  }
  /** Rendering reads points directly and can omit the duplicate changed list.
   * Default callers still receive every changed point in its original order. */
  calculate(bars, from = 0, collectChanges = true) {
    const c = this.config;
    if (c.kind === "volume_profile") {
      this.profile = calculateVolumeProfile(bars, c.profileRange, c.profileRows ?? 32, c.profileValueAreaPercent ?? 70);
      this.points.length = 0;
      this.states.length = 0;
      return [];
    }
    const p = c.period;
    from = Math.max(0, Math.min(from, this.states.length, bars.length));
    this.states.length = from;
    this.points.length = from;
    if (this.prices.length < bars.length) {
      const grown = new Float64Array(Math.max(bars.length, this.prices.length * 2));
      grown.set(this.prices.subarray(0, from));
      this.prices = grown;
    }
    const prices = this.prices;
    const changed = [];
    const usesRange = bars.length >= p && bars.length - from > 2 && (c.kind === "stochastic" || c.kind === "williams" || c.kind === "donchian");
    const highs = usesRange ? new ChartRangeWindow(p, true) : null;
    const lows = usesRange ? new ChartRangeWindow(p, false) : null;
    if (highs && lows && from < bars.length) {
      for (let j = Math.max(0, from - p + 1); j < from; j++) {
        highs.push(bars[j].high, j);
        lows.push(bars[j].low, j);
      }
    }
    let i = from;
    let state;
    let previous;
    const average = (key, input, period2, method) => {
      const prior = previous?.averages[key];
      const expired = this.states[i - period2]?.averages[key]?.input ?? 0;
      const next = advanceStudyAverage(input, period2, method, prior, expired);
      state.averages[key] = next;
      return next.value;
    };
    for (i = from; i < bars.length; i++) {
      const bar = bars[i];
      const price = appliedPrice(bar, c.source ?? (c.kind === "cci" || c.kind === "vwap" ? "hlc3" : "close"));
      prices[i] = price;
      state = { price, averages: {} };
      previous = this.states[i - 1];
      let values;
      let reason;
      switch (c.kind) {
        case "sma":
        case "ema":
        case "smma":
        case "wma":
          values = [average("basis", price, p, c.kind)];
          break;
        case "dema":
        case "tema": {
          const first = average("first", price, p, "ema");
          const second = average("second", first, p, "ema");
          const third = c.kind === "tema" ? average("third", second, p, "ema") : null;
          values = [first == null || second == null ? null : c.kind === "dema" ? 2 * first - second : third == null ? null : 3 * first - 3 * second + third];
          break;
        }
        case "bollinger":
        case "stddev":
        case "cci": {
          const mean = average("basis", price, p, "sma");
          values = c.kind === "bollinger" ? [null, null, null] : [null];
          if (mean != null) {
            let sum = 0;
            if (c.kind === "cci") {
              for (let j = i - p + 1; j < i; j++) sum += Math.abs(prices[j] - mean);
              sum += Math.abs(price - mean);
              const mad = sum / p;
              values = [mad === 0 ? 0 : (price - mean) / (0.015 * mad)];
            } else {
              for (let j = i - p + 1; j < i; j++) sum += (prices[j] - mean) ** 2;
              sum += (price - mean) ** 2;
              const deviation = Math.sqrt(sum / p);
              values = c.kind === "stddev" ? [deviation] : [mean, mean + deviation * (c.multiplier ?? 2), mean - deviation * (c.multiplier ?? 2)];
            }
          }
          break;
        }
        case "rsi": {
          const delta = previous ? price - previous.price : null;
          const gain = average("gain", delta == null ? null : Math.max(0, delta), p, "smma");
          const loss = average("loss", delta == null ? null : Math.max(0, -delta), p, "smma");
          values = [gain == null || loss == null ? null : gain === 0 && loss === 0 ? 50 : loss === 0 ? 100 : 100 - 100 / (1 + gain / loss)];
          break;
        }
        case "macd": {
          const fast = average("fast", price, p, "ema");
          const slow = average("slow", price, c.slow ?? 26, "ema");
          const macd = fast == null || slow == null ? null : fast - slow;
          const signal = average("signal", macd, c.signal ?? 9, c.signalMethod ?? "ema");
          values = [macd, signal, macd == null || signal == null ? null : macd - signal];
          break;
        }
        case "atr": {
          const close = bars[i - 1]?.close;
          const range = chartTrueRange(bar, close);
          values = [average("range", range, p, c.method ?? "smma")];
          break;
        }
        case "dmi": {
          const before = bars[i - 1];
          const up = before ? bar.high - before.high : 0;
          const down = before ? before.low - bar.low : 0;
          const range = before ? Math.max(bar.high - bar.low, Math.abs(bar.high - before.close), Math.abs(bar.low - before.close)) : null;
          const tr = average("tr", range, p, "smma");
          const positive = average("positive", before ? up > 0 && up > down ? up : 0 : null, p, "smma");
          const negative = average("negative", before ? down > 0 && down > up ? down : 0 : null, p, "smma");
          const plus = tr == null || positive == null ? null : tr === 0 ? 0 : 100 * positive / tr;
          const minus = tr == null || negative == null ? null : tr === 0 ? 0 : 100 * negative / tr;
          const dx = plus == null || minus == null ? null : plus + minus === 0 ? 0 : 100 * Math.abs(plus - minus) / (plus + minus);
          values = [plus, minus, average("adx", dx, c.signal ?? 14, "smma")];
          break;
        }
        case "stochastic":
        case "williams":
        case "donchian": {
          let high = -Infinity, low = Infinity;
          if (highs && lows) {
            high = highs.push(bar.high, i);
            low = lows.push(bar.low, i);
          } else if (i >= p - 1) [high, low] = scanChartRange(bars, i - p + 1, i);
          if (c.kind === "donchian") {
            values = i < p - 1 ? [null, null, null] : [high / 2 + low / 2, high, low];
            break;
          }
          const raw = i < p - 1 || high === low ? null : 100 * (bar.close - low) / (high - low);
          if (c.kind === "williams") values = [raw == null ? null : raw - 100];
          else {
            const k = average("k", raw, c.smoothing ?? 3, "sma");
            values = [k, average("d", k, c.signal ?? 3, "sma")];
          }
          break;
        }
        case "envelopes": {
          const basis = average("basis", price, p, c.method ?? "sma");
          const fraction = (c.multiplier ?? 1) / 100;
          values = basis == null ? [null, null, null] : [basis, basis * (1 + fraction), basis * (1 - fraction)];
          break;
        }
        case "momentum":
        case "roc": {
          const before = this.states[i - p]?.price;
          const ratio = before == null || before === 0 ? null : price / before;
          values = [ratio == null ? null : c.kind === "momentum" ? 100 * ratio : 100 * (ratio - 1)];
          break;
        }
        case "vwap": {
          const anchor2 = c.vwapAnchor;
          const prior = previous?.vwap;
          const starts = anchor2 != null && bar.time === anchor2.time;
          if (!anchor2 || bar.time < anchor2.time || !starts && !prior) {
            values = [null];
            reason = "Exact observed-bar anchor is not present at or before this bar.";
            break;
          }
          const volume = observedTradeVolume(bar.volumeEvidence);
          const next = starts ? { numerator: 0, denominator: 0, reason: void 0 } : { ...prior };
          if (!next.reason && (!volume || volume.seriesIdentity !== anchor2.seriesIdentity)) next.reason = "Trade-volume evidence is missing, zero, unqualified or belongs to another source series; cumulative VWAP is held from this bar.";
          if (!next.reason && volume) {
            next.numerator += price * volume.quantity;
            next.denominator += volume.quantity;
            if (!Number.isFinite(next.numerator) || !Number.isSafeInteger(next.denominator) || next.denominator <= 0) next.reason = "Cumulative volume or weighted price exceeds the supported numerical range.";
          }
          state.vwap = next;
          reason = next.reason;
          values = [reason ? null : next.numerator / next.denominator];
          break;
        }
        case "trade_volume":
          values = [observedTradeVolume(bar.volumeEvidence)?.quantity ?? null];
          if (values[0] == null) reason = "No qualified positive provider-reported trade quantity for this bar.";
          break;
        case "tick_volume":
          values = [observedTickVolume(bar.volumeEvidence)];
          break;
        default:
          values = [null];
      }
      this.states.push(state);
      for (let channel = 0; channel < values.length; channel++) {
        const value = values[channel];
        if (value == null || !Number.isFinite(value)) values[channel] = null;
      }
      const point = { time: bar.time, values, ...reason ? { reason } : {} };
      this.points.push(point);
      if (collectChanges) changed.push(point);
    }
    return changed;
  }
};

// artifacts/trading-dashboard/src/lib/chart-engine/chartTextNote.ts
var MAX_NOTE_LENGTH = 240;
var MAX_NOTE_PARAGRAPHS = 6;
var NOTE_FONT = "12px sans-serif";
var NOTE_LINE_HEIGHT = 16;
var NOTE_PADDING = 8;
var NOTE_HEADER_HEIGHT = 18;
var NOTE_MAX_WIDTH = 220;
function normalizeNoteText(value) {
  if (typeof value !== "string" || value.length > MAX_NOTE_LENGTH) return null;
  const text = value.replace(/\r\n?/g, "\n").trim();
  if (!text || /[\u0000-\u0009\u000B-\u001F\u007F-\u009F\u202A-\u202E\u2066-\u2069]/u.test(text) || text.split("\n").length > MAX_NOTE_PARAGRAPHS) return null;
  return text;
}
var context = null;
var layouts = /* @__PURE__ */ new Map();
function measureNoteText(text) {
  context ??= typeof document === "undefined" ? null : document.createElement("canvas").getContext("2d");
  if (context) {
    context.font = NOTE_FONT;
    return context.measureText(text).width;
  }
  return Array.from(text).length * 12;
}
function layoutTextNote(value, width, measure = measureNoteText) {
  const text = normalizeNoteText(value);
  if (text == null || !Number.isFinite(width) || width < 40) return null;
  const boxWidth = Math.min(NOTE_MAX_WIDTH, Math.floor(width));
  const cacheKey = `${boxWidth}:${text}`;
  if (measure === measureNoteText && layouts.has(cacheKey)) return layouts.get(cacheKey);
  const available = boxWidth - NOTE_PADDING * 2;
  const lines = [];
  const segmenter = new Intl.Segmenter(void 0, { granularity: "grapheme" });
  for (const paragraph of text.split("\n")) {
    if (measure(paragraph) <= available) {
      lines.push(paragraph);
      continue;
    }
    let line = "";
    for (const { segment } of segmenter.segment(paragraph)) {
      const next = line + segment;
      if (line && measure(next) > available) {
        const wordBreak = line.lastIndexOf(" ");
        if (wordBreak > 0) {
          lines.push(line.slice(0, wordBreak + 1));
          line = line.slice(wordBreak + 1) + segment;
        } else {
          lines.push(line);
          line = segment;
        }
      } else line = next;
    }
    lines.push(line);
  }
  const result = { lines: Object.freeze(lines), width: boxWidth, height: NOTE_PADDING * 2 + NOTE_HEADER_HEIGHT + lines.length * NOTE_LINE_HEIGHT };
  if (measure === measureNoteText) {
    if (layouts.size >= 128) layouts.delete(layouts.keys().next().value);
    layouts.set(cacheKey, result);
  }
  return result;
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartWorkspace.ts
var CHART_STYLES = ["candles", "bars", "line", "area", "baseline", "heikinAshi", "hollow"];
function closeOnlyStyle(style) {
  return style === "line" || style === "area" || style === "baseline";
}
var DRAWING_NAMES = { measure: "Price and time ruler", channel: "Parallel channel", horizontal: "Horizontal level", vertical: "Vertical line", trend: "Trend line", ray: "Ray", extended: "Extended line", rectangle: "Rectangle", fibonacci: "Fibonacci retracement", text: "Text note (yours)" };
function singleAnchorDrawing(kind) {
  return kind === "horizontal" || kind === "vertical" || kind === "text";
}
var DEFAULT_PREFERENCES = { style: "candles", scale: "linear", studies: [] };
var MAX_DRAWINGS = 40;
var color = (v) => typeof v === "string" && /^#[a-f\d]{6}$/i.test(v);
var period = (v) => Number.isInteger(v) && Number(v) >= 1 && Number(v) <= 1e3;
var anchor = (v) => v && Number.isFinite(v.time) && v.time > 0 && v.time < 1e11 && Number.isFinite(v.price) && v.price > 0;
function validatePreferences(value) {
  const v = value;
  if (!v || typeof v !== "object") return { ...DEFAULT_PREFERENCES, studies: [] };
  const seen = /* @__PURE__ */ new Set();
  const studies = [];
  const kinds = new Set(STUDY_CATALOG.map((item) => item.defaults.kind));
  const sources = ["close", "open", "high", "low", "hl2", "hlc3", "hlcc4", "ohlc4"];
  for (const s of Array.isArray(v.studies) ? v.studies.slice(0, MAX_STUDIES) : []) {
    if (!s || !kinds.has(s.kind) || !period(s.period) || !color(s.color)) continue;
    if (["tick_volume", "trade_volume", "vwap", "volume_profile"].includes(s.kind) && s.period !== 1) continue;
    if (s.kind === "vwap" && s.vwapAnchor != null && (s.vwapAnchor.kind !== "observed_bar" || !Number.isSafeInteger(s.vwapAnchor.time) || s.vwapAnchor.time <= 0 || s.vwapAnchor.time >= 1e11 || typeof s.vwapAnchor.seriesIdentity !== "string" || !/^[a-f0-9]{64}$/.test(s.vwapAnchor.seriesIdentity))) continue;
    if (s.kind === "volume_profile" && (!validProfileRows(s.profileRows ?? 32) || !validProfileValueArea(s.profileValueAreaPercent ?? 70) || s.profileRange != null && !validProfileRange(s.profileRange))) continue;
    if (s.id != null && (typeof s.id !== "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(s.id))) continue;
    const id = studyId(s);
    if (seen.has(id)) continue;
    if (s.source != null && !sources.includes(s.source)) continue;
    if (s.signalMethod != null && !["sma", "ema"].includes(s.signalMethod)) continue;
    if (s.method != null && !["sma", "ema", "smma", "wma"].includes(s.method)) continue;
    if (["bollinger", "envelopes"].includes(s.kind) && (!Number.isFinite(s.multiplier) || s.multiplier <= 0 || s.multiplier > 100)) continue;
    if (s.kind === "macd" && (!period(s.slow) || s.slow <= s.period || !period(s.signal))) continue;
    if (s.kind === "dmi" && !period(s.signal)) continue;
    if (s.kind === "stochastic" && (!period(s.smoothing) || !period(s.signal))) continue;
    let lineStyles;
    if (s.lineStyles != null) {
      const channels = STUDY_CATALOG.find((item) => item.defaults.kind === s.kind).channels.length;
      if (!Array.isArray(s.lineStyles) || s.lineStyles.length > channels) continue;
      let invalid = false;
      lineStyles = Array.from(s.lineStyles, (style, index) => {
        if (!style || typeof style !== "object" || Array.isArray(style) || style.color != null && !color(style.color) || style.width != null && ![1, 2, 3].includes(style.width) || style.style != null && !["solid", "dashed", "dotted"].includes(style.style) || style.visible != null && typeof style.visible !== "boolean" || s.kind === "macd" && index === 2 && [style.color, style.width, style.style].some((v2) => v2 != null)) {
          invalid = true;
          return {};
        }
        return { ...style.color != null ? { color: style.color } : {}, ...style.width != null ? { width: style.width } : {}, ...style.style != null ? { style: style.style } : {}, ...style.visible != null ? { visible: style.visible } : {} };
      });
      if (invalid) continue;
    }
    seen.add(id);
    studies.push({
      ...lineStyles?.length ? { lineStyles } : {},
      ...s.id ? { id: s.id } : {},
      kind: s.kind,
      period: s.period,
      color: s.color,
      ...s.source ? { source: s.source } : {},
      ...s.kind === "volume_profile" ? { profileRows: s.profileRows ?? 32, profileValueAreaPercent: s.profileValueAreaPercent ?? 70, ...s.profileRange ? { profileRange: { ...s.profileRange } } : {} } : {},
      ...s.kind === "vwap" && s.vwapAnchor ? { vwapAnchor: { kind: "observed_bar", time: s.vwapAnchor.time, seriesIdentity: s.vwapAnchor.seriesIdentity } } : {},
      ...["bollinger", "envelopes"].includes(s.kind) ? { multiplier: s.multiplier } : {},
      ...s.kind === "macd" ? { slow: s.slow, signal: s.signal, ...s.signalMethod ? { signalMethod: s.signalMethod } : {} } : {},
      ...s.kind === "dmi" ? { signal: s.signal } : {},
      ...s.kind === "stochastic" ? { smoothing: s.smoothing, signal: s.signal } : {},
      ...["atr", "envelopes"].includes(s.kind) && s.method ? { method: s.method } : {}
    });
  }
  return { style: CHART_STYLES.includes(v.style) ? v.style : "candles", scale: ["linear", "log", "percent", "indexed"].includes(v.scale) ? v.scale : "linear", ...v.inverted === true ? { inverted: true } : {}, ...v.priceOnlyScale === true ? { priceOnlyScale: true } : {}, studies, ...isChartTimeZone(v.timeZone) && v.timeZone !== "UTC" ? { timeZone: v.timeZone } : {} };
}
function validateFibonacciOrigin(value) {
  const p = value;
  const interval = chartIntervalSeconds(p?.timeframe);
  if (!p || !interval || p.method !== "confirmed-swings-v1" || p.span !== 2 || ![p.symbol, p.timeframe, p.source].every((v) => typeof v === "string" && v.length > 0 && v.length <= 120) || typeof p.sourceIdentity !== "string" || !/^[a-f\d]{64}$/i.test(p.sourceIdentity) || !anchor(p.start) || !anchor(p.end) || p.start.time >= p.end.time || p.start.price === p.end.price || ![p.confirmedAt, p.windowFrom, p.windowTo].every((value2) => typeof value2 === "number" && Number.isFinite(value2) && value2 > 0 && value2 < 1e11) || p.start.time - p.windowFrom < 2 * interval || p.end.time - p.start.time < interval || p.confirmedAt - p.end.time < 3 * interval || p.windowTo < p.confirmedAt || !Number.isInteger(p.closedBars) || p.closedBars < 6 || p.closedBars > 600) return null;
  return { method: "confirmed-swings-v1", span: 2, symbol: p.symbol, timeframe: p.timeframe, source: p.source, sourceIdentity: p.sourceIdentity, start: { ...p.start }, end: { ...p.end }, confirmedAt: p.confirmedAt, windowFrom: p.windowFrom, windowTo: p.windowTo, closedBars: p.closedBars };
}
function validatePivotLevelOrigin(value) {
  if (!value || typeof value !== "object") return null;
  const p = value, l = p.level, interval = chartIntervalSeconds(p.timeframe);
  if (p.method !== "latest-confirmed-pivots-v1" || p.span !== 2 || !interval || !l || !anchor(p.referenceClose) || p.referenceClose.time !== p.windowTo || !["support", "resistance"].includes(l.side) || ![p.symbol, p.timeframe, p.source].every((v) => typeof v === "string" && v.length > 0 && v.length <= 120) || typeof p.sourceIdentity !== "string" || !/^[a-f0-9]{64}$/.test(p.sourceIdentity) || ![p.windowFrom, p.windowTo, l.pivotTime, l.confirmedAt].every((v) => Number.isFinite(v) && v > 0 && v < 1e11) || !Number.isFinite(l.price) || l.price <= 0 || !Number.isSafeInteger(p.closedBars) || p.closedBars < 5 || p.closedBars > 600 || !Number.isSafeInteger(l.laterCloseCrossings) || l.laterCloseCrossings < 0 || l.laterCloseCrossings > p.closedBars || (l.side === "support" ? l.price >= p.referenceClose.price : l.price <= p.referenceClose.price) || l.pivotTime < p.windowFrom + 2 * interval || l.confirmedAt < l.pivotTime + 3 * interval || l.confirmedAt > p.windowTo || p.windowTo - p.windowFrom < (p.closedBars - 1) * interval) return null;
  return { method: p.method, span: 2, symbol: p.symbol, timeframe: p.timeframe, source: p.source, sourceIdentity: p.sourceIdentity, windowFrom: p.windowFrom, windowTo: p.windowTo, closedBars: p.closedBars, referenceClose: { ...p.referenceClose }, level: { side: l.side, price: l.price, pivotTime: l.pivotTime, confirmedAt: l.confirmedAt, laterCloseCrossings: l.laterCloseCrossings } };
}
function validateDrawings(value) {
  const seen = /* @__PURE__ */ new Set();
  return (Array.isArray(value) ? value.slice(0, MAX_DRAWINGS) : []).flatMap((d) => {
    if (!d || typeof d.id !== "string" || d.id.length > 80 || seen.has(d.id) || !Object.hasOwn(DRAWING_NAMES, d.kind) || !anchor(d.start) || !color(d.color)) return [];
    if (!singleAnchorDrawing(d.kind) && (!anchor(d.end) || d.kind !== "measure" && d.end.time === d.start.time)) return [];
    if (d.kind === "channel" && !anchor(d.offset)) return [];
    if (d.kind === "channel" && [d.extendLeft, d.extendRight, d.middleLine].some((v) => v != null && typeof v !== "boolean")) return [];
    const text = d.kind === "text" ? normalizeNoteText(d.text) : null;
    if (d.kind === "text" && text == null) return [];
    if (d.width != null && ![1, 2, 3].includes(d.width)) return [];
    if (d.hidden != null && typeof d.hidden !== "boolean") return [];
    if (d.locked != null && typeof d.locked !== "boolean" || d.dashed != null && typeof d.dashed !== "boolean") return [];
    const fibonacciOrigin = d.kind === "fibonacci" ? validateFibonacciOrigin(d.fibonacciOrigin) : null;
    const pivotLevelOrigin = d.kind === "horizontal" ? validatePivotLevelOrigin(d.pivotLevelOrigin) : null;
    seen.add(d.id);
    return [{ ...pivotLevelOrigin ? { pivotLevelOrigin } : {}, ...fibonacciOrigin ? { fibonacciOrigin } : {}, id: d.id, kind: d.kind, start: { time: d.start.time, price: d.start.price }, ...!singleAnchorDrawing(d.kind) ? { end: { time: d.end.time, price: d.end.price } } : {}, ...d.kind === "channel" ? { offset: { time: d.offset.time, price: d.offset.price }, ...d.extendLeft === true ? { extendLeft: true } : {}, ...d.extendRight === true ? { extendRight: true } : {}, ...d.middleLine === true ? { middleLine: true } : {} } : {}, color: d.color, ...d.hidden === true ? { hidden: true } : {}, ...d.locked != null ? { locked: d.locked } : {}, ...d.width != null ? { width: d.width } : {}, ...d.dashed != null ? { dashed: d.dashed } : {}, ...text != null ? { text } : {} }];
  });
}
var FIB_LEVELS = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1];
function drawingSegments(d) {
  if (!d.end) return [];
  if (["trend", "ray", "extended"].includes(d.kind)) return [{ start: d.start, end: d.end, label: "Trend" }];
  if (d.kind === "rectangle") return [
    { start: d.start, end: { time: d.end.time, price: d.start.price }, label: "" },
    { start: { time: d.end.time, price: d.start.price }, end: d.end, label: "" },
    { start: d.end, end: { time: d.start.time, price: d.end.price }, label: "" },
    { start: { time: d.start.time, price: d.end.price }, end: d.start, label: "" }
  ];
  if (d.kind !== "fibonacci") return [];
  return FIB_LEVELS.map((level) => {
    const price = d.start.price + (d.end.price - d.start.price) * level;
    return { start: { time: d.start.time, price }, end: { time: d.end.time, price }, label: `Fib ${(level * 100).toFixed(1)}%` };
  });
}

// artifacts/trading-dashboard/src/lib/chart-engine/nativePriceRenderer.ts
function prepareNativePriceSeries(input) {
  const candles = sanitizeCandlestickData(input).map(({ time: time2, open, high, low, close, volumeEvidence, profileEvidence }) => Object.freeze({
    time: time2,
    open,
    high,
    low,
    close,
    ...volumeEvidence ? { volumeEvidence: Object.freeze({ ...volumeEvidence }) } : {},
    ...profileEvidence ? { profileEvidence: Object.freeze({ ...profileEvidence }) } : {}
  }));
  return Object.freeze({
    candles: Object.freeze(candles),
    heikinAshi: Object.freeze(heikinAshi(candles).map((bar) => Object.freeze(bar))),
    discarded: input.length - candles.length
  });
}
var finiteOrNull = (value) => Number.isFinite(value) ? value : null;
var bodyWidth = (spacing) => Math.max(1, Math.min(24, spacing * 0.7));
function createNativePriceFrame(series, options) {
  const { style } = options;
  const scale = options.scale ?? "linear";
  const plot = Object.freeze({ ...options.plot });
  const range = Object.freeze({ ...options.range });
  if (![plot.left, plot.top, plot.width, plot.height, range.from, range.to].every(Number.isFinite) || plot.width <= 0 || plot.height <= 0 || range.to <= range.from || !Number.isFinite(range.to - range.from) || !Number.isFinite(plot.left + plot.width) || !Number.isFinite(plot.top + plot.height) || !["candles", "bars", "line", "area", "baseline", "heikinAshi", "hollow"].includes(style))
    return { ok: false, reason: "INVALID_VIEW" };
  if (!["linear", "log", "percent", "indexed"].includes(scale)) return { ok: false, reason: "INVALID_SCALE" };
  const reference = options.referencePrice;
  if ((scale === "percent" || scale === "indexed") && !(Number.isFinite(reference) && reference > 0))
    return { ok: false, reason: "INVALID_SCALE" };
  const closeOnly = closeOnlyStyle(style);
  const spacing = plot.width / (range.to - range.from);
  if (!Number.isFinite(spacing) || spacing <= 0) return { ok: false, reason: "INVALID_VIEW" };
  const halfBar = (bodyWidth(spacing) / 2 + (style === "hollow" ? 0.5 : 0)) / spacing;
  const start = Math.max(0, range.from), end = Math.min(series.candles.length - 1, range.to);
  const first = closeOnly ? Math.floor(start) : Math.max(0, Math.ceil(range.from - halfBar));
  const last = closeOnly ? Math.ceil(end) : Math.min(series.candles.length - 1, Math.floor(range.to + halfBar));
  if (closeOnly && end < start) return { ok: false, reason: "NO_VISIBLE_BARS" };
  if (last < first) return { ok: false, reason: "NO_VISIBLE_BARS" };
  const display = style === "heikinAshi" ? series.heikinAshi : series.candles;
  const transform = (price) => scale === "log" ? price > 0 ? Math.log(price) : NaN : price;
  let low = Infinity, high = -Infinity;
  for (let i = first; i <= last; i++) {
    const bar = display[i];
    if (!bar || !isValidCandlestickPoint(bar)) return { ok: false, reason: "INVALID_DISPLAY_BAR" };
    const a = transform(closeOnly ? bar.close : bar.low);
    const b = transform(closeOnly ? bar.close : bar.high);
    if (!Number.isFinite(a) || !Number.isFinite(b)) return { ok: false, reason: "INVALID_SCALE" };
    if (!closeOnly || i >= start && i <= end) {
      low = Math.min(low, a);
      high = Math.max(high, b);
    }
  }
  if (closeOnly) {
    for (const index of [start, end]) {
      const before = Math.floor(index), after = Math.ceil(index), weight = index - before;
      const a = transform(display[before].close), b = transform(display[after].close);
      const value = a * (1 - weight) + b * weight;
      if (!Number.isFinite(value)) return { ok: false, reason: "INVALID_SCALE" };
      low = Math.min(low, value);
      high = Math.max(high, value);
    }
  }
  if (style === "baseline" && !Number.isFinite(transform(series.candles[0].close)))
    return { ok: false, reason: "INVALID_SCALE" };
  for (const price of options.additionalPriceValues ?? []) {
    const value = transform(price);
    if (!Number.isFinite(value)) return { ok: false, reason: "INVALID_SCALE" };
    low = Math.min(low, value);
    high = Math.max(high, value);
  }
  const magnitude = Math.max(Math.abs(low), Math.abs(high)) || 1;
  const lowUnit = low / magnitude, highUnit = high / magnitude;
  const padding = highUnit > lowUnit ? (highUnit - lowUnit) * 0.08 : 0.01;
  const bottom = lowUnit - padding, extent = highUnit + padding - bottom;
  const inverted = options.inverted === true;
  if (!Number.isFinite(extent) || extent <= 0)
    return { ok: false, reason: "INVALID_VIEW" };
  const priceToY = (price, clipToPlot = false) => {
    if (!Number.isFinite(price)) return null;
    const transformed = transform(price);
    if (!Number.isFinite(transformed)) return null;
    const rawUnit = (transformed / magnitude - bottom) / extent;
    const unit = clipToPlot ? Math.max(0, Math.min(1, rawUnit)) : rawUnit;
    return finiteOrNull(plot.top + plot.height * (inverted ? unit : 1 - unit));
  };
  const yToPrice = (y) => {
    if (!Number.isFinite(y)) return null;
    const unit = (y - plot.top) / plot.height;
    const value = (bottom + (inverted ? unit : 1 - unit) * extent) * magnitude;
    const price = scale === "log" ? Math.exp(value) : value;
    return scale === "log" && price <= 0 ? null : finiteOrNull(price);
  };
  const logicalToX = (index) => Number.isFinite(index) ? finiteOrNull(plot.left + (index - range.from) * spacing) : null;
  const xToLogical = (x) => Number.isFinite(x) ? finiteOrNull(range.from + (x - plot.left) / spacing) : null;
  const frame = {
    series,
    plot,
    range,
    style,
    scale,
    inverted,
    first,
    last,
    spacing,
    priceToY,
    yToPrice,
    logicalToX,
    xToLogical,
    timeToX(time2) {
      if (!Number.isFinite(time2)) return null;
      let left = 0, right = series.candles.length - 1;
      while (left <= right) {
        const mid = left + Math.floor((right - left) / 2), candidate = series.candles[mid].time;
        if (candidate === time2) return logicalToX(mid);
        if (candidate < time2) left = mid + 1;
        else right = mid - 1;
      }
      return null;
    },
    barAtX(x) {
      if (x < plot.left || x > plot.left + plot.width) return null;
      const index = xToLogical(x);
      if (index == null) return null;
      return series.candles[Math.round(index)] ?? null;
    },
    axisValue(price) {
      if (!Number.isFinite(price) || scale === "log" && price <= 0) return null;
      return finiteOrNull(scale === "percent" ? (price / reference - 1) * 100 : scale === "indexed" ? price / reference * 100 : price);
    }
  };
  return { ok: true, frame: Object.freeze(frame) };
}
var UP = "#10b981";
var DOWN = "#ef4444";
var LINE = "#38bdf8";
function paintNativePriceLayer(ctx, frame) {
  const { plot, style, series } = frame;
  const display = style === "heikinAshi" ? series.heikinAshi : series.candles;
  ctx.save();
  try {
    ctx.beginPath();
    ctx.rect(plot.left, plot.top, plot.width, plot.height);
    ctx.clip();
    ctx.lineWidth = 1;
    ctx.lineCap = "butt";
    ctx.lineJoin = "miter";
    ctx.setLineDash([]);
    if (closeOnlyStyle(style)) {
      const points = [];
      for (let i = Math.max(0, frame.first - 1); i <= Math.min(display.length - 1, frame.last + 1); i++) {
        const x = frame.logicalToX(i), y2 = frame.priceToY(display[i].close);
        if (x != null && y2 != null) points.push({ x, y: y2 });
      }
      if (!points.length) return;
      const path = () => {
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) ctx.lineTo(points[i].x, points[i].y);
      };
      const stroke = (color2) => {
        path();
        ctx.strokeStyle = color2;
        ctx.lineWidth = 2;
        if (points.length === 1) {
          ctx.arc(points[0].x, points[0].y, 1, 0, Math.PI * 2);
          ctx.fillStyle = color2;
          ctx.fill();
        } else ctx.stroke();
      };
      const fill = (y2, color2) => {
        path();
        ctx.lineTo(points.at(-1).x, y2);
        ctx.lineTo(points[0].x, y2);
        ctx.closePath();
        ctx.fillStyle = color2;
        ctx.fill();
      };
      if (style === "area") fill(plot.top + plot.height, "rgba(56,189,248,0.18)");
      if (style !== "baseline") {
        stroke(LINE);
        return;
      }
      const baseline = frame.priceToY(series.candles[0].close, true);
      if (baseline == null) return;
      const y = Math.max(plot.top, Math.min(plot.top + plot.height, baseline));
      for (const topHalf of [true, false]) {
        ctx.save();
        try {
          ctx.beginPath();
          ctx.rect(plot.left, topHalf ? plot.top : y, plot.width, topHalf ? y - plot.top : plot.top + plot.height - y);
          ctx.clip();
          const up = topHalf !== frame.inverted;
          fill(y, up ? "rgba(16,185,129,0.18)" : "rgba(239,68,68,0.18)");
          stroke(up ? UP : DOWN);
        } finally {
          ctx.restore();
        }
      }
      return;
    }
    const width = bodyWidth(frame.spacing);
    for (let i = frame.first; i <= frame.last; i++) {
      const bar = display[i], x = frame.logicalToX(i);
      const open = frame.priceToY(bar.open), close = frame.priceToY(bar.close), high = frame.priceToY(bar.high), low = frame.priceToY(bar.low);
      if (x == null || open == null || close == null || high == null || low == null) continue;
      const hollow = style === "hollow" ? hollowPoint(bar, i ? series.candles[i - 1].close : null) : null;
      const color2 = hollow?.borderColor ?? (bar.close >= bar.open ? UP : DOWN);
      ctx.strokeStyle = color2;
      ctx.fillStyle = color2;
      ctx.beginPath();
      if (style === "bars") {
        ctx.moveTo(x, high);
        ctx.lineTo(x, low);
        ctx.moveTo(x - width / 2, open);
        ctx.lineTo(x, open);
        ctx.moveTo(x, close);
        ctx.lineTo(x + width / 2, close);
        ctx.stroke();
        continue;
      }
      const top = Math.min(open, close), bottom = Math.max(open, close);
      ctx.moveTo(x, Math.min(high, low));
      ctx.lineTo(x, top);
      ctx.moveTo(x, bottom);
      ctx.lineTo(x, Math.max(high, low));
      ctx.stroke();
      const y = Math.min(open, close), height = Math.max(1, Math.abs(close - open));
      if (hollow?.color !== "transparent") ctx.fillRect(x - width / 2, y, width, height);
      else ctx.strokeRect(x - width / 2, y, width, height);
    }
  } finally {
    ctx.restore();
  }
}

// artifacts/trading-dashboard/src/lib/chart-engine/nativeChartAxes.ts
function nativePlotLayout(width, height, priceAxisWidth = 88, timeAxisHeight = 32) {
  if (![width, height, priceAxisWidth, timeAxisHeight].every(Number.isFinite) || priceAxisWidth < 88 || timeAxisHeight < 20 || width < priceAxisWidth + 48 || height < timeAxisHeight + 40) return null;
  return { left: 8, top: 8, width: width - priceAxisWidth - 8, height: height - timeAxisHeight - 8 };
}
function formatAxisValue(value, digits, scale) {
  const precision = scale === "percent" || scale === "indexed" ? 2 : digits;
  let text = value.toFixed(precision);
  if (!text.includes("e") && text.includes(".")) text = text.replace(/0+$/, "").replace(/\.$/, "");
  if (value !== 0 && Number(text) === 0) text = String(value);
  if (/^-0(?:\.0+)?$/.test(text)) text = text.slice(1);
  return `${text}${scale === "percent" ? "%" : ""}`;
}
function nativePriceTicks(frame, options = {}) {
  const digits = Number.isInteger(options.priceDigits) && options.priceDigits >= 0 && options.priceDigits <= 16 ? options.priceDigits : 2;
  const gap = Number.isFinite(options.minSpacing) ? Math.max(24, options.minSpacing) : 48;
  const count = Math.max(1, Math.min(40, Math.floor(frame.plot.height / gap)));
  const top = frame.yToPrice(frame.plot.top), bottom = frame.yToPrice(frame.plot.top + frame.plot.height);
  if (top === null || bottom === null) return [];
  const topValue = frame.axisValue(top), bottomValue = frame.axisValue(bottom);
  if (topValue === null || bottomValue === null) return [];
  const lo = Math.min(topValue, bottomValue), hi = Math.max(topValue, bottomValue);
  const span = hi - lo;
  const candidates = [];
  const rawStep = span / count;
  const unit = Math.pow(10, Math.floor(Math.log10(rawStep)));
  const ratio = rawStep / unit;
  const step = (ratio <= 1 ? 1 : ratio <= 2 ? 2 : ratio <= 5 ? 5 : 10) * unit;
  if (frame.scale === "log" && lo > 0 && hi > lo) {
    const lowExponent = Math.floor(Math.log10(lo)), highExponent = Math.ceil(Math.log10(hi));
    const exponentStride = Math.max(1, Math.floor((highExponent - lowExponent) / Math.max(1, count)));
    for (let exponent = lowExponent; exponent <= highExponent; exponent += exponentStride) {
      for (const multiplier of [1, 2, 5]) {
        const price = multiplier * Math.pow(10, exponent), y = frame.priceToY(price);
        if (Number.isFinite(price) && price > 0 && y !== null && y >= frame.plot.top && y <= frame.plot.top + frame.plot.height)
          candidates.push({ y, price, value: price });
      }
    }
  } else if (Number.isFinite(span) && span > 0 && Number.isFinite(step) && step > 0) {
    const first = Math.ceil(lo / step) * step;
    for (let i = 0; i < 128; i++) {
      const value = first + i * step;
      if (!Number.isFinite(value) || value > hi) break;
      const weight = (value - bottomValue) / (topValue - bottomValue);
      const price = frame.scale === "percent" || frame.scale === "indexed" ? bottom * (1 - weight) + top * weight : value;
      const y = frame.priceToY(price);
      if (y !== null && y >= frame.plot.top && y <= frame.plot.top + frame.plot.height) candidates.push({ y, price, value });
    }
  }
  if (candidates.length < 2) {
    candidates.length = 0;
    for (let i = 0; i <= count; i++) {
      const y = frame.plot.top + frame.plot.height * i / count;
      const price = frame.yToPrice(y), value = price === null ? null : frame.axisValue(price);
      if (price !== null && value !== null) candidates.push({ y, price, value });
    }
  }
  const result = [], labels = /* @__PURE__ */ new Set();
  for (const tick of candidates.sort((a, b) => a.y - b.y)) {
    const label = formatAxisValue(tick.value, digits, frame.scale);
    if (labels.has(label) || result.length && tick.y - result[result.length - 1].y < gap) continue;
    result.push({ ...tick, label });
    labels.add(label);
  }
  return result;
}
function nativeTimeTicks(frame, options = {}) {
  const gap = Number.isFinite(options.minSpacing) ? Math.max(156, options.minSpacing) : 174;
  const first = Math.max(0, Math.ceil(frame.range.from));
  const last = Math.min(frame.series.candles.length - 1, Math.floor(frame.range.to));
  const stride = Math.max(1, Math.ceil(gap / frame.spacing));
  const result = [];
  for (let i = first; i <= last && result.length < 100; i += stride) {
    const time2 = frame.series.candles[i].time, x = frame.timeToX(time2);
    if (x === null || !Number.isFinite(time2) || Math.abs(time2) > 864e10) continue;
    try {
      result.push({ x, time: time2, label: formatChartTime(time2, options.timeZone ?? "UTC", { seconds: true }) });
    } catch {
    }
  }
  return result;
}
function paintNativeAxes(ctx, frame, options = {}) {
  const { left, top, width, height } = frame.plot, right = left + width, bottom = top + height;
  const prices = nativePriceTicks(frame, options), times = nativeTimeTicks(frame, options);
  ctx.save();
  try {
    ctx.font = "11px ui-monospace, monospace";
    ctx.lineWidth = 1;
    ctx.strokeStyle = "#203047";
    ctx.fillStyle = "#a8b7cc";
    ctx.beginPath();
    for (const tick of prices) {
      ctx.moveTo(left, tick.y);
      ctx.lineTo(right, tick.y);
    }
    for (const tick of times) {
      ctx.moveTo(tick.x, top);
      ctx.lineTo(tick.x, bottom);
    }
    ctx.stroke();
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    for (const tick of prices) ctx.fillText(tick.label, right + 6, Math.max(top + 7, Math.min(bottom - 7, tick.y)), 76);
    ctx.textBaseline = "top";
    let previousRight = -Infinity;
    for (const tick of times) {
      const compactSeconds = tick.label.replace(/^\d{4}-/, "");
      const compact = tick.label.replace(/^\d{4}-(\d{2}-\d{2}) (\d{2}:\d{2}):\d{2} (.+)$/, "$1 $2 $3");
      const clock = tick.label.match(/ (\d{2}:\d{2}):\d{2} /)?.[1] ?? tick.label;
      const label = [tick.label, compactSeconds, compact, clock].find((value) => ctx.measureText(value).width <= width);
      if (!label) continue;
      const measured = ctx.measureText(label).width;
      const x = Math.max(left, Math.min(right - measured, tick.x - measured / 2));
      if (measured > width || x < previousRight + 12) continue;
      ctx.fillText(label, x, (Number.isFinite(options.timeAxisBottom) ? options.timeAxisBottom : bottom) + 8);
      previousRight = x + measured;
    }
  } finally {
    ctx.restore();
  }
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartNavigation.ts
function bounded(center, span, count) {
  if (!Number.isSafeInteger(count) || count < 1 || !Number.isFinite(center) || !Number.isFinite(span)) return null;
  const width = Math.max(4, Math.min(count + 5, span));
  const from = Math.max(-3, Math.min(count + 2 - width, center - width / 2));
  return { from, to: from + width };
}
function valid(range) {
  return !!range && Number.isFinite(range.from) && Number.isFinite(range.to) && range.to > range.from;
}
function panChartWindow(range, fraction, count) {
  if (!valid(range) || !Number.isFinite(fraction) || Math.abs(fraction) > 1) return null;
  const span = range.to - range.from;
  return bounded((range.from + range.to) / 2 + span * fraction, span, count);
}
function zoomChartWindow(range, factor, count) {
  if (!valid(range) || !Number.isFinite(factor) || factor <= 0 || factor > 4) return null;
  return bounded((range.from + range.to) / 2, (range.to - range.from) * factor, count);
}

// artifacts/trading-dashboard/src/lib/chart-engine/candleReconciliation.ts
function sameCandle(a, b) {
  return a.time === b.time && a.open === b.open && a.high === b.high && a.low === b.low && a.close === b.close && sameVolumeInput(a.volumeEvidence, b.volumeEvidence) && sameProfileEvidence(a.profileEvidence, b.profileEvidence);
}
function unchangedCandlePrefix(previous, next) {
  let index = 0;
  while (index < previous.length && index < next.length && sameCandle(previous[index], next[index])) index++;
  return index;
}
function historyRangeShift(previous, next) {
  if (!previous.length || !next.length) return 0;
  let a = 0;
  let b = 0;
  while (a < previous.length && b < next.length) {
    if (previous[a].time === next[b].time) return b - a;
    if (previous[a].time < next[b].time) a++;
    else b++;
  }
  return 0;
}
function candleDisplayPrecision(candles, symbol = "") {
  const fiat = /^(EUR|USD|GBP|AUD|NZD|CAD|CHF|JPY)(EUR|USD|GBP|AUD|NZD|CAD|CHF|JPY)$/;
  let precision = fiat.test(symbol) ? symbol.endsWith("JPY") ? 3 : 5 : 2;
  for (const c of candles.slice(-100)) {
    for (const value of [c.open, c.high, c.low, c.close]) {
      for (let digits = precision; digits <= 8; digits++) {
        if (Math.abs(value - Number(value.toFixed(digits))) < 1e-9 || digits === 8) {
          precision = Math.max(precision, digits);
          break;
        }
      }
    }
  }
  return precision;
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartVolumeProfilePrimitive.ts
function projectVolumeProfile(result, project, width, height, slot = 0, count = 1) {
  if (!result || result.status !== "ready" || ![width, height].every((n) => Number.isFinite(n) && n > 0) || !Number.isInteger(count) || count < 1 || slot < 0 || slot >= count) return [];
  const budget = Math.min(280, width * 0.28), column = budget / count, right = width - 5 - slot * column, maxWidth = Math.max(0, column - 3), max = Math.max(...result.rows.map((r) => r.estimatedTradeUnits));
  if (maxWidth <= 0 || max <= 0) return [];
  const geometry = [];
  result.rows.forEach((row, index) => {
    const a = project(row.low), b = project(row.high);
    if (a == null || b == null || !Number.isFinite(a) || !Number.isFinite(b)) return;
    const low = Math.min(a, b), high = Math.max(a, b), y = Math.max(0, low === high ? low - 1 : low), bottom = Math.min(height, low === high ? high + 1 : high);
    if (bottom <= y) return;
    const w = maxWidth * row.estimatedTradeUnits / max;
    if (w <= 0) return;
    geometry.push({ index, x: right - w, y, width: w, height: bottom - y, poc: index === result.pocIndex, inValueArea: index >= result.valueArea.fromIndex && index <= result.valueArea.toIndex });
  });
  return geometry;
}

// artifacts/trading-dashboard/src/lib/chart-engine/nativeChartStudies.ts
var finite = (value) => typeof value === "number" && Number.isFinite(value);
function freezeConfig(config) {
  if (config.lineStyles) {
    config.lineStyles.forEach(Object.freeze);
    Object.freeze(config.lineStyles);
  }
  if (config.vwapAnchor) Object.freeze(config.vwapAnchor);
  if (config.profileRange) Object.freeze(config.profileRange);
  return Object.freeze(config);
}
function copyCandles(candles) {
  return sanitizeCandlestickData(candles).map((bar) => Object.isFrozen(bar) && (!bar.volumeEvidence || Object.isFrozen(bar.volumeEvidence)) && (!bar.profileEvidence || Object.isFrozen(bar.profileEvidence)) ? bar : Object.freeze({
    ...bar,
    ...bar.volumeEvidence ? { volumeEvidence: Object.freeze({ ...bar.volumeEvidence }) } : {},
    ...bar.profileEvidence ? { profileEvidence: Object.freeze({ ...bar.profileEvidence }) } : {}
  }));
}
var NativeChartStudies = class {
  candles = [];
  calculators = [];
  snapshots = Object.freeze([]);
  retained = /* @__PURE__ */ new Map();
  get paneCount() {
    return this.snapshots.filter((study) => study.paneIndex > 0).length;
  }
  getStudies() {
    return Object.freeze(this.snapshots.map((study) => study.config));
  }
  getRenderStudies() {
    return this.snapshots;
  }
  setStudies(configs, candles) {
    const valid2 = validatePreferences({ studies: configs }).studies.map(freezeConfig);
    const prior = new Map(this.calculators.map((calculator) => [studyId(calculator.config), calculator]));
    this.calculators = valid2.map((config) => {
      const old = prior.get(studyId(config));
      return old?.updatePresentation(config) ? old : new StudyCalculator(config);
    });
    this.setCandles(candles);
  }
  setCandles(candles) {
    if (!this.calculators.length) {
      this.candles = [];
      this.snapshots = Object.freeze([]);
      this.retained.clear();
      return;
    }
    const next = copyCandles(candles), from = unchangedCandlePrefix(this.candles, next);
    this.candles = next;
    let pane = 0;
    const retained = /* @__PURE__ */ new Map();
    this.snapshots = Object.freeze(this.calculators.map((calculator) => {
      const old = this.retained.get(calculator);
      calculator.calculate(next, from, false);
      const keep = Math.min(from, old?.points.length ?? 0, calculator.points.length);
      let points;
      if (old && keep === calculator.points.length && old.points.length === keep) points = old.points;
      else {
        const revised = old ? old.points.slice(0, keep) : [];
        for (let index = keep; index < calculator.points.length; index++) {
          const point = calculator.points[index];
          revised.push(Object.freeze({ time: point.time, values: Object.freeze([...point.values]), ...point.reason ? { reason: point.reason } : {} }));
        }
        points = Object.freeze(revised);
      }
      const snapshot = Object.freeze({
        config: calculator.config,
        paneIndex: studyDefinition(calculator.config.kind).pane ? ++pane : 0,
        points,
        ...calculator.profileResult ? { profile: calculator.profileResult } : {}
      });
      retained.set(calculator, snapshot);
      return snapshot;
    }));
    this.retained = retained;
  }
  reset() {
    this.setStudies(this.getStudies(), []);
  }
  getValues(time2) {
    return Object.freeze(this.snapshots.map((study) => {
      const config = study.config;
      if (config.kind === "volume_profile") return Object.freeze({
        label: studyLabel(config),
        color: config.color,
        ...study.profile?.status === "held" ? { reason: study.profile.reason } : {},
        values: Object.freeze([Object.freeze({
          name: config.lineStyles?.[0]?.visible === false ? "Frozen-range total trade units (hidden)" : "Frozen-range total trade units",
          value: study.profile?.status === "ready" ? study.profile.totalTradeUnits : null
        })])
      });
      let lo = 0, hi = study.points.length - 1, point;
      if (finite(time2)) while (lo <= hi) {
        const mid = lo + hi >>> 1, candidate = study.points[mid];
        if (candidate.time === time2) {
          point = candidate;
          break;
        }
        if (candidate.time < time2) lo = mid + 1;
        else hi = mid - 1;
      }
      return Object.freeze({
        label: studyLabel(config),
        color: config.color,
        ...point?.reason ? { reason: point.reason } : {},
        values: Object.freeze(studyDefinition(config.kind).channels.map((name, index) => Object.freeze({
          name: config.lineStyles?.[index]?.visible === false ? `${name} (hidden)` : name,
          value: finite(point?.values[index]) ? point.values[index] : null
        })))
      });
    }));
  }
  getProfiles() {
    return this.snapshots.flatMap((study) => study.profile ? [Object.freeze({ id: studyId(study.config), label: studyLabel(study.config), visible: study.config.lineStyles?.[0]?.visible !== false, result: study.profile })] : []);
  }
  getPriceBounds(range, scale = "linear") {
    if (!finite(range.from) || !finite(range.to) || range.to <= range.from) return [];
    const values = [];
    for (const study of this.snapshots) {
      if (study.paneIndex) continue;
      if (study.profile?.status === "ready" && study.config.lineStyles?.[0]?.visible !== false) {
        for (const row of study.profile.rows) values.push(row.low, row.high);
        continue;
      }
      studyDefinition(study.config.kind).channels.forEach((_, channel) => {
        if (study.config.lineStyles?.[channel]?.visible !== false) for (const value of visibleChannelValues(study, range, channel, scale)) values.push(value);
      });
    }
    return values;
  }
};
function layoutNativeStudyPanes(fullPlot, count) {
  if (!Number.isInteger(count) || count < 0 || count > 12 || ![fullPlot.left, fullPlot.top, fullPlot.width, fullPlot.height].every(finite) || fullPlot.width <= 0 || fullPlot.height <= 0 || !finite(fullPlot.left + fullPlot.width) || !finite(fullPlot.top + fullPlot.height)) return null;
  if (count === 0) return { price: Object.freeze({ ...fullPlot }), panes: [] };
  const unit = fullPlot.height / (count + 3), priceHeight = unit * 3;
  if (unit < 40 || priceHeight < 100) return null;
  return { price: Object.freeze({ ...fullPlot, height: priceHeight }), panes: Array.from({ length: count }, (_, i) => Object.freeze({ ...fullPlot, top: fullPlot.top + priceHeight + unit * i, height: unit })) };
}
function isHistogram(config, channel) {
  return config.kind === "macd" && channel === 2 || config.kind === "trade_volume" || config.kind === "tick_volume";
}
function visibleChannelValues(study, range, channel, scale = "linear", halfBar) {
  const values = /* @__PURE__ */ new Set(), margin = halfBar == null ? 1 : Math.max(1, Math.ceil(halfBar));
  const first = Math.max(0, Math.floor(range.from) - margin), last = Math.min(study.points.length - 1, Math.ceil(range.to) + margin);
  if (halfBar != null) {
    for (let i = first; i <= last; i++) {
      const value = study.points[i].values[channel];
      if (finite(value) && i + halfBar > range.from && i - halfBar < range.to) values.add(value);
    }
  } else for (let i = first; i < last; i++) {
    const a = study.points[i].values[channel], b = study.points[i + 1].values[channel];
    if (!finite(a) || !finite(b)) continue;
    const start = Math.max(range.from, i), end = Math.min(range.to, i + 1);
    if (end <= start) continue;
    if (scale === "log" && (a <= 0 || b <= 0)) {
      values.add(a);
      values.add(b);
      continue;
    }
    for (const boundary of [start, end]) {
      const weight = boundary - i;
      const value = weight === 0 ? a : weight === 1 ? b : scale === "log" ? Math.exp(Math.log(a) * (1 - weight) + Math.log(b) * weight) : a * (1 - weight) + b * weight;
      if (finite(value)) values.add(value);
    }
  }
  return [...values];
}
function visiblePoints(study, frame) {
  const hasHistogram = studyDefinition(study.config.kind).channels.some((_, channel) => isHistogram(study.config, channel));
  const half = hasHistogram ? Math.max(1, Math.min(24, frame.spacing * 0.7)) / (2 * frame.spacing) : 1;
  const margin = Math.max(1, Math.ceil(half));
  return study.points.slice(Math.max(0, Math.floor(frame.range.from) - margin), Math.min(study.points.length, Math.ceil(frame.range.to) + margin + 1));
}
function paneMapping(study, frame, plot) {
  const definition = studyDefinition(study.config.kind);
  const values = definition.range ? [...definition.range] : [...definition.levels ?? []];
  if (!definition.range) definition.channels.forEach((_, channel) => {
    if (study.config.lineStyles?.[channel]?.visible === false) return;
    const half = isHistogram(study.config, channel) ? Math.max(1, Math.min(24, frame.spacing * 0.7)) / (2 * frame.spacing) : void 0;
    for (const value of visibleChannelValues(study, frame.range, channel, "linear", half)) values.push(value);
  });
  if (study.config.kind === "trade_volume" || study.config.kind === "tick_volume") values.push(0);
  if (!values.length) return null;
  let low = Infinity, high = -Infinity;
  for (const value of values) {
    low = Math.min(low, value);
    high = Math.max(high, value);
  }
  const magnitude = Math.max(Math.abs(low), Math.abs(high)) || 1;
  const a = low / magnitude, b = high / magnitude, padding = definition.range ? 0 : b > a ? (b - a) * 0.08 : 0.01;
  const bottom = a - padding, extent = b + padding - bottom;
  if (!finite(extent) || extent <= 0) return null;
  return { low, high, y: (value) => {
    if (!finite(value)) return null;
    const y = plot.top + plot.height * (1 - (value / magnitude - bottom) / extent);
    return finite(y) ? y : null;
  } };
}
function clipped(ctx, plot, draw) {
  ctx.save();
  try {
    ctx.beginPath();
    ctx.rect(plot.left, plot.top, plot.width, plot.height);
    ctx.clip();
    ctx.globalAlpha = 1;
    draw();
  } finally {
    ctx.restore();
  }
}
function paintNativeStudies(ctx, frame, panes, studies) {
  if (panes.length !== studies.paneCount) throw new Error("Native study pane layout is incomplete");
  for (const study of studies.getRenderStudies()) {
    if (study.config.kind === "volume_profile") continue;
    const plot = study.paneIndex ? panes[study.paneIndex - 1] : frame.plot, points = visiblePoints(study, frame);
    const mapping = study.paneIndex ? paneMapping(study, frame, plot) : null;
    const y = study.paneIndex ? mapping?.y : (value) => frame.priceToY(value);
    clipped(ctx, plot, () => {
      const definition = studyDefinition(study.config.kind), anyVisible = definition.channels.some((_, i) => study.config.lineStyles?.[i]?.visible !== false);
      if (study.paneIndex) {
        ctx.strokeStyle = "#334155";
        ctx.lineWidth = 1;
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.moveTo(plot.left, plot.top);
        ctx.lineTo(plot.left + plot.width, plot.top);
        ctx.stroke();
        ctx.font = "10px sans-serif";
        ctx.textAlign = "left";
        ctx.textBaseline = "top";
        ctx.fillStyle = "#94a3b8";
        ctx.fillText(studyLabel(study.config) + (anyVisible ? "" : " \xB7 hidden"), plot.left + 5, plot.top + 4, Math.max(1, plot.width - 10));
      }
      if (!y || !anyVisible) return;
      for (const level of definition.levels ?? []) {
        const py = y(level);
        if (py == null) continue;
        ctx.strokeStyle = "#64748b";
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 4]);
        ctx.beginPath();
        ctx.moveTo(plot.left, py);
        ctx.lineTo(plot.left + plot.width, py);
        ctx.stroke();
      }
      definition.channels.forEach((_, channel) => {
        const style = study.config.lineStyles?.[channel];
        if (style?.visible === false) return;
        const histogram = isHistogram(study.config, channel);
        ctx.strokeStyle = studyChannelColor(study.config, channel);
        ctx.fillStyle = studyChannelColor(study.config, channel);
        ctx.lineWidth = style?.width ?? 1;
        ctx.setLineDash(style?.style === "dashed" ? [6, 4] : style?.style === "dotted" ? [2, 3] : []);
        if (histogram) {
          const zero = y(0);
          if (zero == null) return;
          const width = Math.max(1, Math.min(24, frame.spacing * 0.7));
          for (const point of points) {
            const value = point.values[channel];
            if (!finite(value)) continue;
            const px = frame.timeToX(point.time), py = y(value);
            if (px == null || py == null) continue;
            ctx.fillStyle = study.config.kind === "macd" ? value >= 0 ? "#10b981" : "#ef4444" : studyChannelColor(study.config, channel);
            ctx.fillRect(px - width / 2, Math.min(zero, py), width, Math.abs(zero - py));
          }
        } else {
          let connected = false;
          ctx.beginPath();
          for (const point of points) {
            const value = point.values[channel], px = frame.timeToX(point.time), py = finite(value) ? y(value) : null;
            if (px == null || py == null) {
              connected = false;
              continue;
            }
            if (connected) ctx.lineTo(px, py);
            else ctx.moveTo(px, py);
            connected = true;
          }
          ctx.stroke();
        }
      });
    });
    if (mapping && studyDefinition(study.config.kind).channels.some((_, channel) => study.config.lineStyles?.[channel]?.visible !== false)) {
      const channel = studyDefinition(study.config.kind).channels[0];
      ctx.save();
      try {
        ctx.beginPath();
        ctx.rect(plot.left + plot.width, plot.top, 88, plot.height);
        ctx.clip();
        ctx.globalAlpha = 1;
        ctx.fillStyle = "#94a3b8";
        ctx.font = "10px sans-serif";
        ctx.textAlign = "left";
        ctx.textBaseline = "top";
        ctx.fillText(formatStudyNumber(mapping.high, channel), plot.left + plot.width + 6, mapping.y(mapping.high), 76);
        if (mapping.low !== mapping.high) {
          ctx.textBaseline = "bottom";
          ctx.fillText(formatStudyNumber(mapping.low, channel), plot.left + plot.width + 6, mapping.y(mapping.low), 76);
        }
      } finally {
        ctx.restore();
      }
    }
  }
  const profiles = studies.getRenderStudies().filter((study) => study.profile?.status === "ready" && study.config.lineStyles?.[0]?.visible !== false);
  profiles.forEach((study, slot) => clipped(ctx, frame.plot, () => {
    const rows = projectVolumeProfile(study.profile, (price) => {
      const y = frame.priceToY(price);
      return y == null ? null : y - frame.plot.top;
    }, frame.plot.width, frame.plot.height, slot, profiles.length);
    ctx.fillStyle = studyChannelColor(study.config, 0);
    ctx.strokeStyle = studyChannelColor(study.config, 0);
    ctx.lineWidth = 1;
    ctx.setLineDash([]);
    for (const row of rows) {
      ctx.globalAlpha = row.inValueArea ? 0.33 : 0.16;
      ctx.fillRect(frame.plot.left + row.x, frame.plot.top + row.y, row.width, row.height);
      if (row.poc) {
        ctx.globalAlpha = 0.9;
        ctx.strokeRect(frame.plot.left + row.x, frame.plot.top + row.y, row.width, row.height);
      }
    }
    if (slot === 0 && frame.plot.width >= 220) {
      ctx.globalAlpha = 1;
      ctx.fillStyle = "#94a3b8";
      ctx.font = "10px sans-serif";
      ctx.textAlign = "right";
      ctx.textBaseline = "top";
      ctx.fillText(profiles.length === 1 ? "Estimated profile" : `Estimated profiles \xB7 ${profiles.length}`, frame.plot.left + frame.plot.width - 6, frame.plot.top + 4);
    }
  }));
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartRangeMeasurement.ts
function rangeMeasurement(start, end) {
  if (![start.time, end.time, start.price, end.price].every(Number.isFinite) || start.time <= 0 || end.time <= 0 || start.price <= 0 || end.price <= 0) return null;
  const priceChange = end.price - start.price;
  const ratio = priceChange / start.price * 100;
  return { priceChange, percentChange: Number.isFinite(ratio) ? ratio : null, elapsedSeconds: Math.abs(end.time - start.time), backwards: end.time < start.time };
}
var signed = (value) => `${value > 0 ? "+" : ""}${Number(value.toPrecision(8))}`;
function measurementLabels(start, end) {
  const value = rangeMeasurement(start, end);
  if (!value) return [];
  let remaining = value.elapsedSeconds;
  const parts = [];
  for (const [seconds, label] of [[86400, "d"], [3600, "h"], [60, "m"]]) {
    const amount = Math.floor(remaining / seconds);
    remaining -= amount * seconds;
    if (amount) parts.push(`${amount}${label}`);
  }
  if (remaining || !parts.length) parts.push(`${Number(remaining.toFixed(3))}s`);
  return [
    `Price ${signed(value.priceChange)} (${value.percentChange === null ? "percentage unavailable" : signed(value.percentChange) + "%"})`,
    `${parts.join(" ")} elapsed${value.backwards ? " \xB7 earlier" : ""}`
  ];
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartDrawingCanvas.ts
function drawingNotes(drawings, project, width, height, measure) {
  const notes = [];
  if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height < NOTE_PADDING * 2 + NOTE_LINE_HEIGHT + 8) return notes;
  for (const drawing of drawings) {
    if (drawing.hidden || drawing.kind !== "text") continue;
    const point = project(drawing.start);
    if (!point || !Number.isFinite(point.x) || !Number.isFinite(point.y) || point.x < 0 || point.x > width || point.y < 0 || point.y > height) continue;
    const layout = layoutTextNote(drawing.text ?? "", width - 8, measure);
    if (!layout) continue;
    const availableHeight = height - 8;
    const truncated = layout.height > availableHeight;
    const compact = truncated && availableHeight < NOTE_PADDING * 2 + NOTE_HEADER_HEIGHT + NOTE_LINE_HEIGHT;
    const maxLines = Math.max(0, Math.floor((availableHeight - NOTE_PADDING * 2 - NOTE_HEADER_HEIGHT - NOTE_LINE_HEIGHT) / NOTE_LINE_HEIGHT));
    const lines = truncated ? layout.lines.slice(0, compact ? 0 : maxLines) : layout.lines;
    const noteHeight = !truncated ? layout.height : compact ? NOTE_PADDING * 2 + NOTE_LINE_HEIGHT : NOTE_PADDING * 2 + NOTE_HEADER_HEIGHT + (lines.length + 1) * NOTE_LINE_HEIGHT;
    notes.push({
      ...layout,
      lines,
      height: noteHeight,
      truncated,
      compact,
      id: drawing.id,
      anchor: point,
      color: drawing.color,
      x: Math.max(4, Math.min(point.x + 8, width - layout.width - 4)),
      y: Math.max(4, Math.min(point.y + 8, height - noteHeight - 4))
    });
  }
  return notes;
}
function drawingStrokes(drawings, project, width, height = 0) {
  const strokes = [];
  for (const drawing of drawings) {
    if (drawing.hidden) continue;
    const style = { id: drawing.id, color: drawing.color, width: drawing.width ?? 1, dashed: drawing.dashed ?? ["horizontal", "fibonacci"].includes(drawing.kind) };
    if (drawing.kind === "horizontal") {
      const start = project(drawing.start, true);
      if (start) strokes.push({ ...style, start: { x: 0, y: start.y }, end: { x: width, y: start.y } });
      continue;
    }
    if (drawing.kind === "vertical") {
      const point = project(drawing.start);
      if (point) strokes.push({ ...style, start: { x: point.x, y: 0 }, end: { x: point.x, y: height } });
      continue;
    }
    if (drawing.kind === "measure") {
      const start = project(drawing.start), end = drawing.end && project(drawing.end);
      if (!start || !end || !drawing.end) continue;
      const corner = { x: end.x, y: start.y };
      strokes.push(
        { ...style, start, end, measurement: measurementLabels(drawing.start, drawing.end) },
        { ...style, dashed: true, start, end: corner },
        { ...style, dashed: true, start: corner, end }
      );
      continue;
    }
    if (drawing.kind === "channel") {
      const start = project(drawing.start), end = drawing.end && project(drawing.end), offset = drawing.offset && project(drawing.offset);
      if (!start || !end || !offset || Math.abs(end.x - start.x) < 1e-3) continue;
      const shift = offset.y - (start.y + (end.y - start.y) * (offset.x - start.x) / (end.x - start.x));
      if (!Number.isFinite(shift)) continue;
      const slope = (end.y - start.y) / (end.x - start.x);
      const left = Math.min(start.x, end.x), right = Math.max(start.x, end.x);
      const x1 = drawing.extendLeft ? Math.min(0, left) : left;
      const x2 = drawing.extendRight ? Math.max(width, right) : right;
      const at = (x, delta = 0) => ({ x, y: start.y + slope * (x - start.x) + delta });
      const from = start.x <= end.x ? x1 : x2, to = start.x <= end.x ? x2 : x1;
      const first = { start: at(from), end: at(to) }, second = { start: at(from, shift), end: at(to, shift) };
      if (![first.start.y, first.end.y, second.start.y, second.end.y].every(Number.isFinite)) continue;
      strokes.push({ ...style, ...first }, { ...style, ...second });
      if (drawing.middleLine) strokes.push({ ...style, dashed: true, start: at(from, shift / 2), end: at(to, shift / 2) });
      continue;
    }
    for (const segment of drawingSegments(drawing)) {
      let start = project(segment.start), end = project(segment.end);
      if (!start || !end) continue;
      if (["ray", "extended"].includes(drawing.kind)) {
        const dx = end.x - start.x;
        if (Math.abs(dx) < 1e-3) continue;
        const slope = (end.y - start.y) / dx;
        const at = (x) => ({ x, y: start.y + slope * (x - start.x) });
        end = at(dx > 0 ? width : 0);
        if (drawing.kind === "extended") start = at(dx > 0 ? 0 : width);
      }
      strokes.push({ ...style, start, end, ...drawing.kind === "fibonacci" ? { label: segment.label } : {} });
    }
  }
  return strokes;
}
function drawingHandles(drawing, project, width, height) {
  if (drawing.hidden) return [];
  const start = project(drawing.start, drawing.kind === "horizontal");
  if (!start) return [];
  if (drawing.kind === "horizontal") return [{ part: "start", point: { x: width / 2, y: start.y } }];
  if (drawing.kind === "vertical") return [{ part: "start", point: { x: start.x, y: height / 2 } }];
  if (drawing.kind === "text") return [{ part: "start", point: start }];
  const end = drawing.end && project(drawing.end);
  if (!end) return [];
  if (drawing.kind === "channel") {
    const offset = drawing.offset && project(drawing.offset);
    return offset ? [{ part: "start", point: start }, { part: "end", point: end }, { part: "offset", point: offset }] : [];
  }
  return [{ part: "start", point: start }, { part: "end", point: end }];
}
function hitTestDrawings(drawings, selected, project, width, height, point, tolerance = 8) {
  const active = drawings.find((drawing) => drawing.id === selected && !drawing.hidden);
  if (active && !active.locked) for (const handle of drawingHandles(active, project, width, height)) {
    if (Math.hypot(point.x - handle.point.x, point.y - handle.point.y) <= tolerance + 2) return { id: active.id, part: handle.part };
  }
  for (const note of drawingNotes(drawings, project, width, height).reverse()) {
    if (point.x >= note.x && point.x <= note.x + note.width && point.y >= note.y && point.y <= Math.min(height, note.y + note.height)) return { id: note.id, part: "body" };
    if (Math.hypot(point.x - note.anchor.x, point.y - note.anchor.y) <= tolerance) return { id: note.id, part: "body" };
  }
  for (const stroke of drawingStrokes(drawings, project, width, height).reverse()) {
    const dx = stroke.end.x - stroke.start.x, dy = stroke.end.y - stroke.start.y;
    const length = dx * dx + dy * dy;
    const fraction = length ? Math.max(0, Math.min(1, ((point.x - stroke.start.x) * dx + (point.y - stroke.start.y) * dy) / length)) : 0;
    if (Math.hypot(point.x - stroke.start.x - dx * fraction, point.y - stroke.start.y - dy * fraction) <= tolerance + stroke.width / 2) return { id: stroke.id, part: "body" };
  }
  return null;
}
function paintChartDrawings(ctx, size, strokes, notes, handles) {
  ctx.save();
  try {
    ctx.beginPath();
    ctx.rect(0, 0, size.width, size.height);
    ctx.clip();
    ctx.font = "10px sans-serif";
    for (const stroke of strokes) {
      if (Math.max(stroke.start.x, stroke.end.x) < 0 || Math.min(stroke.start.x, stroke.end.x) > size.width) continue;
      if (Math.max(stroke.start.y, stroke.end.y) < 0 || Math.min(stroke.start.y, stroke.end.y) > size.height) continue;
      ctx.strokeStyle = stroke.color;
      ctx.fillStyle = stroke.color;
      ctx.lineWidth = stroke.width;
      ctx.setLineDash(stroke.dashed ? [4, 4] : []);
      ctx.beginPath();
      ctx.moveTo(stroke.start.x, stroke.start.y);
      ctx.lineTo(stroke.end.x, stroke.end.y);
      ctx.stroke();
      if (stroke.measurement?.length && size.width >= 100 && size.height >= 44) {
        const width = Math.min(size.width - 8, Math.max(...stroke.measurement.map((line) => ctx.measureText(line).width)) + 12);
        const height = stroke.measurement.length * 14 + 8;
        const x = Math.max(4, Math.min(stroke.end.x + 8, size.width - width - 4));
        const y = Math.max(4, Math.min(stroke.end.y + 8, size.height - height - 4));
        ctx.save();
        try {
          ctx.fillStyle = "#09090bee";
          ctx.fillRect(x, y, width, height);
          ctx.beginPath();
          ctx.rect(x, y, width, height);
          ctx.clip();
          ctx.fillStyle = stroke.color;
          stroke.measurement.forEach((line, index) => ctx.fillText(line, x + 6, y + 14 + index * 14));
        } finally {
          ctx.restore();
        }
      }
      if (stroke.label) {
        const left = stroke.start.x < stroke.end.x ? stroke.start : stroke.end;
        ctx.fillText(stroke.label, Math.max(3, left.x + 3), left.y - 3);
      }
    }
    ctx.font = NOTE_FONT;
    ctx.textBaseline = "top";
    ctx.textAlign = "left";
    for (const note of notes) {
      ctx.setLineDash([]);
      ctx.lineWidth = 1;
      ctx.strokeStyle = note.color;
      ctx.beginPath();
      ctx.moveTo(note.anchor.x, note.anchor.y);
      ctx.lineTo(note.x, note.y);
      ctx.stroke();
      ctx.fillStyle = "#18181bee";
      ctx.fillRect(note.x, note.y, note.width, note.height);
      ctx.strokeRect(note.x, note.y, note.width, note.height);
      ctx.fillStyle = note.color;
      ctx.fillText(note.compact ? "Your note \xB7 Objects" : "Your note", note.x + NOTE_PADDING, note.y + NOTE_PADDING, note.width - NOTE_PADDING * 2);
      ctx.fillStyle = "#f4f4f5";
      note.lines.forEach((line, index) => ctx.fillText(line, note.x + NOTE_PADDING, note.y + NOTE_PADDING + NOTE_HEADER_HEIGHT + index * NOTE_LINE_HEIGHT, note.width - NOTE_PADDING * 2));
      if (note.truncated && !note.compact) {
        ctx.fillStyle = note.color;
        ctx.fillText("More in Objects", note.x + NOTE_PADDING, note.y + NOTE_PADDING + NOTE_HEADER_HEIGHT + note.lines.length * NOTE_LINE_HEIGHT, note.width - NOTE_PADDING * 2);
      }
      ctx.beginPath();
      ctx.arc(note.anchor.x, note.anchor.y, 3, 0, Math.PI * 2);
      ctx.fillStyle = note.color;
      ctx.fill();
    }
    ctx.setLineDash([]);
    ctx.lineWidth = 2;
    ctx.strokeStyle = "#38bdf8";
    ctx.fillStyle = "#09090b";
    for (const point of handles) {
      ctx.beginPath();
      ctx.arc(point.x, point.y, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
  } finally {
    ctx.restore();
  }
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartDrawingEditor.ts
function candleIndex(candles, time2) {
  let lo = 0, hi = candles.length - 1;
  while (lo <= hi) {
    const mid = lo + hi >>> 1, at = candles[mid].time;
    if (at === time2) return mid;
    if (at < time2) lo = mid + 1;
    else hi = mid - 1;
  }
  return -1;
}
function moveDrawing(drawing, part, origin, point, projection, snap) {
  if (drawing.kind === "text" && part === "body") {
    const start = projection.project(drawing.start);
    if (!start) return null;
    const moved2 = projection.anchor({ x: start.x + point.x - origin.x, y: start.y + point.y - origin.y }, false);
    return moved2 ? validateDrawings([{ ...drawing, start: moved2 }])[0] ?? null : null;
  }
  const target = projection.anchor(point, snap);
  if (!target) return null;
  if (part !== "body") {
    const anchor2 = drawing.kind === "horizontal" ? { ...drawing.start, price: target.price } : drawing.kind === "vertical" ? { ...drawing.start, time: target.time } : target;
    return validateDrawings([{ ...drawing, [part]: anchor2 }])[0] ?? null;
  }
  const candles = projection.candles();
  const startPoint = projection.anchor(origin, false);
  if (!startPoint) return null;
  const index = (time2) => candleIndex(candles, time2);
  let delta = index(target.time) - index(startPoint.time);
  const anchors = [drawing.start, ...drawing.end ? [drawing.end] : [], ...drawing.kind === "channel" && drawing.offset ? [drawing.offset] : []];
  const indexes = anchors.map((anchor2) => index(anchor2.time));
  if (drawing.kind !== "horizontal") {
    if (indexes.some((i) => i < 0)) return null;
    delta = Math.max(-Math.min(...indexes), Math.min(candles.length - 1 - Math.max(...indexes), delta));
  }
  const moved = anchors.map((anchor2, i) => {
    const pixel = projection.project(anchor2, drawing.kind === "horizontal");
    if (!pixel) return null;
    const price = drawing.kind === "vertical" ? anchor2.price : projection.price(pixel.y + point.y - origin.y);
    if (price == null || !Number.isFinite(price) || price <= 0) return null;
    return { time: drawing.kind === "horizontal" ? anchor2.time : candles[indexes[i] + delta].time, price };
  });
  if (moved.some((anchor2) => !anchor2)) return null;
  return validateDrawings([{ ...drawing, start: moved[0], ...drawing.end ? { end: moved[1] } : {}, ...drawing.kind === "channel" ? { offset: moved[2] } : {} }])[0] ?? null;
}
var ChartDrawingEditor = class {
  constructor(container, context2) {
    this.container = container;
    this.context = context2;
    this.originalTouchAction = container.style.touchAction;
    container.addEventListener("pointerdown", this.down, true);
    window.addEventListener("pointermove", this.move, true);
    window.addEventListener("pointerup", this.up, true);
    window.addEventListener("pointercancel", this.cancelPointer, true);
    container.addEventListener("lostpointercapture", this.cancelPointer, true);
    window.addEventListener("keydown", this.key);
    window.addEventListener("blur", this.cancel);
    for (const name of ["mousedown", "touchstart", "touchmove", "click", "dblclick"]) container.addEventListener(name, this.blockCompatibility, { capture: true, passive: false });
  }
  config = null;
  drawings = [];
  placement = null;
  gesture = null;
  tap = null;
  suppressClickUntil = 0;
  originalTouchAction;
  destroyed = false;
  revision = 0;
  clone(drawings) {
    const ids = /* @__PURE__ */ new Set();
    return drawings.flatMap((row) => validateDrawings([row])).filter((row) => {
      if (ids.has(row.id)) return false;
      ids.add(row.id);
      return true;
    });
  }
  current(revision) {
    return !this.destroyed && revision === this.revision;
  }
  configure(config) {
    if (this.destroyed) return;
    if (config?.owner && config.owner === this.config?.owner && config.selectedId === this.config.selectedId && config.snap === this.config.snap) {
      this.config = { ...config };
      return;
    }
    const revision = this.cancelCurrent();
    if (!this.current(revision)) return;
    this.config = config ? { ...config } : null;
    this.context.select(config?.selectedId ?? null);
  }
  setDrawings(drawings) {
    if (this.destroyed) return;
    const next = this.clone(drawings), revision = this.cancelCurrent();
    if (this.current(revision)) this.drawings = next;
  }
  setPlacement(handler) {
    if (this.destroyed) return;
    const revision = this.cancelCurrent();
    if (!this.current(revision)) return;
    this.placement = handler;
    this.container.style.touchAction = handler ? "none" : this.originalTouchAction;
  }
  /** Cancel an unfinished preview/tap without persisting it. */
  cancelGesture() {
    if (!this.destroyed) this.cancelCurrent();
  }
  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    this.cancelCurrent();
    this.container.style.touchAction = this.originalTouchAction;
    this.container.removeEventListener("pointerdown", this.down, true);
    window.removeEventListener("pointermove", this.move, true);
    window.removeEventListener("pointerup", this.up, true);
    window.removeEventListener("pointercancel", this.cancelPointer, true);
    this.container.removeEventListener("lostpointercapture", this.cancelPointer, true);
    window.removeEventListener("keydown", this.key);
    window.removeEventListener("blur", this.cancel);
    for (const name of ["mousedown", "touchstart", "touchmove", "click", "dblclick"]) this.container.removeEventListener(name, this.blockCompatibility, true);
    this.config = null;
    this.placement = null;
    this.drawings = [];
  }
  point(event) {
    const rect = this.container.getBoundingClientRect();
    const point = this.context.eventPoint ? this.context.eventPoint(event) : { x: event.clientX - rect.left, y: event.clientY - rect.top };
    return point && Number.isFinite(point.x) && Number.isFinite(point.y) ? point : null;
  }
  block(event) {
    event.preventDefault();
    event.stopImmediatePropagation();
  }
  blockCompatibility = (event) => {
    if (this.gesture || this.placement || Date.now() < this.suppressClickUntil) this.block(event);
  };
  down = (event) => {
    if (this.destroyed) return;
    if (this.gesture || this.tap) {
      this.cancel();
      return;
    }
    if (event.button !== 0 || event.isPrimary === false || !(event.target instanceof HTMLCanvasElement)) return;
    const revision = this.revision;
    const point = this.point(event), size = this.context.size();
    if (!this.current(revision) || !point || point.x < 0 || point.y < 0 || point.x > size.width || point.y > size.height) return;
    this.container.focus({ preventScroll: true });
    if (!this.current(revision)) return;
    if (this.placement) {
      this.tap = { id: event.pointerId, point };
      this.block(event);
      try {
        this.container.setPointerCapture(event.pointerId);
      } catch {
      }
      return;
    }
    if (!this.config) return;
    const hit = hitTestDrawings(this.drawings, this.config.selectedId, this.context.project, size.width, size.height, point, event.pointerType === "touch" ? 14 : 8);
    const drawing = this.drawings.find((d) => d.id === hit?.id);
    if (hit && drawing && !drawing.locked) this.block(event);
    const config = { ...this.config, selectedId: hit?.id ?? null };
    this.config = config;
    config.onSelect(config.selectedId);
    if (!this.current(revision)) return;
    this.context.select(config.selectedId);
    if (!this.current(revision) || !hit || !drawing || drawing.locked) return;
    const gesture = { pointerId: event.pointerId, origin: point, original: this.drawings, drawing, part: hit.part, preview: this.drawings, changed: false, onCommit: config.onCommit };
    this.gesture = gesture;
    this.context.freeze(true);
    if (!this.current(revision) || this.gesture !== gesture) return;
    this.container.style.touchAction = "none";
    try {
      this.container.setPointerCapture(event.pointerId);
    } catch {
    }
  };
  move = (event) => {
    const gesture = this.gesture;
    if (this.destroyed || !gesture || gesture.pointerId !== event.pointerId) return;
    this.block(event);
    const point = this.point(event), size = this.context.size();
    if (!point || point.x < 0 || point.x > size.width || point.y < 0 || point.y > size.height) return;
    if (!gesture.changed && Math.hypot(point.x - gesture.origin.x, point.y - gesture.origin.y) < 3) return;
    const moved = moveDrawing(gesture.drawing, gesture.part, gesture.origin, point, this.context, this.config?.snap ?? false);
    if (!moved) return;
    gesture.preview = gesture.original.map((d) => d.id === moved.id ? moved : d);
    gesture.changed = JSON.stringify(moved) !== JSON.stringify(gesture.drawing);
    this.context.render(this.clone(gesture.preview));
  };
  up = (event) => {
    if (this.destroyed) return;
    if (this.tap && this.tap.id === event.pointerId) {
      const tap = this.tap, revision2 = this.revision, placement = this.placement;
      this.tap = null;
      this.release(event.pointerId);
      this.block(event);
      if (!this.current(revision2)) return;
      const point2 = this.point(event), size2 = this.context.size();
      if (!this.current(revision2) || !point2 || point2.x < 0 || point2.x > size2.width || point2.y < 0 || point2.y > size2.height) return;
      if (Math.hypot(point2.x - tap.point.x, point2.y - tap.point.y) <= 5) {
        const anchor2 = this.context.anchor(point2, this.config?.snap ?? false);
        if (anchor2 && this.current(revision2)) placement?.(anchor2);
      }
      return;
    }
    const gesture = this.gesture, revision = this.revision;
    if (!gesture || gesture.pointerId !== event.pointerId) return;
    const point = this.point(event), size = this.context.size();
    if (!point || point.x < 0 || point.x > size.width || point.y < 0 || point.y > size.height) {
      this.block(event);
      this.cancel();
      return;
    }
    this.move(event);
    if (!this.current(revision) || this.gesture !== gesture) return;
    this.gesture = null;
    this.release(event.pointerId);
    this.container.style.touchAction = this.originalTouchAction;
    this.suppressClickUntil = Date.now() + 250;
    this.context.freeze(false);
    if (!this.current(revision)) return;
    if (gesture.changed) {
      this.drawings = this.clone(gesture.preview);
      gesture.onCommit(this.clone(this.drawings));
    }
  };
  release(id) {
    try {
      this.container.releasePointerCapture(id);
    } catch {
    }
  }
  cancelPointer = (event) => {
    if (this.gesture?.pointerId === event.pointerId || this.tap?.id === event.pointerId) this.cancel();
  };
  key = (event) => {
    if (this.destroyed) return;
    if (event.key === "Escape") {
      this.cancel();
      return;
    }
    if (event.defaultPrevented || event.isComposing || event.repeat || event.altKey || event.target !== this.container || document.activeElement !== this.container || !this.config || this.gesture || this.tap || this.placement) return;
    const key = event.key.toLowerCase();
    if (event.ctrlKey || event.metaKey) {
      const action = key === "z" ? event.shiftKey ? this.config.onRedo : this.config.onUndo : key === "y" && event.ctrlKey && !event.metaKey && !event.shiftKey ? this.config.onRedo : void 0;
      if (action) {
        this.block(event);
        action();
      }
      return;
    }
    if (event.shiftKey || key !== "delete" && key !== "backspace") return;
    const selected = this.drawings.find((d) => d.id === this.config.selectedId);
    if (!selected || selected.locked || selected.hidden) return;
    this.block(event);
    const revision = ++this.revision, config = this.config;
    this.config = { ...config, selectedId: null };
    this.drawings = this.drawings.filter((d) => d.id !== selected.id);
    this.context.render(this.clone(this.drawings));
    if (!this.current(revision)) return;
    this.context.select(null);
    if (!this.current(revision)) return;
    config.onSelect(null);
    if (this.current(revision)) config.onCommit(this.clone(this.drawings));
  };
  cancelCurrent() {
    const revision = ++this.revision, gesture = this.gesture, tap = this.tap;
    this.gesture = null;
    this.tap = null;
    this.container.style.touchAction = this.placement ? "none" : this.originalTouchAction;
    if (gesture) this.release(gesture.pointerId);
    if (tap) this.release(tap.id);
    if (gesture) {
      this.context.freeze(false);
      if (revision === this.revision) this.context.render(this.clone(gesture.original));
    }
    return revision;
  }
  cancel = () => {
    if (!this.destroyed) this.cancelCurrent();
  };
};

// artifacts/trading-dashboard/src/lib/chart-engine/nativeChartViewport.ts
var MAX_CSS_SIDE = 16384;
var MAX_BACKING_SIDE = 8192;
var MAX_BACKING_PIXELS = 16777216;
var clamp = (value, low, high) => Math.max(low, Math.min(high, value));
var NativeChartViewport = class {
  constructor(container, options = {}) {
    this.container = container;
    this.options = { ...options };
    if (options.style && CHART_STYLES.includes(options.style)) this.style = options.style;
    if (options.scale && ["linear", "log", "percent", "indexed"].includes(options.scale)) this.scale = options.scale;
    this.inverted = options.inverted === true;
    if (isChartTimeZone(options.timeZone)) this.timeZone = options.timeZone;
    this.timeframe = options.timeframe ?? "M1";
    this.canvas = container.ownerDocument.createElement("canvas");
    this.canvas.dataset.arxNativeViewport = "true";
    this.canvas.tabIndex = 0;
    this.canvas.setAttribute("role", "region");
    this.canvas.setAttribute("aria-label", "ARX price chart. Drag to pan, scroll or pinch to zoom. Arrow keys pan, plus and minus zoom, Home fits history, End returns to latest.");
    this.canvas.style.touchAction = "none";
    this.canvas.style.display = "block";
    this.canvas.width = 0;
    this.canvas.height = 0;
    this.canvas.style.width = "0px";
    this.canvas.style.height = "0px";
    const context2 = this.canvas.getContext("2d");
    if (!context2) throw new Error("Canvas 2D is unavailable");
    this.context = context2;
    container.appendChild(this.canvas);
    this.drawingEditor = new ChartDrawingEditor(this.canvas, {
      candles: () => this.series.candles,
      project: (anchor2, priceOnly) => this.projectDrawing(anchor2, priceOnly),
      anchor: (point, snap) => this.drawingAnchor(point, snap),
      price: (y) => {
        const frame = this.getFrame();
        return frame?.yToPrice(y + frame.plot.top) ?? null;
      },
      size: () => {
        const plot = this.getFrame()?.plot;
        return { width: plot?.width ?? 0, height: plot?.height ?? 0 };
      },
      eventPoint: (event) => {
        const point = this.point(event), plot = this.getFrame()?.plot;
        return point && plot ? { x: point.x - plot.left, y: point.y - plot.top } : null;
      },
      render: (drawings) => {
        if (!this.destroyed) {
          this.drawings = this.cloneDrawings(drawings);
          this.schedule();
        }
      },
      select: (id) => {
        if (!this.destroyed) {
          this.selectedDrawing = id;
          this.schedule();
        }
      },
      freeze: (active) => {
        if (active) {
          this.cancelGesture();
          this.frozenDrawingFrame = this.getFrame();
          const drawing = this.drawings.find((row) => row.id === this.selectedDrawing);
          this.editAnchorTimes = drawing && drawing.kind !== "horizontal" ? [drawing.start, ...drawing.end ? [drawing.end] : [], ...drawing.offset ? [drawing.offset] : []].map((anchor2) => anchor2.time) : [];
          this.clearHover();
        } else {
          this.frozenDrawingFrame = null;
          this.editAnchorTimes = [];
          this.invalidate();
        }
      }
    });
    const listen = (type, handler, options2) => {
      this.canvas.addEventListener(type, handler, options2);
      this.listeners.push(() => this.canvas.removeEventListener(type, handler, options2));
    };
    listen("pointerdown", this.onPointerDown);
    listen("pointermove", this.onPointerMove);
    listen("pointerup", this.onPointerUp);
    listen("pointercancel", this.onPointerCancel);
    listen("lostpointercapture", this.onLostCapture);
    listen("pointerleave", (() => {
      if (!this.pointers.size) this.clearHover();
    }));
    listen("wheel", this.onWheel, { passive: false });
    listen("keydown", this.onKeyDown);
    const listenWindow = (type, handler) => {
      window.addEventListener(type, handler);
      this.listeners.push(() => window.removeEventListener(type, handler));
    };
    listenWindow("pointermove", this.onOutsidePointerMove);
    listenWindow("pointerup", this.onPointerUp);
    listenWindow("pointercancel", this.onOutsidePointerCancel);
    listenWindow("blur", this.onWindowBlur);
    window.addEventListener("resize", this.onResize);
    this.listeners.push(() => window.removeEventListener("resize", this.onResize));
    if (typeof ResizeObserver !== "undefined") {
      this.observer = new ResizeObserver(() => {
        if (!this.destroyed) this.resize();
      });
      this.observer.observe(container);
    }
    this.resize();
  }
  canvas;
  context;
  options;
  series = prepareNativePriceSeries([]);
  studies = new NativeChartStudies();
  priceOnlyScale = false;
  drawingEditor;
  drawings = [];
  selectedDrawing = null;
  drawingInteraction = null;
  drawingHandler = null;
  drawingNavigationMode = "inspect";
  frozenDrawingFrame = null;
  editAnchorTimes = [];
  range = null;
  frame = null;
  referencePrice = null;
  referenceSet = false;
  style = "candles";
  scale = "linear";
  inverted = false;
  timeZone = "UTC";
  timeframe = "M1";
  priceDigits = 2;
  width = 0;
  height = 0;
  pixelRatio = 1;
  followingLatest = true;
  destroyed = false;
  generation = 0;
  mutationRevision = 0;
  raf = null;
  drawCount = 0;
  paintError = null;
  frameIssue = null;
  callbackError = null;
  hover = null;
  pointers = /* @__PURE__ */ new Map();
  gesture = null;
  observer = null;
  media = null;
  listeners = [];
  watchDpr() {
    this.media?.removeEventListener("change", this.onDprChange);
    this.media = typeof window.matchMedia === "function" ? window.matchMedia(`(resolution: ${window.devicePixelRatio || 1}dppx)`) : null;
    this.media?.addEventListener("change", this.onDprChange);
  }
  onDprChange = () => {
    if (!this.destroyed) this.resize();
  };
  onResize = () => {
    if (!this.destroyed) this.resize();
  };
  resize(width, height) {
    if (this.destroyed) return;
    const revision = ++this.mutationRevision;
    const bounds = this.container.getBoundingClientRect();
    const w = width ?? bounds.width, h = height ?? this.options.height ?? bounds.height;
    const requestedRatio = Number.isFinite(window.devicePixelRatio) && window.devicePixelRatio > 0 ? window.devicePixelRatio : 1;
    const valid2 = Number.isFinite(w) && Number.isFinite(h) && w > 0 && h > 0 && w <= MAX_CSS_SIDE && h <= MAX_CSS_SIDE;
    const nextWidth = valid2 ? w : 0, nextHeight = valid2 ? h : 0;
    const ratio = valid2 ? Math.min(requestedRatio, MAX_BACKING_SIDE / w, MAX_BACKING_SIDE / h, Math.sqrt(MAX_BACKING_PIXELS / (w * h))) : 1;
    if (nextWidth !== this.width || nextHeight !== this.height || ratio !== this.pixelRatio) {
      this.drawingEditor.cancelGesture();
      this.cancelGesture();
      this.clearHover();
      if (this.destroyed || revision !== this.mutationRevision) return;
      this.width = nextWidth;
      this.height = nextHeight;
      this.pixelRatio = ratio;
      this.canvas.width = Math.floor(this.width * ratio);
      this.canvas.height = Math.floor(this.height * ratio);
      this.canvas.style.width = `${this.width}px`;
      this.canvas.style.height = `${this.height}px`;
      this.invalidate();
    }
    this.watchDpr();
  }
  setCandles(candles) {
    if (this.destroyed) return;
    const revision = ++this.mutationRevision;
    const previous = this.series.candles;
    const next = prepareNativePriceSeries(candles);
    const times = new Set(next.candles.map((candle) => candle.time));
    const overlap = previous.some((candle) => times.has(candle.time));
    const selected = this.drawings.find((drawing) => drawing.id === this.selectedDrawing);
    const anchors = selected ? [selected.start, ...selected.end ? [selected.end] : [], ...selected.offset ? [selected.offset] : []] : [];
    if (!next.candles.length || previous.length && !overlap || selected?.kind !== "horizontal" && anchors.some((anchor2) => !times.has(anchor2.time)) || this.editAnchorTimes.some((time2) => !times.has(time2))) this.drawingEditor.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    this.series = next;
    this.studies.setCandles(next.candles);
    if (!this.referenceSet && next.candles.length) {
      this.referencePrice = next.candles[0].close;
      this.referenceSet = true;
    }
    this.priceDigits = Number.isInteger(this.options.priceDigits) && this.options.priceDigits >= 0 && this.options.priceDigits <= 16 ? this.options.priceDigits : candleDisplayPrecision(next.candles);
    if (!next.candles.length || previous.length && !overlap) this.cancelGesture();
    if (!next.candles.length) this.range = null;
    else if (this.followingLatest && !this.frozenDrawingFrame || !this.range || !overlap) this.range = this.latestRange(this.range ? this.range.to - this.range.from : void 0);
    else {
      const shift = historyRangeShift(previous, next.candles);
      const desired = { from: this.range.from + shift, to: this.range.to + shift };
      const bounded2 = panChartWindow(desired, 0, next.candles.length);
      if (this.frozenDrawingFrame && (!bounded2 || Math.abs(bounded2.from - desired.from) > 1e-9 || Math.abs(bounded2.to - desired.to) > 1e-9)) this.drawingEditor.cancelGesture();
      this.range = bounded2;
    }
    this.invalidate();
  }
  latestRange(span = this.options.visibleBars ?? 100) {
    const count = this.series.candles.length;
    const width = Number.isFinite(span) && span > 0 ? span : 100;
    return panChartWindow({ from: count + 1 - width, to: count + 1 }, 0, count);
  }
  cloneDrawings(drawings) {
    const seen = /* @__PURE__ */ new Set();
    return drawings.flatMap((row) => validateDrawings([row])).filter((row) => {
      if (seen.has(row.id)) return false;
      seen.add(row.id);
      return true;
    });
  }
  setDrawings(drawings) {
    if (this.destroyed) return;
    this.drawingEditor.cancelGesture();
    this.drawings = this.cloneDrawings(drawings);
    this.drawingEditor.setDrawings(this.drawings);
    this.schedule();
  }
  getDrawings() {
    return this.cloneDrawings(this.drawings);
  }
  setDrawingInteraction(config) {
    if (this.destroyed) return;
    this.drawingInteraction = config ? {
      ...config,
      onSelect: (id) => this.notify("drawing selection", () => config.onSelect(id)),
      onCommit: (next) => {
        this.drawings = this.cloneDrawings(next);
        this.schedule();
        this.notify("drawing commit", () => config.onCommit(this.cloneDrawings(next)));
      }
    } : null;
    this.drawingEditor.configure(this.drawingNavigationMode === "pan" ? null : this.drawingInteraction);
  }
  setDrawingHandler(handler) {
    if (this.destroyed) return;
    this.drawingHandler = handler;
    this.applyDrawingPlacement();
  }
  setNavigationMode(mode) {
    if (this.destroyed || mode !== "inspect" && mode !== "pan") return;
    this.drawingNavigationMode = mode;
    this.drawingEditor.configure(mode === "pan" ? null : this.drawingInteraction);
    this.applyDrawingPlacement();
  }
  activeDrawingPlacement() {
    return this.drawingNavigationMode !== "pan" && this.drawingHandler !== null;
  }
  applyDrawingPlacement() {
    this.cancelGesture();
    this.clearHover();
    const handler = this.activeDrawingPlacement() ? this.drawingHandler : null;
    this.drawingEditor.setPlacement(handler ? (anchor2) => this.notify("drawing placement", () => handler(anchor2)) : null);
    this.canvas.style.cursor = this.drawingNavigationMode === "pan" ? "grab" : handler ? "crosshair" : "";
  }
  projectDrawing(anchor2, priceOnly = false) {
    const frame = this.getFrame();
    if (!frame) return null;
    const x = priceOnly ? frame.plot.left : frame.timeToX(anchor2.time), y = frame.priceToY(anchor2.price);
    return x == null || y == null ? null : { x: x - frame.plot.left, y: y - frame.plot.top };
  }
  drawingAnchor(point, snap) {
    const frame = this.getFrame();
    if (!frame || point.x < 0 || point.y < 0 || point.x > frame.plot.width || point.y > frame.plot.height) return null;
    const x = point.x + frame.plot.left, y = point.y + frame.plot.top, candle = frame.barAtX(x);
    let price = frame.yToPrice(y);
    if (!candle || price == null || price <= 0 || !Number.isFinite(price)) return null;
    if (snap) price = [candle.open, candle.high, candle.low, candle.close].reduce((best, value) => {
      const a = frame.priceToY(value), b = frame.priceToY(best);
      return a != null && b != null && Math.abs(a - y) < Math.abs(b - y) ? value : best;
    });
    return { time: candle.time, price };
  }
  paintDrawings(ctx, frame) {
    if (!this.drawings.length) return;
    const { width, height, left, top } = frame.plot;
    const project = (anchor2, priceOnly) => this.projectDrawing(anchor2, priceOnly);
    const strokes = drawingStrokes(this.drawings, project, width, height);
    const notes = drawingNotes(this.drawings, project, width, height);
    const selected = this.drawings.find((drawing) => drawing.id === this.selectedDrawing && !drawing.hidden && !drawing.locked);
    const handles = selected ? drawingHandles(selected, project, width, height).map((handle) => handle.point) : [];
    ctx.save();
    try {
      ctx.translate(left, top);
      paintChartDrawings(ctx, { width, height }, strokes, notes, handles);
    } finally {
      ctx.restore();
    }
    ctx.save();
    try {
      ctx.beginPath();
      ctx.rect(left + width, top, this.width - left - width, height);
      ctx.clip();
      ctx.font = "10px sans-serif";
      ctx.textBaseline = "middle";
      ctx.textAlign = "left";
      for (const drawing of this.drawings) {
        if (drawing.hidden || drawing.kind !== "horizontal") continue;
        const y = frame.priceToY(drawing.start.price);
        if (y == null || y < top || y > top + height) continue;
        ctx.fillStyle = drawing.color;
        ctx.fillRect(left + width, y - 8, this.width - left - width, 16);
        ctx.fillStyle = "#09090b";
        let label = drawing.start.price.toFixed(this.priceDigits);
        if (Number(label) === 0 && drawing.start.price !== 0) label = String(drawing.start.price);
        ctx.fillText(label, left + width + 3, y, this.width - left - width - 6);
      }
    } finally {
      ctx.restore();
    }
  }
  getRange() {
    return this.range ? Object.freeze({ ...this.range }) : null;
  }
  getPaneLayout() {
    const full = nativePlotLayout(this.width, this.height);
    return full ? layoutNativeStudyPanes(full, this.studies.paneCount) : null;
  }
  setStudies(configs) {
    if (this.destroyed) return;
    const revision = ++this.mutationRevision;
    this.drawingEditor.cancelGesture();
    this.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    this.studies.setStudies(configs, this.series.candles);
    this.invalidate();
  }
  getStudyValues(time2) {
    return this.studies.getValues(time2);
  }
  getVolumeProfiles() {
    return this.studies.getProfiles();
  }
  setPriceOnlyScale(enabled) {
    if (this.destroyed || this.priceOnlyScale === enabled) return;
    const revision = ++this.mutationRevision;
    this.drawingEditor.cancelGesture();
    this.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    this.priceOnlyScale = enabled;
    this.invalidate();
  }
  getFrame() {
    if (this.destroyed || this.paintError || !this.range) {
      this.frameIssue = this.destroyed ? "DESTROYED" : this.paintError ? "PAINT_FAILED" : "NO_DATA";
      return null;
    }
    if (this.frame) return this.frame;
    if (!nativePlotLayout(this.width, this.height)) {
      this.frameIssue = "ZERO_SIZE_OR_UNSUPPORTED_DIMENSIONS";
      return null;
    }
    const layout = this.getPaneLayout();
    if (!layout) {
      this.frameIssue = "INSUFFICIENT_PANE_SPACE_OR_UNSUPPORTED_DIMENSIONS";
      return null;
    }
    const plot = layout.price;
    const result = createNativePriceFrame(this.series, {
      plot,
      range: this.range,
      style: this.style,
      scale: this.scale,
      inverted: this.inverted,
      referencePrice: this.referencePrice ?? void 0,
      additionalPriceValues: this.priceOnlyScale ? [] : this.studies.getPriceBounds(this.range, this.scale)
    });
    this.frame = result.ok ? result.frame : null;
    if (this.frame && this.frozenDrawingFrame) this.frame = Object.freeze({
      ...this.frame,
      priceToY: this.frozenDrawingFrame.priceToY,
      yToPrice: this.frozenDrawingFrame.yToPrice
    });
    this.frameIssue = result.ok ? null : result.reason;
    return this.frame;
  }
  getState() {
    const frame = this.getFrame();
    return Object.freeze({
      status: this.destroyed ? "destroyed" : this.paintError ? "error" : !this.series.candles.length ? "empty" : frame ? "ready" : "unavailable",
      error: this.paintError ?? this.frameIssue,
      callbackError: this.callbackError,
      referencePrice: this.referencePrice,
      style: this.style,
      scale: this.scale,
      inverted: this.inverted,
      timeZone: this.timeZone,
      effectiveTimeZone: effectiveDisplayZone(this.timeZone, this.timeframe),
      timeframe: this.timeframe,
      barCount: this.series.candles.length,
      discarded: this.series.discarded,
      range: this.getRange(),
      followingLatest: this.followingLatest,
      drawingCount: this.drawings.length,
      selectedDrawing: this.selectedDrawing,
      editingDrawing: this.frozenDrawingFrame !== null,
      paneCount: this.studies.paneCount,
      priceOnlyScale: this.priceOnlyScale,
      width: this.width,
      height: this.height,
      pixelRatio: this.pixelRatio,
      pendingPaint: this.raf != null,
      drawCount: this.drawCount,
      paintCount: this.drawCount
    });
  }
  setRange(range) {
    if (this.destroyed) return;
    const bounded2 = panChartWindow(range, 0, this.series.candles.length);
    if (!bounded2) return;
    const revision = ++this.mutationRevision;
    this.drawingEditor.cancelGesture();
    this.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    this.range = bounded2;
    this.followingLatest = false;
    this.invalidate();
  }
  fit() {
    if (!this.destroyed) this.setRange({ from: -1, to: this.series.candles.length });
  }
  goLatest() {
    if (this.destroyed) return;
    const revision = ++this.mutationRevision;
    this.drawingEditor.cancelGesture();
    this.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    this.range = this.latestRange(this.range ? this.range.to - this.range.from : void 0);
    this.followingLatest = true;
    this.invalidate();
  }
  setStyle(style) {
    if (!this.destroyed && CHART_STYLES.includes(style) && style !== this.style) {
      const revision = ++this.mutationRevision;
      this.drawingEditor.cancelGesture();
      this.cancelGesture();
      this.clearHover();
      if (this.destroyed || revision !== this.mutationRevision) return;
      this.style = style;
      this.invalidate();
    }
  }
  setScale(scale, inverted = this.inverted) {
    if (this.destroyed || !["linear", "log", "percent", "indexed"].includes(scale)) return;
    const revision = ++this.mutationRevision;
    this.drawingEditor.cancelGesture();
    this.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    this.scale = scale;
    this.inverted = inverted;
    this.invalidate();
  }
  setDisplayTimeZone(zone, timeframe = this.timeframe) {
    if (this.destroyed || !isChartTimeZone(zone)) return;
    ++this.mutationRevision;
    this.timeZone = zone;
    this.timeframe = timeframe;
    this.invalidate();
  }
  resetContext() {
    if (this.destroyed) return;
    const revision = ++this.mutationRevision;
    this.drawingEditor.cancelGesture();
    this.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    this.generation++;
    if (this.raf != null) cancelAnimationFrame(this.raf);
    this.raf = null;
    this.series = prepareNativePriceSeries([]);
    this.range = null;
    this.referencePrice = null;
    this.referenceSet = false;
    this.drawingEditor.configure(null);
    this.drawingEditor.setPlacement(null);
    this.drawingEditor.setDrawings([]);
    this.drawings = [];
    this.selectedDrawing = null;
    this.drawingInteraction = null;
    this.drawingHandler = null;
    this.frozenDrawingFrame = null;
    this.editAnchorTimes = [];
    this.studies.reset();
    this.followingLatest = true;
    this.invalidate();
  }
  invalidate() {
    this.frame = null;
    this.paintError = null;
    this.schedule();
  }
  schedule() {
    if (this.destroyed || this.raf != null) return;
    const generation = this.generation;
    const id = requestAnimationFrame(() => {
      if (this.destroyed || generation !== this.generation || this.raf !== id) return;
      this.raf = null;
      this.paint();
    });
    this.raf = id;
  }
  paint() {
    if (this.destroyed) return;
    try {
      const ctx = this.context;
      ctx.setTransform(this.pixelRatio, 0, 0, this.pixelRatio, 0, 0);
      ctx.clearRect(0, 0, this.width, this.height);
      const frame = this.getFrame();
      if (frame) {
        const layout = this.getPaneLayout(), last = layout.panes.at(-1) ?? layout.price;
        const chartBottom = last.top + last.height;
        paintNativeAxes(ctx, frame, { timeZone: effectiveDisplayZone(this.timeZone, this.timeframe), priceDigits: this.priceDigits, timeAxisBottom: chartBottom });
        paintNativePriceLayer(ctx, frame);
        paintNativeStudies(ctx, frame, layout.panes, this.studies);
        this.paintDrawings(ctx, frame);
        if (this.hover) {
          ctx.save();
          try {
            ctx.beginPath();
            ctx.rect(frame.plot.left, frame.plot.top, frame.plot.width, chartBottom - frame.plot.top);
            ctx.clip();
            ctx.strokeStyle = "#94a3b8";
            ctx.lineWidth = 1;
            ctx.setLineDash([3, 3]);
            ctx.beginPath();
            ctx.moveTo(this.hover.x, frame.plot.top);
            ctx.lineTo(this.hover.x, chartBottom);
            ctx.moveTo(frame.plot.left, this.hover.y);
            ctx.lineTo(frame.plot.left + frame.plot.width, this.hover.y);
            ctx.stroke();
          } finally {
            ctx.restore();
          }
        }
      }
      this.drawCount++;
      this.notify("viewport", () => this.options.onViewportChange?.());
    } catch (error) {
      this.frame = null;
      this.paintError = error instanceof Error ? error.message : "Price layer paint failed";
      try {
        this.context.clearRect(0, 0, this.width, this.height);
      } catch {
      }
    }
  }
  exportImage() {
    if (this.destroyed) return null;
    if (this.raf != null) {
      cancelAnimationFrame(this.raf);
      this.raf = null;
      this.paint();
    }
    if (!this.getFrame() || this.paintError) return null;
    try {
      return this.canvas.toDataURL("image/png");
    } catch {
      return null;
    }
  }
  notify(kind, callback) {
    try {
      callback();
    } catch (error) {
      this.callbackError = `${kind} callback failed: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
  point(event) {
    const rect = this.canvas.getBoundingClientRect();
    if (!rect.width || !rect.height || !Number.isFinite(event.clientX) || !Number.isFinite(event.clientY)) return null;
    const x = (event.clientX - rect.left) * this.width / rect.width, y = (event.clientY - rect.top) * this.height / rect.height;
    return Number.isFinite(x) && Number.isFinite(y) ? { x, y } : null;
  }
  inside(point, frame = this.getFrame()) {
    const layout = frame ? this.getPaneLayout() : null;
    return !!layout && [layout.price, ...layout.panes].some((plot) => point.x >= plot.left && point.x <= plot.left + plot.width && point.y >= plot.top && point.y <= plot.top + plot.height);
  }
  clearHover() {
    if (this.hover) {
      this.hover = null;
      this.notify("crosshair", () => this.options.onCrosshair?.(null));
      this.schedule();
    }
  }
  updateHover(point) {
    const frame = this.getFrame(), candle = this.inside(point, frame) ? frame.barAtX(point.x) : null;
    if (!frame || !candle) {
      this.clearHover();
      return;
    }
    const x = frame.timeToX(candle.time);
    if (x == null) {
      this.clearHover();
      return;
    }
    this.hover = Object.freeze({
      candle,
      x,
      y: point.y,
      price: point.y >= frame.plot.top && point.y <= frame.plot.top + frame.plot.height ? frame.yToPrice(point.y) : null
    });
    this.notify("crosshair", () => this.options.onCrosshair?.(this.hover));
    this.schedule();
  }
  gestureState() {
    const values = [...this.pointers.values()];
    if (!values.length) return null;
    if (values.length === 1) return { center: values[0], distance: 0 };
    const [a, b] = values;
    return { center: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, distance: Math.hypot(a.x - b.x, a.y - b.y) };
  }
  cancelGesture() {
    const ids = [...this.pointers.keys()];
    this.pointers.clear();
    this.gesture = null;
    for (const id of ids) {
      try {
        this.canvas.releasePointerCapture(id);
      } catch {
      }
    }
  }
  onPointerDown = (event) => {
    if (this.destroyed || this.frozenDrawingFrame || this.activeDrawingPlacement() || event.defaultPrevented || event.button !== 0 || this.pointers.size >= 2) return;
    const point = this.point(event);
    if (!point || !this.inside(point)) return;
    event.preventDefault();
    this.canvas.focus({ preventScroll: true });
    this.pointers.set(event.pointerId, point);
    this.gesture = this.gestureState();
    try {
      this.canvas.setPointerCapture(event.pointerId);
    } catch {
    }
    this.clearHover();
  };
  shift(range, delta) {
    return panChartWindow({ from: range.from + delta, to: range.to + delta }, 0, this.series.candles.length);
  }
  zoomAt(factor, oldX, newX = oldX) {
    const frame = this.getFrame();
    if (!frame || !this.range) return;
    const anchor2 = frame.xToLogical(oldX);
    if (anchor2 == null) return;
    const zoomed = zoomChartWindow(this.range, clamp(factor, 0.25, 4), this.series.candles.length);
    if (!zoomed) return;
    const fraction = (newX - frame.plot.left) / frame.plot.width;
    const desiredFrom = anchor2 - fraction * (zoomed.to - zoomed.from);
    const next = this.shift(zoomed, desiredFrom - zoomed.from);
    if (next) {
      this.range = next;
      this.followingLatest = false;
      this.frame = null;
      this.schedule();
    }
  }
  onPointerMove = (event) => {
    if (this.destroyed) return;
    const point = this.point(event);
    if (!point) return;
    if (!this.pointers.has(event.pointerId)) {
      if (!this.pointers.size) this.updateHover(point);
      return;
    }
    event.preventDefault();
    const previous = this.gesture;
    this.pointers.set(event.pointerId, point);
    const next = this.gestureState();
    const frame = this.getFrame();
    if (previous && next && frame && this.range) {
      if (this.pointers.size === 2 && previous.distance > 0 && next.distance > 0) this.zoomAt(previous.distance / next.distance, previous.center.x, next.center.x);
      else {
        const shifted = this.shift(this.range, -(next.center.x - previous.center.x) / frame.spacing);
        if (shifted) {
          this.range = shifted;
          this.followingLatest = false;
          this.frame = null;
          this.schedule();
        }
      }
    }
    this.gesture = next;
  };
  onOutsidePointerMove = (event) => {
    if (!this.destroyed && event.target !== this.canvas && this.pointers.has(event.pointerId)) this.onPointerMove(event);
  };
  onOutsidePointerCancel = (event) => {
    if (!this.destroyed && this.pointers.has(event.pointerId)) this.onPointerCancel();
  };
  onWindowBlur = () => {
    if (!this.destroyed) {
      this.cancelGesture();
      this.clearHover();
    }
  };
  onPointerUp = (event) => {
    if (this.destroyed || !this.pointers.has(event.pointerId)) return;
    this.pointers.delete(event.pointerId);
    this.gesture = this.gestureState();
    try {
      this.canvas.releasePointerCapture(event.pointerId);
    } catch {
    }
  };
  onPointerCancel = () => {
    if (!this.destroyed) {
      this.cancelGesture();
      this.clearHover();
    }
  };
  onLostCapture = (event) => {
    if (!this.destroyed && this.pointers.has(event.pointerId)) this.cancelGesture();
  };
  onWheel = (event) => {
    if (this.destroyed || this.frozenDrawingFrame || this.activeDrawingPlacement() || event.defaultPrevented) return;
    const point = this.point(event), frame = this.getFrame();
    if (!point || !this.inside(point, frame) || !Number.isFinite(event.deltaY) || !Number.isFinite(event.deltaX) || event.deltaY === 0 && event.deltaX === 0) return;
    const horizontal = Math.abs(event.deltaX) > Math.abs(event.deltaY);
    const raw = horizontal ? event.deltaX : event.deltaY;
    const pixels = raw * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? horizontal ? frame.plot.width : frame.plot.height : 1);
    const revision = ++this.mutationRevision;
    event.preventDefault();
    this.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    if (horizontal && this.range) {
      const next = this.shift(this.range, pixels / frame.spacing);
      if (next) {
        this.range = next;
        this.followingLatest = false;
        this.frame = null;
        this.schedule();
      }
    } else this.zoomAt(Math.exp(clamp(pixels * 2e-3, -0.65, 0.65)), point.x);
  };
  onKeyDown = (event) => {
    if (this.destroyed || this.frozenDrawingFrame || this.activeDrawingPlacement() || event.defaultPrevented || event.target !== this.canvas || this.canvas.ownerDocument.activeElement !== this.canvas || this.canvas.isContentEditable || this.canvas.getAttribute("contenteditable") === "true" || event.ctrlKey || event.metaKey || event.altKey || !this.range) return;
    if (event.key === "Home") this.fit();
    else if (event.key === "End") this.goLatest();
    else if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
      const next = panChartWindow(this.range, event.key === "ArrowLeft" ? -0.2 : 0.2, this.series.candles.length);
      if (next) this.setRange(next);
    } else if (["+", "=", "-", "_"].includes(event.key)) {
      const next = zoomChartWindow(this.range, event.key === "+" || event.key === "=" ? 0.8 : 1.25, this.series.candles.length);
      if (next) this.setRange(next);
    } else return;
    event.preventDefault();
  };
  destroy() {
    if (this.destroyed) return;
    this.drawingEditor.destroy();
    this.drawings = [];
    this.drawingInteraction = null;
    this.drawingHandler = null;
    this.selectedDrawing = null;
    this.frozenDrawingFrame = null;
    this.editAnchorTimes = [];
    this.destroyed = true;
    this.generation++;
    this.mutationRevision++;
    this.cancelGesture();
    this.clearHover();
    if (this.raf != null) cancelAnimationFrame(this.raf);
    this.raf = null;
    this.observer?.disconnect();
    this.observer = null;
    this.media?.removeEventListener("change", this.onDprChange);
    this.media = null;
    this.listeners.forEach((remove) => remove());
    this.listeners = [];
    this.frame = null;
    this.range = null;
    this.series = prepareNativePriceSeries([]);
    this.studies.setStudies([], []);
    this.referencePrice = null;
    this.referenceSet = false;
    this.canvas.remove();
  }
};

// scripts/scanner-qa/native-viewport-entry.ts
var makeData = (count, offset = 0) => Array.from({ length: count }, (_, i) => {
  const j = i + offset, open = 100 + Math.sin(j * 0.27) * 6 + Math.cos(j * 0.063) * 8, close = open + Math.sin(j * 1.71) * 2.4;
  return { time: 1730613600 + j * 60, open, high: Math.max(open, close) + 1.4, low: Math.min(open, close) - 0.9, close };
});
document.body.innerHTML = `<main><h1>ARX native chart viewport</h1><p>Independent renderer laboratory \xB7 synthetic observations \xB7 no broker connection</p><nav><label>Style <select id="style">${CHART_STYLES.map((v) => `<option>${v}</option>`).join("")}</select></label><label>Scale <select id="scale">${["linear", "log", "percent", "indexed"].map((v) => `<option>${v}</option>`).join("")}</select></label><label>Display zone <select id="zone">${CHART_TIME_ZONES.map((v) => `<option>${v}</option>`).join("")}</select></label><label>Studies <select id="studies"><option value="none">None</option><option value="starter">SMA / EMA / BB / RSI / MACD</option><option value="volume">Synthetic volume evidence</option></select></label><label>Drawings <select id="drawings"><option value="none">None</option><option value="sample">Existing ARX tools</option></select></label><button id="place">Place a note</button><button id="withdraw">Withhold volume</button><button id="invert">Invert price axis</button><button id="fit">Fit loaded history</button><button id="latest">Latest</button><button id="reset">Reset 200-bar view</button></nav><output id="state"></output><section id="chart"></section><output id="study-values"></output><output id="inspect">Move over a candle to inspect canonical OHLC.</output><p class="help">Drag to pan \xB7 wheel/pinch to zoom \xB7 arrow keys to pan \xB7 +/\u2212 to zoom \xB7 Home fits \xB7 End follows latest. Display-only; app integration and Scanner overlays are still pending.</p></main>`;
var css = document.createElement("style");
css.textContent = `*{box-sizing:border-box}body{margin:0;background:#090f1b;color:#dce7f6;font:14px system-ui}main{max-width:1440px;margin:auto;padding:20px}h1{font-size:24px;margin:0 0 8px}p,output{color:#a3b3c9}nav{display:flex;gap:12px;align-items:end;flex-wrap:wrap;margin:20px 0}label{display:grid;gap:5px}select,button{padding:9px;background:#17243b;color:inherit;border:1px solid #3a506d;border-radius:5px;font:inherit}#chart{margin:12px 0;background:#0d1625;border:1px solid #20314b;min-width:0}canvas{max-width:100%;outline-offset:-2px}canvas:focus-visible{outline:2px solid #39b7ff}output{white-space:pre-wrap;display:block;overflow-wrap:anywhere;font:12px ui-monospace,monospace}.help{line-height:1.5}@media(max-width:600px){main{padding:12px}h1{font-size:21px}nav{gap:8px}button,select{padding:8px;font-size:12px}}`;
document.head.append(css);
var data = makeData(2e4);
var viewport = new NativeChartViewport(document.getElementById("chart"), { height: 500, visibleBars: 200, onViewportChange: () => {
  const state = viewport.getState();
  document.getElementById("study-values").textContent = viewport.getStudyValues(data.at(-1)?.time ?? 0).map((s) => `${s.label}: ${s.reason ?? s.values.map((v) => v.name + " " + (v.value === null ? "unavailable" : formatStudyNumber(v.value, v.name))).join(" \xB7 ")}`).join("\n");
  document.getElementById("state").textContent = `${state.status} \xB7 ${state.barCount} loaded bars \xB7 ${state.style}/${state.scale} \xB7 reference ${state.referencePrice} \xB7 ${state.effectiveTimeZone} \xB7 ${state.followingLatest ? "following latest" : "inspecting history"}`;
}, onCrosshair: (value) => {
  document.getElementById("inspect").textContent = value ? `Canonical UTC ${new Date(value.candle.time * 1e3).toISOString()} | O ${value.candle.open} H ${value.candle.high} L ${value.candle.low} C ${value.candle.close}` : "No candle selected.";
} });
var prepareStart = performance.now();
viewport.setCandles(data);
var initialPreparationMs = performance.now() - prepareStart;
document.getElementById("style").addEventListener("change", (e) => viewport.setStyle(e.target.value));
document.getElementById("scale").addEventListener("change", (e) => viewport.setScale(e.target.value));
document.getElementById("zone").addEventListener("change", (e) => viewport.setDisplayTimeZone(e.target.value));
document.getElementById("invert").addEventListener("click", () => viewport.setScale(viewport.getState().scale, !viewport.getState().inverted));
document.getElementById("fit").addEventListener("click", () => viewport.fit());
document.getElementById("latest").addEventListener("click", () => viewport.goLatest());
document.getElementById("reset").addEventListener("click", () => {
  viewport.setRange({ from: data.length - 199, to: data.length + 1 });
  viewport.goLatest();
});
document.getElementById("studies").addEventListener("change", (e) => {
  const selection = e.target.value;
  if (selection === "volume") {
    const identity = "a".repeat(64);
    data = data.map((bar, i) => ({ ...bar, volumeEvidence: { kind: "real_volume", unit: "provider_trade_units", quantity: 100 + i % 41, reason: null, authority: TRADE_VOLUME_AUTHORITY, seriesIdentity: identity }, profileEvidence: { finality: "closed", clockAuthority: TRADE_VOLUME_AUTHORITY } }));
    viewport.setCandles(data);
    const from = data[Math.max(0, data.length - 200)].time, to = data.at(-1).time;
    viewport.setStudies([
      { kind: "vwap", period: 1, color: "#fbbf24", vwapAnchor: { kind: "observed_bar", time: from, seriesIdentity: identity } },
      { kind: "trade_volume", period: 1, color: "#34d399" },
      { kind: "volume_profile", period: 1, color: "#a78bfa", profileRows: 24, profileValueAreaPercent: 70, profileRange: { kind: "observed_range", fromTime: from, toTime: to, seriesIdentity: identity, clockAuthority: TRADE_VOLUME_AUTHORITY } }
    ]);
  } else viewport.setStudies(selection === "starter" ? STUDY_DEFAULTS : []);
});
document.getElementById("withdraw").addEventListener("click", () => {
  data = data.map(({ volumeEvidence: _v, profileEvidence: _p, ...bar }) => bar);
  viewport.setCandles(data);
});
var drawingCommits = [];
var drawingSelection = null;
var history = [];
var future = [];
var bindDrawingInteraction = () => viewport.setDrawingInteraction({
  selectedId: drawingSelection,
  snap: false,
  onSelect: (id) => {
    drawingSelection = id;
  },
  onCommit: (next) => {
    drawingCommits.push(next);
    history.push(next);
    future = [];
  },
  onUndo: () => {
    if (history.length > 1) {
      future.push(history.pop());
      viewport.setDrawings(history.at(-1));
    }
  },
  onRedo: () => {
    const next = future.pop();
    if (next) {
      history.push(next);
      viewport.setDrawings(next);
    }
  }
});
var sampleDrawings = () => {
  const bar = (n) => data[data.length - n], a = bar(160), b = bar(80);
  return [
    { id: "level", kind: "horizontal", start: { time: a.time, price: a.low }, color: "#fbbf24" },
    { id: "trend", kind: "trend", start: { time: a.time, price: a.high }, end: { time: b.time, price: b.high }, color: "#38bdf8", width: 2 },
    { id: "channel", kind: "channel", start: { time: bar(110).time, price: bar(110).high }, end: { time: bar(40).time, price: bar(40).high }, offset: { time: bar(110).time, price: bar(110).low }, color: "#a78bfa", middleLine: true },
    { id: "note", kind: "text", start: { time: bar(50).time, price: bar(50).low }, color: "#34d399", text: "Your chart note. Synthetic observations only." },
    { id: "ruler", kind: "measure", start: { time: bar(185).time, price: bar(185).high }, end: { time: bar(170).time, price: bar(170).low }, color: "#fb7185" }
  ];
};
document.getElementById("drawings").addEventListener("change", (e) => {
  const next = e.target.value === "sample" ? sampleDrawings() : [];
  viewport.setDrawings(next);
  history = [next];
  future = [];
  drawingSelection = null;
  bindDrawingInteraction();
});
document.getElementById("place").addEventListener("click", () => {
  viewport.setDrawingHandler((anchor2) => {
    const next = [...viewport.getDrawings(), { id: "note-" + performance.now(), kind: "text", start: anchor2, color: "#34d399", text: "Your note" }];
    viewport.setDrawings(next);
    history.push(next);
    viewport.setDrawingHandler(null);
  });
});
var waitPaint = async (previous) => {
  for (let i = 0; i < 20; i++) {
    await new Promise(requestAnimationFrame);
    if (viewport.getState().paintCount > previous) return;
  }
  throw Error("Viewport did not paint");
};
window.__arxNativeViewportQa = {
  viewport,
  makeData,
  sampleDrawings,
  get drawingCommits() {
    return drawingCommits;
  },
  bindDrawingInteraction,
  get data() {
    return data;
  },
  replace: (next) => {
    data = next;
    viewport.setCandles(data);
  },
  waitPaint,
  initialPreparationMs,
  benchmark: async () => {
    const samples = [];
    viewport.setStyle("candles");
    viewport.setScale("linear", false);
    for (let i = 0; i < 150; i++) {
      const previous = viewport.getState().paintCount, begin = performance.now();
      viewport.setRange({ from: data.length - 201 - i % 10, to: data.length - 1 - i % 10 });
      await waitPaint(previous);
      if (i >= 30) samples.push(performance.now() - begin);
    }
    return { samples, warmup: 30, loadedBars: data.length, visibleLogicalSpan: 200, initialPreparationMs, dpr: devicePixelRatio, userAgent: navigator.userAgent };
  }
};
