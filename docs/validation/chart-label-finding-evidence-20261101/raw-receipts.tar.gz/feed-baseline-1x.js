async page=>{
 const blocked=[];await page.context().routeWebSocket('**/*',ws=>{blocked.push(ws.url());ws.close();});
 await page.context().route('**/*',r=>{const u=new URL(r.request().url());if(u.hostname==='127.0.0.1'&&['4207','4208'].includes(u.port)&&r.request().method()==='GET'&&!u.pathname.startsWith('/api/'))return r.continue();blocked.push(r.request().url());return r.abort();});
 await page.setViewportSize({width:1440,height:1100});await page.goto('http://127.0.0.1:4207/');await page.waitForFunction(()=>!!window.__arxFeedReconciliationQa);
 const cdp=await page.context().newCDPSession(page);await cdp.send('Emulation.setCPUThrottlingRate',{rate:1});let result;
 try{result=await page.evaluate(async()=>await window.__arxFeedReconciliationQa.run());}finally{await cdp.send('Emulation.setCPUThrottlingRate',{rate:1});await cdp.detach();}
 return {mode:'baseline',rate:1,blocked,browser:page.context().browser().version(),metadata:await page.evaluate(async()=>await(await fetch('/arx-scanner-qa-build-info.json')).json()),result};
}