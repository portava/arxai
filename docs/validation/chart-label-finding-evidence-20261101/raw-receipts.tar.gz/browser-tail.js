const report={initial,checks:[],replies:[],states:[],screenshots:[],limitations:['Generated intercepted candles, not the owner screenshots or a live provider.','Label packing avoids its own labels/anchors only; not global overlap-free rendering.','Local explanation is deterministic chart evidence, not a remote model audit.']};
const check=(name,ok,evidence)=>report.checks.push({name,passed:!!ok,evidence});
const frames=()=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
const qa=()=>page.evaluate(()=>({snapshot:window.__arxChartQa.snapshot(),annotation:window.__arxChartQa.priceAnnotationState(),data:window.__arxChartQa.data()}));
const reader=page.getByTestId('smart-chart-reader').first();
const panel=page.getByTestId('arx-assistant-panel');
const messages=()=>panel.locator('div.flex.justify-start > div');
const waitReply=async count=>{await page.waitForFunction(n=>document.querySelectorAll('[data-testid="arx-assistant-panel"] div.flex.justify-start > div').length>n,count);return await messages().last().innerText();};
const ask=async text=>{const trigger=page.getByTestId('arx-assistant-trigger');await trigger.waitFor();if(await trigger.getAttribute('aria-expanded')==='false')await trigger.click();await panel.waitFor();const count=await messages().count();await page.getByTestId('arx-input').fill(text);await page.getByTestId('arx-send').click();const reply=await waitReply(count);report.replies.push({prompt:text,reply});return reply;};
const capture=async name=>{const path='/Users/areyouok/arx-tier1-release/chart-label-finding-evidence-20261101/'+name+'.png';await page.screenshot({path});report.screenshots.push(path);};
try{
 await page.waitForFunction(()=>document.querySelector('[data-testid="smart-chart-reader"]')?.getAttribute('data-analysis-status')==='ready');
 await reader.locator('[aria-label="Relevant chart patterns"] button[aria-pressed="true"]').waitFor();
 const title=(await reader.locator('[aria-label="Relevant chart patterns"] button[aria-pressed="true"]').innerText()).split(' · ')[0];
 const initialState=await qa();report.states.push({name:'initial',...initialState});
 const count=await messages().count();await reader.getByRole('button',{name:'Explain this finding',exact:true}).click();const manual=await waitReply(count);report.replies.push({prompt:'manual button',reply:manual});
 check('manual button opens existing assistant with selected finding',await panel.isVisible()&&manual.includes(title)&&manual.includes('EURUSD M15')&&manual.includes('mt5 broker'),{title,manual});
 const typed=await ask('explain this pattern');check('typed and manual replies are identical for unchanged evidence',typed===manual,{typed,manual});
 const a=initialState.annotation.selectedAnnotation;
 check('reply names actual annotation anchor prices and roles',a?.anchors.length&&a.anchors.every(x=>typed.includes(Number(x.price.toPrecision(7)).toString())&&typed.includes(x.label)),a);
 check('answer preserves observation and separate assessment limits',typed.includes('not a forecast')&&typed.includes('separate server assessment')&&typed.includes('Observed through'),typed);
 check('no secondary structure marker competes with selected annotation',!!a&&!initialState.annotation.secondaryStructureMarkersPresent&&initialState.annotation.secondaryStructureSeries===0,initialState.annotation);
 await capture('desktop-finding-answer');
 await reader.getByRole('button',{name:'Show automatic chart annotations',exact:true}).click();await frames();
 const hidden=await ask('explain this pattern');check('hidden annotation is disclosed',hidden.includes('Automatic annotation is hidden')&&(await qa()).annotation.selectedAnnotation===null,hidden);
 await reader.getByRole('button',{name:'Show automatic chart annotations',exact:true}).click();
 // Toolbar is the user-visible path, never an adapter mutation.
 const style=page.getByRole('combobox',{name:'Chart style',exact:true});if(!await style.isVisible())await page.getByRole('button',{name:'Chart tools',exact:true}).click();
 for(const value of ['candles','hollow','bars','line','area','baseline','heikinAshi']){
   await style.selectOption(value);await frames();const state=await qa();report.states.push({name:'style-'+value,...state});
   check('one canonical last price — '+value,state.snapshot.style===value&&!state.annotation.nativeLastValueVisible&&!state.annotation.nativePriceLineVisible&&state.annotation.canonicalLastLine?.price===state.data.canonical.at(-1).close&&state.annotation.canonicalLastLineAttached&&state.annotation.attachedPriceLines.filter(x=>x.canonical).length===1&&state.annotation.canonicalLastLine.title===''&&state.annotation.canonicalLastLine.axisLabelVisible===true,state.annotation);
 }
 await style.selectOption('candles');await frames();
 await page.getByTestId('arx-native-canvas').scrollIntoViewIfNeeded();await capture('desktop-single-price');
 await page.evaluate(()=>window.__fixtureRevokeClock());await page.reload();await page.waitForFunction(()=>document.querySelector('[data-testid="smart-chart-reader"]')?.getAttribute('data-analysis-status')==='ready');
 const unqualified=await ask('explain this pattern');check('unverified clock answer retains source-clock limit',unqualified.includes('UTC mapping unverified')&&unqualified.includes('source clock (UTC unverified)'),unqualified);
 const unqualifiedState=await qa();check('unverified freshness has no canonical live price line',!unqualifiedState.snapshot.feed.livePriceAffordance&&unqualifiedState.annotation.canonicalLastLine===null&&!unqualifiedState.annotation.nativeLastValueVisible,unqualifiedState.annotation);
 await page.evaluate(()=>window.__fixtureSwitchSource({source:'deriv_public',identity:'b'.repeat(64)}));await page.reload();await page.waitForFunction(()=>document.querySelector('[data-testid="smart-chart-reader"]')?.getAttribute('data-analysis-source-identity')==='b'.repeat(64));
 const switched=await ask('explain this pattern');check('source switch explanation uses current source',switched.includes('deriv public')&&!switched.includes('mt5 broker'),switched);
 for(const width of [790,390]){await page.setViewportSize({width,height:1000});await reader.scrollIntoViewIfNeeded();await frames();const c=await messages().count();await reader.getByRole('button',{name:'Explain this finding',exact:true}).click();const reply=await waitReply(c);check('manual explanation on width '+width,reply.includes('deriv public')&&reply.includes('EURUSD M15'),reply);await capture('finding-width-'+width);}
}catch(error){report.failure=String(error);await capture('browser-failure');}
report.network=await page.evaluate(()=>window.__readFixtureLog());
check('no model/order request; all incidental mutations intercepted',!report.network.requests.some(x=>x.method==='POST'&&(/assistant\/(?:stream|chat|messages|voice)|\/(?:orders|execute|dispatch)(?:\/|$)/.test(x.path)))&&report.network.blocked.every(x=>x.kind!=='mutation'||x.status===503),report.network.blocked);
report.passed=report.checks.filter(c=>c.passed).length;report.failed=report.checks.filter(c=>!c.passed).length;
return report;
}
