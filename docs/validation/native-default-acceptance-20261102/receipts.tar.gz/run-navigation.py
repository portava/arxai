import subprocess,json,datetime
from pathlib import Path
p=Path(__file__).parent;cli='/Users/areyouok/.local/bin/playwright-cli'
setup='/Users/areyouok/arx-native-time-controls-20261102/scripts/scanner-qa/shared-chart-setup.js'
for rate in [1,4]:
 session='native-navigation-'+str(rate);name='navigation-'+str(rate)+'x'
 for suffix,args in [('open',['open','http://127.0.0.1:4199']),('setup',['run-code','--filename='+setup]),('run',['run-code','--filename='+str(p/('first-navigation-'+str(rate)+'x.js'))]),('close',['close'])]:
  with (p/(name+'-'+suffix+'.log')).open('w') as f:code=subprocess.call([cli,'-s='+session,*args],stdout=f,stderr=subprocess.STDOUT,cwd=p)
  s=(p/(name+'-'+suffix+'.log')).read_text();i=s.find('### Result\n')
  if i>=0:
   x=json.JSONDecoder().raw_decode(s[i+11:].lstrip())[0]
   if suffix=='run':
    x['outerRunner']={'cpuThrottleRate':rate,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'CDP Emulation.setCPUThrottlingRate; shared host; no hardware isolation'}
    (p/(name+'.json')).write_text(json.dumps(x,indent=2));print(name,'passed',x.get('passed'),'failure',x.get('failure'),'summary',x.get('summary'),flush=True)
  if code!=0 or '### Error' in s:
   print(name,suffix,'FAILED',code,flush=True)
   if suffix!='close':subprocess.call([cli,'-s='+session,'close'],stdout=subprocess.DEVNULL);raise SystemExit(1)
