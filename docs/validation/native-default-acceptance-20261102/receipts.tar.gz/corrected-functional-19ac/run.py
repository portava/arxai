import subprocess,json
from pathlib import Path
p=Path(__file__).parent
raw=p.parent
cli='/Users/areyouok/.local/bin/playwright-cli'
root=Path('/Users/areyouok/arx-native-time-controls-20261102/scripts/scanner-qa')
results=[]
def run(session,name,args):
 with (p/(name+'.log')).open('w') as f: code=subprocess.call([cli,'-s='+session,*args],stdout=f,stderr=subprocess.STDOUT,cwd=p)
 text=(p/(name+'.log')).read_text();item={'name':name,'session':session,'exitCode':code}
 i=text.find('### Result\n')
 if i>=0:
  x=json.JSONDecoder().raw_decode(text[i+11:].lstrip())[0];(p/(name+'.json')).write_text(json.dumps(x,indent=2)+'\n');item.update({'passed':x.get('passed') if isinstance(x,dict) else None,'failure':x.get('failure') if isinstance(x,dict) else None,'checks':len(x.get('checks',[])) if isinstance(x,dict) else None})
 results.append(item);(p/'runner-results.json').write_text(json.dumps(results,indent=2)+'\n');print(item,flush=True)
 return code
for session,setup,drivers in [
 ('arx-final-consumers-fresh-19ac','consumer-setup.js',[('consumers','native-consumers-acceptance.js'),('clock-position','native-clock-position-acceptance.js')]),
 ('arx-final-pages-fresh-19ac','pages-setup.js',[('pages','shared-chart-pages-acceptance.js')])]:
 try:
  if run(session,session+'-open',['open'])!=0:continue
  if run(session,session+'-setup',['run-code','--filename='+str(raw/setup)])!=0:continue
  for name,driver in drivers:run(session,name,['run-code','--filename='+str(root/driver)])
 finally:run(session,session+'-close',['close'])
