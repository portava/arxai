// artifacts/trading-dashboard/src/lib/chart-engine/candleSanitize.ts
function isValidCandlestickPoint(p) {
  return Number.isFinite(p.time) && p.time > 0 && Number.isFinite(p.open) && Number.isFinite(p.high) && Number.isFinite(p.low) && Number.isFinite(p.close) && p.high >= Math.max(p.open, p.close, p.low) && p.low <= Math.min(p.open, p.close, p.high);
}
function sanitizeCandlestickData(points) {
  const valid2 = points.filter(isValidCandlestickPoint);
  if (valid2.every((p, i) => i === 0 || p.time > valid2[i - 1].time)) return valid2;
  return [...new Map(valid2.map((p) => [p.time, p])).values()].sort((a, b) => a.time - b.time);
}

// artifacts/trading-dashboard/src/lib/chart-engine/heikinAshi.ts
var HOLLOW_UP_COLOR = "#10b981";
var HOLLOW_DOWN_COLOR = "#ef4444";
var HOLLOW_BODY = "transparent";
function heikinAshiBar(candle, previous) {
  const close = (candle.open + candle.high + candle.low + candle.close) / 4;
  const open = previous ? (previous.open + previous.close) / 2 : (candle.open + candle.close) / 2;
  return { time: candle.time, open, high: Math.max(candle.high, open, close), low: Math.min(candle.low, open, close), close };
}
function heikinAshiSuffix(candles, cache, from) {
  const start = Math.max(0, Math.min(Number.isFinite(from) ? Math.floor(from) : 0, cache.length, candles.length));
  cache.length = start;
  for (let i = start; i < candles.length; i++) cache.push(heikinAshiBar(candles[i], i > 0 ? cache[i - 1] : null));
  return cache;
}
function heikinAshi(candles) {
  return heikinAshiSuffix(candles, [], 0);
}
function hollowPoint(candle, previousClose) {
  const up = previousClose == null ? candle.close >= candle.open : candle.close >= previousClose;
  const colour = up ? HOLLOW_UP_COLOR : HOLLOW_DOWN_COLOR;
  return { ...candle, color: candle.close >= candle.open ? HOLLOW_BODY : colour, borderColor: colour, wickColor: colour };
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartTimeZone.ts
var CHART_TIME_ZONES = [
  "UTC",
  "local",
  "America/New_York",
  "America/Chicago",
  "Europe/London",
  "Europe/Berlin",
  "Asia/Dubai",
  "Asia/Singapore",
  "Asia/Tokyo",
  "Australia/Sydney"
];
function isChartTimeZone(value) {
  return typeof value === "string" && CHART_TIME_ZONES.includes(value);
}
var UTC_ALIASES = /* @__PURE__ */ new Set(["UTC", "Etc/UTC", "Etc/GMT", "GMT", "Etc/Universal", "Etc/Zulu", "Universal", "Zulu", "Etc/UCT", "UCT", "Etc/Greenwich", "Greenwich", "Etc/GMT0", "Etc/GMT+0", "Etc/GMT-0", "GMT0", "GMT+0", "GMT-0"]);
var cachedBrowserZone = null;
function browserZone() {
  if (cachedBrowserZone !== null) return cachedBrowserZone;
  let zone = "UTC";
  try {
    const resolved = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (typeof resolved === "string" && resolved) {
      new Intl.DateTimeFormat("en-US", { timeZone: resolved });
      zone = resolved;
    }
  } catch {
    zone = "UTC";
  }
  cachedBrowserZone = UTC_ALIASES.has(zone) ? "UTC" : zone;
  return cachedBrowserZone;
}
function resolveTimeZone(zone, bz) {
  if (zone === "local") {
    const local = bz ?? browserZone();
    if (!local || UTC_ALIASES.has(local)) return "UTC";
    return formatterFor(local) ? local : "UTC";
  }
  return isChartTimeZone(zone) ? zone : "UTC";
}
var DAILY_TIMEFRAMES = /* @__PURE__ */ new Set(["D1", "W1", "MN1"]);
function effectiveDisplayZone(zone, timeframe) {
  if (DAILY_TIMEFRAMES.has(timeframe)) return "UTC";
  return isChartTimeZone(zone) ? zone : "UTC";
}
var formatters = /* @__PURE__ */ new Map();
function formatterFor(iana) {
  let formatter = formatters.get(iana);
  if (formatter !== void 0) return formatter;
  try {
    formatter = new Intl.DateTimeFormat("en-US", {
      timeZone: iana,
      hourCycle: "h23",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      timeZoneName: "short"
    });
  } catch {
    formatter = null;
  }
  formatters.set(iana, formatter);
  return formatter;
}
var pad = (value, width = 2) => String(value).padStart(width, "0");
function utcParts(ms) {
  const d = new Date(ms);
  return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate(), hour: d.getUTCHours(), minute: d.getUTCMinutes(), second: d.getUTCSeconds(), abbr: "UTC" };
}
function wallParts(ms, iana) {
  if (iana === "UTC") return utcParts(ms);
  const formatter = formatterFor(iana);
  if (!formatter) return utcParts(ms);
  const out = { year: 0, month: 0, day: 0, hour: 0, minute: 0, second: 0, abbr: "" };
  for (const part of formatter.formatToParts(ms)) {
    switch (part.type) {
      case "year":
        out.year = Number(part.value);
        break;
      case "month":
        out.month = Number(part.value);
        break;
      case "day":
        out.day = Number(part.value);
        break;
      case "hour":
        out.hour = Number(part.value) % 24;
        break;
      case "minute":
        out.minute = Number(part.value);
        break;
      case "second":
        out.second = Number(part.value);
        break;
      case "timeZoneName":
        out.abbr = part.value;
        break;
    }
  }
  return out;
}
var wholeSecondMs = (sec) => Math.floor(sec) * 1e3;
function formatChartTime(sec, zone, options = {}) {
  if (!Number.isFinite(sec)) return "time unavailable";
  const iana = resolveTimeZone(zone);
  const ms = wholeSecondMs(sec);
  if (iana === "UTC") return `${new Date(ms).toISOString().slice(0, options.seconds ? 19 : 16).replace("T", " ")} UTC`;
  const p = wallParts(ms, iana);
  return `${pad(p.year, 4)}-${pad(p.month)}-${pad(p.day)} ${pad(p.hour)}:${pad(p.minute)}${options.seconds ? `:${pad(p.second)}` : ""} ${p.abbr}`;
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartStudies.ts
var STUDY_CATALOG = [
  { name: "Simple moving average", group: "Trend", description: "Equal weight over the selected period.", defaults: { kind: "sma", period: 20, color: "#fbbf24" }, channels: ["SMA"], pane: false, appliedPrice: true },
  { name: "Exponential moving average", group: "Trend", description: "Recent prices carry more weight; seeded with an SMA.", defaults: { kind: "ema", period: 50, color: "#38bdf8" }, channels: ["EMA"], pane: false, appliedPrice: true },
  { name: "Bollinger Bands", group: "Volatility", description: "SMA basis with population standard deviation bands.", defaults: { kind: "bollinger", period: 20, multiplier: 2, color: "#a78bfa" }, channels: ["Basis", "Upper", "Lower"], pane: false, appliedPrice: true },
  { name: "Relative strength index", group: "Momentum", description: "Wilder smoothing of gains and losses; flat markets read 50.", defaults: { kind: "rsi", period: 14, color: "#e879f9" }, channels: ["RSI"], pane: true, appliedPrice: true, levels: [30, 70], range: [0, 100] },
  { name: "MACD", group: "Momentum", description: "Fast minus slow EMA. Choose EMA or MT5-style SMA signal smoothing.", defaults: { kind: "macd", period: 12, slow: 26, signal: 9, color: "#2dd4bf" }, channels: ["MACD", "Signal", "Histogram"], pane: true, appliedPrice: true, levels: [0] },
  { name: "Smoothed moving average", group: "Trend", description: "Wilder / RMA smoothing with weight 1 \xF7 period.", defaults: { kind: "smma", period: 20, color: "#fb923c" }, channels: ["SMMA"], pane: false, appliedPrice: true },
  { name: "Weighted moving average", group: "Trend", description: "Linear weights; the newest bar has the largest weight.", defaults: { kind: "wma", period: 20, color: "#4ade80" }, channels: ["WMA"], pane: false, appliedPrice: true },
  { name: "Double exponential moving average", group: "Trend", description: "2 \xD7 EMA minus EMA of EMA; each stage warms up separately.", defaults: { kind: "dema", period: 20, color: "#f472b6" }, channels: ["DEMA"], pane: false, appliedPrice: true },
  { name: "Triple exponential moving average", group: "Trend", description: "3 \xD7 EMA \u2212 3 \xD7 EMA\xB2 + EMA\xB3; three seeded stages.", defaults: { kind: "tema", period: 20, color: "#818cf8" }, channels: ["TEMA"], pane: false, appliedPrice: true },
  { name: "Average true range", group: "Volatility", description: "Range including gaps from the previous close. Select smoothing.", defaults: { kind: "atr", period: 14, method: "smma", color: "#fb923c" }, channels: ["ATR"], pane: true, appliedPrice: false },
  { name: "Commodity channel index", group: "Momentum", description: "Distance from the mean divided by 0.015 \xD7 mean absolute deviation.", defaults: { kind: "cci", period: 20, source: "hlc3", color: "#38bdf8" }, channels: ["CCI"], pane: true, appliedPrice: true, levels: [-100, 0, 100] },
  { name: "Stochastic oscillator", group: "Momentum", description: "SMA-smoothed %K in the high/low range, followed by an SMA %D.", defaults: { kind: "stochastic", period: 14, smoothing: 3, signal: 3, color: "#2dd4bf" }, channels: ["%K", "%D"], pane: true, appliedPrice: false, levels: [20, 80], range: [0, 100] },
  { name: "Williams percent range", group: "Momentum", description: "Close within the lookback high/low range, from \u2212100 to 0.", defaults: { kind: "williams", period: 14, color: "#fbbf24" }, channels: ["%R"], pane: true, appliedPrice: false, levels: [-80, -20], range: [-100, 0] },
  { name: "Standard deviation", group: "Volatility", description: "Population deviation around the selected price's simple mean.", defaults: { kind: "stddev", period: 20, color: "#a78bfa" }, channels: ["Deviation"], pane: true, appliedPrice: true },
  { name: "Moving average envelopes", group: "Trend", description: "Percentage bands above and below a configurable moving average.", defaults: { kind: "envelopes", period: 20, multiplier: 1, method: "sma", color: "#f472b6" }, channels: ["Basis", "Upper", "Lower"], pane: false, appliedPrice: true },
  { name: "Momentum ratio", group: "Momentum", description: "Current price \xF7 price N bars ago \xD7 100 (MT5 convention).", defaults: { kind: "momentum", period: 14, color: "#4ade80" }, channels: ["Momentum"], pane: true, appliedPrice: true, levels: [100] },
  { name: "Rate of change", group: "Momentum", description: "Percentage price change over N bars.", defaults: { kind: "roc", period: 14, color: "#fbbf24" }, channels: ["ROC %"], pane: true, appliedPrice: true, levels: [0] },
  { name: "Donchian Channels", group: "Volatility", description: "Highest high, lowest low and their midpoint over the selected bars, including the forming bar. Requires a full window; channel contact alone is not a breakout signal.", defaults: { kind: "donchian", period: 20, color: "#38bdf8" }, channels: ["Midpoint", "Upper", "Lower"], pane: false, appliedPrice: false },
  { name: "Directional movement (DMI / ADX)", group: "Trend", description: "Wilder-smoothed +DI and \u2212DI show directional movement; ADX measures strength, not direction or confidence. Separate DI and ADX lengths; tied moves count as zero. Not a trade signal.", defaults: { kind: "dmi", period: 14, signal: 14, color: "#38bdf8" }, channels: ["+DI", "\u2212DI", "ADX"], pane: true, appliedPrice: false, range: [0, 100] },
  { name: "Tick volume", group: "Volume", description: "Explicit MT5 per-bar tick counts, not traded size. Only source-qualified observations are plotted; missing or partial streaming evidence stays blank, never zero-filled. No real traded-volume data is inferred.", defaults: { kind: "tick_volume", period: 1, color: "#38bdf8" }, channels: ["Ticks"], pane: true, appliedPrice: false },
  { name: "Anchored VWAP", group: "Volume", description: "Cumulative original bar price \xD7 provider-reported trade units / cumulative trade units, from an exact observed bar. HLC3 by default. Loaded observations only, not a full session or trade-by-trade average. Missing/zero/unqualified volume holds the remaining interval; no tick proxy.", defaults: { kind: "vwap", period: 1, source: "hlc3", color: "#fbbf24" }, channels: ["VWAP"], pane: false, appliedPrice: true },
  { name: "Trade volume", group: "Volume", description: "Qualified provider-reported trade units per original closed bar. These are not tick counts, proven shares or consolidated-market volume. Missing/zero/unqualified quantities stay blank.", defaults: { kind: "trade_volume", period: 1, color: "#34d399" }, channels: ["Trade units"], pane: true, appliedPrice: false },
  { name: "Estimated volume profile", group: "Volume", description: "Fixed-range price bins estimate uniform volume across original candle ranges. Qualified provider trade units only; no tick substitute, observed executions-at-price or complete-session claim.", defaults: { kind: "volume_profile", period: 1, color: "#a78bfa", profileRows: 32, profileValueAreaPercent: 70 }, channels: ["Estimated trade units"], pane: false, appliedPrice: false }
];
var STUDY_DEFAULTS = ["sma", "ema", "bollinger", "rsi", "macd"].map((kind) => STUDY_CATALOG.find((item) => item.defaults.kind === kind).defaults);

// artifacts/trading-dashboard/src/lib/chart-engine/chartWorkspace.ts
var CHART_STYLES = ["candles", "bars", "line", "area", "baseline", "heikinAshi", "hollow"];
function closeOnlyStyle(style) {
  return style === "line" || style === "area" || style === "baseline";
}

// artifacts/trading-dashboard/src/lib/chart-engine/nativePriceRenderer.ts
function prepareNativePriceSeries(input) {
  const candles = sanitizeCandlestickData(input).map(({ time, open, high, low, close }) => Object.freeze({ time, open, high, low, close }));
  return Object.freeze({
    candles: Object.freeze(candles),
    heikinAshi: Object.freeze(heikinAshi(candles).map((bar) => Object.freeze(bar))),
    discarded: input.length - candles.length
  });
}
var finiteOrNull = (value) => Number.isFinite(value) ? value : null;
var bodyWidth = (spacing) => Math.max(1, Math.min(24, spacing * 0.7));
function createNativePriceFrame(series, options) {
  const { style } = options;
  const scale = options.scale ?? "linear";
  const plot = Object.freeze({ ...options.plot });
  const range = Object.freeze({ ...options.range });
  if (![plot.left, plot.top, plot.width, plot.height, range.from, range.to].every(Number.isFinite) || plot.width <= 0 || plot.height <= 0 || range.to <= range.from || !Number.isFinite(range.to - range.from) || !Number.isFinite(plot.left + plot.width) || !Number.isFinite(plot.top + plot.height) || !["candles", "bars", "line", "area", "baseline", "heikinAshi", "hollow"].includes(style))
    return { ok: false, reason: "INVALID_VIEW" };
  if (!["linear", "log", "percent", "indexed"].includes(scale)) return { ok: false, reason: "INVALID_SCALE" };
  const reference = options.referencePrice;
  if ((scale === "percent" || scale === "indexed") && !(Number.isFinite(reference) && reference > 0))
    return { ok: false, reason: "INVALID_SCALE" };
  const closeOnly = closeOnlyStyle(style);
  const spacing = plot.width / (range.to - range.from);
  if (!Number.isFinite(spacing) || spacing <= 0) return { ok: false, reason: "INVALID_VIEW" };
  const halfBar = (bodyWidth(spacing) / 2 + (style === "hollow" ? 0.5 : 0)) / spacing;
  const start = Math.max(0, range.from), end = Math.min(series.candles.length - 1, range.to);
  const first = closeOnly ? Math.floor(start) : Math.max(0, Math.ceil(range.from - halfBar));
  const last = closeOnly ? Math.ceil(end) : Math.min(series.candles.length - 1, Math.floor(range.to + halfBar));
  if (closeOnly && end < start) return { ok: false, reason: "NO_VISIBLE_BARS" };
  if (last < first) return { ok: false, reason: "NO_VISIBLE_BARS" };
  const display = style === "heikinAshi" ? series.heikinAshi : series.candles;
  const transform = (price) => scale === "log" ? price > 0 ? Math.log(price) : NaN : price;
  let low = Infinity, high = -Infinity;
  for (let i = first; i <= last; i++) {
    const bar = display[i];
    if (!bar || !isValidCandlestickPoint(bar)) return { ok: false, reason: "INVALID_DISPLAY_BAR" };
    const a = transform(closeOnly ? bar.close : bar.low);
    const b = transform(closeOnly ? bar.close : bar.high);
    if (!Number.isFinite(a) || !Number.isFinite(b)) return { ok: false, reason: "INVALID_SCALE" };
    if (!closeOnly || i >= start && i <= end) {
      low = Math.min(low, a);
      high = Math.max(high, b);
    }
  }
  if (closeOnly) {
    for (const index of [start, end]) {
      const before = Math.floor(index), after = Math.ceil(index), weight = index - before;
      const a = transform(display[before].close), b = transform(display[after].close);
      const value = a * (1 - weight) + b * weight;
      if (!Number.isFinite(value)) return { ok: false, reason: "INVALID_SCALE" };
      low = Math.min(low, value);
      high = Math.max(high, value);
    }
  }
  if (style === "baseline" && !Number.isFinite(transform(series.candles[0].close)))
    return { ok: false, reason: "INVALID_SCALE" };
  const magnitude = Math.max(Math.abs(low), Math.abs(high)) || 1;
  const lowUnit = low / magnitude, highUnit = high / magnitude;
  const padding = highUnit > lowUnit ? (highUnit - lowUnit) * 0.08 : 0.01;
  const bottom = lowUnit - padding, extent = highUnit + padding - bottom;
  const inverted = options.inverted === true;
  if (!Number.isFinite(extent) || extent <= 0)
    return { ok: false, reason: "INVALID_VIEW" };
  const priceToY = (price, clipToPlot = false) => {
    if (!Number.isFinite(price)) return null;
    const transformed = transform(price);
    if (!Number.isFinite(transformed)) return null;
    const rawUnit = (transformed / magnitude - bottom) / extent;
    const unit = clipToPlot ? Math.max(0, Math.min(1, rawUnit)) : rawUnit;
    return finiteOrNull(plot.top + plot.height * (inverted ? unit : 1 - unit));
  };
  const yToPrice = (y) => {
    if (!Number.isFinite(y)) return null;
    const unit = (y - plot.top) / plot.height;
    const value = (bottom + (inverted ? unit : 1 - unit) * extent) * magnitude;
    const price = scale === "log" ? Math.exp(value) : value;
    return scale === "log" && price <= 0 ? null : finiteOrNull(price);
  };
  const logicalToX = (index) => Number.isFinite(index) ? finiteOrNull(plot.left + (index - range.from) * spacing) : null;
  const xToLogical = (x) => Number.isFinite(x) ? finiteOrNull(range.from + (x - plot.left) / spacing) : null;
  const frame = {
    series,
    plot,
    range,
    style,
    scale,
    inverted,
    first,
    last,
    spacing,
    priceToY,
    yToPrice,
    logicalToX,
    xToLogical,
    timeToX(time) {
      if (!Number.isFinite(time)) return null;
      let left = 0, right = series.candles.length - 1;
      while (left <= right) {
        const mid = left + Math.floor((right - left) / 2), candidate = series.candles[mid].time;
        if (candidate === time) return logicalToX(mid);
        if (candidate < time) left = mid + 1;
        else right = mid - 1;
      }
      return null;
    },
    barAtX(x) {
      if (x < plot.left || x > plot.left + plot.width) return null;
      const index = xToLogical(x);
      if (index == null) return null;
      return series.candles[Math.round(index)] ?? null;
    },
    axisValue(price) {
      if (!Number.isFinite(price) || scale === "log" && price <= 0) return null;
      return finiteOrNull(scale === "percent" ? (price / reference - 1) * 100 : scale === "indexed" ? price / reference * 100 : price);
    }
  };
  return { ok: true, frame: Object.freeze(frame) };
}
var UP = "#10b981";
var DOWN = "#ef4444";
var LINE = "#38bdf8";
function paintNativePriceLayer(ctx, frame) {
  const { plot, style, series } = frame;
  const display = style === "heikinAshi" ? series.heikinAshi : series.candles;
  ctx.save();
  try {
    ctx.beginPath();
    ctx.rect(plot.left, plot.top, plot.width, plot.height);
    ctx.clip();
    ctx.lineWidth = 1;
    ctx.lineCap = "butt";
    ctx.lineJoin = "miter";
    ctx.setLineDash([]);
    if (closeOnlyStyle(style)) {
      const points = [];
      for (let i = Math.max(0, frame.first - 1); i <= Math.min(display.length - 1, frame.last + 1); i++) {
        const x = frame.logicalToX(i), y2 = frame.priceToY(display[i].close);
        if (x != null && y2 != null) points.push({ x, y: y2 });
      }
      if (!points.length) return;
      const path = () => {
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) ctx.lineTo(points[i].x, points[i].y);
      };
      const stroke = (color) => {
        path();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        if (points.length === 1) {
          ctx.arc(points[0].x, points[0].y, 1, 0, Math.PI * 2);
          ctx.fillStyle = color;
          ctx.fill();
        } else ctx.stroke();
      };
      const fill = (y2, color) => {
        path();
        ctx.lineTo(points.at(-1).x, y2);
        ctx.lineTo(points[0].x, y2);
        ctx.closePath();
        ctx.fillStyle = color;
        ctx.fill();
      };
      if (style === "area") fill(plot.top + plot.height, "rgba(56,189,248,0.18)");
      if (style !== "baseline") {
        stroke(LINE);
        return;
      }
      const baseline = frame.priceToY(series.candles[0].close, true);
      if (baseline == null) return;
      const y = Math.max(plot.top, Math.min(plot.top + plot.height, baseline));
      for (const topHalf of [true, false]) {
        ctx.save();
        try {
          ctx.beginPath();
          ctx.rect(plot.left, topHalf ? plot.top : y, plot.width, topHalf ? y - plot.top : plot.top + plot.height - y);
          ctx.clip();
          const up = topHalf !== frame.inverted;
          fill(y, up ? "rgba(16,185,129,0.18)" : "rgba(239,68,68,0.18)");
          stroke(up ? UP : DOWN);
        } finally {
          ctx.restore();
        }
      }
      return;
    }
    const width = bodyWidth(frame.spacing);
    for (let i = frame.first; i <= frame.last; i++) {
      const bar = display[i], x = frame.logicalToX(i);
      const open = frame.priceToY(bar.open), close = frame.priceToY(bar.close), high = frame.priceToY(bar.high), low = frame.priceToY(bar.low);
      if (x == null || open == null || close == null || high == null || low == null) continue;
      const hollow = style === "hollow" ? hollowPoint(bar, i ? series.candles[i - 1].close : null) : null;
      const color = hollow?.borderColor ?? (bar.close >= bar.open ? UP : DOWN);
      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      ctx.beginPath();
      if (style === "bars") {
        ctx.moveTo(x, high);
        ctx.lineTo(x, low);
        ctx.moveTo(x - width / 2, open);
        ctx.lineTo(x, open);
        ctx.moveTo(x, close);
        ctx.lineTo(x + width / 2, close);
        ctx.stroke();
        continue;
      }
      const top = Math.min(open, close), bottom = Math.max(open, close);
      ctx.moveTo(x, Math.min(high, low));
      ctx.lineTo(x, top);
      ctx.moveTo(x, bottom);
      ctx.lineTo(x, Math.max(high, low));
      ctx.stroke();
      const y = Math.min(open, close), height = Math.max(1, Math.abs(close - open));
      if (hollow?.color !== "transparent") ctx.fillRect(x - width / 2, y, width, height);
      else ctx.strokeRect(x - width / 2, y, width, height);
    }
  } finally {
    ctx.restore();
  }
}

// artifacts/trading-dashboard/src/lib/chart-engine/nativeChartAxes.ts
function nativePlotLayout(width, height, priceAxisWidth = 88, timeAxisHeight = 32) {
  if (![width, height, priceAxisWidth, timeAxisHeight].every(Number.isFinite) || priceAxisWidth < 88 || timeAxisHeight < 20 || width < priceAxisWidth + 48 || height < timeAxisHeight + 40) return null;
  return { left: 8, top: 8, width: width - priceAxisWidth - 8, height: height - timeAxisHeight - 8 };
}
function formatAxisValue(value, digits, scale) {
  const precision = scale === "percent" || scale === "indexed" ? 2 : digits;
  let text = value.toFixed(precision);
  if (!text.includes("e") && text.includes(".")) text = text.replace(/0+$/, "").replace(/\.$/, "");
  if (value !== 0 && Number(text) === 0) text = String(value);
  if (/^-0(?:\.0+)?$/.test(text)) text = text.slice(1);
  return `${text}${scale === "percent" ? "%" : ""}`;
}
function nativePriceTicks(frame, options = {}) {
  const digits = Number.isInteger(options.priceDigits) && options.priceDigits >= 0 && options.priceDigits <= 16 ? options.priceDigits : 2;
  const gap = Number.isFinite(options.minSpacing) ? Math.max(24, options.minSpacing) : 48;
  const count = Math.max(1, Math.min(40, Math.floor(frame.plot.height / gap)));
  const top = frame.yToPrice(frame.plot.top), bottom = frame.yToPrice(frame.plot.top + frame.plot.height);
  if (top === null || bottom === null) return [];
  const topValue = frame.axisValue(top), bottomValue = frame.axisValue(bottom);
  if (topValue === null || bottomValue === null) return [];
  const lo = Math.min(topValue, bottomValue), hi = Math.max(topValue, bottomValue);
  const span = hi - lo;
  const candidates = [];
  const rawStep = span / count;
  const unit = Math.pow(10, Math.floor(Math.log10(rawStep)));
  const ratio = rawStep / unit;
  const step = (ratio <= 1 ? 1 : ratio <= 2 ? 2 : ratio <= 5 ? 5 : 10) * unit;
  if (frame.scale === "log" && lo > 0 && hi > lo) {
    const lowExponent = Math.floor(Math.log10(lo)), highExponent = Math.ceil(Math.log10(hi));
    const exponentStride = Math.max(1, Math.floor((highExponent - lowExponent) / Math.max(1, count)));
    for (let exponent = lowExponent; exponent <= highExponent; exponent += exponentStride) {
      for (const multiplier of [1, 2, 5]) {
        const price = multiplier * Math.pow(10, exponent), y = frame.priceToY(price);
        if (Number.isFinite(price) && price > 0 && y !== null && y >= frame.plot.top && y <= frame.plot.top + frame.plot.height)
          candidates.push({ y, price, value: price });
      }
    }
  } else if (Number.isFinite(span) && span > 0 && Number.isFinite(step) && step > 0) {
    const first = Math.ceil(lo / step) * step;
    for (let i = 0; i < 128; i++) {
      const value = first + i * step;
      if (!Number.isFinite(value) || value > hi) break;
      const weight = (value - bottomValue) / (topValue - bottomValue);
      const price = frame.scale === "percent" || frame.scale === "indexed" ? bottom * (1 - weight) + top * weight : value;
      const y = frame.priceToY(price);
      if (y !== null && y >= frame.plot.top && y <= frame.plot.top + frame.plot.height) candidates.push({ y, price, value });
    }
  }
  if (candidates.length < 2) {
    candidates.length = 0;
    for (let i = 0; i <= count; i++) {
      const y = frame.plot.top + frame.plot.height * i / count;
      const price = frame.yToPrice(y), value = price === null ? null : frame.axisValue(price);
      if (price !== null && value !== null) candidates.push({ y, price, value });
    }
  }
  const result = [], labels = /* @__PURE__ */ new Set();
  for (const tick of candidates.sort((a, b) => a.y - b.y)) {
    const label = formatAxisValue(tick.value, digits, frame.scale);
    if (labels.has(label) || result.length && tick.y - result[result.length - 1].y < gap) continue;
    result.push({ ...tick, label });
    labels.add(label);
  }
  return result;
}
function nativeTimeTicks(frame, options = {}) {
  const gap = Number.isFinite(options.minSpacing) ? Math.max(156, options.minSpacing) : 174;
  const first = Math.max(0, Math.ceil(frame.range.from));
  const last = Math.min(frame.series.candles.length - 1, Math.floor(frame.range.to));
  const stride = Math.max(1, Math.ceil(gap / frame.spacing));
  const result = [];
  for (let i = first; i <= last && result.length < 100; i += stride) {
    const time = frame.series.candles[i].time, x = frame.timeToX(time);
    if (x === null || !Number.isFinite(time) || Math.abs(time) > 864e10) continue;
    try {
      result.push({ x, time, label: formatChartTime(time, options.timeZone ?? "UTC", { seconds: true }) });
    } catch {
    }
  }
  return result;
}
function paintNativeAxes(ctx, frame, options = {}) {
  const { left, top, width, height } = frame.plot, right = left + width, bottom = top + height;
  const prices = nativePriceTicks(frame, options), times = nativeTimeTicks(frame, options);
  ctx.save();
  try {
    ctx.font = "11px ui-monospace, monospace";
    ctx.lineWidth = 1;
    ctx.strokeStyle = "#203047";
    ctx.fillStyle = "#a8b7cc";
    ctx.beginPath();
    for (const tick of prices) {
      ctx.moveTo(left, tick.y);
      ctx.lineTo(right, tick.y);
    }
    for (const tick of times) {
      ctx.moveTo(tick.x, top);
      ctx.lineTo(tick.x, bottom);
    }
    ctx.stroke();
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    for (const tick of prices) ctx.fillText(tick.label, right + 6, Math.max(top + 7, Math.min(bottom - 7, tick.y)), 76);
    ctx.textBaseline = "top";
    let previousRight = -Infinity;
    for (const tick of times) {
      const compactSeconds = tick.label.replace(/^\d{4}-/, "");
      const compact = tick.label.replace(/^\d{4}-(\d{2}-\d{2}) (\d{2}:\d{2}):\d{2} (.+)$/, "$1 $2 $3");
      const clock = tick.label.match(/ (\d{2}:\d{2}):\d{2} /)?.[1] ?? tick.label;
      const label = [tick.label, compactSeconds, compact, clock].find((value) => ctx.measureText(value).width <= width);
      if (!label) continue;
      const measured = ctx.measureText(label).width;
      const x = Math.max(left, Math.min(right - measured, tick.x - measured / 2));
      if (measured > width || x < previousRight + 12) continue;
      ctx.fillText(label, x, bottom + 8);
      previousRight = x + measured;
    }
  } finally {
    ctx.restore();
  }
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartNavigation.ts
function bounded(center, span, count) {
  if (!Number.isSafeInteger(count) || count < 1 || !Number.isFinite(center) || !Number.isFinite(span)) return null;
  const width = Math.max(4, Math.min(count + 5, span));
  const from = Math.max(-3, Math.min(count + 2 - width, center - width / 2));
  return { from, to: from + width };
}
function valid(range) {
  return !!range && Number.isFinite(range.from) && Number.isFinite(range.to) && range.to > range.from;
}
function panChartWindow(range, fraction, count) {
  if (!valid(range) || !Number.isFinite(fraction) || Math.abs(fraction) > 1) return null;
  const span = range.to - range.from;
  return bounded((range.from + range.to) / 2 + span * fraction, span, count);
}
function zoomChartWindow(range, factor, count) {
  if (!valid(range) || !Number.isFinite(factor) || factor <= 0 || factor > 4) return null;
  return bounded((range.from + range.to) / 2, (range.to - range.from) * factor, count);
}

// artifacts/trading-dashboard/src/lib/chart-engine/candleReconciliation.ts
function historyRangeShift(previous, next) {
  if (!previous.length || !next.length) return 0;
  let a = 0;
  let b = 0;
  while (a < previous.length && b < next.length) {
    if (previous[a].time === next[b].time) return b - a;
    if (previous[a].time < next[b].time) a++;
    else b++;
  }
  return 0;
}
function candleDisplayPrecision(candles, symbol = "") {
  const fiat = /^(EUR|USD|GBP|AUD|NZD|CAD|CHF|JPY)(EUR|USD|GBP|AUD|NZD|CAD|CHF|JPY)$/;
  let precision = fiat.test(symbol) ? symbol.endsWith("JPY") ? 3 : 5 : 2;
  for (const c of candles.slice(-100)) {
    for (const value of [c.open, c.high, c.low, c.close]) {
      for (let digits = precision; digits <= 8; digits++) {
        if (Math.abs(value - Number(value.toFixed(digits))) < 1e-9 || digits === 8) {
          precision = Math.max(precision, digits);
          break;
        }
      }
    }
  }
  return precision;
}

// artifacts/trading-dashboard/src/lib/chart-engine/nativeChartViewport.ts
var MAX_CSS_SIDE = 16384;
var MAX_BACKING_SIDE = 8192;
var MAX_BACKING_PIXELS = 16777216;
var clamp = (value, low, high) => Math.max(low, Math.min(high, value));
var NativeChartViewport = class {
  constructor(container, options = {}) {
    this.container = container;
    this.options = { ...options };
    if (options.style && CHART_STYLES.includes(options.style)) this.style = options.style;
    if (options.scale && ["linear", "log", "percent", "indexed"].includes(options.scale)) this.scale = options.scale;
    this.inverted = options.inverted === true;
    if (isChartTimeZone(options.timeZone)) this.timeZone = options.timeZone;
    this.timeframe = options.timeframe ?? "M1";
    this.canvas = container.ownerDocument.createElement("canvas");
    this.canvas.dataset.arxNativeViewport = "true";
    this.canvas.tabIndex = 0;
    this.canvas.setAttribute("role", "region");
    this.canvas.setAttribute("aria-label", "ARX price chart. Drag to pan, scroll or pinch to zoom. Arrow keys pan, plus and minus zoom, Home fits history, End returns to latest.");
    this.canvas.style.touchAction = "none";
    this.canvas.style.display = "block";
    this.canvas.width = 0;
    this.canvas.height = 0;
    this.canvas.style.width = "0px";
    this.canvas.style.height = "0px";
    const context = this.canvas.getContext("2d");
    if (!context) throw new Error("Canvas 2D is unavailable");
    this.context = context;
    container.appendChild(this.canvas);
    const listen = (type, handler, options2) => {
      this.canvas.addEventListener(type, handler, options2);
      this.listeners.push(() => this.canvas.removeEventListener(type, handler, options2));
    };
    listen("pointerdown", this.onPointerDown);
    listen("pointermove", this.onPointerMove);
    listen("pointerup", this.onPointerUp);
    listen("pointercancel", this.onPointerCancel);
    listen("lostpointercapture", this.onLostCapture);
    listen("pointerleave", (() => {
      if (!this.pointers.size) this.clearHover();
    }));
    listen("wheel", this.onWheel, { passive: false });
    listen("keydown", this.onKeyDown);
    const listenWindow = (type, handler) => {
      window.addEventListener(type, handler);
      this.listeners.push(() => window.removeEventListener(type, handler));
    };
    listenWindow("pointermove", this.onOutsidePointerMove);
    listenWindow("pointerup", this.onPointerUp);
    listenWindow("pointercancel", this.onOutsidePointerCancel);
    listenWindow("blur", this.onWindowBlur);
    window.addEventListener("resize", this.onResize);
    this.listeners.push(() => window.removeEventListener("resize", this.onResize));
    if (typeof ResizeObserver !== "undefined") {
      this.observer = new ResizeObserver(() => {
        if (!this.destroyed) this.resize();
      });
      this.observer.observe(container);
    }
    this.resize();
  }
  canvas;
  context;
  options;
  series = prepareNativePriceSeries([]);
  range = null;
  frame = null;
  referencePrice = null;
  referenceSet = false;
  style = "candles";
  scale = "linear";
  inverted = false;
  timeZone = "UTC";
  timeframe = "M1";
  priceDigits = 2;
  width = 0;
  height = 0;
  pixelRatio = 1;
  followingLatest = true;
  destroyed = false;
  generation = 0;
  mutationRevision = 0;
  raf = null;
  drawCount = 0;
  paintError = null;
  frameIssue = null;
  callbackError = null;
  hover = null;
  pointers = /* @__PURE__ */ new Map();
  gesture = null;
  observer = null;
  media = null;
  listeners = [];
  watchDpr() {
    this.media?.removeEventListener("change", this.onDprChange);
    this.media = typeof window.matchMedia === "function" ? window.matchMedia(`(resolution: ${window.devicePixelRatio || 1}dppx)`) : null;
    this.media?.addEventListener("change", this.onDprChange);
  }
  onDprChange = () => {
    if (!this.destroyed) this.resize();
  };
  onResize = () => {
    if (!this.destroyed) this.resize();
  };
  resize(width, height) {
    if (this.destroyed) return;
    const revision = ++this.mutationRevision;
    const bounds = this.container.getBoundingClientRect();
    const w = width ?? bounds.width, h = height ?? this.options.height ?? bounds.height;
    const requestedRatio = Number.isFinite(window.devicePixelRatio) && window.devicePixelRatio > 0 ? window.devicePixelRatio : 1;
    const valid2 = Number.isFinite(w) && Number.isFinite(h) && w > 0 && h > 0 && w <= MAX_CSS_SIDE && h <= MAX_CSS_SIDE;
    const nextWidth = valid2 ? w : 0, nextHeight = valid2 ? h : 0;
    const ratio = valid2 ? Math.min(requestedRatio, MAX_BACKING_SIDE / w, MAX_BACKING_SIDE / h, Math.sqrt(MAX_BACKING_PIXELS / (w * h))) : 1;
    if (nextWidth !== this.width || nextHeight !== this.height || ratio !== this.pixelRatio) {
      this.cancelGesture();
      this.clearHover();
      if (this.destroyed || revision !== this.mutationRevision) return;
      this.width = nextWidth;
      this.height = nextHeight;
      this.pixelRatio = ratio;
      this.canvas.width = Math.floor(this.width * ratio);
      this.canvas.height = Math.floor(this.height * ratio);
      this.canvas.style.width = `${this.width}px`;
      this.canvas.style.height = `${this.height}px`;
      this.invalidate();
    }
    this.watchDpr();
  }
  setCandles(candles) {
    if (this.destroyed) return;
    const revision = ++this.mutationRevision;
    const previous = this.series.candles;
    const next = prepareNativePriceSeries(candles);
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    this.series = next;
    if (!this.referenceSet && next.candles.length) {
      this.referencePrice = next.candles[0].close;
      this.referenceSet = true;
    }
    this.priceDigits = Number.isInteger(this.options.priceDigits) && this.options.priceDigits >= 0 && this.options.priceDigits <= 16 ? this.options.priceDigits : candleDisplayPrecision(next.candles);
    const times = new Set(next.candles.map((candle) => candle.time));
    const overlap = previous.some((candle) => times.has(candle.time));
    if (!next.candles.length || previous.length && !overlap) this.cancelGesture();
    if (!next.candles.length) this.range = null;
    else if (this.followingLatest || !this.range || !overlap) this.range = this.latestRange(this.range ? this.range.to - this.range.from : void 0);
    else {
      const shift = historyRangeShift(previous, next.candles);
      this.range = panChartWindow({ from: this.range.from + shift, to: this.range.to + shift }, 0, next.candles.length);
    }
    this.invalidate();
  }
  latestRange(span = this.options.visibleBars ?? 100) {
    const count = this.series.candles.length;
    const width = Number.isFinite(span) && span > 0 ? span : 100;
    return panChartWindow({ from: count + 1 - width, to: count + 1 }, 0, count);
  }
  getRange() {
    return this.range ? Object.freeze({ ...this.range }) : null;
  }
  getFrame() {
    if (this.destroyed || this.paintError || !this.range) {
      this.frameIssue = this.destroyed ? "DESTROYED" : this.paintError ? "PAINT_FAILED" : "NO_DATA";
      return null;
    }
    if (this.frame) return this.frame;
    const plot = nativePlotLayout(this.width, this.height);
    if (!plot) {
      this.frameIssue = "ZERO_SIZE_OR_UNSUPPORTED_DIMENSIONS";
      return null;
    }
    const result = createNativePriceFrame(this.series, {
      plot,
      range: this.range,
      style: this.style,
      scale: this.scale,
      inverted: this.inverted,
      referencePrice: this.referencePrice ?? void 0
    });
    this.frame = result.ok ? result.frame : null;
    this.frameIssue = result.ok ? null : result.reason;
    return this.frame;
  }
  getState() {
    const frame = this.getFrame();
    return Object.freeze({
      status: this.destroyed ? "destroyed" : this.paintError ? "error" : !this.series.candles.length ? "empty" : frame ? "ready" : "unavailable",
      error: this.paintError ?? this.frameIssue,
      callbackError: this.callbackError,
      referencePrice: this.referencePrice,
      style: this.style,
      scale: this.scale,
      inverted: this.inverted,
      timeZone: this.timeZone,
      effectiveTimeZone: effectiveDisplayZone(this.timeZone, this.timeframe),
      timeframe: this.timeframe,
      barCount: this.series.candles.length,
      discarded: this.series.discarded,
      range: this.getRange(),
      followingLatest: this.followingLatest,
      width: this.width,
      height: this.height,
      pixelRatio: this.pixelRatio,
      pendingPaint: this.raf != null,
      drawCount: this.drawCount,
      paintCount: this.drawCount
    });
  }
  setRange(range) {
    if (this.destroyed) return;
    const bounded2 = panChartWindow(range, 0, this.series.candles.length);
    if (!bounded2) return;
    const revision = ++this.mutationRevision;
    this.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    this.range = bounded2;
    this.followingLatest = false;
    this.invalidate();
  }
  fit() {
    if (!this.destroyed) this.setRange({ from: -1, to: this.series.candles.length });
  }
  goLatest() {
    if (this.destroyed) return;
    const revision = ++this.mutationRevision;
    this.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    this.range = this.latestRange(this.range ? this.range.to - this.range.from : void 0);
    this.followingLatest = true;
    this.invalidate();
  }
  setStyle(style) {
    if (!this.destroyed && CHART_STYLES.includes(style) && style !== this.style) {
      const revision = ++this.mutationRevision;
      this.cancelGesture();
      this.clearHover();
      if (this.destroyed || revision !== this.mutationRevision) return;
      this.style = style;
      this.invalidate();
    }
  }
  setScale(scale, inverted = this.inverted) {
    if (this.destroyed || !["linear", "log", "percent", "indexed"].includes(scale)) return;
    const revision = ++this.mutationRevision;
    this.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    this.scale = scale;
    this.inverted = inverted;
    this.invalidate();
  }
  setDisplayTimeZone(zone, timeframe = this.timeframe) {
    if (this.destroyed || !isChartTimeZone(zone)) return;
    ++this.mutationRevision;
    this.timeZone = zone;
    this.timeframe = timeframe;
    this.invalidate();
  }
  resetContext() {
    if (this.destroyed) return;
    const revision = ++this.mutationRevision;
    this.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    this.generation++;
    if (this.raf != null) cancelAnimationFrame(this.raf);
    this.raf = null;
    this.series = prepareNativePriceSeries([]);
    this.range = null;
    this.referencePrice = null;
    this.referenceSet = false;
    this.followingLatest = true;
    this.invalidate();
  }
  invalidate() {
    this.frame = null;
    this.paintError = null;
    this.schedule();
  }
  schedule() {
    if (this.destroyed || this.raf != null) return;
    const generation = this.generation;
    const id = requestAnimationFrame(() => {
      if (this.destroyed || generation !== this.generation || this.raf !== id) return;
      this.raf = null;
      this.paint();
    });
    this.raf = id;
  }
  paint() {
    if (this.destroyed) return;
    try {
      const ctx = this.context;
      ctx.setTransform(this.pixelRatio, 0, 0, this.pixelRatio, 0, 0);
      ctx.clearRect(0, 0, this.width, this.height);
      const frame = this.getFrame();
      if (frame) {
        paintNativeAxes(ctx, frame, { timeZone: effectiveDisplayZone(this.timeZone, this.timeframe), priceDigits: this.priceDigits });
        paintNativePriceLayer(ctx, frame);
        if (this.hover) {
          ctx.save();
          try {
            ctx.beginPath();
            ctx.rect(frame.plot.left, frame.plot.top, frame.plot.width, frame.plot.height);
            ctx.clip();
            ctx.strokeStyle = "#94a3b8";
            ctx.lineWidth = 1;
            ctx.setLineDash([3, 3]);
            ctx.beginPath();
            ctx.moveTo(this.hover.x, frame.plot.top);
            ctx.lineTo(this.hover.x, frame.plot.top + frame.plot.height);
            ctx.moveTo(frame.plot.left, this.hover.y);
            ctx.lineTo(frame.plot.left + frame.plot.width, this.hover.y);
            ctx.stroke();
          } finally {
            ctx.restore();
          }
        }
      }
      this.drawCount++;
      this.notify("viewport", () => this.options.onViewportChange?.());
    } catch (error) {
      this.frame = null;
      this.paintError = error instanceof Error ? error.message : "Price layer paint failed";
      try {
        this.context.clearRect(0, 0, this.width, this.height);
      } catch {
      }
    }
  }
  exportImage() {
    if (this.destroyed) return null;
    if (this.raf != null) {
      cancelAnimationFrame(this.raf);
      this.raf = null;
      this.paint();
    }
    if (!this.getFrame() || this.paintError) return null;
    try {
      return this.canvas.toDataURL("image/png");
    } catch {
      return null;
    }
  }
  notify(kind, callback) {
    try {
      callback();
    } catch (error) {
      this.callbackError = `${kind} callback failed: ${error instanceof Error ? error.message : String(error)}`;
    }
  }
  point(event) {
    const rect = this.canvas.getBoundingClientRect();
    if (!rect.width || !rect.height || !Number.isFinite(event.clientX) || !Number.isFinite(event.clientY)) return null;
    const x = (event.clientX - rect.left) * this.width / rect.width, y = (event.clientY - rect.top) * this.height / rect.height;
    return Number.isFinite(x) && Number.isFinite(y) ? { x, y } : null;
  }
  inside(point, frame = this.getFrame()) {
    return !!frame && point.x >= frame.plot.left && point.x <= frame.plot.left + frame.plot.width && point.y >= frame.plot.top && point.y <= frame.plot.top + frame.plot.height;
  }
  clearHover() {
    if (this.hover) {
      this.hover = null;
      this.notify("crosshair", () => this.options.onCrosshair?.(null));
      this.schedule();
    }
  }
  updateHover(point) {
    const frame = this.getFrame(), candle = this.inside(point, frame) ? frame.barAtX(point.x) : null;
    if (!frame || !candle) {
      this.clearHover();
      return;
    }
    const x = frame.timeToX(candle.time);
    if (x == null) {
      this.clearHover();
      return;
    }
    this.hover = Object.freeze({ candle, x, y: point.y, price: frame.yToPrice(point.y) });
    this.notify("crosshair", () => this.options.onCrosshair?.(this.hover));
    this.schedule();
  }
  gestureState() {
    const values = [...this.pointers.values()];
    if (!values.length) return null;
    if (values.length === 1) return { center: values[0], distance: 0 };
    const [a, b] = values;
    return { center: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, distance: Math.hypot(a.x - b.x, a.y - b.y) };
  }
  cancelGesture() {
    const ids = [...this.pointers.keys()];
    this.pointers.clear();
    this.gesture = null;
    for (const id of ids) {
      try {
        this.canvas.releasePointerCapture(id);
      } catch {
      }
    }
  }
  onPointerDown = (event) => {
    if (this.destroyed || event.button !== 0 || this.pointers.size >= 2) return;
    const point = this.point(event);
    if (!point || !this.inside(point)) return;
    event.preventDefault();
    this.canvas.focus({ preventScroll: true });
    this.pointers.set(event.pointerId, point);
    this.gesture = this.gestureState();
    try {
      this.canvas.setPointerCapture(event.pointerId);
    } catch {
    }
    this.clearHover();
  };
  shift(range, delta) {
    return panChartWindow({ from: range.from + delta, to: range.to + delta }, 0, this.series.candles.length);
  }
  zoomAt(factor, oldX, newX = oldX) {
    const frame = this.getFrame();
    if (!frame || !this.range) return;
    const anchor = frame.xToLogical(oldX);
    if (anchor == null) return;
    const zoomed = zoomChartWindow(this.range, clamp(factor, 0.25, 4), this.series.candles.length);
    if (!zoomed) return;
    const fraction = (newX - frame.plot.left) / frame.plot.width;
    const desiredFrom = anchor - fraction * (zoomed.to - zoomed.from);
    const next = this.shift(zoomed, desiredFrom - zoomed.from);
    if (next) {
      this.range = next;
      this.followingLatest = false;
      this.frame = null;
      this.schedule();
    }
  }
  onPointerMove = (event) => {
    if (this.destroyed) return;
    const point = this.point(event);
    if (!point) return;
    if (!this.pointers.has(event.pointerId)) {
      if (!this.pointers.size) this.updateHover(point);
      return;
    }
    event.preventDefault();
    const previous = this.gesture;
    this.pointers.set(event.pointerId, point);
    const next = this.gestureState();
    const frame = this.getFrame();
    if (previous && next && frame && this.range) {
      if (this.pointers.size === 2 && previous.distance > 0 && next.distance > 0) this.zoomAt(previous.distance / next.distance, previous.center.x, next.center.x);
      else {
        const shifted = this.shift(this.range, -(next.center.x - previous.center.x) / frame.spacing);
        if (shifted) {
          this.range = shifted;
          this.followingLatest = false;
          this.frame = null;
          this.schedule();
        }
      }
    }
    this.gesture = next;
  };
  onOutsidePointerMove = (event) => {
    if (!this.destroyed && event.target !== this.canvas && this.pointers.has(event.pointerId)) this.onPointerMove(event);
  };
  onOutsidePointerCancel = (event) => {
    if (!this.destroyed && this.pointers.has(event.pointerId)) this.onPointerCancel();
  };
  onWindowBlur = () => {
    if (!this.destroyed) {
      this.cancelGesture();
      this.clearHover();
    }
  };
  onPointerUp = (event) => {
    if (this.destroyed || !this.pointers.has(event.pointerId)) return;
    this.pointers.delete(event.pointerId);
    this.gesture = this.gestureState();
    try {
      this.canvas.releasePointerCapture(event.pointerId);
    } catch {
    }
  };
  onPointerCancel = () => {
    if (!this.destroyed) {
      this.cancelGesture();
      this.clearHover();
    }
  };
  onLostCapture = (event) => {
    if (!this.destroyed && this.pointers.has(event.pointerId)) this.cancelGesture();
  };
  onWheel = (event) => {
    if (this.destroyed) return;
    const point = this.point(event), frame = this.getFrame();
    if (!point || !this.inside(point, frame) || !Number.isFinite(event.deltaY) || !Number.isFinite(event.deltaX) || event.deltaY === 0 && event.deltaX === 0) return;
    const horizontal = Math.abs(event.deltaX) > Math.abs(event.deltaY);
    const raw = horizontal ? event.deltaX : event.deltaY;
    const pixels = raw * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? horizontal ? frame.plot.width : frame.plot.height : 1);
    const revision = ++this.mutationRevision;
    event.preventDefault();
    this.cancelGesture();
    this.clearHover();
    if (this.destroyed || revision !== this.mutationRevision) return;
    if (horizontal && this.range) {
      const next = this.shift(this.range, pixels / frame.spacing);
      if (next) {
        this.range = next;
        this.followingLatest = false;
        this.frame = null;
        this.schedule();
      }
    } else this.zoomAt(Math.exp(clamp(pixels * 2e-3, -0.65, 0.65)), point.x);
  };
  onKeyDown = (event) => {
    if (this.destroyed || event.target !== this.canvas || this.canvas.ownerDocument.activeElement !== this.canvas || this.canvas.isContentEditable || this.canvas.getAttribute("contenteditable") === "true" || event.ctrlKey || event.metaKey || event.altKey || !this.range) return;
    if (event.key === "Home") this.fit();
    else if (event.key === "End") this.goLatest();
    else if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
      const next = panChartWindow(this.range, event.key === "ArrowLeft" ? -0.2 : 0.2, this.series.candles.length);
      if (next) this.setRange(next);
    } else if (["+", "=", "-", "_"].includes(event.key)) {
      const next = zoomChartWindow(this.range, event.key === "+" || event.key === "=" ? 0.8 : 1.25, this.series.candles.length);
      if (next) this.setRange(next);
    } else return;
    event.preventDefault();
  };
  destroy() {
    if (this.destroyed) return;
    this.destroyed = true;
    this.generation++;
    this.mutationRevision++;
    this.cancelGesture();
    this.clearHover();
    if (this.raf != null) cancelAnimationFrame(this.raf);
    this.raf = null;
    this.observer?.disconnect();
    this.observer = null;
    this.media?.removeEventListener("change", this.onDprChange);
    this.media = null;
    this.listeners.forEach((remove) => remove());
    this.listeners = [];
    this.frame = null;
    this.range = null;
    this.series = prepareNativePriceSeries([]);
    this.referencePrice = null;
    this.referenceSet = false;
    this.canvas.remove();
  }
};

// scripts/scanner-qa/native-viewport-entry.ts
var makeData = (count, offset = 0) => Array.from({ length: count }, (_, i) => {
  const j = i + offset, open = 100 + Math.sin(j * 0.27) * 6 + Math.cos(j * 0.063) * 8, close = open + Math.sin(j * 1.71) * 2.4;
  return { time: 1730613600 + j * 60, open, high: Math.max(open, close) + 1.4, low: Math.min(open, close) - 0.9, close };
});
document.body.innerHTML = `<main><h1>ARX native chart viewport</h1><p>Independent renderer laboratory \xB7 synthetic observations \xB7 no broker connection</p><nav><label>Style <select id="style">${CHART_STYLES.map((v) => `<option>${v}</option>`).join("")}</select></label><label>Scale <select id="scale">${["linear", "log", "percent", "indexed"].map((v) => `<option>${v}</option>`).join("")}</select></label><label>Display zone <select id="zone">${CHART_TIME_ZONES.map((v) => `<option>${v}</option>`).join("")}</select></label><button id="invert">Invert price axis</button><button id="fit">Fit loaded history</button><button id="latest">Latest</button><button id="reset">Reset 200-bar view</button></nav><output id="state"></output><section id="chart"></section><output id="inspect">Move over a candle to inspect canonical OHLC.</output><p class="help">Drag to pan \xB7 wheel/pinch to zoom \xB7 arrow keys to pan \xB7 +/\u2212 to zoom \xB7 Home fits \xB7 End follows latest. Display-only; studies, drawings and app integration are still pending.</p></main>`;
var css = document.createElement("style");
css.textContent = `*{box-sizing:border-box}body{margin:0;background:#090f1b;color:#dce7f6;font:14px system-ui}main{max-width:1440px;margin:auto;padding:20px}h1{font-size:24px;margin:0 0 8px}p,output{color:#a3b3c9}nav{display:flex;gap:12px;align-items:end;flex-wrap:wrap;margin:20px 0}label{display:grid;gap:5px}select,button{padding:9px;background:#17243b;color:inherit;border:1px solid #3a506d;border-radius:5px;font:inherit}#chart{margin:12px 0;background:#0d1625;border:1px solid #20314b;min-width:0}canvas{max-width:100%;outline-offset:-2px}canvas:focus-visible{outline:2px solid #39b7ff}output{display:block;overflow-wrap:anywhere;font:12px ui-monospace,monospace}.help{line-height:1.5}@media(max-width:600px){main{padding:12px}h1{font-size:21px}nav{gap:8px}button,select{padding:8px;font-size:12px}}`;
document.head.append(css);
var data = makeData(2e4);
var viewport = new NativeChartViewport(document.getElementById("chart"), { height: 500, visibleBars: 200, onViewportChange: () => {
  const state = viewport.getState();
  document.getElementById("state").textContent = `${state.status} \xB7 ${state.barCount} loaded bars \xB7 ${state.style}/${state.scale} \xB7 reference ${state.referencePrice} \xB7 ${state.effectiveTimeZone} \xB7 ${state.followingLatest ? "following latest" : "inspecting history"}`;
}, onCrosshair: (value) => {
  document.getElementById("inspect").textContent = value ? `Canonical UTC ${new Date(value.candle.time * 1e3).toISOString()} | O ${value.candle.open} H ${value.candle.high} L ${value.candle.low} C ${value.candle.close}` : "No candle selected.";
} });
var prepareStart = performance.now();
viewport.setCandles(data);
var initialPreparationMs = performance.now() - prepareStart;
document.getElementById("style").addEventListener("change", (e) => viewport.setStyle(e.target.value));
document.getElementById("scale").addEventListener("change", (e) => viewport.setScale(e.target.value));
document.getElementById("zone").addEventListener("change", (e) => viewport.setDisplayTimeZone(e.target.value));
document.getElementById("invert").addEventListener("click", () => viewport.setScale(viewport.getState().scale, !viewport.getState().inverted));
document.getElementById("fit").addEventListener("click", () => viewport.fit());
document.getElementById("latest").addEventListener("click", () => viewport.goLatest());
document.getElementById("reset").addEventListener("click", () => {
  viewport.setRange({ from: data.length - 199, to: data.length + 1 });
  viewport.goLatest();
});
var waitPaint = async (previous) => {
  for (let i = 0; i < 20; i++) {
    await new Promise(requestAnimationFrame);
    if (viewport.getState().paintCount > previous) return;
  }
  throw Error("Viewport did not paint");
};
window.__arxNativeViewportQa = {
  viewport,
  makeData,
  get data() {
    return data;
  },
  replace: (next) => {
    data = next;
    viewport.setCandles(data);
  },
  waitPaint,
  initialPreparationMs,
  benchmark: async () => {
    const samples = [];
    viewport.setStyle("candles");
    viewport.setScale("linear", false);
    for (let i = 0; i < 150; i++) {
      const previous = viewport.getState().paintCount, begin = performance.now();
      viewport.setRange({ from: data.length - 201 - i % 10, to: data.length - 1 - i % 10 });
      await waitPaint(previous);
      if (i >= 30) samples.push(performance.now() - begin);
    }
    return { samples, warmup: 30, loadedBars: data.length, visibleLogicalSpan: 200, initialPreparationMs, dpr: devicePixelRatio, userAgent: navigator.userAgent };
  }
};
