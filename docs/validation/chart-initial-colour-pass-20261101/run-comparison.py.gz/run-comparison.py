import subprocess,json,time,select,os,signal
from pathlib import Path
repo=Path('/Users/areyouok/arx-chart-initial-colour-pass-20261101');out=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
cli='/Users/areyouok/.local/bin/playwright-cli';runner=(repo/'scripts/chart-qa/stress-matrix-runner.js').read_text().strip();records=[]
def action(name,label,args):
 with (out/f'{name}-{label}.log').open('w') as log:proc=subprocess.run([cli,'-s=arx-initial-colour',*args],cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=300)
 return proc.returncode
def result(name,label):
 text=(out/f'{name}-{label}.log').read_text();value=json.JSONDecoder().raw_decode(text.split('### Result\n',1)[1])[0]
 (out/f'{name}-{label}.json').write_text(json.dumps(value,indent=2)+'\n');return value
for index,variant,label in [(1,'baseline','matrix'),(2,'candidate','matrix'),(3,'candidate','matrix'),(4,'baseline','matrix'),(5,'baseline','visual'),(6,'candidate','visual')]:
 name=f'{index}-{variant}';expected='true' if variant=='candidate' else 'false'
 script=runner.replace('r.build=build;',f"if(Boolean(build.initialColourPassExperiment)!=={expected})throw Error('Wrong experiment variant');r.build=build;")
 (out/f'{name}-matrix.js').write_text(f"async page=>{{const STRESS_EXPECTED_COMMIT={json.dumps(head)};return await ({script})(page);}}\n")
 (out/f'{name}-visual.js').write_text(f"async page=>{{const errors=[],blocked=[];page.on('pageerror',e=>errors.push(e.message));await page.context().route('**/*',async route=>{{const req=route.request(),url=new URL(req.url());if(url.origin!=='http://127.0.0.1:4179'||req.method()!=='GET'||url.pathname.startsWith('/api/')){{blocked.push({{url:req.url(),method:req.method()}});return route.fulfill({{status:503,body:'OFFLINE_BLOCKED'}});}}return route.continue();}});await page.context().routeWebSocket('**/*',ws=>ws.close());await page.setViewportSize({{width:1600,height:1100}});await page.goto('http://127.0.0.1:4179');await page.waitForFunction(()=>typeof window.runStudyRowVisualProbe==='function');const build=await page.evaluate(()=>fetch('/arx-chart-qa-build-info.json').then(r=>r.json()));if(build.git?.head!=={json.dumps(head)}||build.git.dirty!==false||build.git.treeChangedDuringBuild!==false||Boolean(build.initialColourPassExperiment)!=={expected})throw Error('Wrong visual build');const result=await page.evaluate(()=>window.runStudyRowVisualProbe());return {{build,result,errors,blocked}};}}\n")
 server=subprocess.Popen(['python3','/tmp/arx-offline-run.py','/usr/local/bin/node','scripts/chart-qa/prod-server.mjs',f'--out=scripts/node_modules/.initial-colour-{variant}','--no-build'],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=True)
 record={'name':name,'commit':head,'startedAt':time.time()}
 try:
  with (out/f'{name}-server.log').open('w') as f:
   deadline=time.monotonic()+40
   while time.monotonic()<deadline:
    ready,_,_=select.select([server.stdout],[],[],1)
    if ready:
     line=server.stdout.readline();f.write(line);f.flush()
     if 'Production chart fixture ready' in line:break
     if server.poll() is not None:raise RuntimeError('Fixture exited '+str(server.returncode))
   else:raise RuntimeError('Fixture ready timeout')
  record['openExit']=action(name,'open',['open','about:blank'])
  for label in [label]:
   record[label+'Exit']=action(name,label,['run-code',f'--filename={out/name}-{label}.js'])
   try:
    value=result(name,label);record[label+'Valid']=value['allCorrect'] if label=='matrix' else value['result']['valid']
   except Exception as error:record[label+'Error']=repr(error)
   print(json.dumps({'name':name,'phase':label,**{k:v for k,v in record.items() if k.startswith(label)}}),flush=True)
 except Exception as error:record['error']=repr(error)
 finally:
  record['closeExit']=action(name,'close',['close'])
  try:os.killpg(server.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:server.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait()
  record['finishedAt']=time.time();records.append(record);(out/'comparison-runs.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 if record.get('error'):break
