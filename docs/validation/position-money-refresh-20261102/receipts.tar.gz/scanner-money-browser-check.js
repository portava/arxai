async page => {
 const out={passed:false,checks:[],failure:null,scope:'Offline synthetic actual Market Scanner; no terminal/broker/trade actions'};
 const check=(v,label)=>{if(!v)throw Error(label);out.checks.push(label);};
 const row={scope:'live',brokerTicket:'fixture-money',symbol:'EURUSD',side:'BUY',lotSize:.01,entryPrice:1.001,currentPrice:1.002,stopLoss:.99,takeProfit:1.01,floatingPnl:1,openedAt:'2026-01-02T10:00:00.000Z',sourceCommandId:null,accountMode:'LIVE',source:'OFFLINE_FIXTURE'};
 try {
  await page.evaluate(row=>{localStorage.setItem('arx_autoRefresh_enabled','true');return window.__moneyFixtureSet([row]);},row);
  await page.setViewportSize({width:1440,height:1000});await page.goto('http://127.0.0.1:4199/market-scanner');
  await page.getByTestId('scanner-chart-pos-fixture-money').waitFor();
  out.build=await page.evaluate(async()=>{const r=await fetch('/arx-scanner-qa-build-info.json');return r.json();});
  check(out.build.source.head==='0090138ed5eb3dee1ead795d188d1261af2ec269'&&out.build.sourceUnchanged&&!out.build.source.status&&out.build.qaOnlyDefaultEngineOverride===false&&await page.evaluate(()=>window.__arxScannerQaBuildId)===out.build.buildId,'Exact committed production source executed');
  check(await page.evaluate(()=>window.__offlineStreams.filter(s=>!s.closed).length)===1,'Exactly one shared account stream on Scanner');
  await page.evaluate(()=>window.__offlineStreams[0].emit({type:'account_snapshot',snapshot:{userId:'900007',accountMode:'UNKNOWN',freshness:'unavailable',positions:[],warnings:[]}}));
  await page.evaluate(row=>window.__moneyFixtureSet([{...row,floatingPnl:-12.345,currentPrice:1.003}]),row);
  await page.evaluate(()=>{window.__moneyHintAt=performance.now();window.__offlineStreams[0].emit({type:'personal_account_changed'});});
  await page.waitForFunction(()=>document.querySelector('[data-testid="scanner-chart-pos-fixture-money"]')?.textContent.includes('-12.345'));
  out.hintToReadbackMs=await page.evaluate(()=>performance.now()-window.__moneyHintAt);
  check(out.hintToReadbackMs<5000,'Scanner updates exact P/L before five-second fallback');
  check((await page.getByTestId('scanner-chart-position-evidence').innerText()).includes('last reported'),'Scanner qualifies position observation and currency');
  await page.getByRole('switch',{name:'Auto-refresh'}).click();
  await page.evaluate(()=>window.__moneyFixtureSet([]));
  await page.getByRole('button',{name:'Refresh',exact:true}).click();
  await page.waitForFunction(()=>!document.querySelector('[data-testid="scanner-chart-pos-fixture-money"]'));
  check(await page.getByTestId('scanner-chart-manage').count()===0,'Paused manual refresh removes absent position panel');
  check(await page.evaluate(()=>localStorage.getItem('arx_autoRefresh_enabled'))==='false','Manual refresh preserves pause');
  out.fixture=await page.evaluate(()=>window.__readFixtureLog());
  check(out.fixture.errors.length===0,'No page exception');
  check(!out.fixture.blocked.some(x=>x.kind==='external'||x.kind==='websocket'),'No external network or broker');
  check(!out.fixture.requests.some(r=>r.method!=='GET'&&/positions.*(?:close|modify)|live-intent|\/execute|\/orders|\/commands/.test(r.path)),'No trade action attempted');
  await page.screenshot({path:'scanner-money-final.png'});out.passed=true;
 }catch(error){out.failure=String(error?.stack??error);await page.screenshot({path:'scanner-money-failure.png'});}
 return out;
}
