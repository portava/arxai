async page => {
 const out={passed:false,checks:[],failure:null,scope:'Synthetic read-only actual live-chart page; no terminal, broker or live financial evidence'};
 const check=(value,label)=>{if(!value)throw Error(label);out.checks.push(label);};
 try {
  await page.evaluate(()=>window.__moneyFixtureSet([{scope:'live',brokerTicket:'fixture-money',symbol:'EURUSD',side:'BUY',lotSize:.01,entryPrice:1.001,currentPrice:1.002,stopLoss:.99,takeProfit:1.01,floatingPnl:1,openedAt:'2026-01-02T10:00:00.000Z',sourceCommandId:null,accountMode:'LIVE',source:'OFFLINE_FIXTURE'}]));
  await page.setViewportSize({width:1440,height:1000});await page.goto('http://127.0.0.1:4199/live-chart');
  await page.getByTestId('btn-select-position-live-fixture-money').waitFor();
  out.build=await page.evaluate(async()=>{const r=await fetch('/arx-scanner-qa-build-info.json');return r.json();});
  check(out.build.source.head==='0090138ed5eb3dee1ead795d188d1261af2ec269'&&out.build.sourceUnchanged&&!out.build.source.status&&out.build.qaOnlyDefaultEngineOverride===false&&await page.evaluate(()=>window.__arxScannerQaBuildId)===out.build.buildId,'Exact committed production source executed');
  await page.evaluate(()=>{window.__offlineStreams[0].emit({type:'account_snapshot',snapshot:{userId:'900007',accountMode:'UNKNOWN',freshness:'unavailable',positions:[],warnings:[]}});});
  await page.getByTestId('btn-select-position-live-fixture-money').click();
  await page.getByTestId('text-position-pnl').waitFor();
  check(await page.getByTestId('text-position-pnl').innerText()==='+1','Initial selected card uses supplied report');
  const updated={scope:'live',brokerTicket:'fixture-money',symbol:'EURUSD',side:'BUY',lotSize:.01,entryPrice:1.001,currentPrice:1.003,stopLoss:.995,takeProfit:1.01,floatingPnl:-12.345,openedAt:'2026-01-02T10:00:00.000Z',sourceCommandId:null,accountMode:'LIVE',source:'OFFLINE_FIXTURE'};
  await page.evaluate(row=>window.__moneyFixtureSet([row]),updated);
  await page.evaluate(()=>{window.__moneyHintAt=performance.now();window.__offlineStreams[0].emit({type:'personal_account_changed'});});
  await page.waitForFunction(()=>document.querySelector('[data-testid="text-position-pnl"]')?.textContent==='-12.345');
  out.hintToReadbackMs=await page.evaluate(()=>performance.now()-window.__moneyHintAt);
  check(out.hintToReadbackMs<5000,'Notification updates detail before five-second fallback interval');
  check((await page.getByTestId('btn-select-position-live-fixture-money').innerText()).includes('-12.345'),'List and selected card show identical reported P/L');
  await page.waitForFunction(()=>document.querySelector('[data-testid=\"arx-native-pnl-bubble\"]')?.textContent?.includes('-12.345'),null,{timeout:1000});
  check(true,'Chart bubble updates to identical unrounded reported P/L before fallback');
  const panelPnl=await page.getByTestId('chart-position-pnl').allTextContents();check(panelPnl.length===1&&panelPnl[0].includes('-12.345'),'Chart position panel agrees with picker and bubble');
  check(await page.getByTestId('text-position-current').innerText()==='1.003','Selected price follows same report');
  check(await page.getByTestId('text-position-status').innerText()==='Reported open','Open status is qualified');
  check((await page.getByTestId('text-position-risk').innerText()).includes('contract size and currency'),'Unsupported dollar risk is withheld');
  check(await page.evaluate(()=>window.__offlineStreams.filter(s=>!s.closed).length)===1,'Exactly one shared account stream');
  await page.getByRole('switch',{name:'Auto-refresh'}).click();
  await page.evaluate(()=>window.__moneyFixtureSet([]));
  await page.getByRole('button',{name:'Refresh',exact:true}).click();
  await page.waitForFunction(()=>!document.querySelector('[data-testid="position-side-card"]'));
  check(await page.getByTestId('text-no-open-positions').isVisible(),'Explicit paused refresh withdraws removed position');
  await page.waitForFunction(()=>document.querySelectorAll('[data-testid=\"arx-native-pnl-bubble\"],[data-testid=\"chart-position-pnl\"]').length===0,null,{timeout:1000});
  check(true,'Removed position withdraws chart bubble and position panel together');
  check(await page.evaluate(()=>localStorage.getItem('arx_autoRefresh_enabled'))==='false','Manual refresh preserves pause');
  out.fixture=await page.evaluate(()=>window.__readFixtureLog());
  check(out.fixture.errors.length===0,'No page exception');
  check(!out.fixture.blocked.some(x=>x.kind==='external'||x.kind==='websocket'),'No external network or broker');
  check(!out.fixture.requests.some(r=>r.method!=='GET'&&/positions.*(?:close|modify)|live-intent|\/execute|\/orders|\/commands/.test(r.path)),'No trade action attempted');
  await page.screenshot({path:'money-aligned-final.png'});out.passed=true;
 }catch(error){out.failure=String(error?.stack??error);out.visible=await page.evaluate(()=>({card:document.querySelector('[data-testid=\"text-position-pnl\"]')?.textContent,bubbles:[...document.querySelectorAll('[data-testid=\"arx-native-pnl-bubble\"]')].map(x=>x.textContent)}));await page.screenshot({path:'money-alignment-final-failure.png'});}
 return out;
}
