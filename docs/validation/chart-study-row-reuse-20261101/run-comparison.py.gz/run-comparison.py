import subprocess,json,time,select,os,signal
from pathlib import Path
repo=Path('/Users/areyouok/arx-chart-study-row-reuse-20261101');out=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
cli='/Users/areyouok/.local/bin/playwright-cli';runner=(repo/'scripts/chart-qa/stress-matrix-runner.js').read_text().strip();records=[]
def action(name,label,args):
 with (out/f'{name}-{label}.log').open('w') as log:proc=subprocess.run([cli,'-s=arx-study-reuse',*args],cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 return proc.returncode
def result(name,label):
 text=(out/f'{name}-{label}.log').read_text();value=json.JSONDecoder().raw_decode(text.split('### Result\n',1)[1])[0]
 (out/f'{name}-{label}.json').write_text(json.dumps(value,indent=2)+'\n');return value
for index,variant in enumerate(['baseline','candidate','candidate','baseline'],start=1):
 name=f'{index}-{variant}';expected='true' if variant=='candidate' else 'false'
 script=runner.replace('r.build=build;',f"if(Boolean(build.studyRowReuseExperiment)!=={expected})throw Error('Wrong experiment variant');r.build=build;")
 (out/f'{name}-matrix.js').write_text(f"async page=>{{const STRESS_EXPECTED_COMMIT={json.dumps(head)};return await ({script})(page);}}\n")
 (out/f'{name}-visual.js').write_text(f"async page=>{{const build=await page.evaluate(()=>fetch('/arx-chart-qa-build-info.json').then(r=>r.json()));if(build.git?.head!=={json.dumps(head)}||build.git.dirty!==false||build.git.treeChangedDuringBuild!==false||Boolean(build.studyRowReuseExperiment)!=={expected})throw Error('Wrong visual build');const result=await page.evaluate(()=>window.runStudyRowVisualProbe());return {{build,result}};}}\n")
 server=subprocess.Popen(['python3','/tmp/arx-offline-run.py','/usr/local/bin/node','scripts/chart-qa/prod-server.mjs',f'--out=scripts/node_modules/.study-reuse-v2-{variant}','--no-build'],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=True)
 record={'name':name,'commit':head,'startedAt':time.time()}
 try:
  with (out/f'{name}-server.log').open('w') as f:
   deadline=time.monotonic()+40
   while time.monotonic()<deadline:
    ready,_,_=select.select([server.stdout],[],[],1)
    if ready:
     line=server.stdout.readline();f.write(line);f.flush()
     if 'Production chart fixture ready' in line:break
     if server.poll() is not None:raise RuntimeError('Fixture exited '+str(server.returncode))
   else:raise RuntimeError('Fixture ready timeout')
  record['openExit']=action(name,'open',['open','about:blank'])
  for label in ['matrix','visual']:
   record[label+'Exit']=action(name,label,['run-code',f'--filename={out/name}-{label}.js'])
   try:
    value=result(name,label);record[label+'Valid']=value['allCorrect'] if label=='matrix' else value['result']['valid']
   except Exception as error:record[label+'Error']=repr(error)
   print(json.dumps({'name':name,'phase':label,**{k:v for k,v in record.items() if k.startswith(label)}}),flush=True)
 except Exception as error:record['error']=repr(error)
 finally:
  record['closeExit']=action(name,'close',['close'])
  try:os.killpg(server.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:server.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(server.pid,signal.SIGKILL);server.wait()
  record['finishedAt']=time.time();records.append(record);(out/'comparison-runs.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(record),flush=True)
 if record.get('error'):break
