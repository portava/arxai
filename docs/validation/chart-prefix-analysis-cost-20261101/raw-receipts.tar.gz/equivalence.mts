import assert from 'node:assert/strict';
import {resolve} from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const [base,candidate]=process.argv.slice(2).map(p=>resolve(p));
const source=(p:string)=>({head:execFileSync('git',['rev-parse','HEAD'],{cwd:p,encoding:'utf8'}).trim(),diff:createHash('sha256').update(execFileSync('git',['diff','HEAD','--'],{cwd:p})).digest('hex')});
const before=[source(base),source(candidate)];
const load=(p:string)=>import(resolve(p,'artifacts/trading-dashboard/src/lib/chart-engine/smartChartAnalysis.ts'));
const a=await load(base),b=await load(candidate),start=1700000000;
const context={symbol:'EURUSD',timeframe:'M5',source:'mt5_broker',sourceIdentity:'a'.repeat(64)};
let cases=0,findings=0;const hashes:any[]=[];const families=new Set<string>();
for(const seed0 of [1,17,307,9001]){
 let seed=seed0;const bars=Array.from({length:700},(_,i)=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;const close=100+10*Math.sin(i/8)+seed/4294967296*3,open=close+(i%2?-.4:.4);return {time:start+i*300,closeTime:start+(i+1)*300,open,close,high:Math.max(open,close)+.6,low:Math.min(open,close)-.6,isComplete:true,isFinal:true,isForming:false};});
 for(const end of [0,1,19,20,23,24,30,33,50,100,577,599,600,601,700]){
  const selected=bars.slice(0,end);const input={...context,bars:selected,asOfMs:(bars.at(-1)!.closeTime+1)*1000,dataState:'current'};
  const variants=[{},...['stale','historical','unconfirmed','unavailable','delayed'].map(dataState=>({dataState})),{feedReadFailed:true},{replayCutoff:start+Math.floor(end*.7)*300},{visibleRange:{from:start+Math.floor(end*.3)*300,to:start+end*300}},{sourceIdentity:null},{bars:[...selected,{...bars[end%700],isComplete:false,isForming:true}]},{bars:[...selected].reverse()}];
  for(let variant=0;variant<variants.length;variant++){
   const request={...input,...variants[variant]},original=structuredClone(request),baseline=a.analyzeSmartChart(request),candidate=b.analyzeSmartChart(request);
   assert.deepEqual(candidate,baseline,`seed=${seed0} end=${end} variant=${variant}`);assert.deepEqual(request,original,'input mutated');
   findings+=baseline.allFindings.length;for(const f of baseline.allFindings)families.add(f.family??f.title);
   hashes.push({seed:seed0,end,variant,sha256:createHash('sha256').update(JSON.stringify(baseline)).digest('hex')});cases++;
  }
 }
}
assert.ok(findings>0);const after=[source(base),source(candidate)];assert.deepEqual(after,before,'source changed');
console.log(JSON.stringify({source:before,cases,findingsCompared:findings,families:[...families],sourceUnchanged:true,hashes,limitations:['Generated bounded cases, not proof across all input histories or predictive accuracy.','All object fields/order/metadata compared; no output filtering.']},null,2));
