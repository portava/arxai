import datetime,hashlib,json,pathlib,subprocess,time
root=pathlib.Path('/Users/areyouok/arx-chart-support-resistance-20261101')
out=pathlib.Path('/Users/areyouok/arx-tier1-release/account-monetary-evidence-20261101')
pnpm='/Users/areyouok/.local/bin/pnpm'
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
head=git('rev-parse','HEAD'); assert not git('status','--porcelain'), 'Source must be committed and clean'
checks=[('api-typecheck',[pnpm,'--filter','@workspace/api-server','run','typecheck']),('dashboard-typecheck',[pnpm,'--filter','@workspace/trading-dashboard','run','typecheck']),('profit-truth',[pnpm,'--filter','@workspace/api-server','run','test:account-profit-truth']),('account-stream',[pnpm,'--filter','@workspace/api-server','run','test:account-stream-scheduling']),('account-projection',[pnpm,'--filter','@workspace/api-server','run','test:broker-hub-account-snapshot']),('legacy-snapshot',[pnpm,'--filter','@workspace/scripts','run','test:live-account-snapshot']),('frontend',[pnpm,'--filter','@workspace/trading-dashboard','test']),('mt5-offline',[pnpm,'--filter','@workspace/api-server','run','test:mt5-demo-ea']),('bridge-package',[pnpm,'--filter','@workspace/api-server','run','test:mt5-bridge-package']),('guards',['node','--import','./scripts/node_modules/tsx/dist/loader.mjs','scripts/src/ci/run-all.ts']),('api-build',[pnpm,'--filter','@workspace/api-server','run','build']),('dashboard-build',[pnpm,'--filter','@workspace/trading-dashboard','run','build'])]
d={'applicationCommit':head,'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':[]}
for name,command in checks:
 t=time.monotonic();log=out/(name+'.log')
 with log.open('w') as f:r=subprocess.run(['python3','/tmp/arx-offline-run.py',*command],cwd=root,stdout=f,stderr=subprocess.STDOUT)
 row={'check':name,'command':command,'exitCode':r.returncode,'elapsedSeconds':round(time.monotonic()-t,3),'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};d['results'].append(row)
 (out/'combined-validation.json').write_text(json.dumps(d,indent=2)+'\n');print(name,r.returncode,flush=True)
d.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),finalHead=git('rev-parse','HEAD'),finalStatus=git('status','--porcelain'))
(out/'combined-validation.json').write_text(json.dumps(d,indent=2)+'\n')
assert d['finalHead']==head and not d['finalStatus']
raise SystemExit(int(any(x['exitCode'] for x in d['results'] if x['check']!='guards')))
