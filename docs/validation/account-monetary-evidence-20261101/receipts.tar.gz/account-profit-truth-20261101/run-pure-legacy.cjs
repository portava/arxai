const fs=require('node:fs');const vm=require('node:vm');const{createRequire}=require('node:module');
const repo='/Users/areyouok/arx-account-profit-truth-20261101';const ts=createRequire(repo+'/scripts/package.json')('typescript');
const read=p=>fs.readFileSync(repo+'/'+p,'utf8');
function functions(path,names){const src=read(path);const ast=ts.createSourceFile(path,src,ts.ScriptTarget.Latest,true);const nodes=ast.statements.filter(n=>ts.isFunctionDeclaration(n)&&n.name&&names.includes(n.name.text));if(nodes.length!==names.length)throw Error('Missing pure production function');return nodes.map(n=>n.getText(ast).replace(/^export /,'')).join('\n');}
const pure=functions('artifacts/api-server/src/lib/live/investorLiveBalance.ts',['computeAvailableBalance','mapFreshnessStatus','modeToSource','composeInvestorBalance','toInvestorLiveBalanceWire']);
const legacy=read('scripts/src/investorLiveBalanceTest.ts');const tree=ts.createSourceFile('legacy.ts',legacy,ts.ScriptTarget.Latest,true);const body=tree.statements.filter(n=>!ts.isImportDeclaration(n)).map(n=>n.getText(tree)).join('\n');
const js=ts.transpileModule('const round2=(n:number)=>Math.round(n*100)/100;\n'+pure+'\n'+body,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;
console.log('Original investorLiveBalanceTest assertions, actual pure production functions extracted; no DB/provider imports.');
vm.runInNewContext(js,{console,process:{exit(code){if(code!==0)throw Error('Legacy test failed: '+code);}}});
