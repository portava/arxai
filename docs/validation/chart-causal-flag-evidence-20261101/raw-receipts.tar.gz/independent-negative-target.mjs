import { detectChartPatterns } from '/Users/areyouok/arx-chart-support-resistance-20261101/lib/domain/src/chart-patterns/patternEngine.ts';
const row=close=>({open:close,high:close+.2,low:close-.2,close,isComplete:true,isForming:false});
const source=[...Array.from({length:6},()=>row(100)),...Array.from({length:8},(_,i)=>row(100-i*10)),...Array.from({length:6},(_,i)=>row(30.2+i*.2)),row(30.8)];
console.log(JSON.stringify({allSourcePricesPositive:source.every(c=>c.low>0),source,pattern:detectChartPatterns(source).patterns.find(p=>p.id==='bear_flag')},null,2));
