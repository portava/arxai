async page => {
 const result=await page.evaluate(()=>({snapshots:[window.__arxChartQa.snapshot(0),window.__arxChartQa.snapshot(1)], legends:[...document.querySelectorAll('[data-testid="chart-candle-inspector"]')].map(e=>e.textContent)}));
 await page.screenshot({path:'native-link-failure.png',fullPage:false});
 return result;
}
