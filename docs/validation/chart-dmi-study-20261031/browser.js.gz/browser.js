async page=>{
 const report={passed:false,checks:[],samples:[],failure:null};
 const check=(ok,label)=>{report.checks.push({label,pass:!!ok});if(!ok)throw Error(label);};
 const frames=()=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
function oracle(bars,period,signal){
 const rma=(values,length)=>{
  let total=0,count=0,previous=null;
  return values.map(value=>{if(value===null){total=0;count=0;previous=null;return null;}count++;if(count<=length)total+=value;
   if(count<length)return null;
   previous=count===length?total/length:(previous*(length-1)+value)/length;return previous;});
 };
 const plus=[null],minus=[null],tr=[null];
 for(let i=1;i<bars.length;i++){
  const b=bars[i],a=bars[i-1],up=b.high-a.high,down=a.low-b.low;
  plus.push(up>0&&up>down?up:0);minus.push(down>0&&down>up?down:0);
  tr.push(Math.max(b.high-b.low,Math.abs(b.high-a.close),Math.abs(b.low-a.close)));
 }
 const p=rma(plus,period),m=rma(minus,period),t=rma(tr,period);
 const di=p.map((v,i)=>v===null?null:t[i]===0?0:100*v/t[i]);
 const dm=m.map((v,i)=>v===null?null:t[i]===0?0:100*v/t[i]);
 const dx=di.map((v,i)=>v===null?null:(v+dm[i]) === 0?0:100*Math.abs(v-dm[i])/(v+dm[i]));
 const adx=rma(dx,signal);return bars.map((_,i)=>[di[i],dm[i],adx[i]]);
}
 const panel=page.getByTestId('scanner-chart-panel'),button=name=>panel.getByRole('button',{name,exact:true});
 const verify=async(period,signal,label)=>{
  await frames();const observed=await page.evaluate(()=>({state:window.__arxChartQa.snapshot(),data:window.__arxChartQa.data(),config:window.__arxChartQa.configuration()}));
  const logs=await page.evaluate(()=>window.__readFixtureLog());const source=logs.candleResponses.filter(r=>r.symbol==='EURUSD'&&r.timeframe==='M15'&&r.canonical.length===200).at(-1);
  check(source&&JSON.stringify(source.canonical)===JSON.stringify(observed.data.canonical),label+' exact canonical source');
  check(observed.data.display.length===source.canonical.length&&observed.data.display.every((b,i)=>['time','open','high','low','close'].every(k=>b[k]===source.canonical[i][k])),label+' exact displayed source');
  const study=observed.config.studies.find(s=>s.config.kind==='dmi');check(study?.config.period===period&&study?.config.signal===signal&&study.lines.length===3,label+' configured three actual series');
  const expected=oracle(source.canonical,period,signal);
  for(let k=0;k<3;k++){
   const values=expected.map((row,i)=>({time:source.canonical[i].time,value:row[k]})).filter(p=>p.value!==null);
   check(study.lines[k].length===values.length&&study.lines[k].every((p,i)=>p.time===values[i].time&&Math.abs(p.value-values[i].value)<1e-9),label+' complete plotted channel '+k+' independent oracle');
  }
  report.samples.push({label,period,signal,study,source:source.canonical});
 };
 try{
  await page.setViewportSize({width:1440,height:1100});await page.goto('http://127.0.0.1:4199/market-scanner');
  report.build=await page.evaluate(async()=>fetch('/arx-scanner-qa-build-info.json').then(r=>r.json()));
  check(report.build.source.head==='d83a02d773743990704465548af7cea556851d0c'&&report.build.sourceUnchanged&&!report.build.source.status,'Exact clean source');
  await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.barCount===200);
  await button('Studies (0)').click();await panel.getByLabel('Search studies',{exact:true}).fill('ADX');await button('Add Directional movement (DMI / ADX)').click();
  check(await panel.getByLabel('DMI 1 DI period').inputValue()==='14'&&await panel.getByLabel('DMI 1 ADX smoothing').inputValue()==='14','Explicit defaults');
  check(await panel.getByLabel('DMI 1 Source').count()===0,'No misleading price selector');
  await button('Studies (1)').click();await verify(14,14,'default');
  await button('Studies (1)').click();await panel.getByLabel('DMI 1 DI period').fill('7');await panel.getByLabel('DMI 1 DI period').blur();await panel.getByLabel('DMI 1 ADX smoothing').fill('21');await panel.getByLabel('DMI 1 ADX smoothing').blur();
  await button('Duplicate study 1').click();await panel.getByLabel('DMI 2 ADX smoothing').fill('3');await panel.getByLabel('DMI 2 ADX smoothing').blur();
  check(await page.evaluate(()=>window.__arxChartQa.configuration().studies.filter(s=>s.config.kind==='dmi').map(s=>s.config.signal).join(',')==='21,3'),'Duplicate independent lengths');
  await button('Remove study 2').click();await button('Studies (1)').click();await verify(7,21,'edited');
  await panel.getByTestId('arx-native-canvas').scrollIntoViewIfNeeded();await page.screenshot({path:'/Users/areyouok/arx-tier1-release/chart-dmi-study-20261031/dmi-desktop.png'});
  await page.reload();await page.waitForFunction(()=>window.__arxChartQa?.configuration()?.studies?.some(s=>s.config.kind==='dmi'));await verify(7,21,'reload');
  await page.setViewportSize({width:390,height:844});await frames();await verify(7,21,'phone-width');
  check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'No horizontal overflow');await panel.getByTestId('arx-native-canvas').scrollIntoViewIfNeeded();await page.screenshot({path:'/Users/areyouok/arx-tier1-release/chart-dmi-study-20261031/dmi-mobile.png'});
  report.network=await page.evaluate(()=>window.__readFixtureLog());check(report.network.errors.length===0,'No page exceptions');report.passed=true;
 }catch(e){report.failure=String(e?.stack??e);}
 return report;
}