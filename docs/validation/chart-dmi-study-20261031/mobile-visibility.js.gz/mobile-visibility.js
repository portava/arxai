async page=>{
 const canvas=page.getByTestId('scanner-chart-panel').getByTestId('arx-native-canvas');
 await canvas.evaluate(el=>el.scrollIntoView({block:'center',behavior:'instant'}));
 await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 const result=await canvas.evaluate(el=>{const b=el.getBoundingClientRect(),x=b.left+Math.min(100,b.width/2),y=b.bottom-30,at=document.elementFromPoint(x,y);return {bounds:{top:b.top,bottom:b.bottom,left:b.left,right:b.right,height:b.height},viewport:{width:innerWidth,height:innerHeight},studyBottomUnobscured:!!at&&el.contains(at),fits:b.top>=56&&b.bottom<=innerHeight-56};});
 await page.screenshot({path:'/Users/areyouok/arx-tier1-release/chart-dmi-study-20261031/dmi-mobile-centered.png'});return result;
}
