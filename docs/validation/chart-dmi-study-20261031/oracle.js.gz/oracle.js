function oracle(bars,period,signal){
 const rma=(values,length)=>{
  let total=0,count=0,previous=null;
  return values.map(value=>{if(value===null){total=0;count=0;previous=null;return null;}count++;if(count<=length)total+=value;
   if(count<length)return null;
   previous=count===length?total/length:(previous*(length-1)+value)/length;return previous;});
 };
 const plus=[null],minus=[null],tr=[null];
 for(let i=1;i<bars.length;i++){
  const b=bars[i],a=bars[i-1],up=b.high-a.high,down=a.low-b.low;
  plus.push(up>0&&up>down?up:0);minus.push(down>0&&down>up?down:0);
  tr.push(Math.max(b.high-b.low,Math.abs(b.high-a.close),Math.abs(b.low-a.close)));
 }
 const p=rma(plus,period),m=rma(minus,period),t=rma(tr,period);
 const di=p.map((v,i)=>v===null?null:t[i]===0?0:100*v/t[i]);
 const dm=m.map((v,i)=>v===null?null:t[i]===0?0:100*v/t[i]);
 const dx=di.map((v,i)=>v===null?null:(v+dm[i]) === 0?0:100*Math.abs(v-dm[i])/(v+dm[i]));
 const adx=rma(dx,signal);return bars.map((_,i)=>[di[i],dm[i],adx[i]]);
}