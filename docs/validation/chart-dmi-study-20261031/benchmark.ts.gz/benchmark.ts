import { performance } from 'node:perf_hooks';
import { StudyCalculator } from '/Users/areyouok/arx-chart-dmi-study-20261031/artifacts/trading-dashboard/src/lib/chart-engine/chartStudies.ts';
const result={source:'d83a02d773743990704465548af7cea556851d0c',node:process.version,scope:'calculator only; no browser/paint/network/competitor claim',samples:[] as any[]};
for(const count of [5000,50000])for(const period of [14,1000]){
 const bars=Array.from({length:count},(_,i)=>{const close=100+Math.sin(i/7)*4;return {time:100+i*60,open:close,high:close+.4,low:close-.4,close};});
 for(let sample=0;sample<7;sample++){
  const c=new StudyCalculator({kind:'dmi',period,signal:period,color:'#38bdf8'});
  let start=performance.now();c.calculate(bars,0,false);const full=performance.now()-start;
  start=performance.now();for(let i=0;i<100;i++){bars[count-1]={...bars[count-1]!,high:101+i*.001,low:99,open:100,close:100};c.calculate(bars,count-1,false);}const revisions=performance.now()-start;
  if(c.points.length!==count||c.points.at(-1)!.values.some(v=>v===null||!Number.isFinite(v)))throw Error('Invalid DMI output');
  result.samples.push({count,period,sample,warmup:sample<2,fullMs:full,revisions100Ms:revisions});
 }
}
console.log(JSON.stringify(result,null,2));
