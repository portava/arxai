import assert from 'node:assert/strict';
import {runCausalResearchV2 as baseline} from '/Users/areyouok/arx-chart-compact-evidence-integration-20261101/lib/domain/src/backtest/research.ts';
import {runCausalResearchV2 as candidate} from '/Users/areyouok/arx-chart-support-resistance-20261101/lib/domain/src/backtest/research.ts';
let count=0;const hashes=[];
for(const priceBasis of ['MID','BID'] as const)for(const direction of ['long_only','short_only','both'] as const)for(const fee of [0,.03]){
 const input={symbol:'TEST',priceBasis,intervalMs:60000,asOfMs:300*60000,source:{kind:'generated' as const,reference:'legacy-no-cash-comparison'},bars:Array.from({length:300},(_,i)=>{const c=100+Math.sin(i/4)*3;return{openTimeMs:i*60000,open:c-.1,high:c+.3,low:c-.3,close:c};})};
 const config={strategy:{version:'ema-cross-atr-v1' as const,fastPeriod:3,slowPeriod:7,atrPeriod:2,stopAtrMultiple:2,targetR:2,maxHoldingBars:4,direction},costs:{fullSpreadPriceUnits:.2,adverseSlippagePerFillPriceUnits:.05,feePerFillPriceUnits:fee},maxEntryGapMs:0,splits:{trainEndExclusive:180,validationEndExclusive:240}};
 const a=baseline(input,config),b=candidate(input,config);assert.deepEqual(b,a);hashes.push(b.fingerprints.result);count++;
}
console.log(JSON.stringify({pass:count,fail:0,baseline:'474a3416',scope:'complete result and fingerprints without cash setting',hashes}));
