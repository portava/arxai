async page=>{
const report={passed:false,checks:[],samples:[],failure:null};
const check=(ok,label)=>{report.checks.push({label,pass:!!ok});if(!ok)throw Error(label);};
const frames=()=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  function installNoteObserver() {
    if(window.__arxNotesQa)throw Error('Use a fresh note observer/session');
    const clicks=[],textDraws=new Map();
    const canvasPrototype=CanvasRenderingContext2D.prototype,originalFillText=canvasPrototype.fillText;
    function observedFillText(...args) {
      const result=originalFillText.apply(this,args);
      if(this.canvas?.closest?.('[data-testid="scanner-chart-panel"] [data-testid="arx-native-canvas"]')) {
        const text=String(args[0]);
        if(!textDraws.has(text)&&textDraws.size>=4096)textDraws.delete(textDraws.keys().next().value);
        textDraws.set(text,(textDraws.get(text)??0)+1);
      }
      return result;
    }
    canvasPrototype.fillText=observedFillText;
    function engine() {
      const container=document.querySelector('[data-testid="scanner-chart-panel"] [data-testid="arx-native-canvas"]');
      if(!container)throw Error('Scanner native canvas absent');
      const key=Object.keys(container).find(key=>key.startsWith('__reactFiber$'));
      let fiber=container[key],steps=0;
      while(fiber&&!fiber.memoizedProps?.externalFeed&&steps++<100)fiber=fiber.return;
      let hook=fiber?.memoizedState,adapter;steps=0;
      while(hook&&steps++<100){if(hook.memoizedState?.current?.getScannerOverlaySurface){adapter=hook.memoizedState.current;break;}hook=hook.next;}
      if(!adapter||adapter.container!==container)throw Error('Active Scanner adapter binding unavailable');
      const surface=adapter.getScannerOverlaySurface();
      if(!surface||surface.chart!==adapter.chart||surface.series!==adapter.series||surface.container!==container)throw Error('Scanner surface binding differs');
      return {adapter,container};
    }
    const down=event=>{
      if(!(event.target instanceof HTMLCanvasElement))return;
      const {adapter,container}=engine();
      if(!container.contains(event.target))return;
      const bounds=container.getBoundingClientRect(),x=event.clientX-bounds.left,y=event.clientY-bounds.top;
      clicks.push({trusted:event.isTrusted,pointerType:event.pointerType,button:event.button,x,y,time:adapter.chart.timeScale().coordinateToTime(x),price:adapter.series.coordinateToPrice(y)});
    };
    document.addEventListener('pointerdown',down,true);
    const api={
      read(){
        const {adapter}=engine(),primitive=adapter.analysis?.drawingPrimitive;
        if(primitive&&(primitive.attachment?.chart!==adapter.chart||primitive.attachment?.series!==adapter.series))throw Error('Drawing primitive detached from active price series');
        return {drawings:primitive?.drawings??[],notes:primitive?.notes??[],dirty:primitive?.dirty??false,
          projected:(primitive?.drawings??[]).filter(d=>d.kind==='text').map(d=>({id:d.id,x:adapter.chart.timeScale().timeToCoordinate(d.start.time),y:adapter.series.priceToCoordinate(d.start.price)})),
          pane:{width:adapter.chart.timeScale().width(),height:adapter.series.getPane().getHeight()},clicks:[...clicks],textDraws:Object.fromEntries(textDraws)};
      },
      target(){
        const {adapter}=engine(),range=adapter.chart.timeScale().getVisibleLogicalRange();
        if(!range||!adapter.candles.length)throw Error('No current chart range');
        const candle=adapter.candles[Math.max(0,Math.min(adapter.candles.length-1,Math.round((range.from+range.to)/2)))];
        return {x:adapter.chart.timeScale().timeToCoordinate(candle.time),y:adapter.series.priceToCoordinate(candle.close),time:candle.time,price:candle.close};
      },
      resetTextDraws(){textDraws.clear();},
      stop(){
        document.removeEventListener('pointerdown',down,true);if(window.__arxNotesQa===api)delete window.__arxNotesQa;
        if(canvasPrototype.fillText!==observedFillText)throw Error('Canvas text observer ownership changed before restoration');
        canvasPrototype.fillText=originalFillText;
      },
    };
    window.__arxNotesQa=api;
  }

try{
 report.build=await page.evaluate(async()=>fetch('/arx-scanner-qa-build-info.json').then(r=>r.json()));
 check(report.build.source.head==='1b6cbb5e87338f1b1cb559478ac4733ee6caa508'&&report.build.sourceUnchanged&&!report.build.source.status,'Clean exact application commit');
 for(const width of [1440,390]){
  await page.setViewportSize({width,height:width===390?844:1100});
  await page.goto('http://127.0.0.1:4199/market-scanner');
  await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.barCount===200);
  await page.evaluate(installNoteObserver);
  const chart=page.getByTestId('scanner-chart-panel'),canvas=chart.getByTestId('arx-native-canvas');
  const tools=chart.getByRole('button',{name:'Chart tools',exact:true});if(await tools.isVisible())await tools.click();
  const before=await page.evaluate(()=>({state:window.__arxChartQa.snapshot(),data:window.__arxChartQa.data()}));
  await chart.getByLabel('Drawing tool',{exact:true}).selectOption('horizontal');
  await canvas.scrollIntoViewIfNeeded();await frames();
  const point=await page.evaluate(()=>window.__arxNotesQa.target()),box=await canvas.boundingBox();
  await page.mouse.click(box.x+point.x,box.y+point.y);await frames();
  const stored=()=>page.evaluate(()=>JSON.parse(localStorage.getItem('arx.chart.drawings.v1:EURUSD:M15')||'[]'));
  const original=await stored();check(original.length===1,width+' drawing created');
  check(await canvas.evaluate(el=>el===document.activeElement),width+' click focuses chart');
  await page.keyboard.press('Backspace');await frames();
  check((await stored()).length===0&&(await page.evaluate(()=>window.__arxNotesQa.read())).drawings.length===0,width+' Backspace removes actual drawing');
  await page.keyboard.press('Control+z');await frames();
  check(JSON.stringify(await stored())===JSON.stringify(original)&&(await page.evaluate(()=>window.__arxNotesQa.read())).drawings.length===1,width+' Ctrl Z restores persisted and rendered drawing');
  await page.keyboard.press('Control+Shift+z');await frames();check((await stored()).length===0,width+' Ctrl Shift Z redoes deletion');
  await page.keyboard.press('Meta+z');await frames();check((await stored()).length===1,width+' Cmd Z undo');
  await page.keyboard.press('Control+y');await frames();check((await stored()).length===0,width+' Ctrl Y redo');
  await page.keyboard.press('Meta+z');await frames();
  await chart.getByRole('button',{name:'Objects (1)',exact:true}).click();
  await chart.getByLabel('Select drawing 1',{exact:true}).click();
  const search=chart.getByLabel('Find drawing',{exact:true});await search.fill('abc');await page.keyboard.press('Backspace');
  check(await search.inputValue()==='ab'&&(await stored()).length===1,width+' Backspace edits field without deleting chart drawing');
  await search.fill('');await chart.getByLabel('Lock drawing 1',{exact:true}).click();
  await canvas.focus();await page.keyboard.press('Delete');await frames();check((await stored()).length===1,width+' locked drawing preserved');
  await chart.getByLabel('Unlock drawing 1',{exact:true}).click();await canvas.focus();await page.keyboard.press('Delete');await frames();
  check((await stored()).length===0,width+' selected unlocked drawing deleted');
  const after=await page.evaluate(()=>({state:window.__arxChartQa.snapshot(),data:window.__arxChartQa.data()}));
  check(before.state.chartId===after.state.chartId&&before.state.seriesId===after.state.seriesId&&JSON.stringify(before.data)===JSON.stringify(after.data),width+' engine and all source/display candles unchanged');
  check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),width+' no document overflow');
  await canvas.scrollIntoViewIfNeeded();await page.screenshot({path:'/Users/areyouok/arx-tier1-release/chart-drawing-shortcuts-20261031/shortcuts-'+width+'.png'});
  await page.evaluate(()=>window.__arxNotesQa.stop());
 }
 report.network=await page.evaluate(()=>window.__readFixtureLog());check(report.network.errors.length===0,'No page exceptions');report.passed=true;
}catch(e){report.failure=String(e?.stack??e);}
return report;
}