async page=>{
const report={passed:false,samples:[],failure:null};
  function installNoteObserver() {
    if(window.__arxNotesQa)throw Error('Use a fresh note observer/session');
    const clicks=[],textDraws=new Map();
    const canvasPrototype=CanvasRenderingContext2D.prototype,originalFillText=canvasPrototype.fillText;
    function observedFillText(...args) {
      const result=originalFillText.apply(this,args);
      if(this.canvas?.closest?.('[data-testid="scanner-chart-panel"] [data-testid="arx-native-canvas"]')) {
        const text=String(args[0]);
        if(!textDraws.has(text)&&textDraws.size>=4096)textDraws.delete(textDraws.keys().next().value);
        textDraws.set(text,(textDraws.get(text)??0)+1);
      }
      return result;
    }
    canvasPrototype.fillText=observedFillText;
    function engine() {
      const container=document.querySelector('[data-testid="scanner-chart-panel"] [data-testid="arx-native-canvas"]');
      if(!container)throw Error('Scanner native canvas absent');
      const key=Object.keys(container).find(key=>key.startsWith('__reactFiber$'));
      let fiber=container[key],steps=0;
      while(fiber&&!fiber.memoizedProps?.externalFeed&&steps++<100)fiber=fiber.return;
      let hook=fiber?.memoizedState,adapter;steps=0;
      while(hook&&steps++<100){if(hook.memoizedState?.current?.getScannerOverlaySurface){adapter=hook.memoizedState.current;break;}hook=hook.next;}
      if(!adapter||adapter.container!==container)throw Error('Active Scanner adapter binding unavailable');
      const surface=adapter.getScannerOverlaySurface();
      if(!surface||surface.chart!==adapter.chart||surface.series!==adapter.series||surface.container!==container)throw Error('Scanner surface binding differs');
      return {adapter,container};
    }
    const down=event=>{
      if(!(event.target instanceof HTMLCanvasElement))return;
      const {adapter,container}=engine();
      if(!container.contains(event.target))return;
      const bounds=container.getBoundingClientRect(),x=event.clientX-bounds.left,y=event.clientY-bounds.top;
      clicks.push({trusted:event.isTrusted,pointerType:event.pointerType,button:event.button,x,y,time:adapter.chart.timeScale().coordinateToTime(x),price:adapter.series.coordinateToPrice(y)});
    };
    document.addEventListener('pointerdown',down,true);
    const api={
      read(){
        const {adapter}=engine(),primitive=adapter.analysis?.drawingPrimitive;
        if(primitive&&(primitive.attachment?.chart!==adapter.chart||primitive.attachment?.series!==adapter.series))throw Error('Drawing primitive detached from active price series');
        return {drawings:primitive?.drawings??[],notes:primitive?.notes??[],dirty:primitive?.dirty??false,
          projected:(primitive?.drawings??[]).filter(d=>d.kind==='text').map(d=>({id:d.id,x:adapter.chart.timeScale().timeToCoordinate(d.start.time),y:adapter.series.priceToCoordinate(d.start.price)})),
          pane:{width:adapter.chart.timeScale().width(),height:adapter.series.getPane().getHeight()},clicks:[...clicks],textDraws:Object.fromEntries(textDraws)};
      },
      target(){
        const {adapter}=engine(),range=adapter.chart.timeScale().getVisibleLogicalRange();
        if(!range||!adapter.candles.length)throw Error('No current chart range');
        const candle=adapter.candles[Math.max(0,Math.min(adapter.candles.length-1,Math.round((range.from+range.to)/2)))];
        return {x:adapter.chart.timeScale().timeToCoordinate(candle.time),y:adapter.series.priceToCoordinate(candle.close),time:candle.time,price:candle.close};
      },
      resetTextDraws(){textDraws.clear();},
      stop(){
        document.removeEventListener('pointerdown',down,true);if(window.__arxNotesQa===api)delete window.__arxNotesQa;
        if(canvasPrototype.fillText!==observedFillText)throw Error('Canvas text observer ownership changed before restoration');
        canvasPrototype.fillText=originalFillText;
      },
    };
    window.__arxNotesQa=api;
  }

const cdp=await page.context().newCDPSession(page);
try{
 report.build=await page.evaluate(async()=>fetch('/arx-scanner-qa-build-info.json').then(r=>r.json()));
 if(report.build.source.head!=='6537d90d898898b97e6aadc2f26e67fde2b2a57b'||!report.build.sourceUnchanged||report.build.source.status)throw Error('Unverified final source');
 for(const rate of [1,4])for(const width of [1440,390]){
  await cdp.send('Emulation.setCPUThrottlingRate',{rate});await page.setViewportSize({width,height:width===390?844:1100});
  await page.evaluate(()=>localStorage.removeItem('arx.chart.drawings.v1:EURUSD:M15'));
  await page.goto('http://127.0.0.1:4199/market-scanner');await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.barCount===200);await page.evaluate(installNoteObserver);
  const chart=page.getByTestId('scanner-chart-panel'),canvas=chart.getByTestId('arx-native-canvas'),tools=chart.getByRole('button',{name:'Chart tools',exact:true});
  if(await tools.isVisible())await tools.click();await chart.getByLabel('Drawing tool',{exact:true}).selectOption('horizontal');await canvas.scrollIntoViewIfNeeded();
  const point=await page.evaluate(()=>window.__arxNotesQa.target()),box=await canvas.boundingBox();await page.mouse.click(box.x+point.x,box.y+point.y);
  await page.keyboard.press('Delete');await page.waitForFunction(()=>window.__arxNotesQa.read().drawings.length===0);
  const before=await page.evaluate(()=>window.__arxChartQa.data());
  for(let i=0;i<10;i++){
   const expected=i%2===0?1:0;
   await page.evaluate(expected=>{
    window.__shortcutReceipt=null;
    document.addEventListener('keydown',function start(event){
     if(!['z','Z'].includes(event.key))return;
     document.removeEventListener('keydown',start,true);
     const started=performance.now();let frames=0;
     function observe(){
      const el=document.querySelector('[data-testid="scanner-chart-panel"] [data-testid="arx-native-canvas"]'),rect=el.getBoundingClientRect();
      const actual=window.__arxNotesQa.read(),stored=JSON.parse(localStorage.getItem('arx.chart.drawings.v1:EURUSD:M15')||'[]');
      const correct=actual.drawings.length===expected&&stored.length===expected;
      frames=correct?frames+1:0;
      if(frames>=2||performance.now()-started>2000){window.__shortcutReceipt={ms:performance.now()-started,correct,frames,trusted:event.isTrusted,focused:document.activeElement===el,visible:rect.width>=100&&rect.height>=100&&rect.bottom>100&&rect.top<innerHeight-100,rendered:actual.drawings.length,expected};return;}
      requestAnimationFrame(observe);
     }requestAnimationFrame(observe);
    },true);
   },expected);
   await page.keyboard.press(i%2===0?'Control+z':'Control+Shift+z');await page.waitForFunction(()=>window.__shortcutReceipt!==null);
   const receipt=await page.evaluate(()=>window.__shortcutReceipt);report.samples.push({rate,width,action:i%2===0?'undo':'redo',...receipt});
   if(!receipt.correct||receipt.frames<2||!receipt.trusted||!receipt.focused||!receipt.visible)throw Error('Invalid shortcut receipt');
  }
  const after=await page.evaluate(()=>window.__arxChartQa.data());if(JSON.stringify(before)!==JSON.stringify(after))throw Error('Source/display data changed');
  await page.evaluate(()=>window.__arxNotesQa.stop());
 }
 report.passed=true;
}catch(e){report.failure=String(e?.stack??e);}
finally{await cdp.send('Emulation.setCPUThrottlingRate',{rate:1});await cdp.detach();}
return report;
}