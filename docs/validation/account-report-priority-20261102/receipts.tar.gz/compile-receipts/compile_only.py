#!/usr/bin/env python3
"""Reviewable compile-only runner. Default: verify and print plan; --run starts MetaEditor.
Never invokes terminal64.exe, installs an EA, or writes sources into the MT5 installation.
Existing Wine/MetaEditor may update its runtime prefix; report those writes explicitly.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, os, platform, re, shutil, signal, subprocess, sys, time
HERE=Path(__file__).resolve().parent
COMMIT='2982faf56b8dadd1fa017c7b81b8cfa877da256d'
EAS=['ARX_AI_Universal_Agent_v154.mq5']
class Stopped(RuntimeError):pass
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write_json(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def files(root):
 result={}
 for directory,dirs,names in os.walk(root,followlinks=False,onerror=lambda e:(_ for _ in ()).throw(e)):
  for name in names:
   p=Path(directory)/name
   if p.is_symlink():raise Stopped('Unexpected package symlink: '+str(p))
   result[str(p.relative_to(root))]=sha(p)
 return result

def verify(manifest):
 if manifest['commit']!=COMMIT or (HERE/'COMMIT.txt').read_text().strip()!=COMMIT:raise Stopped('Wrong source commit')
 if files(HERE/'src')!=manifest['sources']:raise Stopped('Source manifest mismatch')
 if files(HERE/'mql5')!=manifest['standardLibrary']:raise Stopped('Copied standard library manifest mismatch')
 for name,key in [('metaEditor','metaEditorSha256'),('wine','wineSha256')]:
  p=Path(manifest[name])
  if not p.is_file() or sha(p)!=manifest[key]:raise Stopped('Installed compiler/runtime changed: '+name)
 if not os.access(manifest['wine'],os.X_OK):raise Stopped('Bundled Wine is not executable')
 if not (Path(manifest['winePrefix'])/'dosdevices/z:').is_symlink() or (Path(manifest['winePrefix'])/'dosdevices/z:').resolve()!=Path('/'):
  raise Stopped('Existing Wine Z: mapping is not the filesystem root; no mapping will be changed')

def inventory(pattern,path):
 # pgrep exit1 is verified absence. Any inventory error/timeout is a hard stop.
 try:r=subprocess.run(['/usr/bin/pgrep','-fl',pattern],capture_output=True,text=True,timeout=5)
 except Exception as error:raise Stopped('Process inventory failed: '+str(error))
 path.write_text('exit='+str(r.returncode)+'\n'+r.stdout+r.stderr)
 if r.returncode not in (0,1):raise Stopped('Process inventory failed; see '+str(path))
 return r.returncode==0

def idle(out,label):
 if inventory('[Tt]erminal(64)?[.]exe|[Mm]eta[Ee]ditor(64)?[.]exe',out/(label+'-processes.txt')):
  raise Stopped('Terminal or MetaEditor is running; this runner will not close it')

def prefix_state(root):
 # Metadata only, never account/credential contents. Fail on unreadable inventory.
 result={}
 for directory,dirs,names in os.walk(root,followlinks=False,onerror=lambda e:(_ for _ in ()).throw(e)):
  for name in names:
   p=Path(directory)/name;s=p.lstat();result[str(p.relative_to(root))]=[s.st_size,s.st_mtime_ns]
 return result

def win(path):
 value='Z:'+str(path.resolve()).replace('/',chr(92))
 if ' ' in value:raise Stopped('Compile paths must be space-free; no Wine path helper will be started')
 return value

def terminate_owned(process):
 # Never use global pkill/wineserver-kill. Only this child session is signaled.
 try:os.killpg(process.pid,signal.SIGTERM)
 except ProcessLookupError:pass
 try:process.wait(timeout=5)
 except subprocess.TimeoutExpired:
  try:os.killpg(process.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  process.wait(timeout=5)

def invoke(args,env,log,timeout,out):
 start=time.monotonic()
 with log.open('wb') as output:
  process=subprocess.Popen(args,env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   while process.poll() is None:
    if time.monotonic()-start>=timeout:raise Stopped('Compiler exceeded '+str(timeout)+' seconds')
    if inventory('[Tt]erminal(64)?[.]exe',out/'terminal-during.txt'):raise Stopped('Terminal appeared during compile; stopping only owned compiler process group')
    time.sleep(.5)
  except BaseException:
   terminate_owned(process)
   raise
 return {'exitCode':process.returncode,'elapsedSeconds':round(time.monotonic()-start,3)}

def decode(data):
 if data.startswith((b'\xff\xfe',b'\xfe\xff')):return data.decode('utf-16'), 'UTF-16 BOM'
 if data[:2].endswith(b'\0'):return data.decode('utf-16-le'),'UTF-16LE'
 return data.decode('utf-8'),'UTF-8'

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--run',action='store_true');parser.add_argument('--timeout',type=int,default=90);args=parser.parse_args()
 if not 10<=args.timeout<=300:raise Stopped('Timeout must be 10..300 seconds per EA')
 manifest=json.loads((HERE/'MANIFEST.json').read_text());verify(manifest)
 plan={'commit':COMMIT,'mode':'MetaEditor under bundled Wine on macOS; not native Windows','eas':EAS,'maxSecondsPerEA':args.timeout,'writes':'new package run directory; Wine/MetaEditor incidental existing-prefix writes inventoried','noTerminalInvocation':True}
 print(json.dumps(plan,indent=2))
 if not args.run:
  print('VERIFY ONLY: no Wine, compiler or terminal process started. Review script, then use --run if approved.')
  return 0
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
 out=HERE/('raw-'+stamp);out.mkdir(exist_ok=False)
 summary={'commit':COMMIT,'environment':plan['mode'],'status':'not green','files':[]};before=None
 prefix=Path(manifest['winePrefix']);env={**os.environ,'WINEPREFIX':str(prefix),'WINEDEBUG':'-all'}
 try:
  idle(out,'before');before=prefix_state(prefix);write_json(out/'prefix-before.json',before)
  version=subprocess.run([sys.executable,str(HERE/'pe_version.py'),manifest['metaEditor']],capture_output=True,text=True,timeout=10)
  (out/'metaeditor-version.txt').write_text(version.stdout+version.stderr)
  if version.returncode:raise Stopped('Could not read installed MetaEditor version without execution')
  write_json(out/'environment.json',{'platform':platform.platform(),'machine':platform.machine(),'python':sys.version,'wine':manifest['wine'],'wineSha256':manifest['wineSha256'],'metaEditor':manifest['metaEditor'],'metaEditorSha256':manifest['metaEditorSha256'],'prefix':str(prefix),'originalStandardLibrary':manifest['originalStandardLibrary'],'locale':{k:os.environ.get(k) for k in ['LANG','LC_ALL','LC_CTYPE']}})
  invoke([manifest['wine'],'--version'],env,out/'wine-version.txt',10,out)
  idle(out,'after-wine-version')
  for ea in EAS:
   idle(out,ea+'-before')
   job=out/Path(ea).stem;job.mkdir();shutil.copytree(HERE/'src',job/'src')
   src=job/'src'/ea;rawlog=src.with_suffix('.compile.raw.log');binary=src.with_suffix('.ex5')
   command=[manifest['wine'],manifest['metaEditor'],'/compile:'+win(src),'/include:'+win(HERE/'mql5'),'/log:'+win(rawlog)]
   write_json(job/'command.json',command)
   record={'source':ea,'sourceSha256':sha(src),'status':'not green'};summary['files'].append(record)
   record.update(invoke(command,env,job/'wine-output.log',args.timeout,out))
   idle(out,ea+'-after')
   for name,digest in manifest['sources'].items():
    if sha(job/'src'/name)!=digest:raise Stopped('Compiler modified original source: '+name)
   if not rawlog.is_file():raise Stopped('No raw compiler log: '+ea)
   text,encoding=decode(rawlog.read_bytes());(job/'compile.utf8.log').write_text(text);record['logEncoding']=encoding
   results=re.findall(r'Result:\s*(\d+)\s+errors?,\s*(\d+)\s+warnings?',text,re.I)
   if len(results)!=1:raise Stopped('Missing/ambiguous compiler result: '+ea)
   errors,warnings=map(int,results[0]);record.update(errors=errors,warnings=warnings)
   if errors or not binary.is_file() or binary.stat().st_size==0:raise Stopped('Compile errors or no newly generated EX5: '+ea)
   record.update(status='compiled; pending log review',ex5Sha256=sha(binary),ex5Bytes=binary.stat().st_size,rawLogSha256=sha(rawlog))
  idle(out,'after');verify(manifest)
  summary['status']='selected EA compiled; pending independent raw-log review'
 except BaseException as error:
  summary['failure']=str(error);print('STOPPED:',error,file=sys.stderr)
 finally:
  if before is not None:
   try:
    after=prefix_state(prefix);changed=[{'path':p,'before':before.get(p),'after':after.get(p)} for p in sorted(set(before)|set(after)) if before.get(p)!=after.get(p)]
    write_json(out/'prefix-writes.json',changed);summary['incidentalPrefixChangedFiles']=len(changed)
   except Exception as error:summary['prefixInventoryFailure']=str(error);summary['status']='not green'
  try:idle(out,'final')
  except Exception as error:summary['finalProcessFailure']=str(error);summary['status']='not green'
  write_json(out/'summary.json',summary);print('Raw results:',out)
 return 0 if summary['status']=='selected EA compiled; pending independent raw-log review' else 1

if __name__=='__main__':
 try:sys.exit(main())
 except Exception as error:print('STOPPED:',error,file=sys.stderr);sys.exit(1)
