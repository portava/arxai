async page => {
 const result={passed:false,checks:[],screenshots:[],limitations:['QA-only native engine override of the actual app; default product engine unchanged.','Synthetic historical data; no live feed, broker, latency or full parity acceptance.']};
 const check=(yes,label)=>{if(!yes)throw Error(label);result.checks.push(label);};
 const frames=()=>page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
 const snap=()=>page.evaluate(()=>window.__arxChartQa.snapshot());
 const panel=page.getByTestId('scanner-chart-panel');
 const match=async(symbol,timeframe,interval)=>{
  await page.waitForFunction(({symbol,interval})=>{const s=window.__arxChartQa.snapshot();return s?.symbol===symbol&&s.intervalSeconds===interval&&s.barCount>0&&!s.state.pendingPaint;},{symbol,interval});
  await frames();
  const log=await page.evaluate(()=>window.__readFixtureLog());
  const expected=log.candleResponses.filter(x=>x.symbol===symbol&&x.timeframe===timeframe).at(-1);
  const actual=await page.evaluate(()=>window.__arxChartQa.data());
  check(!!expected&&JSON.stringify(actual.canonical)===JSON.stringify(expected.canonical),'Actual viewport canonical candles match '+symbol+' '+timeframe);
  check((await snap()).state.status==='ready','Native completed frame is ready '+symbol+' '+timeframe);
 };
 try {
  result.build=await page.evaluate(async()=>{const r=await fetch('/arx-scanner-qa-build-info.json');return r.json();});
  check(result.build.nativeEngine&&result.build.qaOnlyDefaultEngineOverride&&result.build.sourceUnchanged&&!result.build.source.status,'Clean exact-source native QA build');
  check(await page.evaluate(()=>window.__arxChartQa.engine==='arx-native'),'Observer belongs to native adapter');
  check(await page.locator('canvas[data-arx-native-viewport]').count()===1,'One actual ARX Canvas viewport');
  check(await page.locator('.tv-lightweight-charts,#tv-attr-logo,iframe').count()===0,'Scanner native fixture contains no legacy renderer or iframe');
  await panel.getByTestId('arx-native-tf-M15').click();await match('EURUSD','M15',900);
  const initial=await snap();
  const selected=page.getByTestId('selected-market-panel');
  if(!await selected.getByTestId('chip-symbol-GBPUSD').isVisible())await selected.getByTestId('category-chip-forex').click();
  await selected.getByTestId('chip-symbol-GBPUSD').click();await match('GBPUSD','M15',900);
  await panel.getByTestId('arx-native-tf-M5').click();await match('GBPUSD','M5',300);
  check((await snap()).adapterId===initial.adapterId,'Symbol and interval changes preserve the native adapter');
  const tools=panel.getByRole('button',{name:'Chart tools',exact:true});
  if(await tools.isVisible()&&await tools.getAttribute('aria-expanded')!=='true')await tools.click();
  const before=await page.evaluate(()=>window.__arxChartQa.data().canonical);
  await panel.getByLabel('Chart style',{exact:true}).selectOption('heikinAshi');
  await page.waitForFunction(()=>window.__arxChartQa.snapshot().state.style==='heikinAshi'&&!window.__arxChartQa.snapshot().state.pendingPaint);
  check(JSON.stringify(before)===JSON.stringify(await page.evaluate(()=>window.__arxChartQa.data().canonical)),'HA display preserves canonical OHLC');
  await panel.getByLabel('Chart style',{exact:true}).selectOption('candles');await frames();
  await panel.getByRole('button',{name:'Fit history',exact:true}).click();await frames();const fit=await snap();
  await panel.getByRole('button',{name:'Zoom in chart',exact:true}).click();await frames();const zoom=await snap();
  check(zoom.range.to-zoom.range.from<fit.range.to-fit.range.from,'Real shared toolbar zoom changes native range');
  await panel.getByRole('button',{name:'Pan to earlier candles',exact:true}).click();await frames();
  check((await snap()).range.from<zoom.range.from,'Real shared toolbar pans native history');
  const canvas=panel.getByTestId('arx-native-canvas');await canvas.scrollIntoViewIfNeeded();await frames();
  await page.screenshot({path:'native-app-desktop.png',fullPage:false});result.screenshots.push('native-app-desktop.png');
  await page.setViewportSize({width:390,height:844});await frames();await canvas.scrollIntoViewIfNeeded();await frames();
  const mobile=await snap();check(mobile.bounds.width>100&&mobile.state.status==='ready','Native viewport resizes in real mobile Scanner');
  await page.screenshot({path:'native-app-mobile.png',fullPage:false});result.screenshots.push('native-app-mobile.png');
  result.fixture=await page.evaluate(()=>window.__readFixtureLog());
  check(result.fixture.errors.length===0,'No page errors');
  check(!result.fixture.blocked.some(x=>x.kind==='external'||x.kind==='websocket'),'No external feed requests');
  result.final=await snap();result.passed=true;
 }catch(error){result.failure=String(error);result.fixture=await page.evaluate(()=>window.__readFixtureLog());}
 return result;
}
