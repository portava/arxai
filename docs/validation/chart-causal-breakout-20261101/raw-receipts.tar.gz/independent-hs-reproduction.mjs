// Read-only causal reproduction. Run: node independent-hs-reproduction.mjs [worktree]
import { registerHooks } from 'node:module';
import { existsSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const root = process.argv[2] ?? '/Users/areyouok/arx-chart-support-resistance-20261101';
registerHooks({ resolve(specifier, context, next) {
  try { return next(specifier, context); } catch (error) {
    if (specifier.startsWith('.') && context.parentURL) {
      for (const candidate of [specifier.replace(/\.js$/, '.ts'), specifier + '.ts', specifier + '/index.ts']) {
        const url = new URL(candidate, context.parentURL);
        if (existsSync(url)) return next(url.href, context);
      }
    }
    throw error;
  }
}});
const source = root + '/artifacts/trading-dashboard/src/lib/chart-engine/smartChartAnalysis.ts';
const { analyzeSmartChart } = await import(pathToFileURL(source));
const { detectChartPatterns, atr } = await import(pathToFileURL(root + '/lib/domain/src/chart-patterns/index.ts'));
const points = [[0,90],[8,96],[12,105],[16,99],[20,112],[24,99],[28,107],[30,102],[31,98],[32,97]];
const bars = Array.from({ length:33 }, (_, i) => {
  const right = points.findIndex(p => p[0] >= i);
  const a = points[Math.max(0, right-1)], b = points[right];
  const close = right === 0 ? 90 : a[1] + (b[1]-a[1])*(i-a[0])/(b[0]-a[0]);
  return { time:1700000000+i*300, closeTime:1700000000+(i+1)*300,
    isFinal:true,isComplete:true,isForming:false,open:close-.05,high:close+.2,low:close-.2,close };
});
bars.push({ ...bars.at(-1),time:1700000000+33*300,closeTime:1700000000+34*300,open:97,high:110,low:50,close:96 });
const rows = [];
for (const inverse of [false,true]) {
  const all = inverse ? bars.map(b => ({...b,open:220-b.open,high:220-b.low,low:220-b.high,close:220-b.close})) : bars;
  const id = inverse ? 'inverse_head_and_shoulders' : 'head_and_shoulders';
  for (let length=30;length<=34;length++) {
    const prefix = all.slice(0,length);
    const raw = detectChartPatterns(prefix).patterns.find(p=>p.id===id);
    const result = analyzeSmartChart({symbol:'EURUSD',timeframe:'M5',source:'mt5_broker',sourceIdentity:'a'.repeat(64),bars:prefix,asOfMs:(prefix.at(-1).closeTime+.01)*1000,dataState:'current'});
    const finding = result.allFindings.find(p=>p.id.startsWith(id));
    rows.push({inverse,length,atr:atr(prefix,14),rawStatus:raw?.status??null,status:finding?.status??null,
      confirmationIndex:finding?.confirmedAt==null?null:(finding.confirmedAt-1700000000)/300-1});
  }
}
console.log(JSON.stringify({source,sourceSha256:createHash('sha256').update(readFileSync(source)).digest('hex'),
  expected:'No finding for prefixes 30-33; first confirmation index33 for prefix34. Before fix, prefix34 incorrectly claimed index31.',rows},null,2));
