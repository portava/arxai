async page=>{
 const out={passed:false,checks:[],failure:null};const check=(yes,label)=>{if(!yes)throw Error(label);out.checks.push(label);};
 try{
  out.build=await page.evaluate(async()=>({info:await(await fetch('/arx-scanner-qa-build-info.json')).json(),runtime:window.__arxScannerQaBuildId}));
  check(out.build.info.source.head==='79b2776c2e07147122fbb63c79c06fa1572faec4'&&!out.build.info.source.status&&out.build.info.sourceUnchanged&&out.build.runtime===out.build.info.buildId,'Exact committed candidate executed');
  await page.setViewportSize({width:1440,height:1100});
  await page.evaluate(()=>{history.pushState(null,'','/admin/fund-control-center');dispatchEvent(new PopStateEvent('popstate'));});
  await page.getByTestId('fund-control-center').waitFor();
  await page.waitForFunction(()=>document.querySelectorAll('[data-testid="native-money-balance"]').length===2);
  check((await page.getByTestId('kpi-broker-equity').innerText()).includes('Unavailable'),'No mixed-account equity total');
  check((await page.getByTestId('kpi-open-exposure').innerText()).includes('Unavailable'),'No partial-position account-profit total');
  check((await page.getByTestId('overview-native-accounts').innerText()).includes('KWD 9,007,199,254,740,993.123'),'Overview preserves exact native decimal and currency');
  await page.getByRole('tab',{name:'Broker Mirrors',exact:true}).click();
  const first=page.getByTestId('bridge-card-7');await first.waitFor();
  check(await first.getByTestId('native-money-balance').innerText()==='KWD 9,007,199,254,740,993.123','Bridge card matches exact overview balance');
  check(await first.getByTestId('native-money-profit').innerText()==='KWD -12.345','Native ACCOUNT_PROFIT replaces position subtotal');
  check(await first.getByTestId('native-money-credit').innerText()==='KWD 212.345','Credit is explicit, not inferred from equity minus balance');
  check((await first.innerText()).includes('current state unverified')&&(await first.innerText()).includes('not account-money freshness'),'Telemetry and reported money remain distinct');
  check(!(await page.getByTestId('position-fixture').innerText()).includes('$'),'Position row does not invent dollar currency');
  await page.screenshot({path:'fund-native-desktop.png'});
  const refresh=page.getByRole('button',{name:'Refresh account reports',exact:true});
  await page.evaluate(()=>window.__fundMode('updated'));await refresh.click();
  await page.waitForFunction(()=>document.querySelector('[data-testid="bridge-card-7"] [data-testid="native-money-profit"]')?.textContent==='KWD -22.456');check(true,'New authoritative report replaces displayed P/L');
  await page.evaluate(()=>window.__fundMode('rejected'));await refresh.click();
  await page.waitForFunction(()=>document.querySelector('[data-testid="bridge-card-7"] [data-testid="native-money-balance"]')?.textContent==='—');
  check((await first.innerText()).includes('latest account report was rejected'),'Rejected latest report withholds old money despite fresh heartbeat');
  await page.evaluate(()=>window.__fundMode('failed'));await refresh.click();await page.getByTestId('mirrors-error').waitFor();
  check(await page.getByTestId('native-money-balance').count()===0,'Failed read hides cached monetary rows');
  await page.evaluate(()=>window.__fundMode('native'));await page.getByTestId('mirrors-error').getByRole('button').click();await first.waitFor();
  check(await first.getByTestId('native-money-profit').innerText()==='KWD -12.345','Explicit refresh recovers from failure');
  await page.getByRole('checkbox',{name:'Refresh account reports automatically'}).uncheck();
  const before=await page.evaluate(()=>window.__readFixtureLog().requests.filter(r=>r.path==='/api/admin/fundbook/broker-mirror').length);
  await page.evaluate(()=>window.__fundMode('updated'));await page.waitForTimeout(5500);
  const after=await page.evaluate(()=>window.__readFixtureLog().requests.filter(r=>r.path==='/api/admin/fundbook/broker-mirror').length);
  check(before===after&&await first.getByTestId('native-money-profit').innerText()==='KWD -12.345','Pause stops periodic reads; prior report remains explicitly unverified');
  await refresh.click();await page.waitForFunction(()=>document.querySelector('[data-testid="bridge-card-7"] [data-testid="native-money-profit"]')?.textContent==='KWD -22.456');check(true,'Manual refresh remains available while paused');
  await page.setViewportSize({width:390,height:844});await first.scrollIntoViewIfNeeded();await page.screenshot({path:'fund-native-mobile.png'});
  check(await first.getByTestId('native-money-balance').innerText()==='KWD 9,007,199,254,740,993.123','Mobile preserves the exact monetary string');
  out.fixture=await page.evaluate(()=>window.__readFixtureLog());check(out.fixture.errors.length===0,'No page exception');
  check(!out.fixture.blocked.some(x=>x.kind==='external'||x.kind==='websocket'),'No external feed or broker');out.passed=true;
 }catch(e){out.failure=String(e?.stack??e);await page.screenshot({path:'fund-native-failure.png'});}
 return out;
}
