from pathlib import Path
import subprocess,json
p=Path(__file__).parent;cli='/Users/areyouok/.local/bin/playwright-cli'
for name,args in [('open',['open','http://127.0.0.1:4199']),('setup',['run-code','--filename=/Users/areyouok/arx-position-money-refresh-20261102/scripts/scanner-qa/shared-chart-setup.js']),('profile',['run-code','--filename='+str(p/'profile-baseline-full.js')]),('close',['close'])]:
 with (p/('full-'+name+'.log')).open('w') as f:code=subprocess.call([cli,'-s=scanner-mount-profile',*args],cwd=p,stdout=f,stderr=subprocess.STDOUT)
 s=(p/('full-'+name+'.log')).read_text();i=s.find('### Result\n')
 if name=='profile' and i>=0:
  x=json.JSONDecoder().raw_decode(s[i+11:].lstrip())[0];(p/'profile-baseline-full.json').write_text(json.dumps(x));print('trace',len(x.get('trace',[])),'samples',len(x.get('profile',{}).get('samples',[])),'failure',x.get('report',{}).get('failure'),'report',x.get('report',{}).get('summary'),flush=True)
 if code or '### Error' in s:print(name,'error',code,flush=True);break
