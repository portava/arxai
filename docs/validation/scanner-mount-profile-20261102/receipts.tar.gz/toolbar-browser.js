async page => {
 const out={passed:false,checks:[],failure:null};const check=(x,s)=>{if(!x)throw Error(s);out.checks.push(s);};
 const ready=()=>page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.renderVerified===true&&!window.__arxChartQa.snapshot().state.pendingPaint);
 try {
  out.build=await page.evaluate(async()=>({info:await(await fetch('/arx-scanner-qa-build-info.json')).json(),runtime:window.__arxScannerQaBuildId}));
  check(out.build.info.source.head==='53b81168bedec2dd3f5d9fcb8388861ca0aa751b'&&!out.build.info.source.status&&out.build.info.sourceUnchanged&&!out.build.info.qaOnlyDefaultEngineOverride&&out.build.runtime===out.build.info.buildId,'Exact candidate native production source');
  await page.setViewportSize({width:1440,height:1100});await ready();
  const root=page.getByTestId('chart-workbench-tools').first(),tools=root.getByRole('button',{name:'Chart tools',exact:true}),advanced=root.getByTestId('chart-advanced-tools');
  await root.scrollIntoViewIfNeeded();check(await tools.isHidden(),'Wide pane exposes advanced controls without compact toggle');
  const original=await page.evaluate(()=>window.__arxChartQa.data().canonical);const id=await page.evaluate(()=>window.__arxChartQa.snapshot().adapterId);
  await root.getByLabel('Price scale',{exact:true}).focus();
  await page.setViewportSize({width:780,height:1000});await tools.waitFor();
  await page.waitForFunction(()=>document.activeElement?.getAttribute('aria-label')==='Chart tools');
  check(await advanced.isHidden(),'Narrow pane collapses controls and moves focus before hiding');
  await tools.click();await root.getByLabel('Price scale',{exact:true}).waitFor();
  check(await tools.getAttribute('aria-expanded')==='true','Compact tools open normally');
  await root.getByLabel('Price scale',{exact:true}).selectOption('percent');await ready();
  check(await root.getByLabel('Price scale',{exact:true}).inputValue()==='percent','Settings remain usable after observer delivery');
  await tools.click();await tools.focus();await page.setViewportSize({width:1440,height:1100});
  await page.waitForFunction(()=>document.activeElement?.textContent?.trim()==='Pan');
  check(await tools.isHidden()&&await advanced.isVisible(),'Growing pane restores controls and visible keyboard focus');
  await page.setViewportSize({width:390,height:844});await tools.waitFor();await tools.click();
  await root.getByLabel('Chart style',{exact:true}).waitFor();check(await root.getByLabel('Chart style',{exact:true}).inputValue()==='candles','Mobile initial/resize controls retain chart style');
  await tools.click();await ready();
  check(await page.evaluate(()=>window.__arxChartQa.snapshot().adapterId)===id,'Resize does not recreate the renderer');
  check(JSON.stringify(await page.evaluate(()=>window.__arxChartQa.data().canonical))===JSON.stringify(original),'Resize and scale selection preserve canonical source OHLC');
  out.fixture=await page.evaluate(()=>window.__readFixtureLog());check(out.fixture.errors.length===0,'No page exception');
  check(!out.fixture.blocked.some(x=>x.kind==='external'||x.kind==='websocket'),'No external network or broker');
  await page.screenshot({path:'toolbar-mobile.png'});out.passed=true;
 }catch(e){out.failure=String(e?.stack??e);await page.screenshot({path:'toolbar-failure.png'});}
 return out;
}
