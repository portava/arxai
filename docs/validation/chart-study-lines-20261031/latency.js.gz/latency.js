async page=>{
 const report={passed:false,samples:[],failure:null,measurement:'Trusted checkbox click to changed actual series visibility plus two animation frames; not physical paint, cold navigation, broker or competitor timing'};
 const panel=page.getByTestId('scanner-chart-panel');const frames=()=>page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
 const cdp=await page.context().newCDPSession(page);
 try{
  report.build=await page.evaluate(async()=>fetch('/arx-scanner-qa-build-info.json').then(r=>r.json()));
  for(const rate of [1,4])for(const viewport of [{width:1440,height:1100},{width:390,height:844}]){
   await cdp.send('Emulation.setCPUThrottlingRate',{rate});await page.setViewportSize(viewport);
   const tools=panel.getByRole('button',{name:'Chart tools',exact:true});if(await tools.isVisible()&&await tools.getAttribute('aria-expanded')==='false')await tools.click();
   const studies=panel.getByRole('button',{name:'Studies (1)',exact:true});await studies.click();
   const details=panel.getByTestId('chart-study-instance').first().locator('details');if(!await details.evaluate(el=>el.open))await details.locator('summary').click();
   const control=panel.getByLabel('DMI 1 +DI visible',{exact:true});await control.scrollIntoViewIfNeeded();await frames();
   const initial=await page.evaluate(()=>({study:window.__arxChartQa.configuration().studies[0],data:window.__arxChartQa.data()}));
   for(let attempt=0;attempt<10;attempt++){
    const wanted=!await control.isChecked();
    await control.evaluate((el,wanted)=>{
     window.__styleLatency=null;
     el.addEventListener('click',e=>{
      const start=e.timeStamp,trusted=e.isTrusted,deadline=performance.now()+2000;
      const wait=()=>{
       const s=window.__arxChartQa.configuration().studies[0];
       if(s.options[0].visible===wanted){requestAnimationFrame(()=>requestAnimationFrame(()=>{window.__styleLatency={trusted,ms:performance.now()-start,visible:s.options[0].visible,calculatorId:s.calculatorId,lineIds:s.lineIds};}));return;}
       if(performance.now()>deadline){window.__styleLatency={failure:'Actual series option timeout',trusted};return;}requestAnimationFrame(wait);
      };requestAnimationFrame(wait);
     },{once:true});
    },wanted);
    await control.click();await page.waitForFunction(()=>window.__styleLatency!==null,null,{timeout:3000});
    const sample=await page.evaluate(()=>window.__styleLatency);report.samples.push({rate,viewport,attempt,...sample});
    if(sample.failure||!sample.trusted||sample.visible!==wanted||sample.calculatorId!==initial.study.calculatorId||JSON.stringify(sample.lineIds)!==JSON.stringify(initial.study.lineIds))throw Error('Invalid appearance sample');
   }
   const after=await page.evaluate(()=>({study:window.__arxChartQa.configuration().studies[0],data:window.__arxChartQa.data()}));
   if(JSON.stringify(initial.study.lines)!==JSON.stringify(after.study.lines)||JSON.stringify(initial.data)!==JSON.stringify(after.data))throw Error('Source/value change during appearance timing');
   await studies.click();
  }
  report.passed=true;
 }catch(e){report.failure=String(e?.stack??e);}finally{await cdp.send('Emulation.setCPUThrottlingRate',{rate:1});await cdp.detach();}
 return report;
}