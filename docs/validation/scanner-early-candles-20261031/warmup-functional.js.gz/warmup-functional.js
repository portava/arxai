async page=>{
 const report={passed:false,checks:[],failure:null};const check=(v,label)=>{report.checks.push({label,pass:!!v});if(!v)throw Error(label);};
 try{
  await page.setViewportSize({width:1440,height:1100});const start=Date.now();await page.goto('http://127.0.0.1:4199/');
  await page.waitForFunction(async since=>{const log=await window.__readFixtureLog();return log.requests.some(r=>r.path==='/api/chart/candles'&&r.started>=since&&r.ended);},start);
  await page.getByRole('link',{name:'Market Scanner',exact:true}).waitFor();
  const first=await page.evaluate(()=>({streams:window.__offlineStreams?.map(s=>s.url)}));
  report.before=await page.evaluate(()=>window.__readFixtureLog());
  const reads=report.before.requests.filter(r=>r.path==='/api/chart/candles'&&r.started>=start);
  check(reads.length===1,'One automatic selected candle read on dashboard');
  check(reads[0].method==='GET'&&reads[0].query==='?symbol=EURUSD&timeframe=M15&limit=200','Bounded selected context, read-only');
  check(!(first.streams??[]).some(url=>String(url).includes('/chart/tick-stream')),'No chart tick stream before Scanner navigation');
  check(await page.locator('[data-testid="arx-native-canvas"]').count()===0,'No hidden chart engine mounted on dashboard');
  await page.getByRole('link',{name:'Market Scanner',exact:true}).click();
  await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.barCount===200);
  const observed=await page.evaluate(()=>({state:window.__arxChartQa.snapshot(),data:window.__arxChartQa.data()}));
  report.after=await page.evaluate(()=>window.__readFixtureLog());
  const afterReads=report.after.requests.filter(r=>r.path==='/api/chart/candles'&&r.started>=start);
  check(afterReads.length===1,'Mounted Scanner shares the automatic request');
  const authority=report.after.candleResponses.filter(r=>r.symbol==='EURUSD'&&r.timeframe==='M15').at(-1);const bar=p=>({time:p.time,open:p.open,high:p.high,low:p.low,close:p.close});
  check(authority&&JSON.stringify(observed.data.canonical)===JSON.stringify(authority.canonical)&&JSON.stringify(observed.data.display.map(bar))===JSON.stringify(authority.canonical),'All displayed and canonical candles match the warmed authority');
  check(observed.state.feed.source==='offline_fixture'&&observed.state.feed.livePriceAffordance===false,'Warm cache never upgrades unavailable feed to live');
  check(report.after.errors.length===0,'No page exceptions');report.observed=observed;report.passed=true;
 }catch(e){report.failure=String(e?.stack??e);}return report;
}