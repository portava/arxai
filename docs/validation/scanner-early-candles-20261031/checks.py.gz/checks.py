import json,subprocess,time
from pathlib import Path
repo=Path('/Users/areyouok/arx-scanner-early-candles-20261031')
raw=Path('/Users/areyouok/arx-tier1-release/scanner-early-candles-20261031')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
checks=[('domain',repo,['pnpm','exec','tsc','-b','lib/domain']),('frontend',repo/'artifacts/trading-dashboard',['pnpm','exec','vitest','run']),('typecheck',repo/'artifacts/trading-dashboard',['pnpm','exec','tsc','--noEmit']),('build',repo/'artifacts/trading-dashboard',['pnpm','exec','vite','build','--configLoader','runner']),('guards',repo/'scripts',['node','--import','tsx','src/ci/run-all.ts']),('bindings',repo/'scripts',['node','--import','tsx','src/ci/check-master-live-bridge-binding.test.ts'])]
results=[]
for name,cwd,args in checks:
 args[0]={'pnpm':'/Users/areyouok/.local/bin/pnpm','node':'/usr/local/bin/node'}[args[0]]
 start=time.monotonic()
 with (raw/(name+'.log')).open('w') as log:r=subprocess.run(['python3','/tmp/arx-offline-run.py',*args],cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(check=name,exit=r.returncode,seconds=round(time.monotonic()-start,2),head=head))
 (raw/'checks.json').write_text(json.dumps(results,indent=2));print(results[-1],flush=True)
