async page => {
 const errors=[]; page.on('pageerror',e=>errors.push(String(e)));
 await page.route('**/*',route=>new URL(route.request().url()).origin==='http://127.0.0.1:4198'?route.continue():route.abort());
 await page.setViewportSize({width:1280,height:1280});
 await page.goto('http://127.0.0.1:4198');
 await page.waitForFunction(()=>window.__arxNativePriceQa?.state);
 const initial=await page.evaluate(()=>window.__arxNativePriceQa.state);
 if(initial.metrics.length!==7) throw Error('seven styles missing');
 const pixels=await page.evaluate(()=>[...document.querySelectorAll('canvas')].map(c=>{const d=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let colored=0;for(let i=0;i<d.length;i+=4)if(d[i+3]>0&&((d[i]>150&&d[i+1]<140)||(d[i+1]>120&&d[i+2]<200)||(d[i+2]>200&&d[i]<150)))colored++;return {style:c.dataset.style,colored};}));
 if(pixels.some(x=>x.colored<100))throw Error('missing price pixels '+JSON.stringify(pixels));
 await page.getByRole('button',{name:'Pan left',exact:true}).click();
 const pan=await page.evaluate(()=>window.__arxNativePriceQa.state.range);
 if(!(pan.from<initial.range.from))throw Error('pan did not move');
 await page.getByRole('button',{name:'Zoom in',exact:true}).click();
 const zoom=await page.evaluate(()=>window.__arxNativePriceQa.state.range);
 if(!(zoom.to-zoom.from<pan.to-pan.from))throw Error('zoom did not narrow');
 for(const scale of ['log','percent','indexed','linear']) {
  await page.getByLabel('Price scale').selectOption(scale);
  if(await page.evaluate(()=>window.__arxNativePriceQa.state.scale)!==scale)throw Error('scale failed '+scale);
 }
 await page.getByRole('button',{name:'Invert axis',exact:true}).click();
 if(!await page.evaluate(()=>window.__arxNativePriceQa.state.inverted))throw Error('inversion failed');
 await page.getByRole('button',{name:'Invert axis',exact:true}).click();
 await page.screenshot({path:'/Users/areyouok/arx-tier1-release/native-price-renderer-20261101/desktop.png',fullPage:true});
 const measurements=[];
 for(let run=0;run<2;run++) measurements.push(await page.evaluate(()=>window.__arxNativePriceQa.benchmark()));
 await page.setViewportSize({width:390,height:844});
 await page.waitForFunction(()=>document.querySelector('canvas').clientWidth<390);
 await page.screenshot({path:'/Users/areyouok/arx-tier1-release/native-price-renderer-20261101/mobile.png',fullPage:true});
 const horizontalOverflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
 if(horizontalOverflow)throw Error('horizontal overflow');
 if(errors.length)throw Error(errors.join('\n'));
 return {checks:['seven rendered styles','visible price pixels','pan','zoom','four scales','inversion','390px containment','no page errors'],pixels,measurements,errors};
}