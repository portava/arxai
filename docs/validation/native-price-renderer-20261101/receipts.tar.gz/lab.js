// artifacts/trading-dashboard/src/lib/chart-engine/candleSanitize.ts
function isValidCandlestickPoint(p) {
  return Number.isFinite(p.time) && p.time > 0 && Number.isFinite(p.open) && Number.isFinite(p.high) && Number.isFinite(p.low) && Number.isFinite(p.close) && p.high >= Math.max(p.open, p.close, p.low) && p.low <= Math.min(p.open, p.close, p.high);
}
function sanitizeCandlestickData(points) {
  const valid2 = points.filter(isValidCandlestickPoint);
  if (valid2.every((p, i) => i === 0 || p.time > valid2[i - 1].time)) return valid2;
  return [...new Map(valid2.map((p) => [p.time, p])).values()].sort((a, b) => a.time - b.time);
}

// artifacts/trading-dashboard/src/lib/chart-engine/heikinAshi.ts
var HOLLOW_UP_COLOR = "#10b981";
var HOLLOW_DOWN_COLOR = "#ef4444";
var HOLLOW_BODY = "transparent";
function heikinAshiBar(candle, previous) {
  const close = (candle.open + candle.high + candle.low + candle.close) / 4;
  const open = previous ? (previous.open + previous.close) / 2 : (candle.open + candle.close) / 2;
  return { time: candle.time, open, high: Math.max(candle.high, open, close), low: Math.min(candle.low, open, close), close };
}
function heikinAshiSuffix(candles, cache, from) {
  const start = Math.max(0, Math.min(Number.isFinite(from) ? Math.floor(from) : 0, cache.length, candles.length));
  cache.length = start;
  for (let i = start; i < candles.length; i++) cache.push(heikinAshiBar(candles[i], i > 0 ? cache[i - 1] : null));
  return cache;
}
function heikinAshi(candles) {
  return heikinAshiSuffix(candles, [], 0);
}
function hollowPoint(candle, previousClose) {
  const up = previousClose == null ? candle.close >= candle.open : candle.close >= previousClose;
  const colour = up ? HOLLOW_UP_COLOR : HOLLOW_DOWN_COLOR;
  return { ...candle, color: candle.close >= candle.open ? HOLLOW_BODY : colour, borderColor: colour, wickColor: colour };
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartStudies.ts
var STUDY_CATALOG = [
  { name: "Simple moving average", group: "Trend", description: "Equal weight over the selected period.", defaults: { kind: "sma", period: 20, color: "#fbbf24" }, channels: ["SMA"], pane: false, appliedPrice: true },
  { name: "Exponential moving average", group: "Trend", description: "Recent prices carry more weight; seeded with an SMA.", defaults: { kind: "ema", period: 50, color: "#38bdf8" }, channels: ["EMA"], pane: false, appliedPrice: true },
  { name: "Bollinger Bands", group: "Volatility", description: "SMA basis with population standard deviation bands.", defaults: { kind: "bollinger", period: 20, multiplier: 2, color: "#a78bfa" }, channels: ["Basis", "Upper", "Lower"], pane: false, appliedPrice: true },
  { name: "Relative strength index", group: "Momentum", description: "Wilder smoothing of gains and losses; flat markets read 50.", defaults: { kind: "rsi", period: 14, color: "#e879f9" }, channels: ["RSI"], pane: true, appliedPrice: true, levels: [30, 70], range: [0, 100] },
  { name: "MACD", group: "Momentum", description: "Fast minus slow EMA. Choose EMA or MT5-style SMA signal smoothing.", defaults: { kind: "macd", period: 12, slow: 26, signal: 9, color: "#2dd4bf" }, channels: ["MACD", "Signal", "Histogram"], pane: true, appliedPrice: true, levels: [0] },
  { name: "Smoothed moving average", group: "Trend", description: "Wilder / RMA smoothing with weight 1 \xF7 period.", defaults: { kind: "smma", period: 20, color: "#fb923c" }, channels: ["SMMA"], pane: false, appliedPrice: true },
  { name: "Weighted moving average", group: "Trend", description: "Linear weights; the newest bar has the largest weight.", defaults: { kind: "wma", period: 20, color: "#4ade80" }, channels: ["WMA"], pane: false, appliedPrice: true },
  { name: "Double exponential moving average", group: "Trend", description: "2 \xD7 EMA minus EMA of EMA; each stage warms up separately.", defaults: { kind: "dema", period: 20, color: "#f472b6" }, channels: ["DEMA"], pane: false, appliedPrice: true },
  { name: "Triple exponential moving average", group: "Trend", description: "3 \xD7 EMA \u2212 3 \xD7 EMA\xB2 + EMA\xB3; three seeded stages.", defaults: { kind: "tema", period: 20, color: "#818cf8" }, channels: ["TEMA"], pane: false, appliedPrice: true },
  { name: "Average true range", group: "Volatility", description: "Range including gaps from the previous close. Select smoothing.", defaults: { kind: "atr", period: 14, method: "smma", color: "#fb923c" }, channels: ["ATR"], pane: true, appliedPrice: false },
  { name: "Commodity channel index", group: "Momentum", description: "Distance from the mean divided by 0.015 \xD7 mean absolute deviation.", defaults: { kind: "cci", period: 20, source: "hlc3", color: "#38bdf8" }, channels: ["CCI"], pane: true, appliedPrice: true, levels: [-100, 0, 100] },
  { name: "Stochastic oscillator", group: "Momentum", description: "SMA-smoothed %K in the high/low range, followed by an SMA %D.", defaults: { kind: "stochastic", period: 14, smoothing: 3, signal: 3, color: "#2dd4bf" }, channels: ["%K", "%D"], pane: true, appliedPrice: false, levels: [20, 80], range: [0, 100] },
  { name: "Williams percent range", group: "Momentum", description: "Close within the lookback high/low range, from \u2212100 to 0.", defaults: { kind: "williams", period: 14, color: "#fbbf24" }, channels: ["%R"], pane: true, appliedPrice: false, levels: [-80, -20], range: [-100, 0] },
  { name: "Standard deviation", group: "Volatility", description: "Population deviation around the selected price's simple mean.", defaults: { kind: "stddev", period: 20, color: "#a78bfa" }, channels: ["Deviation"], pane: true, appliedPrice: true },
  { name: "Moving average envelopes", group: "Trend", description: "Percentage bands above and below a configurable moving average.", defaults: { kind: "envelopes", period: 20, multiplier: 1, method: "sma", color: "#f472b6" }, channels: ["Basis", "Upper", "Lower"], pane: false, appliedPrice: true },
  { name: "Momentum ratio", group: "Momentum", description: "Current price \xF7 price N bars ago \xD7 100 (MT5 convention).", defaults: { kind: "momentum", period: 14, color: "#4ade80" }, channels: ["Momentum"], pane: true, appliedPrice: true, levels: [100] },
  { name: "Rate of change", group: "Momentum", description: "Percentage price change over N bars.", defaults: { kind: "roc", period: 14, color: "#fbbf24" }, channels: ["ROC %"], pane: true, appliedPrice: true, levels: [0] },
  { name: "Donchian Channels", group: "Volatility", description: "Highest high, lowest low and their midpoint over the selected bars, including the forming bar. Requires a full window; channel contact alone is not a breakout signal.", defaults: { kind: "donchian", period: 20, color: "#38bdf8" }, channels: ["Midpoint", "Upper", "Lower"], pane: false, appliedPrice: false },
  { name: "Directional movement (DMI / ADX)", group: "Trend", description: "Wilder-smoothed +DI and \u2212DI show directional movement; ADX measures strength, not direction or confidence. Separate DI and ADX lengths; tied moves count as zero. Not a trade signal.", defaults: { kind: "dmi", period: 14, signal: 14, color: "#38bdf8" }, channels: ["+DI", "\u2212DI", "ADX"], pane: true, appliedPrice: false, range: [0, 100] },
  { name: "Tick volume", group: "Volume", description: "Explicit MT5 per-bar tick counts, not traded size. Only source-qualified observations are plotted; missing or partial streaming evidence stays blank, never zero-filled. No real traded-volume data is inferred.", defaults: { kind: "tick_volume", period: 1, color: "#38bdf8" }, channels: ["Ticks"], pane: true, appliedPrice: false },
  { name: "Anchored VWAP", group: "Volume", description: "Cumulative original bar price \xD7 provider-reported trade units / cumulative trade units, from an exact observed bar. HLC3 by default. Loaded observations only, not a full session or trade-by-trade average. Missing/zero/unqualified volume holds the remaining interval; no tick proxy.", defaults: { kind: "vwap", period: 1, source: "hlc3", color: "#fbbf24" }, channels: ["VWAP"], pane: false, appliedPrice: true },
  { name: "Trade volume", group: "Volume", description: "Qualified provider-reported trade units per original closed bar. These are not tick counts, proven shares or consolidated-market volume. Missing/zero/unqualified quantities stay blank.", defaults: { kind: "trade_volume", period: 1, color: "#34d399" }, channels: ["Trade units"], pane: true, appliedPrice: false },
  { name: "Estimated volume profile", group: "Volume", description: "Fixed-range price bins estimate uniform volume across original candle ranges. Qualified provider trade units only; no tick substitute, observed executions-at-price or complete-session claim.", defaults: { kind: "volume_profile", period: 1, color: "#a78bfa", profileRows: 32, profileValueAreaPercent: 70 }, channels: ["Estimated trade units"], pane: false, appliedPrice: false }
];
var STUDY_DEFAULTS = ["sma", "ema", "bollinger", "rsi", "macd"].map((kind) => STUDY_CATALOG.find((item) => item.defaults.kind === kind).defaults);

// artifacts/trading-dashboard/src/lib/chart-engine/chartWorkspace.ts
var CHART_STYLES = ["candles", "bars", "line", "area", "baseline", "heikinAshi", "hollow"];
function closeOnlyStyle(style) {
  return style === "line" || style === "area" || style === "baseline";
}

// artifacts/trading-dashboard/src/lib/chart-engine/nativePriceRenderer.ts
function prepareNativePriceSeries(input) {
  const candles = sanitizeCandlestickData(input).map(({ time, open, high, low, close }) => Object.freeze({ time, open, high, low, close }));
  return Object.freeze({
    candles: Object.freeze(candles),
    heikinAshi: Object.freeze(heikinAshi(candles).map((bar) => Object.freeze(bar))),
    discarded: input.length - candles.length
  });
}
var finiteOrNull = (value) => Number.isFinite(value) ? value : null;
var bodyWidth = (spacing) => Math.max(1, Math.min(24, spacing * 0.7));
function createNativePriceFrame(series2, options) {
  const { style } = options;
  const scale2 = options.scale ?? "linear";
  const plot = Object.freeze({ ...options.plot });
  const range2 = Object.freeze({ ...options.range });
  if (![plot.left, plot.top, plot.width, plot.height, range2.from, range2.to].every(Number.isFinite) || plot.width <= 0 || plot.height <= 0 || range2.to <= range2.from || !Number.isFinite(range2.to - range2.from) || !Number.isFinite(plot.left + plot.width) || !Number.isFinite(plot.top + plot.height) || !["candles", "bars", "line", "area", "baseline", "heikinAshi", "hollow"].includes(style))
    return { ok: false, reason: "INVALID_VIEW" };
  if (!["linear", "log", "percent", "indexed"].includes(scale2)) return { ok: false, reason: "INVALID_SCALE" };
  const reference = options.referencePrice;
  if ((scale2 === "percent" || scale2 === "indexed") && !(Number.isFinite(reference) && reference > 0))
    return { ok: false, reason: "INVALID_SCALE" };
  const closeOnly = closeOnlyStyle(style);
  const spacing = plot.width / (range2.to - range2.from);
  if (!Number.isFinite(spacing) || spacing <= 0) return { ok: false, reason: "INVALID_VIEW" };
  const halfBar = (bodyWidth(spacing) / 2 + (style === "hollow" ? 0.5 : 0)) / spacing;
  const start = Math.max(0, range2.from), end = Math.min(series2.candles.length - 1, range2.to);
  const first = closeOnly ? Math.floor(start) : Math.max(0, Math.ceil(range2.from - halfBar));
  const last = closeOnly ? Math.ceil(end) : Math.min(series2.candles.length - 1, Math.floor(range2.to + halfBar));
  if (closeOnly && end < start) return { ok: false, reason: "NO_VISIBLE_BARS" };
  if (last < first) return { ok: false, reason: "NO_VISIBLE_BARS" };
  const display = style === "heikinAshi" ? series2.heikinAshi : series2.candles;
  const transform = (price) => scale2 === "log" ? price > 0 ? Math.log(price) : NaN : price;
  let low = Infinity, high = -Infinity;
  for (let i = first; i <= last; i++) {
    const bar = display[i];
    if (!bar || !isValidCandlestickPoint(bar)) return { ok: false, reason: "INVALID_DISPLAY_BAR" };
    const a = transform(closeOnly ? bar.close : bar.low);
    const b = transform(closeOnly ? bar.close : bar.high);
    if (!Number.isFinite(a) || !Number.isFinite(b)) return { ok: false, reason: "INVALID_SCALE" };
    if (!closeOnly || i >= start && i <= end) {
      low = Math.min(low, a);
      high = Math.max(high, b);
    }
  }
  if (closeOnly) {
    for (const index of [start, end]) {
      const before = Math.floor(index), after = Math.ceil(index), weight = index - before;
      const a = transform(display[before].close), b = transform(display[after].close);
      const value = a * (1 - weight) + b * weight;
      if (!Number.isFinite(value)) return { ok: false, reason: "INVALID_SCALE" };
      low = Math.min(low, value);
      high = Math.max(high, value);
    }
  }
  if (style === "baseline" && !Number.isFinite(transform(series2.candles[0].close)))
    return { ok: false, reason: "INVALID_SCALE" };
  const magnitude = Math.max(Math.abs(low), Math.abs(high)) || 1;
  const lowUnit = low / magnitude, highUnit = high / magnitude;
  const padding = highUnit > lowUnit ? (highUnit - lowUnit) * 0.08 : 0.01;
  const bottom = lowUnit - padding, extent = highUnit + padding - bottom;
  const inverted2 = options.inverted === true;
  if (!Number.isFinite(extent) || extent <= 0)
    return { ok: false, reason: "INVALID_VIEW" };
  const priceToY = (price, clipToPlot = false) => {
    if (!Number.isFinite(price)) return null;
    const transformed = transform(price);
    if (!Number.isFinite(transformed)) return null;
    const rawUnit = (transformed / magnitude - bottom) / extent;
    const unit = clipToPlot ? Math.max(0, Math.min(1, rawUnit)) : rawUnit;
    return finiteOrNull(plot.top + plot.height * (inverted2 ? unit : 1 - unit));
  };
  const yToPrice = (y) => {
    if (!Number.isFinite(y)) return null;
    const unit = (y - plot.top) / plot.height;
    const value = (bottom + (inverted2 ? unit : 1 - unit) * extent) * magnitude;
    const price = scale2 === "log" ? Math.exp(value) : value;
    return scale2 === "log" && price <= 0 ? null : finiteOrNull(price);
  };
  const logicalToX = (index) => Number.isFinite(index) ? finiteOrNull(plot.left + (index - range2.from) * spacing) : null;
  const xToLogical = (x) => Number.isFinite(x) ? finiteOrNull(range2.from + (x - plot.left) / spacing) : null;
  const frame = {
    series: series2,
    plot,
    range: range2,
    style,
    scale: scale2,
    inverted: inverted2,
    first,
    last,
    spacing,
    priceToY,
    yToPrice,
    logicalToX,
    xToLogical,
    timeToX(time) {
      if (!Number.isFinite(time)) return null;
      let left = 0, right = series2.candles.length - 1;
      while (left <= right) {
        const mid = left + Math.floor((right - left) / 2), candidate = series2.candles[mid].time;
        if (candidate === time) return logicalToX(mid);
        if (candidate < time) left = mid + 1;
        else right = mid - 1;
      }
      return null;
    },
    barAtX(x) {
      if (x < plot.left || x > plot.left + plot.width) return null;
      const index = xToLogical(x);
      if (index == null) return null;
      return series2.candles[Math.round(index)] ?? null;
    },
    axisValue(price) {
      if (!Number.isFinite(price) || scale2 === "log" && price <= 0) return null;
      return finiteOrNull(scale2 === "percent" ? (price / reference - 1) * 100 : scale2 === "indexed" ? price / reference * 100 : price);
    }
  };
  return { ok: true, frame: Object.freeze(frame) };
}
var UP = "#10b981";
var DOWN = "#ef4444";
var LINE = "#38bdf8";
function paintNativePriceLayer(ctx, frame) {
  const { plot, style, series: series2 } = frame;
  const display = style === "heikinAshi" ? series2.heikinAshi : series2.candles;
  ctx.save();
  try {
    ctx.beginPath();
    ctx.rect(plot.left, plot.top, plot.width, plot.height);
    ctx.clip();
    ctx.lineWidth = 1;
    ctx.lineCap = "butt";
    ctx.lineJoin = "miter";
    ctx.setLineDash([]);
    if (closeOnlyStyle(style)) {
      const points = [];
      for (let i = Math.max(0, frame.first - 1); i <= Math.min(display.length - 1, frame.last + 1); i++) {
        const x = frame.logicalToX(i), y2 = frame.priceToY(display[i].close);
        if (x != null && y2 != null) points.push({ x, y: y2 });
      }
      if (!points.length) return;
      const path = () => {
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) ctx.lineTo(points[i].x, points[i].y);
      };
      const stroke = (color) => {
        path();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        if (points.length === 1) {
          ctx.arc(points[0].x, points[0].y, 1, 0, Math.PI * 2);
          ctx.fillStyle = color;
          ctx.fill();
        } else ctx.stroke();
      };
      const fill = (y2, color) => {
        path();
        ctx.lineTo(points.at(-1).x, y2);
        ctx.lineTo(points[0].x, y2);
        ctx.closePath();
        ctx.fillStyle = color;
        ctx.fill();
      };
      if (style === "area") fill(plot.top + plot.height, "rgba(56,189,248,0.18)");
      if (style !== "baseline") {
        stroke(LINE);
        return;
      }
      const baseline = frame.priceToY(series2.candles[0].close, true);
      if (baseline == null) return;
      const y = Math.max(plot.top, Math.min(plot.top + plot.height, baseline));
      for (const topHalf of [true, false]) {
        ctx.save();
        try {
          ctx.beginPath();
          ctx.rect(plot.left, topHalf ? plot.top : y, plot.width, topHalf ? y - plot.top : plot.top + plot.height - y);
          ctx.clip();
          const up = topHalf !== frame.inverted;
          fill(y, up ? "rgba(16,185,129,0.18)" : "rgba(239,68,68,0.18)");
          stroke(up ? UP : DOWN);
        } finally {
          ctx.restore();
        }
      }
      return;
    }
    const width = bodyWidth(frame.spacing);
    for (let i = frame.first; i <= frame.last; i++) {
      const bar = display[i], x = frame.logicalToX(i);
      const open = frame.priceToY(bar.open), close = frame.priceToY(bar.close), high = frame.priceToY(bar.high), low = frame.priceToY(bar.low);
      if (x == null || open == null || close == null || high == null || low == null) continue;
      const hollow = style === "hollow" ? hollowPoint(bar, i ? series2.candles[i - 1].close : null) : null;
      const color = hollow?.borderColor ?? (bar.close >= bar.open ? UP : DOWN);
      ctx.strokeStyle = color;
      ctx.fillStyle = color;
      ctx.beginPath();
      if (style === "bars") {
        ctx.moveTo(x, high);
        ctx.lineTo(x, low);
        ctx.moveTo(x - width / 2, open);
        ctx.lineTo(x, open);
        ctx.moveTo(x, close);
        ctx.lineTo(x + width / 2, close);
        ctx.stroke();
        continue;
      }
      const top = Math.min(open, close), bottom = Math.max(open, close);
      ctx.moveTo(x, Math.min(high, low));
      ctx.lineTo(x, top);
      ctx.moveTo(x, bottom);
      ctx.lineTo(x, Math.max(high, low));
      ctx.stroke();
      const y = Math.min(open, close), height = Math.max(1, Math.abs(close - open));
      if (hollow?.color !== "transparent") ctx.fillRect(x - width / 2, y, width, height);
      else ctx.strokeRect(x - width / 2, y, width, height);
    }
  } finally {
    ctx.restore();
  }
}

// artifacts/trading-dashboard/src/lib/chart-engine/chartNavigation.ts
function bounded(center, span, count) {
  if (!Number.isSafeInteger(count) || count < 1 || !Number.isFinite(center) || !Number.isFinite(span)) return null;
  const width = Math.max(4, Math.min(count + 5, span));
  const from = Math.max(-3, Math.min(count + 2 - width, center - width / 2));
  return { from, to: from + width };
}
function valid(range2) {
  return !!range2 && Number.isFinite(range2.from) && Number.isFinite(range2.to) && range2.to > range2.from;
}
function panChartWindow(range2, fraction, count) {
  if (!valid(range2) || !Number.isFinite(fraction) || Math.abs(fraction) > 1) return null;
  const span = range2.to - range2.from;
  return bounded((range2.from + range2.to) / 2 + span * fraction, span, count);
}
function zoomChartWindow(range2, factor, count) {
  if (!valid(range2) || !Number.isFinite(factor) || factor <= 0 || factor > 4) return null;
  return bounded((range2.from + range2.to) / 2, (range2.to - range2.from) * factor, count);
}

// scripts/scanner-qa/native-price-layer-entry.ts
var data = Array.from({ length: 2e4 }, (_, i) => {
  const open = 100 + Math.sin(i * 0.27) * 6 + Math.cos(i * 0.063) * 8;
  const close = open + Math.sin(i * 1.71) * 2.4;
  return { time: 17e8 + i * 60, open, high: Math.max(open, close) + 1.4, low: Math.min(open, close) - 0.9, close };
});
var prepareStarted = performance.now();
var series = prepareNativePriceSeries(data);
var initialPreparationMs = performance.now() - prepareStarted;
var range = { from: 19800, to: 19999 };
var scale = "linear";
var inverted = false;
document.body.innerHTML = `<main><h1>ARX native price-layer laboratory</h1><p>Synthetic observations \xB7 staged renderer \xB7 no broker or trading \xB7 not the application chart</p><nav><button id="left">Pan left</button><button id="right">Pan right</button><button id="zoom">Zoom in</button><button id="out">Zoom out</button><button id="invert">Invert axis</button><select id="scale" aria-label="Price scale"><option>linear</option><option>log</option><option>percent</option><option>indexed</option></select></nav><output id="state"></output><section>${CHART_STYLES.map((style) => `<article><h2>${style}</h2><canvas data-style="${style}"></canvas></article>`).join("")}</section></main>`;
var css = document.createElement("style");
css.textContent = `body{margin:0;background:#090f1b;color:#dce7f6;font:14px system-ui}main{padding:20px}h1{font-size:24px;margin:0 0 8px}p,output{color:#a3b3c9}nav{display:flex;gap:8px;flex-wrap:wrap;margin:16px 0}button,select{padding:8px;background:#17243b;color:inherit;border:1px solid #3a506d;border-radius:5px}section{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-top:14px}article{min-width:0;background:#0d1625;border:1px solid #20314b}h2{font-size:15px;padding:0 14px}canvas{width:100%;height:230px;display:block}@media(max-width:600px){section{grid-template-columns:1fr}}`;
document.head.append(css);
var canvases = [...document.querySelectorAll("canvas")];
function draw() {
  const metrics = [];
  for (let i = 0; i < canvases.length; i++) {
    const canvas = canvases[i], width = canvas.clientWidth, height = canvas.clientHeight, dpr = window.devicePixelRatio;
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const result = createNativePriceFrame(series, { plot: { left: 8, top: 8, width: width - 72, height: height - 32 }, range, style: CHART_STYLES[i], scale, referencePrice: data[0].close, inverted });
    if (!result.ok) throw Error(result.reason);
    const frame = result.frame;
    ctx.font = "11px monospace";
    for (let tick = 0; tick <= 4; tick++) {
      const y = frame.plot.top + frame.plot.height * tick / 4;
      ctx.strokeStyle = "#20314b";
      ctx.beginPath();
      ctx.moveTo(8, y);
      ctx.lineTo(width - 64, y);
      ctx.stroke();
      const price = frame.yToPrice(y), value = price == null ? null : frame.axisValue(price);
      ctx.fillStyle = "#a3b3c9";
      ctx.fillText(value == null ? "\u2014" : value.toFixed(2), width - 60, y + 4);
    }
    paintNativePriceLayer(ctx, frame);
    ctx.fillStyle = "#a3b3c9";
    ctx.fillText(`loaded bars ${Math.ceil(range.from)}\u2013${Math.floor(range.to)}`, 8, height - 8);
    metrics.push({ style: CHART_STYLES[i], first: frame.first, last: frame.last, price: frame.barAtX(frame.logicalToX(19900))?.close ?? null });
  }
  document.querySelector("output").textContent = `${scale} \xB7 ${inverted ? "inverted" : "normal"} \xB7 ${range.from.toFixed(2)}\u2013${range.to.toFixed(2)}`;
  window.__arxNativePriceQa.state = { range: { ...range }, scale, inverted, metrics };
}
window.__arxNativePriceQa = {
  state: null,
  // Browser main-thread CPU + Canvas command submission timing only. This
  // excludes data preparation, compositor/presentation and whole-page startup.
  benchmark: async () => {
    const canvas = canvases[0], ctx = canvas.getContext("2d");
    const samples = [];
    for (let i = 0; i < 150; i++) {
      await new Promise(requestAnimationFrame);
      const begin = performance.now();
      const result = createNativePriceFrame(series, { plot: { left: 8, top: 8, width: canvas.clientWidth - 72, height: canvas.clientHeight - 32 }, range: { from: 19800 - i % 10, to: 19999 - i % 10 }, style: "candles" });
      if (!result.ok) throw Error(result.reason);
      ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
      paintNativePriceLayer(ctx, result.frame);
      if (i >= 30) samples.push(performance.now() - begin);
    }
    draw();
    return { warmup: 30, loadedBars: data.length, visibleBars: 200, initialPreparationMs, samples, dpr: devicePixelRatio, userAgent: navigator.userAgent };
  }
};
for (const [id, update] of Object.entries({
  left: () => panChartWindow(range, -0.25, data.length),
  right: () => panChartWindow(range, 0.25, data.length),
  zoom: () => zoomChartWindow(range, 0.75, data.length),
  out: () => zoomChartWindow(range, 1.25, data.length)
})) document.getElementById(id).addEventListener("click", () => {
  const next = update();
  if (next) range = next;
  draw();
});
document.getElementById("invert").addEventListener("click", () => {
  inverted = !inverted;
  draw();
});
document.getElementById("scale").addEventListener("change", (event) => {
  scale = event.target.value;
  draw();
});
window.addEventListener("resize", draw);
draw();
