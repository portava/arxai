import assert from 'node:assert/strict';
import { mock } from 'node:test';
import { readFileSync, writeFileSync, unlinkSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { pathToFileURL } from 'node:url';
import os from 'node:os';

// Run only in the coordinator's explicit quiet window. This times pure builder
// work with local seam doubles; never provider, HTTP, UI or broker latency.
const repo='/Users/areyouok/arx-chart-support-resistance-20261101';
const receipt='/Users/areyouok/arx-tier1-release/chart-assessment-captured-input-20261101';
const relative='artifacts/api-server/src/lib/data/chart/chartIntelligence.ts';
const directory=repo+'/'+relative.slice(0,relative.lastIndexOf('/'));
const baseline='9275a5c9';
const candidate='5648453f8905f88e4e5f9fcb1676c2c29c795a7e';
const sha=(bytes:Buffer|string)=>createHash('sha256').update(bytes).digest('hex');
const git=(...args:string[])=>execFileSync('git',args,{cwd:repo});
const oldBytes=git('show',baseline+':'+relative), newBytes=git('show',candidate+':'+relative);
assert.equal(sha(readFileSync(repo+'/'+relative)),sha(newBytes),'Candidate worktree source changed: refuse timing');
const baselineCommit=git('rev-parse',baseline).toString().trim();
const oldPath=directory+'/chartIntelligence.benchmark-baseline-'+process.pid+'.ts';
const warmups:any[]=[],samples:any[]=[];
const stamp=new Date().toISOString().replace(/[:.]/g,'-');
const output=receipt+'/capture-overhead-'+stamp+'.json';
const originalNow=Date.now;
const result:any={benchmark:'actual intelligence state builder, local seam doubles',baselineCommit,candidateCommit:candidate,
 sourceHashes:{baseline:sha(oldBytes),candidate:sha(newBytes),script:sha(readFileSync(new URL(import.meta.url)))},
 environment:{node:process.version,platform:process.platform,arch:process.arch,osRelease:os.release(),cpus:os.cpus().length,cpuModel:os.cpus()[0]?.model},
 warmupPairs:30,measuredPairs:120,fixtureBars:200,warmups,samples,
 limitations:['No provider/DB/network/HTTP/browser/broker measurements.','Fixture is normalized offline data, not evidence of a live qualified feed.','Retain all samples and outliers; no trimming or automatic retry.','Other current pure-engine source is shared by both versions; baseline module differs only by its exact git source.']};
let temporaryCreated=false;
try{
 const moduleUrl=(name:string)=>pathToFileURL(directory+'/'+name).href;
 const {runCandleTruth}=await import(moduleUrl('candleTruthEngine.ts'));
 const {computeChartTruthScore}=await import(moduleUrl('chartTruthScore.ts'));
 const symbol='CAPTURE_BENCH_OFFLINE',epoch=1_700_000_100_000;
 const normalized=runCandleTruth(Array.from({length:200},(_,i)=>({time:new Date(epoch+i*300_000).toISOString(),open:100+i/10,high:101+i/10,low:99+i/10,close:100.2+i/10})),
  {symbol,displaySymbol:symbol,timeframe:'M5',source:'dev',assetClass:'forex',limit:200,now:epoch+201*300_000});
 assert.equal(normalized.verifiedCandles.length,200);
 assert.ok(normalized.verifiedCandles.every((c:any)=>c.isComplete&&!c.isForming));
 const feed={symbol,displaySymbol:symbol,assetClass:'forex',source:'dev',isLive:false,lastTickTime:null,lastCandleTime:normalized.verifiedCandles.at(-1).closeTime,latencyMs:null,
 missingCandleCount:0,duplicateCount:0,outOfOrderCount:0,invalidOhlcCount:0,trailingIntervals:0,stale:false,quality:'delayed',warning:'Offline fixture',aiUsable:false,feedReadinessState:null,message:'Offline fixture',completenessReason:null};
 const observation={symbol,displaySymbol:symbol,timeframe:'M5',assetClass:'forex',source:'dev',quality:'delayed',aiUsable:false,warning:'Offline fixture',latencyMs:null,requestedLimit:200,candleCount:200,
 candles:normalized.verifiedCandles,feedStatus:feed,truthResult:normalized.truthResult,chartTruthScore:computeChartTruthScore(normalized.truthResult,feed),
 marketEvidence:{symbol,timeframe:'M5',source:'dev',sourceIdentity:'offline-benchmark-only',lastClosedCandleAt:feed.lastCandleTime}};
 result.fixtureSha256=sha(JSON.stringify(observation));
 let providerCalls=0;
 mock.module(moduleUrl('chartDataService.js'),{namedExports:{getChartCandles:async()=>{providerCalls++;return observation;}}});
 mock.module(moduleUrl('engines/chartMarketMemory.js'),{namedExports:{getRecentChartEvents:async()=>[],recordChartEvents:async()=>{}}});
 mock.module(moduleUrl('engines/timeframeAgreement.js'),{namedExports:{getTimeframeAgreement:()=>({populated:false,agreementScore:null,alignedDirection:'unknown',scalpOnlyWarning:false,timeframes:[],computedAt:null,note:'Offline background seam'})}});
 mock.module(moduleUrl('chartAgentConsensus.js'),{namedExports:{computeChartAgentConsensus:async()=>({populated:false,headline:'No consensus',detail:'',stance:'neutral',conflict:false,protective:false,influencingAgentCount:0,agents:[],cautions:[],note:'Offline external seam'})}});
 writeFileSync(oldPath,oldBytes,{flag:'wx'});temporaryCreated=true;
 const legacy=await import(pathToFileURL(oldPath).href);
 const current=await import(moduleUrl('chartIntelligence.ts'));
 let fakeNow=epoch+300*300_000;Date.now=()=>fakeNow;
 const run=async(builder:any)=>{fakeNow+=3001;const start=performance.now();const state=await builder(symbol,'M5',200);return{ms:performance.now()-start,state};};
 const compare=(a:any,b:any)=>{assert.deepEqual(a.candleStats,b.candleStats);assert.deepEqual(a.fastFlags,b.fastFlags);assert.deepEqual(a.latestClosedCandle,b.latestClosedCandle);assert.deepEqual(a.marketUnderstanding,b.marketUnderstanding);assert.deepEqual(a.chartTruthScore,b.chartTruthScore);assert.deepEqual(a.gateOutput,b.gateOutput);};
 for(let pair=0;pair<150;pair++){
  const order=pair%2===0?'baseline-first':'candidate-first';
  let before:any,after:any;
  if(order==='baseline-first'){before=await run(legacy.buildChartIntelligenceState);after=await run(current.buildChartIntelligenceState);}
  else{after=await run(current.buildChartIntelligenceState);before=await run(legacy.buildChartIntelligenceState);}
  const row={pair,order,baselineMs:before.ms,candidateMs:after.ms,deltaMs:after.ms-before.ms};
  (pair<30?warmups:samples).push(row);compare(before.state,after.state);
 }
 assert.equal(providerCalls,300,'Every invocation must rebuild, not hit cache');
 assert.equal(sha(JSON.stringify(observation)),result.fixtureSha256,'A builder mutated the shared fixture');
 const stats=(values:number[])=>{const s=[...values].sort((a,b)=>a-b);return{count:s.length,min:s[0],p50:s[Math.ceil(s.length*.5)-1],p95:s[Math.ceil(s.length*.95)-1],max:s.at(-1),mean:s.reduce((a,b)=>a+b,0)/s.length};};
 result.providerCalls=providerCalls;result.summary={baselineMs:stats(samples.map(r=>r.baselineMs)),candidateMs:stats(samples.map(r=>r.candidateMs)),pairedDeltaMs:stats(samples.map(r=>r.deltaMs)),outlierPolicy:'all samples retained'};result.status='completed';
}catch(error){result.status='failed';result.failure=error instanceof Error?error.stack:String(error);process.exitCode=1;}
finally{Date.now=originalNow;if(temporaryCreated){unlinkSync(oldPath);result.temporaryBaselineRemoved=true;}writeFileSync(output,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({receipt:output,status:result.status,summary:result.summary,failure:result.failure},null,2));}
