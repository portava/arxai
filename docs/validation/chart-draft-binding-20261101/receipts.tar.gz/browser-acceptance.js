async page => {
 const checks=[];
 const panel=page.getByTestId('scanner-chart-panel');
 const read=panel.getByTestId('ruby-chart-read');
 const ask=read.getByTestId('ruby-chart-read-ask');
 const canvas=page.getByTestId('arx-native-canvas').first();
 async function menu(label,y=.4){await canvas.scrollIntoViewIfNeeded();const b=await canvas.boundingBox();await canvas.click({button:'right',position:{x:b.width*.55,y:b.height*y}});await page.getByTestId('scanner-chart-command-menu').getByText(label,{exact:true}).click();}
 async function request(){await ask.click();return page.evaluate(()=>window.__draftQaRequests());}
 async function reply(index){await page.evaluate(i=>window.__draftQaReply(i),index);await read.getByText('OFFLINE PLAN RECEIPT '+index,{exact:true}).first().waitFor();}
 async function absent(index){await page.waitForFunction(i=>!document.querySelector('[data-testid="scanner-chart-panel"] [data-testid="ruby-chart-read"]').textContent.includes('OFFLINE PLAN RECEIPT '+i),index);}
 await page.keyboard.press('Escape');
 await menu('Plan Buy here');
 await panel.getByTestId('scanner-chart-draft-values').waitFor();
 const first=await request();if(first.length!==1||first[0].body.draft.side!=='BUY')throw Error('First plan request not bound');
 await reply(0);checks.push('completed BUY assessment displayed for submitted draft');
 await menu('Set invalidation (SL) here',.65);await absent(0);checks.push('changing SL withdraws completed assessment');
 const second=await request();if(second.length!==2||second[1].body.draft.sl===first[0].body.draft.sl)throw Error('Edited SL not submitted');
 await reply(1);checks.push('reread submits changed exact SL');
 await panel.getByTestId('scanner-chart-draft-clear').click();await absent(1);checks.push('clear withdraws assessment');
 await menu('Plan Sell here');const third=await request();if(third.length!==3||third[2].body.draft.side!=='SELL')throw Error('Sell request not bound');
 await menu('Set take-profit here',.7);await page.evaluate(()=>window.__draftQaReply(2));await absent(2);
 if(await ask.isDisabled())throw Error('Old request blocks reread');checks.push('edited pending SELL plan rejects late response');
 const fourth=await request();if(fourth.length!==4||fourth[3].body.draft.tp===third[2].body.draft.tp)throw Error('Edited TP not submitted');
 await reply(3);checks.push('new response survives cancellation of old plan');
 await page.setViewportSize({width:390,height:844});
 await panel.getByTestId('scanner-chart-draft-clear').click();await absent(3);checks.push('narrow viewport clear removes previous assessment');
 await read.scrollIntoViewIfNeeded();
 await page.screenshot({path:'/Users/areyouok/arx-tier1-release/chart-draft-binding-20261101/browser-mobile-cleared.png'});
 const log=await page.evaluate(()=>window.__readFixtureLog());
 if(log.errors.length)throw Error('Page errors: '+log.errors.join(';'));
 return {passed:true,checks,submitted:await page.evaluate(()=>window.__draftQaRequests()),pageErrors:log.errors,blockedMutations:log.blocked.filter(x=>x.kind==='mutation'),blockedExternal:log.blocked.filter(x=>x.kind==='external'),limitations:['Real Scanner production build, synthetic candles and intercepted restricted assessment responses','No broker connection, orders or live/demo tests','UI draft values changed through menu; dragging checked separately by existing unit suites','No full affirmative AI read because fixture feed is unverified; cross-plan full-read cap covered in component tests','No hardware paint or latency parity measurement']};
}
