import {createRequire} from 'node:module';
import {writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {createSharedAccountChangeRefresh} from '/Users/areyouok/arx-chart-support-resistance-20261101/artifacts/trading-dashboard/src/hooks/sharedAccountChangeRefresh.ts';
const require=createRequire('/Users/areyouok/arx-chart-support-resistance-20261101/artifacts/trading-dashboard/package.json');
const {QueryClient,QueryObserver}=require('@tanstack/react-query');
const key=['/api/me/shared-account/summary'];
const samples:number[]=[]; const warmups:number[]=[];
for(let i=0;i<330;i++){
 const client=new QueryClient({defaultOptions:{queries:{retry:false,gcTime:Infinity}}});
 client.setQueryData(key,{version:0});
 let began:number|null=null;
 const observer=new QueryObserver(client,{queryKey:key,staleTime:Infinity,queryFn:async()=>{began=performance.now();return {version:1};}});
 const unsubscribe=observer.subscribe(()=>{});
 const coordinator=createSharedAccountChangeRefresh(client);
 const start=performance.now();coordinator.notify();
 for(let spin=0;spin<30 && began===null;spin++)await Promise.resolve();
 if(began===null)throw new Error('No canonical query started for hint');
 (i<30?warmups:samples).push(began-start);
 coordinator.dispose();unsubscribe();client.clear();
}
const sorted=[...samples].sort((a,b)=>a-b);
const pct=(p:number)=>sorted[Math.min(sorted.length-1,Math.ceil(sorted.length*p)-1)];
const result={scope:'Synthetic existing QueryClient hint handler to canonical query function entry only. No HTTP, server authorization, broker/EA, database, DOM rendering or cross-process delivery included. No end-to-end or competitor comparison.',sampleCount:samples.length,warmupCount:warmups.length,p50Ms:pct(.5),p95Ms:pct(.95),p99Ms:pct(.99),maxMs:sorted.at(-1),samplesMs:samples,warmupsMs:warmups};
writeFileSync('/Users/areyouok/arx-tier1-release/account-change-propagation-20261101/hint-query-measurement.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({...result,samplesMs:undefined,warmupsMs:undefined}));
