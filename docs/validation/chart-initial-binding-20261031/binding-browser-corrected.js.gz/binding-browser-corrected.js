async page => {
 const report={passed:false,checks:[],failure:null};
 const check=(ok,label)=>{report.checks.push({label,pass:!!ok});if(!ok)throw Error(label);};
 try {
  report.build=await page.evaluate(async()=>fetch('/arx-scanner-qa-build-info.json').then(r=>r.json()));
  check(report.build.source.head===SCANNER_QA_EXPECTED_COMMIT&&report.build.sourceUnchanged&&!report.build.source.status,'Exact clean source build');
  for(const width of [1440,390]){
   await page.setViewportSize({width,height:width===390?844:1100});
   await page.evaluate(()=>window.__fixtureSwitchSource({source:'offline_fixture',identity:'synthetic-history-A'}));
   let release;const gate=new Promise(resolve=>{release=resolve;});const handler=async route=>{await gate;await route.fallback();};
   await page.route('**/api/chart/candles*',handler);
   try{
    await page.goto('http://127.0.0.1:4199/market-scanner');
    const panel=page.getByTestId('scanner-chart-panel');
    const tools=panel.getByRole('button',{name:'Chart tools',exact:true});
    if(width===390)await tools.waitFor({state:'visible'});
    if(await tools.isVisible()&&await tools.getAttribute('aria-expanded')!=='true')await tools.click();
    const studies=panel.getByRole('button',{name:'Studies (0)',exact:true});await studies.click();
    const search=panel.getByLabel('Search studies',{exact:true});await search.fill('Donchian');const input=await search.elementHandle();
    check(!(await page.evaluate(()=>window.__arxChartQa?.snapshot()?.barCount>0)),width+' no source bars before release');
    release();await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.barCount===200);
    await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
    check(await input.evaluate(el=>el.isConnected&&el===document.activeElement&&el.value==='Donchian'),width+' same focused input and search survives initial binding');
    const observed=await page.evaluate(()=>({state:window.__arxChartQa.snapshot(),data:window.__arxChartQa.data()}));
    const log=await page.evaluate(()=>window.__readFixtureLog());const response=log.candleResponses.filter(r=>r.source==='offline_fixture'&&r.canonical.length===200).at(-1);
    check(response&&JSON.stringify(observed.data.canonical)===JSON.stringify(response.canonical),width+' full source candle equality');
    await page.evaluate(()=>window.__fixtureSwitchSource({source:'offline_replacement',identity:'synthetic-history-B'}));
    const details=panel.getByTestId('scanner-feed-details');
    if(await details.getAttribute('open')===null)await details.locator('summary').click();
    await panel.getByTestId('scanner-chart-reload').click();await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.feed?.source==='offline_replacement');
    check(await input.evaluate(el=>!el.isConnected),width+' previous workbench reset on actual provider change');
    check(await panel.getByLabel('Search studies',{exact:true}).count()===0,width+' old study search closed');
    check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),width+' no document overflow');
   }finally{release();await page.unroute('**/api/chart/candles*',handler);}
  }
  report.logs=await page.evaluate(()=>window.__readFixtureLog());check(report.logs.errors.length===0,'No page exceptions');report.passed=true;
 }catch(e){report.failure=String(e?.stack??e);}
 return report;
}
