from pathlib import Path
import subprocess,json,datetime
root=Path('/Users/areyouok/arx-position-money-refresh-20261102');out=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
receipt={'head':head,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':[]}
checks=[('combined-full',['--filter','@workspace/trading-dashboard','exec','vitest','run']),('combined-libs',['run','typecheck:libs']),('combined-typecheck',['--filter','@workspace/trading-dashboard','run','typecheck']),('combined-api-typecheck',['--filter','@workspace/api-server','run','typecheck']),('combined-pattern-library',['--filter','@workspace/api-server','run','test:pattern-library-intelligence']),('combined-pattern-truth',['--filter','@workspace/api-server','run','test:pattern-truth']),('combined-gold',['--filter','@workspace/api-server','run','test:gold']),('combined-scanner-child',['--filter','@workspace/api-server','run','test:pattern-scanner-child']),('combined-build',['--filter','@workspace/trading-dashboard','run','build']),('combined-api-build',['--filter','@workspace/api-server','run','build']),('combined-guards',['run','ci:guards'])]
for name,args in checks:
 cmd=['python3','/tmp/arx-offline-run.py','/Users/areyouok/.local/bin/pnpm',*args]
 with (out/(name+'.log')).open('w') as f:code=subprocess.call(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 receipt['checks'].append({'name':name,'command':cmd,'exit':code,'log':name+'.log'})
 (out/'combined-checks.json').write_text(json.dumps(receipt,indent=2));print(name,code,flush=True)
receipt['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();receipt['headUnchanged']=head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();receipt['status']=subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
(out/'combined-checks.json').write_text(json.dumps(receipt,indent=2))
