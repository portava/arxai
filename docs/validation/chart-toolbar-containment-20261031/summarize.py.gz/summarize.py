import json,statistics,sys
from pathlib import Path
for name in sys.argv[1:]:
 p=Path(name);text=p.read_text();v=json.JSONDecoder().raw_decode(text.split('### Result\n')[1])[0];p.with_suffix('.json').write_text(json.dumps(v,indent=2));out={'run':name,'passed':v.get('passed'),'failure':v.get('failure'),'source':v.get('build',{}).get('source',{}),'groups':[]}
 for viewport in ['desktop','mobile']:
  rows=[s for s in v.get('samples',[]) if s['viewport']==viewport];times=[s.get('visibleCompleteMs') for s in rows];out['groups'].append({'viewport':viewport,'rows':len(rows),'keys':list(rows[0]) if rows else [],'times':times,'failures':[s.get('failure') for s in rows]})
 print(json.dumps(out,indent=2))
