import subprocess,json,time,select,os
from pathlib import Path
repo=Path('/Users/areyouok/arx-chart-row-reuse-20261101');out=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
cli='/Users/areyouok/.local/bin/playwright-cli'
runner=(repo/'scripts/chart-qa/stress-matrix-runner.js').read_text().strip()
records=[]
for index,variant in enumerate(['baseline','candidate','candidate','baseline']):
 name=f'{index+1}-{variant}'
 expected='true' if variant=='candidate' else 'false'
 script=runner.replace('r.build=build;', f"if(Boolean(build.priceRowReuseExperiment)!=={expected})throw Error('Wrong experiment variant');r.build=build;")
 (out/f'{name}.js').write_text(f"async page=>{{const STRESS_EXPECTED_COMMIT={json.dumps(head)};return await ({script})(page);}}\n")
 server=subprocess.Popen(['python3','/tmp/arx-offline-run.py','/usr/local/bin/node','scripts/chart-qa/prod-server.mjs',f'--out=scripts/node_modules/.row-reuse-{variant}','--no-build'],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
 record={'name':name,'commit':head,'startedAt':time.time()}
 try:
  with (out/f'{name}-server.log').open('w') as f:
   deadline=time.monotonic()+40
   while time.monotonic()<deadline:
    ready,_,_=select.select([server.stdout],[],[],1)
    if ready:
     line=server.stdout.readline();f.write(line);f.flush()
     if 'Production chart fixture ready' in line:break
     if server.poll() is not None:raise RuntimeError('Fixture exited '+str(server.returncode))
   else:raise RuntimeError('Fixture ready timeout')
  for action,args in [('open',['open','about:blank']),('matrix',['run-code',f'--filename={out/name}.js']),('close',['close'])]:
   with (out/f'{name}-{action}.log').open('w') as log:
    proc=subprocess.run([cli,'-s=arx-row-reuse',*args],cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=180)
   record[action+'Exit']=proc.returncode
  text=(out/f'{name}-matrix.log').read_text()
  result=json.JSONDecoder().raw_decode(text.split('### Result\n',1)[1])[0]
  (out/f'{name}.json').write_text(json.dumps(result,indent=2)+'\n')
  record['allCorrect']=result['allCorrect'];record['cases']=len(result['cases']);record['allMeetFrameProxy']=result['allMeetFrameProxy']
 except Exception as error:record['error']=repr(error)
 finally:
  server.terminate()
  try:server.wait(timeout=10)
  except subprocess.TimeoutExpired:server.kill();server.wait()
  record['finishedAt']=time.time();records.append(record)
  (out/'comparison-runs.json').write_text(json.dumps(records,indent=2)+'\n')
  print(json.dumps(record),flush=True)
 if record.get('error'):break
