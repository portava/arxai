async page=>{
 const out={passed:false,checks:[]};const check=(yes,label)=>{if(!yes)throw Error(label);out.checks.push(label);};
 try{
  out.build=await page.evaluate(async()=>await(await fetch('/arx-scanner-qa-build-info.json')).json());
  check(out.build.source.head.startsWith('ae251596')&&!out.build.source.status&&out.build.sourceUnchanged,'Exact clean committed source');
  const panel=page.getByTestId('scanner-chart-panel');const reader=panel.getByTestId('smart-chart-reader');
  await page.waitForFunction(()=>document.querySelector('[data-testid="smart-chart-reader"]')?.getAttribute('data-analysis-status')==='ready');
  const buttons=reader.getByRole('button',{name:/^Shooting Star · observed/,includeHidden:true});
  check(await buttons.count()===1,'One observed genuine shooting star; no duplicate confirmed non-star');
  await reader.locator('summary').first().click();
  await buttons.first().click();
  const text=await reader.innerText();
  check(text.includes('next close did not confirm'),'Reader describes the actual non-confirming next close');
  check(!text.includes('confirming the rejection'),'No false rejection confirmation');
  check(text.includes('stale'),'Historical fixture retains freshness qualification');
  out.native=await page.evaluate(()=>({snapshot:window.__arxChartQa.snapshot(),data:window.__arxChartQa.data()}));
  check(out.native.snapshot.engineId==='arx-native','Actual native chart rendered');
  check(out.native.data.canonical.length===69,'All69 source candles retained');
  const bars=out.native.data.canonical;check(bars[66].high===bars[67].high&&bars[66].low===bars[67].low&&bars[66].close!==bars[67].close,'Repeated-extrema source fixture applied without substitution');
  await reader.scrollIntoViewIfNeeded();await page.screenshot({path:'star-reader-desktop.png'});
  await page.setViewportSize({width:390,height:844});await reader.scrollIntoViewIfNeeded();
  check((await reader.innerText()).includes('next close did not confirm'),'Mobile keeps the same evidence-qualified interpretation');
  await page.screenshot({path:'star-reader-mobile.png'});
  out.fixture=await page.evaluate(()=>window.__readFixtureLog());
  check(out.fixture.errors.length===0,'No page errors');check(!out.fixture.blocked.some(x=>x.kind==='external'||x.kind==='websocket'),'No external feeds or broker requests');
  out.passed=true;
 }catch(e){out.failure=String(e.stack??e);await page.screenshot({path:'star-failure.png'});}
 return out;
}