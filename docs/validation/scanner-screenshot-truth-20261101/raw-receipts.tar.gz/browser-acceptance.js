async page=>{page.setDefaultTimeout(10000);page.setDefaultNavigationTimeout(15000); const setup=async page=>{const SCANNER_QA_PRESERVE_STORAGE_ON_RELOAD=true;return await (async page => {
 function resolveFixtureRole(value) {
  if(value===undefined)return 'USER';
  if(value==='USER'||value==='ADMIN')return value;
  throw Error('Offline fixture role must be USER or ADMIN');
 }
 const fixtureRole=resolveFixtureRole(typeof SCANNER_QA_ROLE==='undefined'?undefined:SCANNER_QA_ROLE);
 const preserveStorageOnReload=typeof SCANNER_QA_PRESERVE_STORAGE_ON_RELOAD==='undefined'?false:SCANNER_QA_PRESERVE_STORAGE_ON_RELOAD;
 if(typeof preserveStorageOnReload!=='boolean')throw Error('Offline storage preservation must be boolean');
 function initializeOfflineStorage(preserve) {
  const marker='arx.offline.qa.storage.initialized.v1';
  if(!preserve||sessionStorage.getItem(marker)!=='yes') {
   localStorage.clear();sessionStorage.clear();
   localStorage.setItem('highroll.chartSymbol','EURUSD');
   localStorage.setItem('arx.chart.preferences.v1',JSON.stringify({timeZone:'America/New_York'}));
   localStorage.setItem('highroll.onboarding.firstrun.dismissed.v1','1');
   if(preserve)sessionStorage.setItem(marker,'yes');
  }
 }

 const requests=[],unknown=[],blocked=[],errors=[],consoleErrors=[],candleResponses=[];
 const origin=typeof SCANNER_QA_BASE_URL==='string'?SCANNER_QA_BASE_URL:'http://127.0.0.1:4199';
 if(new URL(origin).hostname!=='127.0.0.1')throw Error('Offline fixture requires loopback');
 if(page.context().serviceWorkers().length)throw Error('Use a fresh browser session without service workers');
 const fixtureEnd=Math.floor(Date.now()/1000)-2; let fixtureSource='mt5_broker',fixtureIdentity='a'.repeat(64),basisQualified=true,clockQualified=false; await page.exposeFunction('__fixtureSetClock',value=>{clockQualified=value===true;return true;}); await page.exposeFunction('__fixtureRevokeClock',()=>{clockQualified=false;return true;}); await page.exposeFunction('__fixtureRevokeBasis',()=>{basisQualified=false;return true;});
 await page.exposeFunction('__fixtureSwitchSource', config => {fixtureSource=config.source;fixtureIdentity=config.identity;return true;});
 page.on('pageerror',e=>errors.push(e.message));
 page.on('console',m=>{if(m.type()==='error') consoleErrors.push(m.text());});
 await page.exposeFunction('__readFixtureLog',()=>({fixtureRole,preserveStorageOnReload,requests,unknown,blocked,errors,consoleErrors,candleResponses}));
 await page.context().routeWebSocket('**/*',ws=>{blocked.push({kind:'websocket',url:ws.url()});ws.close();});
 await page.addInitScript(initializeOfflineStorage,preserveStorageOnReload);
 await page.addInitScript(()=>{
  if(navigator.serviceWorker)navigator.serviceWorker.register=async()=>{throw Error('Service workers disabled for offline QA');};
  window.__offlineStreams=[];
  class OfflineEventSource { constructor(url){this.url=url;this.readyState=2;window.__offlineStreams.push(this);} close(){this.closed=true;} addEventListener(){} removeEventListener(){} }
  window.EventSource=OfflineEventSource;
  window.addEventListener('DOMContentLoaded',()=>{const note=document.createElement('div');note.textContent='OFFLINE QA — generated UTC fixture only, NOT verified MT5 clock; all APIs intercepted; trading disabled';note.style='position:fixed;bottom:0;left:0;right:0;z-index:999999;background:#854d0e;color:white;padding:4px;font:12px sans-serif;pointer-events:none';document.body.append(note);});
 });
 const symbols=['EURUSD','GBPUSD','USDJPY','XAUUSD','NAS100','V75'];
 const mode={ok:true,userId:900007,currentAccountMode:'LIVE_SHARED',cleanModeLabel:'Offline read-only fixture',cleanUserMessage:'No broker connection',cleanBlockedReason:'OFFLINE_FIXTURE',role:fixtureRole,isAdmin:fixtureRole==='ADMIN',isAdminPreviewingUserMode:false,adminDiagnosticsAvailable:false,liveExecutionArmed:false,userSharedMasterAssignment:{attached:false},accountShellStatus:{accountMode:'SHARED_MASTER_MT5',tradingMode:'DISABLED',tradingModeLabel:'Disabled',approvalStatus:'APPROVED',tradingStatus:'DISABLED'},userAllocation:{hasAllocation:false,currentBalance:0,assignedStartingBalance:null,equity:0,marginUsed:0},userRiskCaps:{maxLotSize:0,maxOpenTrades:0,maxDailyLossAmount:0,allowedSymbols:[],requireStopLoss:true},userFrozenStatus:{isFrozen:true,freezeMessage:'Offline fixture'},userApprovalStatus:'APPROVED',userCanManualTrade:false,userCanAutoTrade:false,aiSleeveStatus:{enabled:false,autoEnabled:false},demoAvailable:false,paperAvailable:false,modeSwitchOptions:[],adminDiagnostics:null};
 function selected(symbol,timeframe){return{ok:true,symbolRaw:symbol,symbol,timeframe,highlights:{bias:'WAIT',confidenceLabel:'Very Low',confidenceScore:0,volatilityLabel:'Calm',trendState:'neutral',entryZone:null,suggestedStop:null,suggestedTakeProfit:null,riskRewardRatio:0,riskWarnings:['Offline fixture: not market analysis']},explanation:{hedge:'Offline fixture; no live market read.',why:'Synthetic historical candles for UI validation only.',whyItMatters:'No financial inference is available.',risk:'Unavailable.',invalidation:'Unavailable.',cautions:['No live source'],disclaimer:'OFFLINE QA ONLY'},upcomingEvents:[],newsRisk:{riskLevel:'none',blockTrading:true,summary:'News unavailable in offline fixture'},dataSource:'LIVE_FEED',dataSourceLabel:'Offline fixture — no live feed',dataState:'UNAVAILABLE',dataAsOf:'2026-01-02T12:00:00.000Z',generatedAt:'2026-01-02T12:00:01.000Z',levelsWithheld:true,levelsWithheldReason:'Offline fixture',cacheHit:false};}
 function candles(symbol,timeframe,limit){const step=({M1:60,M2:120,M3:180,M4:240,M5:300,M6:360,M10:600,M12:720,M15:900,M20:1200,M30:1800,H1:3600,H2:7200,H3:10800,H4:14400,H6:21600,H8:28800,H12:43200,D1:86400})[timeframe];if(!step)throw Error('Unsupported fixture interval: '+timeframe);limit=Math.min(Math.max(Math.floor(limit),1),1000);const end=fixtureEnd;const bars=Array.from({length:Math.min(limit,1000)},(_,i)=>{const ms=(end-(limit-i)*step)*1000,close=(symbol==='GBPUSD'?100:symbol==='USDJPY'?10000:1)*(1+Math.sin(i/17)*.003);return{symbol,timeframe,openTime:new Date(ms).toISOString(),closeTime:new Date(ms+step*1000).toISOString(),open:close-.0001,high:close+.0003,low:close-.0003,close,volume:0,volumeEvidence:i%7===0?{kind:'unavailable',quantity:null,unit:null,reason:'Offline test missing count'}:{kind:'tick_count',quantity:i%5===0?0:10+i,unit:'ticks',reason:null},source:fixtureSource,isComplete:true,isFinal:true,sourceMode:'demo',priceBasis:'BID',priceBasisEvidence:basisQualified?{kind:'producer_declared',basis:'BID',reason:null}:undefined,timeBasisEvidence:clockQualified?{kind:'original_utc',basis:'UTC',authority:'offline-generated-fixture-utc-v1-NOT-MT5',reason:null}:undefined,isForming:false,qualityFlags:[]};});const fs={symbol,displaySymbol:symbol,assetClass:'forex',source:fixtureSource,quality:'clean',isLive:true,stale:false,aiUsable:true,lastCandleTime:new Date(fixtureEnd*1000).toISOString(),lastTickTime:null,latencyMs:0,missingCandleCount:0,duplicateCount:0,outOfOrderCount:0,invalidOhlcCount:0,trailingIntervals:0,warning:'OFFLINE FIXTURE — synthetic historical bars, not market data',message:'Offline fixture',feedReadinessState:null,completenessReason:null};return{symbol,displaySymbol:symbol,timeframe,assetClass:'forex',source:fixtureSource,quality:'clean',aiUsable:true,requestedLimit:limit,candleCount:bars.length,candles:bars,feedStatus:fs,marketEvidence:{symbol,timeframe,source:fixtureSource,sourceIdentity:fixtureIdentity,lastClosedCandleAt:new Date(fixtureEnd*1000).toISOString()},truthResult:null,chartTruthScore:null};}
 await page.context().route('**/*',async route=>{
  const request=route.request(),url=new URL(request.url());
  if(url.origin!==origin){blocked.push({kind:'external',url:request.url()});return route.abort();}
  if(!url.pathname.startsWith('/api/')){if(request.method()!=='GET'){blocked.push({kind:'mutation',path:url.pathname,method:request.method(),status:503});return route.fulfill({status:503,contentType:'application/json',body:'{\"error\":\"OFFLINE_MUTATION_BLOCKED\"}'});}return route.continue();}
  const item={path:url.pathname,query:url.search,method:request.method(),started:Date.now(),ended:null,status:200};requests.push(item);
  let payload,status=200,delay=20;
  const p=url.pathname,symbol=url.searchParams.get('symbol')??'EURUSD',tf=url.searchParams.get('timeframe')??'M15';
  if(request.method()==='POST'&&p==='/api/me/assistant/read-chart'){payload={chartRead:{dataQuality:'ok',basis:'VERIFIED',readLayer:'FULL',liveSetupWithheld:true,canShowLiveTradeSetup:false,bias:'Bearish',confidence:'Medium',htfBias:'No clear edge',why:'Generated downward structural context; no actual market conclusion.',blockedReason:'OFFLINE fixture: exact setup withheld by a separate policy restriction.',supportZone:'0.9970–0.9980',resistanceZone:'1.0020–1.0030',riskNote:'Generated structural caution only.',patternRead:{patternNote:'Offline generated formation is still forming',patternStatus:'forming',patternConditional:true,patternContextOnly:true},trendlineRead:{trendlineNote:'Offline generated descending line is broken',trendlineStatus:'broken',trendlineConditional:true,trendlineContextOnly:true}}};} else if(request.method()!=='GET'){status=503;payload={ok:false,error:'OFFLINE_MUTATION_BLOCKED'};blocked.push({kind:'mutation',path:p,method:request.method(),status:503});}
  else if(p==='/api/me')payload={user:{id:900007,email:'offline@example.invalid',name:'Offline QA',role:fixtureRole,lastLoginAt:null,createdAt:'2026-01-01T00:00:00Z',updatedAt:'2026-01-01T00:00:00Z'}};
  else if(p==='/api/me/account-mode')payload=mode;
  else if(p==='/api/me/assistant/conversations')payload={conversations:[{id:900007,title:'Offline research clock test',archivedAt:null}]};
  else if(p==='/api/me/assistant/conversations/900007')payload={conversation:{id:900007,title:'Offline research clock test'},messages:[]};
  else if(p==='/api/me/assistant-settings')payload={displayName:'Eleanor',isDefault:true};
  else if(p==='/api/onboarding/status')payload={status:{status:'COMPLETED',walkthroughCompleted:true,totalSteps:0,completedSteps:[],skippedSteps:[],nextStep:null}};
  else if(p==='/api/feature-announcements')payload={announcements:[]};
  else if(p==='/api/market-scanner/universes')payload={universes:[{id:'all',label:'Offline universe',symbols,available:true,note:'Fixture symbols only'},{id:'forex',label:'Forex',symbols:symbols.slice(0,3),available:true}],defaultUniverse:'all'};
  else if(p==='/api/market-scanner/status')payload={running:false,universe:'all',lastScanAt:null,feedNote:'OFFLINE QA — no live feed'};
  else if(p==='/api/market-scanner/opportunities')payload={opportunities:[],universe:'all',universeSymbols:symbols,generatedAt:'2026-01-02T12:00:01Z',dataSource:'AWAITING_FEED'};
  else if(p==='/api/market-scanner/selected-market'){payload=selected(symbol,tf);delay=450;}
  else if(p==='/api/chart/candles'){payload=candles(symbol,tf,Number(url.searchParams.get('limit')??200));delay=80;candleResponses.push({symbol,timeframe:tf,requestPath:p,requestQuery:url.search,source:fixtureSource,sourceIdentity:fixtureIdentity,priceBasis:payload.candles[0]?.priceBasis,priceBasisEvidence:payload.candles[0]?.priceBasisEvidence,timeBasisEvidence:payload.candles[0]?.timeBasisEvidence,canonical:payload.candles.map(c=>({time:Date.parse(c.openTime)/1000,open:c.open,high:c.high,low:c.low,close:c.close}))});}
  else if(p==='/api/chart/history')payload={ok:true,source:fixtureSource,candles:[],status:'unavailable',returnedCount:0,oldest:null,newest:null,hasMoreHistory:false,nextBefore:null,providerLimitReached:true,limitationReason:'Offline fixture',cacheHit:false};
  else if(p==='/api/market-data/deriv/status')payload={configured:false,connected:false,status:'OFFLINE_FIXTURE'};
  else if(p==='/api/me/opportunity-map'){const cats=['READY_NOW','FORMING_SOON','WATCH_AFTER_NEWS','TOO_LATE','AVOID','NO_CLEAN_SETUP'];const rows=symbols.map(symbol=>({symbol,displayName:symbol,direction:'NEUTRAL',recommendedAction:'WAIT',setupType:'Offline fixture',edgeScore:0,entryQuality:0,executionQuality:0,newsRisk:'unknown',hasLiveData:false,isLate:false,reason:'Offline fixture: no live analysis.',category:'NO_CLEAN_SETUP',kind:'NONE',bestAction:'WAIT',stageLabel:'Unavailable'}));payload={universe:'all',timeframe:tf,generatedAt:new Date().toISOString(),universeCount:rows.length,map:{rows,categories:Object.fromEntries(cats.map(c=>[c,c==='NO_CLEAN_SETUP'?rows:[]])),best:{bestScalp:null,bestMomentum:null,bestRetest:null,bestReversal:null},scannedCount:rows.length,liveCount:0},bestVsSelected:{selectedSymbol:url.searchParams.get('selectedSymbol'),hasCleanerAlternative:false,best:null,message:'Offline fixture'},skippedSymbols:[],dataNote:'OFFLINE FIXTURE — no market assessment'};delay=url.searchParams.has('selectedSymbol')?450:20;}
  else if(p==='/api/watchlists')payload=[];
  else if(p==='/api/aaci/cohesion')payload={items:[]};
  else if(p==='/api/me/live/positions')payload={positions:[]};
  else if(p==='/api/me/live/commands')payload={commands:[]};
  else if(p==='/api/me/chart/smart-layers')payload={layers:[],handshakeInputs:{signalSymbol:symbol,signalExists:false,hasSufficientData:false,levelCount:0,newsMapped:false},signal:null};
  else if(p==='/api/me/chart-annotations')payload={annotations:[]};
  else {unknown.push({path:p,query:url.search});status=503;payload={ok:false,error:'OFFLINE_FIXTURE_UNAVAILABLE',message:'Unavailable in offline QA'};}
  await new Promise(resolve=>setTimeout(resolve,delay));
  item.ended=Date.now();item.status=status;
  try{await route.fulfill({status,contentType:'application/json',body:JSON.stringify(payload)});}catch{item.cancelled=true;}
 });
 await page.setViewportSize({width:1440,height:1100});
 await page.goto(origin+'/market-scanner');
 await page.getByTestId('scanner-chart-panel').waitFor({timeout:15000});
 await page.getByTestId('arx-native-canvas').waitFor({timeout:15000});
 await page.getByTestId('badge-active-symbol').waitFor({timeout:15000});
 await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.barCount>0);
 return{url:page.url(),fixtureRole,fixture:'real dashboard route and providers; synthetic history; no broker',canvasCount:await page.locator('canvas').count(),errors,unknown:[...new Set(unknown.map(x=>x.path))],requests:requests.length,blocked};
}
)(page);}; const initial=await setup(page);

 const assertions=[]; const check=(name,pass,evidence)=>assertions.push({name,pass:!!pass,evidence});
 const text=async id=>await page.getByTestId(id).innerText();
 const header=async()=>({data:await text('scanner-header-data'),reader:await text('scanner-header-ruby'),trading:await text('scanner-header-trading'),readiness:await text('scanner-header-readiness')});
 const build=await page.evaluate(async()=>await (await fetch('/arx-scanner-qa-build-info.json')).json());
 await page.waitForFunction(async()=> (await window.__readFixtureLog()).requests.some(r=>r.path==='/api/market-scanner/selected-market'&&r.ended&&r.status===200));
 await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
 const first=await header();
 check('Unqualified clock cannot claim live data',!/^Data\s+Live\b/i.test(first.data),first.data);
 check('Unqualified clock cannot claim Full read',!first.reader.includes('Full read'),first.reader);
 check('Unqualified clock cannot claim Live-confirmed readiness',!first.readiness.includes('Live-confirmed'),first.readiness);
 check('Chart visibly discloses unqualified clock',(await text('chart-evidence-restrictions')).includes('UTC mapping unverified'),await text('chart-evidence-restrictions'));
 const read=page.getByTestId('ruby-chart-read');
 await page.getByTestId('ruby-chart-read-ask').click();
 await page.getByTestId('ruby-chart-read-ask').filter({hasText:'Re-read'}).waitFor();
 const unqualifiedRead=await read.innerText();
 check('Withheld setup caps the reader header',!(await text('scanner-header-ruby')).includes('Full read'),await text('scanner-header-ruby'));
 check('Restricted context retains source-clock limitation',/UTC mapping unverified/.test(unqualifiedRead),unqualifiedRead);
 check('Confidence is not presented as momentum',!/Momentum:\s*Read confidence/.test(unqualifiedRead),unqualifiedRead);
 await page.evaluate(async()=>await window.__fixtureSetClock(true));
 await page.reload(); await page.getByTestId('scanner-chart-panel').waitFor();
 await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.barCount>0);
 await page.waitForFunction(()=>document.querySelector('[data-testid="scanner-header-data"]')?.textContent.includes('Live'));
 await page.getByTestId('ruby-chart-read-ask').click();
 await page.getByTestId('ruby-chart-read-ask').filter({hasText:'Re-read'}).waitFor();
 const qualified=await header(), assessed=await read.innerText();
 check('Qualified current feed remains independent of blocked trading',/^Data\s+Live\b/i.test(qualified.data)&&qualified.trading.includes('Blocked'),qualified);
 check('Current-feed heading avoids an overall trade-health claim',/current feed/i.test(qualified.readiness),qualified.readiness);
 check('Qualified feed does not override withheld setup',!qualified.reader.includes('Full read'),qualified.reader);
 check('Actual nested trendline note appears with conditions',assessed.includes('Offline generated descending line is broken')&&assessed.includes('conditional')&&assessed.includes('context only'),assessed);
 check('Missing pattern/trendline placeholders do not discard supplied evidence',!assessed.includes('No specific trendline named')&&!assessed.includes('No specific chart pattern named'),assessed);
 check('Setup restriction does not promise feed confirmation will clear it',!assessed.includes('withheld until EURUSD'),assessed);
 for(const width of [1440,790,390]){
  await page.setViewportSize({width,height:1000});
  await page.getByTestId('scanner-header-strip').scrollIntoViewIfNeeded();
  const geometry=await page.getByTestId('scanner-header-strip').evaluate(el=>{const parent=el.getBoundingClientRect();return {parent:{left:parent.left,right:parent.right,width:parent.width},items:[...el.children].map(c=>{const r=c.getBoundingClientRect();return{left:r.left,right:r.right,top:r.top,width:r.width,client:c.clientWidth,scroll:c.scrollWidth,text:c.textContent};})};});
  check('Status cards contain their text at width '+width,geometry.items.every(c=>c.scroll<=c.client+1&&c.left>=geometry.parent.left-1&&c.right<=geometry.parent.right+1),geometry);
  const measureHeaders=async()=>await page.evaluate(()=>{const header=document.querySelector('header'),safety=document.querySelector('[aria-label="Trading safety status"]');if(!header||!safety)return null;const h=header.getBoundingClientRect(),s=safety.getBoundingClientRect();return{header:{top:h.top,bottom:h.bottom},safety:{top:s.top,bottom:s.bottom},scrollY};});
  const before=await measureHeaders();
  await page.getByTestId('arx-native-canvas').scrollIntoViewIfNeeded();
  const after=await measureHeaders();
  check('Topbar and safety header do not overlap after scrolling at '+width,after&&after.header.bottom<=after.safety.top+1,{before,after});
  await page.getByTestId('scanner-header-strip').scrollIntoViewIfNeeded();
  await page.screenshot({path:'/Users/areyouok/arx-tier1-release/scanner-screenshot-truth-20261101/'+build.buildId+'-width-'+width+'.png'});
 }
 const log=await page.evaluate(async()=>await window.__readFixtureLog());
 check('No page exception',log.errors.length===0,log.errors);
 check('No API or external request forwarded',log.blocked.filter(x=>x.kind==='external').length===0,log.blocked);
 return {build:{id:build.buildId,source:build.source,sourceUnchanged:build.sourceUnchanged},initial,assertions,pass:assertions.filter(x=>x.pass).length,fail:assertions.filter(x=>!x.pass).length,requests:log.requests,errors:log.errors,unknown:log.unknown,blocked:log.blocked,limitations:['Generated candles and mocked read, not screenshot source replay','No provider/model/broker APIs forwarded; no latency benchmark','Only screenshot-scope layout and evidence projection checked']};
}
