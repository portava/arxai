from pathlib import Path
root=Path('/Users/areyouok/arx-tier1-release/scanner-screenshot-truth-20261101')
s=Path('/Users/areyouok/arx-tier1-release/chart-research-capital-20261101/browser-base.js').read_text()
s=s[:s.index('}; await page.addInitScript(()=>{window.__cashWorkerInputs=')]+ '}; const initial=await setup(page);\n'
s=s.replace("let fixtureSource='mt5_broker',fixtureIdentity='a'.repeat(64),basisQualified=true,clockQualified=true;", "const fixtureEnd=Math.floor(Date.now()/1000)-2; let fixtureSource='mt5_broker',fixtureIdentity='a'.repeat(64),basisQualified=true,clockQualified=false; await page.exposeFunction('__fixtureSetClock',value=>{clockQualified=value===true;return true;});")
s=s.replace('const end=1767355200;', 'const end=fixtureEnd;')
s=s.replace('async page=>{ const setup=', 'async page=>{page.setDefaultTimeout(10000);page.setDefaultNavigationTimeout(15000); const setup=')
s=s.replace("isLive:false,stale:true,aiUsable:false,lastCandleTime:'2026-01-02T12:00:00.000Z'", "isLive:true,stale:false,aiUsable:true,lastCandleTime:new Date(fixtureEnd*1000).toISOString()")
s=s.replace("quality:'clean',aiUsable:false,requestedLimit", "quality:'clean',aiUsable:true,requestedLimit")
s=s.replace("lastClosedCandleAt:'2026-01-02T12:00:00Z'", "lastClosedCandleAt:new Date(fixtureEnd*1000).toISOString()")
s=s.replace('trailingIntervals:9999','trailingIntervals:0')
s=s.replace("if(request.method()!=='GET'){status=503;", "if(request.method()==='POST'&&p==='/api/me/assistant/read-chart'){payload={chartRead:{dataQuality:'ok',basis:'VERIFIED',readLayer:'FULL',liveSetupWithheld:true,canShowLiveTradeSetup:false,bias:'Bearish',confidence:'Medium',htfBias:'No clear edge',why:'Generated downward structural context; no actual market conclusion.',blockedReason:'OFFLINE fixture: exact setup withheld by a separate policy restriction.',supportZone:'0.9970–0.9980',resistanceZone:'1.0020–1.0030',riskNote:'Generated structural caution only.',patternRead:{patternNote:'Offline generated formation is still forming',patternStatus:'forming',patternConditional:true,patternContextOnly:true},trendlineRead:{trendlineNote:'Offline generated descending line is broken',trendlineStatus:'broken',trendlineConditional:true,trendlineContextOnly:true}}};} else if(request.method()!=='GET'){status=503;")
s+='''
 const assertions=[]; const check=(name,pass,evidence)=>assertions.push({name,pass:!!pass,evidence});
 const text=async id=>await page.getByTestId(id).innerText();
 const header=async()=>({data:await text('scanner-header-data'),reader:await text('scanner-header-ruby'),trading:await text('scanner-header-trading'),readiness:await text('scanner-header-readiness')});
 const build=await page.evaluate(async()=>await (await fetch('/arx-scanner-qa-build-info.json')).json());
 await page.waitForFunction(async()=> (await window.__readFixtureLog()).requests.some(r=>r.path==='/api/market-scanner/selected-market'&&r.ended&&r.status===200));
 await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
 const first=await header();
 check('Unqualified clock cannot claim live data',!/^Data\\s+Live\\b/i.test(first.data),first.data);
 check('Unqualified clock cannot claim Full read',!first.reader.includes('Full read'),first.reader);
 check('Unqualified clock cannot claim Live-confirmed readiness',!first.readiness.includes('Live-confirmed'),first.readiness);
 check('Chart visibly discloses unqualified clock',(await text('chart-evidence-restrictions')).includes('UTC mapping unverified'),await text('chart-evidence-restrictions'));
 const read=page.getByTestId('ruby-chart-read');
 await page.getByTestId('ruby-chart-read-ask').click();
 await page.getByTestId('ruby-chart-read-ask').filter({hasText:'Re-read'}).waitFor();
 const unqualifiedRead=await read.innerText();
 check('Withheld setup caps the reader header',!(await text('scanner-header-ruby')).includes('Full read'),await text('scanner-header-ruby'));
 check('Restricted context retains source-clock limitation',/UTC mapping unverified/.test(unqualifiedRead),unqualifiedRead);
 check('Confidence is not presented as momentum',!/Momentum:\s*Read confidence/.test(unqualifiedRead),unqualifiedRead);
 await page.evaluate(async()=>await window.__fixtureSetClock(true));
 await page.reload(); await page.getByTestId('scanner-chart-panel').waitFor();
 await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.barCount>0);
 await page.waitForFunction(()=>document.querySelector('[data-testid="scanner-header-data"]')?.textContent.includes('Live'));
 await page.getByTestId('ruby-chart-read-ask').click();
 await page.getByTestId('ruby-chart-read-ask').filter({hasText:'Re-read'}).waitFor();
 const qualified=await header(), assessed=await read.innerText();
 check('Qualified current feed remains independent of blocked trading',/^Data\\s+Live\\b/i.test(qualified.data)&&qualified.trading.includes('Blocked'),qualified);
 check('Current-feed heading avoids an overall trade-health claim',/current feed/i.test(qualified.readiness),qualified.readiness);
 check('Qualified feed does not override withheld setup',!qualified.reader.includes('Full read'),qualified.reader);
 check('Actual nested trendline note appears with conditions',assessed.includes('Offline generated descending line is broken')&&assessed.includes('conditional')&&assessed.includes('context only'),assessed);
 check('Missing pattern/trendline placeholders do not discard supplied evidence',!assessed.includes('No specific trendline named')&&!assessed.includes('No specific chart pattern named'),assessed);
 check('Setup restriction does not promise feed confirmation will clear it',!assessed.includes('withheld until EURUSD'),assessed);
 for(const width of [1440,790,390]){
  await page.setViewportSize({width,height:1000});
  await page.getByTestId('scanner-header-strip').scrollIntoViewIfNeeded();
  const geometry=await page.getByTestId('scanner-header-strip').evaluate(el=>{const parent=el.getBoundingClientRect();return {parent:{left:parent.left,right:parent.right,width:parent.width},items:[...el.children].map(c=>{const r=c.getBoundingClientRect();return{left:r.left,right:r.right,top:r.top,width:r.width,client:c.clientWidth,scroll:c.scrollWidth,text:c.textContent};})};});
  check('Status cards contain their text at width '+width,geometry.items.every(c=>c.scroll<=c.client+1&&c.left>=geometry.parent.left-1&&c.right<=geometry.parent.right+1),geometry);
  const measureHeaders=async()=>await page.evaluate(()=>{const header=document.querySelector('header'),safety=document.querySelector('[aria-label="Trading safety status"]');if(!header||!safety)return null;const h=header.getBoundingClientRect(),s=safety.getBoundingClientRect();return{header:{top:h.top,bottom:h.bottom},safety:{top:s.top,bottom:s.bottom},scrollY};});
  const before=await measureHeaders();
  await page.getByTestId('arx-native-canvas').scrollIntoViewIfNeeded();
  const after=await measureHeaders();
  check('Topbar and safety header do not overlap after scrolling at '+width,after&&after.header.bottom<=after.safety.top+1,{before,after});
  await page.getByTestId('scanner-header-strip').scrollIntoViewIfNeeded();
  await page.screenshot({path:'/Users/areyouok/arx-tier1-release/scanner-screenshot-truth-20261101/'+build.buildId+'-width-'+width+'.png'});
 }
 const log=await page.evaluate(async()=>await window.__readFixtureLog());
 check('No page exception',log.errors.length===0,log.errors);
 check('No API or external request forwarded',log.blocked.filter(x=>x.kind==='external').length===0,log.blocked);
 return {build:{id:build.buildId,source:build.source,sourceUnchanged:build.sourceUnchanged},initial,assertions,pass:assertions.filter(x=>x.pass).length,fail:assertions.filter(x=>!x.pass).length,requests:log.requests,errors:log.errors,unknown:log.unknown,blocked:log.blocked,limitations:['Generated candles and mocked read, not screenshot source replay','No provider/model/broker APIs forwarded; no latency benchmark','Only screenshot-scope layout and evidence projection checked']};
}
'''
(root/'browser-acceptance.js').write_text(s)
