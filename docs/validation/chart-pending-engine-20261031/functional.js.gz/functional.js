async page=>{const SCANNER_QA_EXPECTED_COMMIT='db6cf42ff515a8be66ed802c6756c9ebd70c1a2a';return await (async page => {
 const report={passed:false,checks:[],failure:null};
 const check=(ok,label)=>{report.checks.push({label,pass:!!ok});if(!ok)throw Error(label);};
 try {
  report.build=await page.evaluate(async()=>fetch('/arx-scanner-qa-build-info.json').then(r=>r.json()));
  check(report.build.source.head===SCANNER_QA_EXPECTED_COMMIT&&report.build.sourceUnchanged&&!report.build.source.status,'Exact clean source build');
  for(const width of [1440,390]){
   await page.setViewportSize({width,height:width===390?844:1100});
   await page.evaluate(()=>window.__fixtureSwitchSource({source:'offline_fixture',identity:'synthetic-history-A'}));
   let release;const gate=new Promise(resolve=>{release=resolve;});const handler=async route=>{await gate;await route.fallback();};
   await page.route('**/api/chart/candles*',handler);
   try{
    await page.goto('http://127.0.0.1:4199/market-scanner');
    const panel=page.getByTestId('scanner-chart-panel');
    const tools=panel.getByRole('button',{name:'Chart tools',exact:true});
    if(width===390)await tools.waitFor({state:'visible'});
    if(await tools.isVisible()&&await tools.getAttribute('aria-expanded')!=='true')await tools.click();
    const studies=panel.getByRole('button',{name:'Studies (0)',exact:true});await studies.click();
    const search=panel.getByLabel('Search studies',{exact:true});await search.fill('Donchian');const input=await search.elementHandle();
    check((await page.evaluate(()=>window.__arxChartQa?.snapshot()))===null,width+' no empty engine while response is pending');
    release();await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.barCount===200);
    await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
    check(await input.evaluate(el=>el.isConnected&&el===document.activeElement&&el.value==='Donchian'),width+' same focused input and search survives initial binding');
    const location=await input.evaluate(el=>{const r=el.getBoundingClientRect(),at=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return {left:r.left,right:r.right,top:r.top,bottom:r.bottom,width:r.width,height:r.height,viewportWidth:innerWidth,viewportHeight:innerHeight,unobscured:at===el||el.contains(at)};});
    (report.fieldBounds??=[]).push({width,...location});
    check(location.width>0&&location.height>0&&location.left>=0&&location.right<=location.viewportWidth&&location.top>=0&&location.bottom<=location.viewportHeight&&location.unobscured,width+' focused search remains visible and unobscured');
    await page.screenshot({path:'/Users/areyouok/arx-tier1-release/chart-pending-engine-20261031/binding-final-'+width+'.png'});
    const observed=await page.evaluate(()=>({state:window.__arxChartQa.snapshot(),data:window.__arxChartQa.data()}));
    const log=await page.evaluate(()=>window.__readFixtureLog());const response=log.candleResponses.filter(r=>r.source==='offline_fixture'&&r.canonical.length===200).at(-1);
    check(response&&JSON.stringify(observed.data.canonical)===JSON.stringify(response.canonical)&&JSON.stringify(observed.data.display)===JSON.stringify(response.canonical),width+' full source candle equality');
    await page.evaluate(()=>window.__fixtureSwitchSource({source:'offline_replacement',identity:'synthetic-history-B'}));
    const details=panel.getByTestId('scanner-feed-details');
    if(await details.getAttribute('open')===null)await details.locator('summary').click();
    await panel.getByTestId('scanner-chart-reload').click();await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.feed?.source==='offline_replacement');
    check(await page.evaluate(id=>window.__arxChartQa.snapshot().adapterId===id,observed.state.adapterId),width+' retains engine across real source replacement');
    check(await input.evaluate(el=>!el.isConnected),width+' previous workbench reset on actual provider change');
    check(await panel.getByLabel('Search studies',{exact:true}).count()===0,width+' old study search closed');
    check(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),width+' no document overflow');
   }finally{release();await page.unroute('**/api/chart/candles*',handler);}
  }
  report.logs=await page.evaluate(()=>window.__readFixtureLog());check(report.logs.errors.length===0,'No page exceptions');report.passed=true;
 }catch(e){report.failure=String(e?.stack??e);}
 return report;
}
)(page);}