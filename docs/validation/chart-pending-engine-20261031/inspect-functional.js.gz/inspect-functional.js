async page => await page.evaluate(async()=>({state:window.__arxChartQa.snapshot(),data:window.__arxChartQa.data(),log:await window.__readFixtureLog()}))
