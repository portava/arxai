async page => {
 await page.waitForFunction(()=>window.__arxChartQa?.snapshot()?.barCount===200);
 return await page.evaluate(async()=>({metadata:await(await fetch('/arx-scanner-qa-build-info.json')).json(),timelinePresent:!!window.__arxCandleTimeline,profilePresent:!!window.__arxReactProfile,state:window.__arxChartQa.snapshot(),data:window.__arxChartQa.data(),network:await window.__readFixtureLog()}));
}