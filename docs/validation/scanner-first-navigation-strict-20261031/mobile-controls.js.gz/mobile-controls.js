async page => {
 const checks=[];const check=(ok,name)=>{checks.push({name,passed:!!ok});if(!ok)throw Error(name)};
 const capture=()=>page.evaluate(()=>({state:window.__arxChartQa.snapshot(),data:window.__arxChartQa.data()}));
 const before=await capture();
 await page.getByRole('button',{name:'Show status details',exact:true}).click();
 check(await page.getByRole('button',{name:'Hide status details',exact:true}).getAttribute('aria-expanded')==='true','Status details expands');
 check(await page.getByRole('button',{name:'Hide status details',exact:true}).evaluate(el=>el.getAttribute('aria-controls').split(' ').every(id=>{const target=document.getElementById(id);return target&&getComputedStyle(target).display!=='none'})),'Both described status sections visible');
 await page.getByRole('button',{name:'Hide status details',exact:true}).click();
 await page.getByTestId('scanner-feed-details').locator('summary').click();
 check(await page.getByTestId('scanner-feed-details').evaluate(el=>el.open),'Feed details expands');
 await page.getByTestId('scanner-feed-details').locator('summary').click();
 check(!await page.getByTestId('scanner-feed-details').evaluate(el=>el.open),'Feed details collapses');
 await page.getByRole('button',{name:'Fullscreen',exact:true}).click();
 check(await page.getByRole('button',{name:'Exit fullscreen',exact:true}).isVisible(),'Mobile fullscreen reachable');
 const full=await capture();check(full.state.adapterId===before.state.adapterId&&full.state.candlesId===before.state.candlesId,'Fullscreen preserves engine');
 check(JSON.stringify(full.data.canonical)===JSON.stringify(before.data.canonical),'Fullscreen preserves exact bars');
 await page.screenshot({path:'/Users/areyouok/arx-tier1-release/scanner-first-navigation-strict-20261031/mobile-fullscreen.png'});
 await page.getByRole('button',{name:'Exit fullscreen',exact:true}).click();
 const preZoom=await capture();
 await page.getByRole('button',{name:'Zoom in chart',exact:true}).click();
 await page.waitForFunction(width=>{const r=window.__arxChartQa.snapshot().range;return r.to-r.from<width-.01},preZoom.state.range.to-preZoom.state.range.from);
 const zoom=await capture();check(zoom.state.range.to-zoom.state.range.from<preZoom.state.range.to-preZoom.state.range.from,'Zoom changes actual logical range');
 await page.getByRole('button',{name:'Pan to earlier candles',exact:true}).click();
 await page.waitForFunction(from=>window.__arxChartQa.snapshot().range.from<from-.01,zoom.state.range.from);
 const pan=await capture();check(pan.state.range.from<zoom.state.range.from,'Pan changes actual logical range');
 check(JSON.stringify(pan.data.canonical)===JSON.stringify(before.data.canonical),'Controls preserve exact bars');
 return {checks,passed:checks.every(c=>c.passed)};
}
