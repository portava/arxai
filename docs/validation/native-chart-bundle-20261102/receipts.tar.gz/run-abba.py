import subprocess,os,signal,socket,time,json
from pathlib import Path
p=Path(__file__).parent;repo=Path('/Users/areyouok/arx-position-money-refresh-20261102')
runs=[('baseline-a1','4fde9067f94b0203','0090138ed5eb3dee1ead795d188d1261af2ec269'),('candidate-b1','5564ca657e004b35','9896274762b6ecde8906087a4e54a80aa199df7a'),('candidate-b2','5564ca657e004b35','9896274762b6ecde8906087a4e54a80aa199df7a'),('baseline-a2','4fde9067f94b0203','0090138ed5eb3dee1ead795d188d1261af2ec269')]
for label,build,head in runs:
 with socket.socket() as s:
  if s.connect_ex(('127.0.0.1',4199))==0:raise RuntimeError('Port already owned; do not replace')
 with (p/(label+'-server.log')).open('w') as f:
  server=subprocess.Popen(['python3','/tmp/arx-offline-run.py','node','scripts/scanner-qa/shared-chart-fixture/build.mjs','--serve='+build],cwd=repo,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   for _ in range(100):
    if server.poll() is not None:raise RuntimeError('Server exited')
    with socket.socket() as s:
     if s.connect_ex(('127.0.0.1',4199))==0:break
    time.sleep(.1)
   else:raise RuntimeError('Server not ready')
   code=subprocess.call(['python3',str(p/'run-navigation.py'),label,head],cwd=p)
   if code:raise RuntimeError('Navigation runner failed '+label)
  finally:
   os.killpg(server.pid,signal.SIGINT);server.wait(timeout=15)
print('All ABBA sessions closed',flush=True)
