from pathlib import Path
import sys,subprocess,json,datetime
raw=Path(__file__).parent;label,head=sys.argv[1:3];p=raw/label;p.mkdir(exist_ok=False)
cli='/Users/areyouok/.local/bin/playwright-cli';setup='/Users/areyouok/arx-position-money-refresh-20261102/scripts/scanner-qa/shared-chart-setup.js';old=Path('/Users/areyouok/arx-tier1-release/position-money-refresh-20261102')
for rate in [1,4]:
 driver=p/('navigation-'+str(rate)+'.js');driver.write_text((old/('first-navigation-'+str(rate)+'x.js')).read_text().replace('0090138ed5eb3dee1ead795d188d1261af2ec269',head))
 session='mount-nav-'+label+'-'+str(rate);name='navigation-'+str(rate)+'x'
 for suffix,args in [('open',['open','http://127.0.0.1:4199']),('setup',['run-code','--filename='+setup]),('run',['run-code','--filename='+str(driver)]),('close',['close'])]:
  with (p/(name+'-'+suffix+'.log')).open('w') as f:code=subprocess.call([cli,'-s='+session,*args],stdout=f,stderr=subprocess.STDOUT,cwd=p)
  s=(p/(name+'-'+suffix+'.log')).read_text();i=s.find('### Result\n')
  if i>=0 and suffix=='run':
   x=json.JSONDecoder().raw_decode(s[i+11:].lstrip())[0];x['outerRunner']={'orderLabel':label,'cpuThrottleRate':rate,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'diagnosticProfile':False};(p/(name+'.json')).write_text(json.dumps(x,indent=2));print(label,name,x.get('passed'),x.get('failure'),x.get('summary'),flush=True)
  if code or '### Error' in s:
   subprocess.call([cli,'-s='+session,'close'],stdout=subprocess.DEVNULL);raise SystemExit(name+' '+suffix+' failed '+str(code))
