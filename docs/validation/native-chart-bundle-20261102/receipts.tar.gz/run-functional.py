import subprocess,json
from pathlib import Path
p=Path(__file__).parent
cli='/Users/areyouok/.local/bin/playwright-cli'
root=Path('/Users/areyouok/arx-position-money-refresh-20261102/scripts/scanner-qa')
def run(name,args):
 with (p/(name+'.log')).open('w') as f: code=subprocess.call([cli,'-s=native-bundle-functional',*args],stdout=f,stderr=subprocess.STDOUT,cwd=p)
 s=(p/(name+'.log')).read_text();i=s.find('### Result\n')
 if i>=0:
  x=json.JSONDecoder().raw_decode(s[i+11:].lstrip())[0];(p/(name+'.json')).write_text(json.dumps(x,indent=2));print(name,'exit',code,'passed',x.get('passed'),'failure',x.get('failure'),flush=True)
 else: print(name,'exit',code,flush=True)
run('functional-open',['open','http://127.0.0.1:4199'])
run('final-consumers-setup',['run-code','--filename='+str(p/'consumer-setup.js')])
for name,driver in [('final-consumers','native-consumers-acceptance.js'),('final-clock-position','native-clock-position-acceptance.js')]:run(name,['run-code','--filename='+str(root/driver)])
run('final-pages-setup',['run-code','--filename='+str(p/'pages-setup.js')])
run('final-pages',['run-code','--filename='+str(root/'shared-chart-pages-acceptance.js')])
run('final-functional-close',['close'])
