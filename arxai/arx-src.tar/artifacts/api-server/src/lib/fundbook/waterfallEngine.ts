// ARX Fund Book — profit waterfall engine (Task #142).
//
// Pure, side-effect-free math for the 60/40 profit waterfall:
//  - computeWaterfallSplit: eligible net-new-profit-above-HWM and its 60/40 split.
//  - allocateInvestorDistributable: the investor 40% split pro-rata by units.
//
// SAFETY / DESIGN:
// - This module touches NO database, NO broker, NO execution path. It is pure
//   arithmetic so the economics are deterministic and unit-testable.
// - The 60/40 split is computed so the two shares sum EXACTLY to the eligible
//   profit (investorDistributable = eligible − arxInternalShare), avoiding any
//   penny drift between the two halves.
// - The crystallization high-water mark advances to the current net value ONLY
//   on a positive run (eligibleProfit > 0); otherwise it stays at the prior HWM.
//   Losses and runs at/below the HWM produce a $0 split and DO NOT advance it.

import { round2 } from "./navMath.js";

// The fund's profit-sharing economics: 60% ARX internal / 40% investor.
export const ARX_INTERNAL_SHARE_PCT = 60 as const;
export const INVESTOR_DISTRIBUTABLE_PCT = 40 as const;

export interface WaterfallSplitInput {
  // Net value at the run cutoff (settled + assigned floating overlay, or NAV).
  currentNetValue: number;
  // The crystallization high-water mark this run is measured against.
  priorHighWaterMark: number;
}

export interface WaterfallSplit {
  eligibleProfit: number;
  arxInternalShare: number;
  investorDistributable: number;
  highWaterValueBefore: number;
  highWaterValueAfter: number;
  isPositiveRun: boolean;
}

// eligibleProfit = max(0, currentNetValue − priorHWM). A loss or a value at/below
// the HWM yields 0 across the board and leaves the HWM unchanged.
export function computeWaterfallSplit(input: WaterfallSplitInput): WaterfallSplit {
  const before = round2(input.priorHighWaterMark);
  const current = round2(input.currentNetValue);
  const eligibleProfit = round2(Math.max(0, current - before));
  const isPositiveRun = eligibleProfit > 0;
  // Compute ARX first, then derive the investor share as the exact remainder so
  // the two halves always sum to eligibleProfit with no rounding drift.
  const arxInternalShare = round2(eligibleProfit * (ARX_INTERNAL_SHARE_PCT / 100));
  const investorDistributable = round2(eligibleProfit - arxInternalShare);
  return {
    eligibleProfit,
    arxInternalShare,
    investorDistributable,
    highWaterValueBefore: before,
    // Advance the crystallization watermark only on a positive run.
    highWaterValueAfter: isPositiveRun ? current : before,
    isPositiveRun,
  };
}

export interface InvestorOwnership {
  userId: number;
  units: number;
}

export interface InvestorAllocation {
  userId: number;
  units: number;
  ownershipFraction: number;
  distributableShare: number;
}

// Allocate the investor distributable strictly pro-rata by unit ownership at the
// cutoff. Each share is rounded to cents; any rounding remainder (so the sum
// equals the distributable exactly) is assigned to the largest holder. Holders
// with 0 units receive 0. When there are no units, nothing is allocated.
export function allocateInvestorDistributable(
  investorDistributable: number,
  holders: readonly InvestorOwnership[],
  totalUnits: number,
): InvestorAllocation[] {
  const distributable = round2(investorDistributable);
  const total = totalUnits > 0 ? totalUnits : 0;
  if (total <= 0 || distributable === 0 || holders.length === 0) {
    return holders.map((h) => ({
      userId: h.userId,
      units: h.units,
      ownershipFraction: total > 0 ? h.units / total : 0,
      distributableShare: 0,
    }));
  }

  const allocations: InvestorAllocation[] = holders.map((h) => {
    const ownershipFraction = h.units / total;
    return {
      userId: h.userId,
      units: h.units,
      ownershipFraction,
      distributableShare: round2(distributable * ownershipFraction),
    };
  });

  // Reconcile rounding so the sum of shares equals the distributable exactly.
  const allocatedSum = round2(
    allocations.reduce((acc, a) => acc + a.distributableShare, 0),
  );
  const remainder = round2(distributable - allocatedSum);
  if (remainder !== 0) {
    // Give the penny remainder to the holder with the most units (largest stake).
    let largestIdx = -1;
    let largestUnits = -Infinity;
    for (let i = 0; i < allocations.length; i++) {
      const a = allocations[i]!;
      if (a.units > largestUnits) {
        largestUnits = a.units;
        largestIdx = i;
      }
    }
    if (largestIdx >= 0) {
      const target = allocations[largestIdx]!;
      target.distributableShare = round2(target.distributableShare + remainder);
    }
  }

  return allocations;
}
